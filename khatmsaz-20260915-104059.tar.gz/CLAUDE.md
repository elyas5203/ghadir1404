# KhatmSaz — instructions for Claude Code

KhatmSaz (ختم‌ساز) is a Persian-first platform for organising group Khatms,
under the خدمتگزاران (Khedmatgozaran) brand. It is a **modular monolith**:
TypeScript, Node 24 LTS, NestJS API, Next.js web + admin, npm workspaces.

## Start every task like this

1. **Understand the task before editing anything.** Ask if the request is ambiguous.
2. **Read `docs/ai/PROJECT_STATE.md` first.** It is the fastest orientation file
   and its newest state is always at the top.
3. **Read only the additional docs your task needs** — not all of them:
   - architecture or module boundaries → `docs/ai/ARCHITECTURE.md`
   - domain concepts → `docs/ai/DOMAIN_MODEL.md`
   - schema/persistence → `docs/ai/DATABASE.md`
   - Telegram / Bale / SMS / payments / storage → `docs/ai/INTEGRATIONS.md`
   - why something is the way it is → `docs/ai/DECISIONS.md`
   - what is planned → `docs/ai/ROADMAP.md`
   - a recurring bug → `docs/ai/DEBUGGING.md`, `docs/ai/KNOWN_ISSUES.md`
   - security rules → `docs/ai/SECURITY.md`
   - test expectations → `docs/ai/TESTING.md`
4. Also read the matching file in `.claude/rules/`.

## Hard rules

- **Respect module boundaries.** Domain logic never imports a platform SDK.
  Telegram and Bale are adapters. `packages/contracts` holds shapes, not rules.
  Boundaries are enforced but not frozen — a boundary may change when the change
  is reviewed, tested, migrated and documented.
- **No large architectural change without explicit approval.** Adding a
  framework, a datastore, a queue, a new app, or restructuring modules requires
  the user to say yes first.
- **Never invent business requirements.** If a rule is not written down, ask.
  Do not guess pricing, limits, flows, wording, or entitlements.
- **Never expose secrets.** No tokens, keys or credentials in code, logs,
  error messages, tests, fixtures, or documentation. `.env` is never committed.
- **Never deploy to production**, and never run destructive commands against
  data you did not create.
- **Run validation before claiming completion** — see below. Never report a
  check as passing unless you actually ran it and saw it pass.

## Validation before you say "done"

```bash
npm run typecheck
npm run lint
npm run test
npm run build
```

If a check fails and the fix is outside your task's scope, say so plainly
rather than working around it.

## After a meaningful change

Update the project memory in the same task:

- `docs/ai/PROJECT_STATE.md` — refresh the current-state block at the top
- `docs/ai/CHANGELOG.md` — add a dated entry at the top
- `docs/ai/DECISIONS.md` — add a decision if you made one (never overwrite an
  old decision; mark it superseded and link the replacement)
- `docs/ai/ROADMAP.md` — mark items completed, never delete history
- `docs/ai/KNOWN_ISSUES.md` / `DEBUGGING.md` — only for real, recurring problems

History is preserved. Do not compact these files by deleting the past.

## End-of-task report (always produce this)

```
KHATMSAZ TASK REPORT
Task            — what was asked
Status          — PASS / PARTIAL / BLOCKED
What I Changed  — concise
Files Changed   — grouped by area
Commands Run    — command and result
Validation      — Build / Lint / Typecheck / Tests, each PASS / FAIL / NOT RUN + reason
Security        — what was checked, what was found
Docs Updated    — which docs/ai files
Decisions Added — decision IDs
Known Issues    — real unresolved items only
Next Step       — one short recommendation
```

Do not hide failures. Do not claim work you did not perform.
