---
description: Security rules that apply to every task.
---

# Security rules

- **Secrets never enter the repository.** No tokens, API keys, bot tokens,
  payment credentials, OTP secrets, private certificates — not in code, tests,
  fixtures, comments, documentation, or commit messages.
- `.env` is git-ignored. Only `.env.example` is tracked, and it contains
  placeholders that are safe to publish.
- Local container credentials (Postgres, MinIO) are **local-only placeholders**
  and are documented as such. They must not be reused anywhere shared.
- Development services bind to `127.0.0.1`. Do not publish a development port
  to `0.0.0.0` or to the LAN.
- CORS uses an explicit origin allow-list. `*` requires a written reason.
- No debug or diagnostic endpoint may return environment variables, config
  values, connection strings, or dependency inventories.
- **Never log** phone numbers, OTP codes, tokens, payment identifiers, or full
  request bodies.
- Creators must never be able to download an export containing participant phone
  numbers. Bulk export of sensitive data is reserved for authorised top-level
  administration and must be audited.
- Report dependency-audit findings honestly. Fix what is in scope; state the
  rest. Do not chase every transitive low-severity warning.
- Never deploy to production from Claude Code.
