---
description: Persian-first RTL UI conventions for the web and admin apps.
globs: apps/web/**,apps/admin/**,packages/ui/**
---

# Frontend and UI rules

## Non-negotiables

- **Persian-first.** All user-facing copy is Persian. `lang="fa"`, `dir="rtl"`.
- **True RTL**, not a mirrored LTR layout: use CSS logical properties
  (`margin-inline`, `padding-block`, `inline-size`, `inset-inline-start`).
  Do not use `left` / `right` / `margin-left` for layout.
- **Mobile-first.** Base styles target small screens; widen with `min-width`.
- Colours, spacing, radii and type come from the tokens in
  `@khatmsaz/ui/tokens.css`. Do not hard-code hex values in an app.
- Accessibility: visible focus, sufficient contrast, real landmarks and
  headings, `prefers-reduced-motion` respected.

## Copy

- Write production copy, never placeholder-speak. No "TODO", no "Lorem ipsum",
  no "Click here to test", no jokes, no developer shorthand.
- Short, calm, plain Persian. No exclamation marks.

## The hierarchy rule

Anything the user does not need for the current task must not be in front of
them.

- **Bot** — extremely simple and fast. The fewest possible steps.
- **Web app** — more capability, still extremely simple.
- **Admin** — powerful, clearly categorised, never visually chaotic.

## Brand

The final خدمتگزاران logo and brand assets have not been delivered. The current
green palette is an explicitly temporary placeholder. Do not copy assets from
any existing website.
