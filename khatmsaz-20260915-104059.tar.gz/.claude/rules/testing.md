---
description: What to test and how to report test results.
---

# Testing rules

- Every capability module ships with tests next to its source
  (`*.spec.ts`). API end-to-end tests live in `apps/api/test/*.e2e-spec.ts`.
- Test behaviour at the boundary — the contract a caller depends on — rather
  than internal implementation detail.
- A test must not require a network call, a real Telegram/Bale token, a payment
  gateway, or a live database. If it would, it belongs behind a fake.
- The repository must build and test with **every** integration variable empty.
- Run before claiming completion:
  ```bash
  npm run typecheck && npm run lint && npm run test && npm run build
  ```
- Report each check as PASS / FAIL / NOT RUN with a reason. Never report a check
  you did not run.
