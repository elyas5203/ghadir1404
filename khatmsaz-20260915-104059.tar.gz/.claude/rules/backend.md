---
description: NestJS API conventions.
globs: apps/api/**
---

# Backend rules (apps/api)

- NestJS module per capability: `src/<capability>/` containing the module,
  controller, service, and its tests. Keep controllers thin — they translate
  HTTP to a service call and back, nothing more.
- Response shapes are imported from `@khatmsaz/contracts`. If the shape does not
  exist there yet, add it there, not inline.
- Configuration is read through `@khatmsaz/config` helpers, never `process.env`
  scattered through modules.
- Never log secrets, tokens, phone numbers, or full request bodies.
- No endpoint may echo environment variables or configuration back to a caller.
  `/health` reports liveness only.
- CORS is an explicit allow-list from `API_CORS_ORIGINS`. Never `*`.
- The API binds to `127.0.0.1` by default. Changing that is a deliberate act.
- Database access, queues and scheduled work are **not implemented yet**. Do not
  add Prisma/TypeORM/BullMQ wiring without the phase that calls for it.
