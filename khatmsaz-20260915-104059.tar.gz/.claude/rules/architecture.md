---
description: Module boundaries and architectural constraints for KhatmSaz.
---

# Architecture rules

- KhatmSaz is a **modular monolith**. One deployable API, strongly isolated
  modules inside it. Modules are shaped so they *could* be extracted later —
  that is the point of the isolation, not a plan to extract them now.
- **Do not introduce** microservices, Kubernetes, Kafka, event sourcing, a CQRS
  framework, a service mesh, or a monorepo build system (Nx, Turborepo) without
  explicit approval. Prefer boring, stable, understandable technology.
- Dependency direction: `apps/*` → `packages/*`. Never the reverse.
  `packages/*` must not import from `apps/*`.
- `packages/shared` is framework-independent. No NestJS, no Next.js, no React,
  no database driver, no HTTP client.
- `packages/contracts` holds DTO / API / event **shapes** only. No business
  rules, no validation policy, no persistence concerns.
- `packages/ui` holds presentation primitives and design tokens. It never
  contains domain logic and never talks to the API.
- `packages/config` holds non-secret configuration helpers only.
- Platform integrations (Telegram, Bale, SMS, payment gateway, object storage)
  live behind **adapters**. Domain modules depend on an interface the domain
  owns; the adapter implements it. A domain module must never import a vendor
  SDK.
- The Khatm execution engine will be **generic** — driven by templates and
  configuration — rather than a separate hard-coded implementation per prayer
  type. Do not hard-code a new prayer type as its own subsystem.
- Node 24 LTS. Do not target Node 26 Current.
