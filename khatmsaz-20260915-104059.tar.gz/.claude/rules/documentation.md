---
description: How to maintain the docs/ai project memory.
globs: docs/ai/**
---

# Documentation maintenance rules

`docs/ai/` is long-term project memory for future sessions. Treat it as an
append-and-refresh log, not a scratch pad.

- **PROJECT_STATE.md** — newest current-state block always at the **top**:
  current phase, working state, done, in progress, blockers, commands known to
  work, next planned phase, recent changes. Older state stays below.
- **DECISIONS.md** — one entry per decision: ID, date, status, decision,
  reason, consequences. Never rewrite or delete a past decision. To replace one,
  mark it `Superseded by DEC-XXXX` and add the new entry.
- **CHANGELOG.md** — newest entry at the top, with date. Record meaningful code,
  config and documentation changes.
- **ROADMAP.md** — completed items are marked Completed and kept. Never delete
  them to shorten the file.
- **DEBUGGING.md** — only genuinely recurring or hard problems, with the proven
  fix. Not a log of ordinary command failures.
- **KNOWN_ISSUES.md** — separate Active, Workaround, Planned fix and Resolved.
  Resolved issues remain in the file so they stay traceable.
- Never write planned work as if it already exists. Documentation describes
  reality; ROADMAP describes intent.
