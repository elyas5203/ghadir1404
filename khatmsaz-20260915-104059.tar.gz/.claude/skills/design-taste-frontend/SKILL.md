---
name: design-taste-frontend
description: Anti-slop frontend skill for landing pages, portfolios, and redesigns. Enforces three tuning dials (VARIANCE/MOTION/DENSITY), pre-flight checklist, and rejects AI design tells. Use for web UI with high visual ambition.
metadata:
  author: leonxlnx
  version: "2.0"
---

# design-taste-frontend — Anti-Slop Frontend Skill

Source: https://github.com/Leonxlnx/taste-skill

## Section 0 — Brief Inference

Before designing, read the room:
1. Output a one-line design read: *"Reading this as: \<type> for \<audience>, with a \<vibe> language, leaning toward \<system/aesthetic>."*
2. Ask only one clarifying question if truly needed.
3. Reject AI defaults deliberately — name what you're avoiding and why.

## Section 1 — Three Dials

Set these before writing any code. Baseline: **8 / 6 / 4**

- `DESIGN_VARIANCE` (1-10): How far from standard patterns (1 = safe, 10 = experimental)
- `MOTION_INTENSITY` (1-10): Amount and complexity of animation (1 = static, 10 = cinematic)
- `VISUAL_DENSITY` (1-10): Information and element density (1 = spacious, 10 = dense)

Infer from brief signals. State the values explicitly before building.

## Section 2 — Design System Selection

When to use official packages: Fluent, Carbon, Material, Polaris, Primer, GOV.UK, USWDS, shadcn/ui, Radix Themes, Tailwind.
When to build custom: use honest aesthetic labeling.
**Hard rule: one design system per project. No mixing.**

## Section 3 — Default Architecture

- React/Next.js + Tailwind v4 + Motion (`motion/react`)
- `next/font` for font loading
- Phosphor Icons or HugeIcons (no hand-rolled SVG icons)
- `min-h-[100dvh]` for viewports
- CSS Grid over flex-math for layouts
- Verify all dependencies exist before referencing them

## Section 4 — Design Engineering Directives

### Typography
- Default fonts: Geist or Satoshi (not Inter, not Roboto)
- Max 2 typeface families, clearly distinct roles
- Check italic descender clearance before shipping
- Serif fonts: use sparingly, only with clear intent

### Color
- Max 1 accent color, used identically throughout
- **LILA RULE**: No AI-purple gradients unless brief explicitly calls for purple
- No beige + brass + oxblood palette for premium-consumer contexts (banned, rotate alternatives)
- Define dark mode tokens; test both modes before shipping

### Layout
- Hero must fit viewport: headline ≤ 2 lines, subtext ≤ 20 words AND ≤ 4 lines, CTA visible without scroll
- Hero top padding: max `pt-24`, no floating halfway down
- Eyebrow labels: max 1 per 3 sections (mechanical count in pre-flight)
- Zigzag (image+text alternating) cap: no 3+ consecutive zigzag layouts
- Navigation: one line at desktop, ≤ 80px height
- No duplicate CTA intent on same page

### Images
- Use gen-tool first, real photos second, explicit `<!-- TODO -->` placeholders third
- No fake screenshots (div-based)
- Logo walls: real SVG logos (Simple Icons / devicon) or generated marks, NOT plain text wordmarks

## Section 5 — Context-Aware Proactivity

- Glassmorphism: use only with restraint and clear purpose
- Magnetic physics: use for interactive hero elements, not navigation
- Perpetual micro-interactions: forbidden (they exhaust users)
- Marquee: max one per page
- Motion must be motivated — every animation needs a one-sentence justification
- GSAP sticky-stack and horizontal-pan: use canonical skeletons
- **Forbidden patterns**: `window.addEventListener('scroll')` (use IntersectionObserver, CSS scroll-driven, or Motion/ScrollTrigger), decorative status dots without real semantic state

## Section 6 — Performance & Accessibility

- Hardware acceleration: animate only `transform` and `opacity`
- `prefers-reduced-motion`: mandatory for `MOTION_INTENSITY > 3`
- Dark mode by default (Tailwind `dark:` variants or CSS variables)
- Core Web Vitals targets: LCP < 2.5s, CLS < 0.1, FID < 100ms
- DOM cost awareness: avoid deeply nested animation trees
- Z-index restraint: define a z-index scale, don't scatter magic numbers

## Section 9 — AI Tells (Forbidden)

These patterns mark output as AI-generated. Never use them unless the brief explicitly demands one:

- Warm cream background (#F4F1EA range) + terracotta accent (#D97757 range)
- AI-purple gradient overlays (LILA RULE)
- Three equal-sized feature cards in a row → use 2-col zig-zag, asymmetric grid, or scroll-pinned
- ALL-CAPS eyebrow labels on every section
- Meta strings joined with middle dots `A · B · C` as a default
- `WORD — fragment` labels with spaced em dash
- `→` appended to every link and button
- Tinted near-black (#0B0B0B, #111) everywhere instead of real black
- Monospace face on every data label
- **EM-DASH BAN (non-negotiable)**: em-dash (`—`) is completely forbidden everywhere — headlines, eyebrows, body, quotes, captions, buttons, alt text. Zero allowance. This is the #1 LLM signature Tell.
- Centered hero with dark mesh background as default → use asymmetric split, editorial manifesto, or kinetic type

## Section 10 — Reference Vocabulary

Pattern names to reach for contextually:
- Asymmetric Split Hero, Editorial Manifesto Hero, Kinetic Type Hero
- Bento Grid, Asymmetric Bento, Z-Axis Cascade
- Sticky-Stack Sections, Horizontal Pan Gallery
- Scroll-Pinned Feature Reveal, Parallax Depth Layer
- Editorial Split Layout, Magazine Spread
- Comparison Slider, Before/After Reveal
- Morphing Feedback Button, Hold-to-Delete
- Staggered List Entrance, Viewport-Triggered Reveal

## Section 14 — Pre-Flight Checklist (Non-Optional)

Every box must be ticked before output is done. Single failure = page is incomplete.

- [ ] Brief inferred, one-line design read stated
- [ ] Three dials set explicitly (VARIANCE / MOTION / DENSITY)
- [ ] Design system selected, one system only
- [ ] Theme lock: one light/dark/auto theme for entire page, no mid-scroll inversions
- [ ] Color lock: one accent color used identically throughout
- [ ] Shape lock: one corner-radius system applied consistently
- [ ] Zero em-dashes anywhere (non-negotiable)
- [ ] No AI-purple gradients (unless brief explicit)
- [ ] No beige+brass+oxblood premium-consumer palette (unless brand-explicit)
- [ ] No three equal feature cards in a row
- [ ] No eyebrow on every section (count ≤ ceil(sectionCount / 3))
- [ ] No zigzag cap violation (≤ 2 consecutive image+text-split layouts)
- [ ] No duplicate CTA intent
- [ ] Hero fits viewport (headline ≤ 2 lines, subtext ≤ 20 words/4 lines, CTA visible)
- [ ] Hero top padding ≤ pt-24
- [ ] Button contrast: WCAG AA 4.5:1 minimum, no white-on-white
- [ ] CTA labels don't wrap at desktop
- [ ] Form contrast: inputs, placeholders, labels, focus rings pass WCAG AA
- [ ] Logo walls: real SVGs or generated marks (not plain text)
- [ ] Bento: exact cell count (N items = N cells), ≥ 2-3 cells with real visual variation
- [ ] Images: real or explicit `<!-- TODO -->` (no fake screenshots)
- [ ] Every animation justified in one sentence
- [ ] Marquee: max one per page
- [ ] Navigation: one line at desktop, ≤ 80px height
- [ ] Reduced motion: every animation with MOTION_INTENSITY > 3 honors `prefers-reduced-motion`
- [ ] Dark mode: tokens defined, tested in both modes
- [ ] Core Web Vitals: plausible targets met
- [ ] No `window.addEventListener('scroll')` (use IntersectionObserver/ScrollTrigger/CSS scroll-driven)

## Out of Scope

This skill is NOT for: dashboards, data tables, multi-step forms, code editors, native mobile, realtime collaborative UIs.
