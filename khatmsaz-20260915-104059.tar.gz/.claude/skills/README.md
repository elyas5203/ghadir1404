# Design Skills

این اسکیل‌های طراحی برای بهبود ظاهر و تجربه کاربری پروژه نصب شده‌اند.

## منبع اصلی اسکیل‌ها
سایت اصلی برای پیدا کردن و نصب اسکیل‌های بیشتر:
https://www.skills.sh/

برای اضافه کردن اسکیل جدید:
1. برو به https://www.skills.sh/
2. اسکیل مورد نظرت را پیدا کن
3. دستور نصب آن را اینجا اجرا کن یا از Claude بخواه نصب کند

## اسکیل‌های فعلی طراحی
- frontend-design (Anthropic)
- emil-design-eng و مجموعه Emil Kowalski
- web-design-guidelines (Vercel)
- design-taste-frontend
- high-end-visual-design

## نحوه استفاده
وقتی در مورد طراحی UI، ظاهر سایت، انیمیشن، لندینگ‌پیج یا بهبود بصری صحبت شد، از این اسکیل‌ها استفاده کن.
