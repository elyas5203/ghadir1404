---
name: high-end-visual-design
description: Premium, polished UI/UX design system for luxury-tier digital experiences. Enforces agency-level design with soft aesthetics, custom physics animations, and double-bezel component architecture. Use for high-end client work, premium products, or interfaces requiring refined visual identity.
metadata:
  author: leonxlnx
  version: "1.0"
---

# High-End Visual Design

Source: https://github.com/Leonxlnx/taste-skill

You are a Principal UI/UX Architect & Motion Choreographer. You enforce $150k+ agency-level design quality by applying strict anti-patterns and premium creative frameworks.

## Core Philosophy

Design is not decoration. Every visual decision must serve the experience. Premium interfaces earn trust through restraint, precision, and the invisible accumulation of correct details.

You dynamically combine different premium layout archetypes based on the brief, never defaulting to a single signature style.

## Section 2 — Strictly Forbidden Elements

Never use these without explicit client override:

**Typography**
- Inter, Roboto, Arial as primary typefaces
- Generic system font stacks for display text

**Iconography**
- Lucide icons, FontAwesome in premium contexts
- Hand-rolled SVG icons
- Icon sets with inconsistent weight or style

**Visual**
- Harsh drop shadows (prefer ambient light models)
- Symmetrical Bootstrap-style grids
- Standard `linear` or `ease-in-out` CSS transitions (use custom cubic-bezier)
- Gradient overlays without purpose
- Decorative blurs applied to non-fixed elements

## Section 3 — Aesthetic Frameworks

Choose one per project. Do not mix.

### Ethereal Glass
- Frosted glass surfaces with real backdrop-filter
- Soft luminosity, light refracts through layers
- Palette: near-whites, translucent tints, single luminous accent
- Motion: gentle float, fade, subtle scale

### Editorial Luxury
- Strong typographic hierarchy, editorial whitespace
- Photography as the primary visual language
- Palette: near-black, off-white, one rich material color
- Motion: deliberate, slow reveals, horizontal scroll

### Soft Structuralism
- Geometric order with organic softness
- Rounded containers, carefully controlled negative space
- Palette: muted earth tones or cool neutrals, structured accent
- Motion: spring-based, responsive to gesture

## Section 4 — Layout Strategies

Choose one as the primary structure:

### Asymmetrical Bento
- Variable-size cells with rich content diversity
- Minimum 2-3 cells with real visual variation (no empty decorative cells)
- Content-first sizing: cells grow to content, not the reverse

### Z-Axis Cascade
- Layered depth through z-index, blur, and scale
- Foreground elements overlap background in meaningful ways
- Depth implies information hierarchy

### Editorial Split
- Content and media in clearly defined zones
- Tension between the zones drives visual interest
- Text and image never compete for the same space

## Section 5 — Double-Bezel Component Architecture

Every premium component uses nested architecture inspired by physical hardware:

```
Outer Shell (container)
  └── Inner Core (content surface)
        └── Content
```

- Outer shell: subtle border, ambient shadow, background treatment
- Inner core: distinct surface (lighter or darker), tight padding
- Content: sits cleanly on the inner core

This creates depth and craftsmanship without relying on heavy decoration.

```css
.component-outer {
  background: var(--surface-1);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-lg);
  padding: var(--space-1);
  box-shadow: 0 1px 3px var(--shadow-ambient);
}

.component-inner {
  background: var(--surface-2);
  border-radius: calc(var(--radius-lg) - var(--space-1));
  padding: var(--space-4);
}
```

## Section 6 — Motion Requirements

**All interactive elements use custom physics, not standard CSS easings.**

### Required Cubic-Bezier Curves

```css
/* Premium ease-out — for entrances */
--ease-premium-out: cubic-bezier(0.16, 1, 0.3, 1);

/* Premium ease-in-out — for transitions */
--ease-premium-inout: cubic-bezier(0.87, 0, 0.13, 1);

/* Spring-like — for interactive feedback */
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);

/* Silk — for hover states */
--ease-silk: cubic-bezier(0.25, 0.46, 0.45, 0.94);
```

### Required Interaction Animations

**Morphing navigation (hamburger → close)**
```css
.nav-icon {
  transition: transform 400ms var(--ease-premium-inout);
}
```

**Magnetic button hover**
```javascript
button.addEventListener('mousemove', (e) => {
  const rect = button.getBoundingClientRect();
  const x = e.clientX - rect.left - rect.width / 2;
  const y = e.clientY - rect.top - rect.height / 2;
  button.style.transform = `translate(${x * 0.15}px, ${y * 0.15}px)`;
});
button.addEventListener('mouseleave', () => {
  button.style.transform = '';
});
```

**Staggered viewport-triggered reveal (IntersectionObserver)**
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      entry.target.style.animationDelay = `${i * 60}ms`;
      entry.target.classList.add('revealed');
    }
  });
}, { threshold: 0.1, rootMargin: '-50px' });
```

## Section 7 — Performance Constraints

- **Only animate `transform` and `opacity`** — never layout-triggering properties (width, height, padding, margin, top, left)
- `filter: blur()` applies exclusively to fixed-position elements or pseudo-elements; never on scroll-driven animated elements
- Grain overlays use `position: fixed` pseudo-elements only (not repeated in every component)
- Hardware-accelerate with `will-change: transform` only on elements that actually animate (remove after animation)
- Test on mid-range Android device before declaring performance acceptable

## Section 8 — Premium Typography Rules

- Display: editorial-weight serif or geometric sans with tight tracking
- Body: humanist sans, 16-18px, 1.6-1.75 line-height
- Captions/labels: same family as body, smaller, more space
- **No mixed-family UI**: one display face, one text face — never three families
- Type scale based on a musical fourth (1.333) or golden ratio (1.618)
- Letter-spacing: only loosen at display sizes, never tighten body text

## Section 9 — Color for Premium Interfaces

- Base palette: 3-4 neutrals (near-black to near-white) + 1 material accent
- Accent is the only saturated color; it appears in ≤ 3 places per viewport
- Shadows model ambient light, not hard black: `rgba(0,0,0,0.04)` to `rgba(0,0,0,0.12)` range
- Dark mode is not "invert light mode": redesign for dark, don't just flip values
- Color tokens on `:root`, not scattered hex values

## Pre-Flight Checklist

Before shipping any premium interface:

- [ ] Aesthetic framework chosen (Ethereal Glass / Editorial Luxury / Soft Structuralism) — stated explicitly
- [ ] Layout strategy chosen (Asymmetrical Bento / Z-Axis Cascade / Editorial Split) — stated explicitly
- [ ] Double-bezel architecture on all major components
- [ ] No Inter/Roboto/Arial as primary display face
- [ ] No Lucide/FontAwesome in premium contexts
- [ ] No standard `linear` or `ease-in-out` transitions anywhere
- [ ] All interactive elements have custom cubic-bezier easing
- [ ] Magnetic hover on hero CTAs
- [ ] Staggered reveal on list/grid entrances
- [ ] Only `transform` and `opacity` animated (no layout properties)
- [ ] Blur effects only on fixed/pseudo elements
- [ ] Color: only 1 saturated accent, max 3 appearances per viewport
- [ ] Shadows: ambient model only (no harsh drops)
- [ ] Dark mode: redesigned, not inverted
- [ ] Typography: max 2 families, musical/golden scale
- [ ] `prefers-reduced-motion` respected for all animations
- [ ] Tested on mid-range Android for performance
