---
name: frontend-quality-gate
description: Review a frontend change for internationalization, true RTL, mobile-first layout, design-token usage, and accessibility before it lands. Use when editing UI components, pages, or styles. Especially relevant for right-to-left, Persian/Arabic, or multilingual interfaces.
---

# Frontend quality gate

A checklist for UI changes. Read the project's frontend rules first
(`.claude/rules/frontend.md` if present) — they override these defaults.

## Checklist

1. **Language & direction.** Correct `lang` and `dir` on the document. For RTL
   locales the layout is genuinely mirrored, not an LTR layout pushed right.
2. **Logical CSS only.** Use logical properties — `margin-inline`,
   `padding-block`, `inset-inline-start`, `inline-size` — not physical `left` /
   `right` / `margin-left` for layout. This is what makes one stylesheet serve
   both directions.
3. **Mobile-first.** Base styles target small screens; widen with `min-width`
   media queries.
4. **Design tokens.** Colours, spacing, radii, and type come from the shared
   token layer. No hard-coded hex values in an app.
5. **Accessibility.** Visible focus, sufficient contrast, real landmarks and
   heading order, labelled controls, `prefers-reduced-motion` respected.
6. **Copy.** Production wording in the product's language — no placeholder text,
   no "TODO"/"Lorem ipsum", calm and plain.

## How to respond

Flag each miss with the file and a concrete fix. Prefer the smallest change that
satisfies the rule. Do not redesign beyond the task.
