---
name: debugging-librarian
description: Record a genuinely recurring or hard-won bug fix so it is not rediscovered later. Use after diagnosing a non-obvious problem with a proven fix. Writes to docs/ai/DEBUGGING.md and KNOWN_ISSUES.md; keeps history and separates active from resolved.
---

# Debugging librarian

Capture only **recurring or hard** problems with a **proven** fix. Not a log of
ordinary command failures.

## Where it goes

- **`docs/ai/DEBUGGING.md`** — the reproducible problem and its proven fix.
  Include: symptom, root cause, the fix that worked, and how to confirm it.
- **`docs/ai/KNOWN_ISSUES.md`** — if still unresolved or worked-around. Keep the
  stable sections: Active, then Resolved. Move an item to Resolved with a date
  and the actual solution; never delete it.

## Rules

- One clear entry per problem, with a short id if the file uses them.
- Prefer the smallest reproduction and the exact fix over a narrative.
- Do not record secrets or environment-specific tokens.
- If it happened once and is understood, it may not belong here — reserve this
  for things a future session would otherwise waste time rediscovering.
