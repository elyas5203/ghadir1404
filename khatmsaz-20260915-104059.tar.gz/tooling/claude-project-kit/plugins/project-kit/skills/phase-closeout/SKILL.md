---
name: phase-closeout
description: Close out a development phase cleanly. Use when a phase or milestone is finished and needs sign-off. Runs the validation gate, updates project memory, checks security, and produces a structured phase report. Only marks a phase complete when its gate genuinely passed.
---

# Phase closeout

A checklist to finish a phase honestly. Chain the focused skills rather than
duplicating them.

## Steps

1. **Validate.** Run `test-gate` (typecheck, lint, tests, build). Record real
   results. If any mandatory check fails, the phase is not complete.
2. **Security.** Run `security-check`. Resolve in-scope findings; document the
   rest.
3. **Memory.** Run `project-memory-maintainer` to refresh
   `docs/ai/PROJECT_STATE.md` (newest block on top) and `CHANGELOG.md`.
4. **Roadmap.** Run `roadmap-maintainer` — mark the phase Completed only if the
   gate passed, else PARTIAL with the reason.
5. **Decisions.** If a durable decision was made, run `decision-recorder`.
6. **Known issues.** Update `docs/ai/KNOWN_ISSUES.md`: mark items Resolved with a
   date only when truly resolved; add any genuine new issues. Preserve history.

## Phase report

End with a structured report: Phase, Status (PASS/PARTIAL/BLOCKED), what changed,
files changed, commands run and results, validation (each PASS/FAIL/NOT RUN),
security findings, docs updated, decisions added, known issues, next step.

## Rules

- Do not hide failures or claim work not performed.
- Do not mark a phase complete on an unmet gate.
