---
name: decision-recorder
description: Record a durable architectural or product decision as an ADR entry in docs/ai/DECISIONS.md. Use when a choice was made that future sessions must not silently reverse. Never rewrites or deletes a past decision; supersedes by linking.
---

# Decision recorder

`docs/ai/DECISIONS.md` is an immutable ledger. One entry per decision.

## Entry format

```
### DEC-XXXX — <short title>
- Date: <absolute date>
- Status: Accepted | Superseded by DEC-YYYY
- Decision: <what was decided, in one or two sentences>
- Reason: <why; the forces and alternatives considered>
- Consequences: <what this commits us to, and what it rules out>
```

Use the next free `DEC-XXXX` id (check the highest existing id first).

## Rules

- Never edit or delete a past decision. To replace one, set the old entry's
  status to `Superseded by DEC-YYYY` and add the new entry — keep both.
- Only record **durable** decisions (architecture, boundaries, data model,
  security posture, product rules). A routine dependency bump or config tweak
  belongs in CHANGELOG.md, not here.
- Do not invent a decision to have something to write. If nothing durable was
  decided, record nothing.
