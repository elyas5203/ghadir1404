---
name: project-memory-maintainer
description: Refresh long-term project memory in docs/ai after a meaningful change. Use when code, config, or architecture changed and PROJECT_STATE.md / CHANGELOG.md must be brought back in sync with reality. Keeps newest state on top and never deletes history.
---

# Project memory maintainer

Keep `docs/ai/` describing **reality**, as an append-and-refresh log — never a
scratch pad. Do this in the SAME task as the change, not later.

## What to update

1. **`docs/ai/PROJECT_STATE.md`** — the single source of current truth.
   - Add or refresh the **newest state block at the very top**. Older blocks stay
     below under a History heading. Never edit an old block in place.
   - Cover: current phase, working state, done, in progress, blockers, commands
     known to work, next planned phase, notable recent changes.
   - Convert relative dates to absolute (e.g. write the real calendar date).

2. **`docs/ai/CHANGELOG.md`** — newest dated entry at the **top**. Record
   meaningful code, config and documentation changes. Group by area.

## Rules

- Newest on top; history preserved below. Do NOT compact files by deleting the
  past — traceability is the point.
- Describe only what is real now. Planned work belongs in ROADMAP, not here.
- Never write secrets, tokens, phone numbers, or credentials into memory.
- If a decision was made, also run `decision-recorder`. If the roadmap moved, run
  `roadmap-maintainer`. Do not duplicate the full content of those files here.

## Quick check before finishing

- Does PROJECT_STATE.md's top block match `git status` / the actual build state?
- Is there a CHANGELOG entry with today's date?
- Did you avoid deleting any prior state or changelog history?
