---
name: security-check
description: Run a practical repository security review before a commit or release. Use to check for staged secrets, exposed config, unsafe CORS, public dev services, and dependency vulnerabilities. Reports findings honestly rather than chasing every low-severity transitive warning.
---

# Security check

A fast, practical review. Report findings; fix what is in scope; state the rest.

## Checklist

1. **Secrets never in the repo.**
   - `.env` and `.env.*` are git-ignored (only `.env.example` tracked). Confirm
     with `git check-ignore .env` and that `git ls-files` does not list `.env`.
   - No token/key/credential in tracked source, tests, fixtures, comments, or
     docs. Scan for private-key headers and provider key prefixes.
   - `node_modules/`, build output, caches, and runtime data are not tracked.
2. **Network exposure.** Dev services bind to loopback; no dev port published to
   `0.0.0.0`/LAN. CORS is an explicit allow-list, never `*` without a written
   reason.
3. **Endpoint hygiene.** No health/debug endpoint returns environment values,
   config, connection strings, or a dependency inventory.
4. **Logging.** No phone numbers, OTP codes, tokens, payment ids, or full
   request bodies are logged.
5. **Dependency audit.** Run `npm audit` (and `npm audit --omit=dev` for the
   runtime surface). Explain criticals/highs; do not burn time on irrelevant
   low-severity transitive warnings.

## Reporting

List each check PASS/FAIL with evidence. Never claim a check passed without
running it. Record the outcome in `docs/ai/SECURITY.md` when closing a phase.
