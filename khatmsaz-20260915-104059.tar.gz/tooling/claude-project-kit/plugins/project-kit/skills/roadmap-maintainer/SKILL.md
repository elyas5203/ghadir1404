---
name: roadmap-maintainer
description: Update the project roadmap when work is planned, started, or completed. Use when a phase or milestone changes status. Marks items Completed and keeps them forever; never deletes history to shorten the file.
---

# Roadmap maintainer

`docs/ai/ROADMAP.md` describes **intent and progress**. Reality lives in
PROJECT_STATE.md and CHANGELOG.md — keep the two in sync but distinct.

## How to edit

- Mark items **Completed** with the real date; keep them in place forever.
- Move status only when it genuinely changed: Planned → In progress → Completed
  (or PARTIAL when a gate did not fully pass).
- Add new phases/items at the correct place; do not renumber or remove old ones.
- A phase is **Completed** only when its acceptance gate actually passed. If a
  mandatory check did not pass, mark it **PARTIAL** and say why.

## Rules

- Never delete a completed item to shorten the file — history is required.
- Never describe planned work as if it already exists.
- Keep phase language consistent with PROJECT_STATE.md's "next planned phase".
