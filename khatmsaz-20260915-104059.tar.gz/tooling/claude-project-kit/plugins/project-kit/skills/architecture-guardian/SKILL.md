---
name: architecture-guardian
description: Check a change against the project's architectural boundaries before it lands. Use when adding a dependency, an import across module/package lines, a new framework/datastore/queue, or a new top-level module. Flags boundary violations and large architectural changes that need explicit approval.
---

# Architecture guardian

Guard the module boundaries recorded in the project's architecture docs
(`docs/ai/ARCHITECTURE.md`, `docs/ai/DECISIONS.md`, `.claude/rules/`). Read them
first; they are the source of truth for this repo.

## What to flag

1. **Dependency direction.** Apps may depend on shared packages; packages must
   not depend on apps. Framework-independent packages must not import a
   framework, a database driver, or an HTTP client.
2. **Contract vs rules.** Contract/DTO packages hold shapes only — no business
   rules, no validation policy, no persistence concerns.
3. **Adapters.** Domain/business modules must not import a vendor SDK directly
   (messaging, SMS, payment, storage). They depend on an interface the domain
   owns; an adapter implements it.
4. **Large architectural change.** Adding a framework, datastore, queue, new
   app, or restructuring modules needs explicit human approval first. Do not
   introduce microservices/Kubernetes/Kafka/CQRS/monorepo-build-systems on your
   own initiative.

## How to respond

- If a change crosses a boundary, stop and surface it: name the rule, the file,
  and a compliant alternative.
- A boundary may still change when the change is reviewed, tested, migrated and
  documented — but that is a human decision, not a silent one.
- Never weaken a boundary just to make an import compile.
