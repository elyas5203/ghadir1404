---
name: test-gate
description: Run the project validation gate (typecheck, lint, tests, build) and report each as PASS/FAIL/NOT RUN with evidence. Use before claiming work is done or closing a phase. Never reports a check as passing without running it.
---

# Test gate

Run the gate and report honestly. Never mark a check PASS unless you ran it and
saw it pass.

## Commands (Node/npm monorepo default)

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

Adapt to the project's real scripts if they differ (check `package.json`). If a
project uses a different toolchain, run its equivalent gate.

## Reporting

Report each as **PASS / FAIL / NOT RUN** with a one-line reason. On FAIL, show
the failing output, do not summarise it away.

## Rules

- Do NOT make a check pass by weakening it: no silencing TypeScript with `any`,
  no disabling a lint rule to go green, no deleting or skipping a failing test,
  no weakening assertions.
- If a failure is real but out of the current task's scope, say so plainly
  rather than working around it.
- The suite must pass with every optional integration environment variable
  empty; a test must never require the network, a live database, or a real
  third-party credential.
