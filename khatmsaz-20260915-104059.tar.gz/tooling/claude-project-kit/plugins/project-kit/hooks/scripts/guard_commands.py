#!/usr/bin/env python3
"""PreToolUse guard: refuse clearly catastrophic shell commands.

Reads the hook JSON payload on stdin, inspects the Bash command, and blocks
(exit code 2, reason on stderr) only for unambiguously destructive patterns, so
legitimate work is never in the way. Deterministic, offline, no side effects.
"""
import sys
import re
import json

# (regex, human reason). Kept deliberately narrow — only unambiguous danger.
RULES = [
    (r"(curl|wget)\b[^|]*\|\s*(sudo\s+)?(ba)?sh\b",
     "piping a downloaded script straight into a shell is unsafe."),
    (r"\brm\s+(-[a-zA-Z]*\s+)*-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+(-[-a-zA-Z]+\s+)*(/|/\*|~|~/|\$HOME|/home|/etc|/usr|/var|/boot)(\s|/|\*|$)",
     "recursive force-delete of a system or home root."),
    (r"\brm\s+(-[a-zA-Z]*\s+)*-[a-zA-Z]*f[a-zA-Z]*r[a-zA-Z]*\s+(-[-a-zA-Z]+\s+)*(/|/\*|~|~/|\$HOME|/home|/etc|/usr|/var|/boot)(\s|/|\*|$)",
     "recursive force-delete of a system or home root."),
    (r"\bmkfs\b", "creating a filesystem (mkfs) destroys existing data."),
    (r":\(\)\s*\{\s*:\s*\|", "fork bomb."),
    (r"\bdd\b[^\n]*\bof=/dev/", "writing directly to a device with dd."),
    (r"\bchmod\s+-R\s+[0-7]{3}\s+/(\s|$)", "recursive permission change on /."),
    (r">\s*/dev/sd[a-z]", "writing to a raw disk device."),
]


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except Exception:
        return 0

    cmd = (data.get("tool_input") or {}).get("command") or ""
    if not cmd:
        return 0

    for pattern, reason in RULES:
        if re.search(pattern, cmd):
            sys.stderr.write(
                "BLOCKED by project-kit guard-commands: {}\nRefusing to run: {}\n".format(
                    reason, cmd
                )
            )
            return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
