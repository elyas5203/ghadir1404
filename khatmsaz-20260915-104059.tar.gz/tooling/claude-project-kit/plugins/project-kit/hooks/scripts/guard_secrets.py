#!/usr/bin/env python3
"""PreToolUse guard: refuse to write secret/credential files into the repo.

Reads the hook JSON payload on stdin, inspects the target path, and blocks
(exit code 2, reason on stderr) when the path looks like a secret. Allows
`*.example` template files. Deterministic, offline, no side effects.
"""
import sys
import os
import re
import json


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except Exception:
        # If we cannot parse the payload, do not get in the way.
        return 0

    tool_input = data.get("tool_input") or {}
    path = tool_input.get("file_path") or tool_input.get("path") or ""
    if not path:
        return 0

    base = os.path.basename(path)

    # Always allow example/template files (safe to commit).
    if base.endswith(".example") or ".env.example" in base:
        return 0

    secret_name_patterns = [
        r"^\.env(\..+)?$",              # .env, .env.local, .env.production, ...
        r".*\.(pem|key|p12|pfx)$",      # private keys / certificates bundles
        r".*\.(secret|token)$",         # explicit secret material
        r"^credentials.*\.json$",       # cloud credentials
        r"^service-account.*\.json$",   # service-account keys
    ]

    in_secret_dir = re.search(r"(^|/)secrets?/", path) is not None
    name_hit = any(re.match(p, base) for p in secret_name_patterns)

    if in_secret_dir or name_hit:
        sys.stderr.write(
            "BLOCKED by project-kit guard-secrets: '{}' looks like a secret or "
            "credential file. Secrets must never be written into the repository. "
            "Use an .env.example with placeholders, or handle this file outside "
            "Claude Code.\n".format(path)
        )
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
