# Security audit — claude-project-kit

Assessment of every plugin this kit activates or offers, plus the kit's own
components. Date: 2026-09-05. Reviewer: automated setup session, sources
inspected directly from the cloned marketplace and official docs.

## Trust model

- **Active plugins are first-party** (Anthropic, `anthropics/claude-plugins-official`)
  or **authored in this repo** (`project-kit`). No community/third-party plugin
  is enabled by default.
- No active component executes downloaded code, opens a network connection, or
  requests secrets. The one optional networked plugin (`context7`) is called out
  explicitly and left disabled.
- Everything is installed at **project scope**; the only user-level change is the
  official marketplace registration (a pointer) and, for the LSP, a user-level
  npm global prefix (`~/.local`, no sudo).

## Active plugins

| Plugin | Owner | Source | Executes code? | Network? | Secrets? | Notes |
|--------|-------|--------|----------------|----------|----------|-------|
| typescript-lsp | Anthropic | official marketplace | runs `typescript-language-server` (out-of-process, local) | no | no | Needs the LSP binary on PATH. Standard, widely used. |
| security-guidance | Anthropic (David Dworken) | official | runs local python hooks | no | no | 4 hooks: SessionStart/UserPromptSubmit/PostToolUse/Stop. Stop/commit hooks run an LLM diff review — local, but adds per-stop work; can be disabled if slow. |
| frontend-design | Anthropic | official | no | no | no | Skill (guidance only). |
| commit-commands | Anthropic | official | runs git via the session | no | no | Git commit/push/PR helper skills. |
| skill-creator | Anthropic | official | no | no | no | Skill authoring + evals. |
| feature-dev | Anthropic | official | no | no | no | 3 read/review agents + 1 skill. |
| project-kit | this repo | local dir | python hooks (local) | no | no | See below. |

## The kit's own plugin (`project-kit`)

- **Skills (9)** — Markdown guidance only. No code execution, no network.
- **Agents (3)** — read-only reviewers; tools limited to `Glob, Grep, LS, Read,
  Bash` (Bash used for `git diff`). They review and report; they do not edit.
- **Hooks (2, PreToolUse)** — `guard_secrets.py` and `guard_commands.py`. Pure
  python, stdin→exit-code, no network, no writes, ~10s timeout. Unit-tested in
  `verify.sh`. They only ever **block** (exit 2) or **allow** (exit 0); they never
  modify a command or file.
- **KhatmSaz override** — `project-overrides/khatmsaz/hooks/guard_backup.py`
  blocks mutating the `/mnt/z/KhatmSaz` backup. Same properties; project-scope
  only, not part of the portable plugin.

## Optional plugins (NOT enabled by default)

| Plugin | Owner | Why optional | Risk to weigh |
|--------|-------|--------------|---------------|
| pr-review-toolkit | Anthropic | ~1,600 always-on tokens; overlaps built-in review | context cost only |
| plugin-dev | Anthropic | ~1,700 always-on tokens; overlaps skill-creator | context cost only |
| context7 | Upstash (listed in official marketplace) | **remote MCP**: sends doc queries to `mcp.context7.com` | **network egress**; enable only if acceptable |
| playwright | Microsoft (official marketplace, external_plugins) | launches a real browser; heavy | runs a browser, downloads browser binaries |
| claude-security | Anthropic | on-demand deep scan; not needed always-on | none notable |
| claude-md-management | Anthropic | overlaps this kit's memory skills | none notable |

## Rules honored

- No `curl | bash` from any community source; none installed.
- No plugin installed solely on a social-media recommendation.
- Uncertain/untrusted tooling recorded in `CANDIDATES.md`, **not** installed.
- `.env` and secrets are never touched; the kit's guard hooks actively prevent
  writing them.
