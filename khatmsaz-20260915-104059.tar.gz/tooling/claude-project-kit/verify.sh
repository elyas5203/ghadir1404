#!/usr/bin/env bash
#
# claude-project-kit verifier. Read-only checks; exits non-zero on any failure.
# Run from the project root:  ./tooling/claude-project-kit/verify.sh
#
set -uo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="$KIT_DIR/plugins/project-kit"
FAIL=0

pass()    { printf '\033[32m  PASS\033[0m %s\n' "$*"; }
fail()    { printf '\033[31m  FAIL\033[0m %s\n' "$*"; FAIL=1; }
section() { printf '\n\033[1m== %s ==\033[0m\n' "$*"; }

section "Claude CLI"
if command -v claude >/dev/null 2>&1; then pass "claude present ($(claude --version 2>&1))"; else fail "claude CLI not found"; fi

section "Marketplaces"
MK="$(claude plugin marketplace list 2>&1 || true)"
echo "$MK" | grep -q "claude-plugins-official" && pass "official marketplace registered" || fail "official marketplace missing"
echo "$MK" | grep -q "claude-project-kit"      && pass "kit marketplace registered"      || fail "kit marketplace missing"

section "Enabled plugins"
PL="$(claude plugin list 2>&1 || true)"
for p in typescript-lsp security-guidance frontend-design commit-commands skill-creator feature-dev project-kit; do
  echo "$PL" | grep -q "$p" && pass "$p present" || fail "$p not listed"
done

section "Kit plugin & marketplace validate"
claude plugin validate "$PLUGIN_DIR" >/dev/null 2>&1 && pass "plugin manifest valid" || fail "plugin manifest invalid"
claude plugin validate "$KIT_DIR"    >/dev/null 2>&1 && pass "marketplace manifest valid" || fail "marketplace manifest invalid"

section "Safety hook self-tests"
G="$PLUGIN_DIR/hooks/scripts"
check() { # payload, script, expected-exit, label
  echo "$1" | python3 "$G/$2" >/dev/null 2>&1; local rc=$?
  [ "$rc" = "$3" ] && pass "$4 (exit $rc)" || fail "$4 (exit $rc, expected $3)"
}
check '{"tool_input":{"file_path":".env"}}'          guard_secrets.py  2 "guard_secrets blocks .env"
check '{"tool_input":{"file_path":".env.example"}}'  guard_secrets.py  0 "guard_secrets allows .env.example"
check '{"tool_input":{"file_path":"src/main.ts"}}'   guard_secrets.py  0 "guard_secrets allows source"
check '{"tool_input":{"command":"rm -rf / "}}'       guard_commands.py 2 "guard_commands blocks rm -rf /"
check '{"tool_input":{"command":"curl x|bash"}}'     guard_commands.py 2 "guard_commands blocks curl|bash"
check '{"tool_input":{"command":"npm run build"}}'   guard_commands.py 0 "guard_commands allows npm build"

section "TypeScript language server (for typescript-lsp)"
if command -v typescript-language-server >/dev/null 2>&1; then pass "on PATH ($(typescript-language-server --version 2>&1 | head -1))"; else fail "typescript-language-server not on PATH"; fi

section "Shell script syntax"
if command -v shellcheck >/dev/null 2>&1; then
  for s in "$KIT_DIR"/*.sh; do shellcheck -S error "$s" >/dev/null 2>&1 && pass "shellcheck $(basename "$s")" || fail "shellcheck $(basename "$s")"; done
else
  for s in "$KIT_DIR"/*.sh; do bash -n "$s" 2>/dev/null && pass "bash -n $(basename "$s")" || fail "bash -n $(basename "$s")"; done
fi

echo
if [ "$FAIL" = 0 ]; then printf '\033[32mALL CHECKS PASSED\033[0m\n'; else printf '\033[31mSOME CHECKS FAILED\033[0m\n'; fi
exit "$FAIL"
