#!/usr/bin/env bash
#
# claude-project-kit updater. Refreshes marketplace metadata and updates the
# curated plugins to their latest versions. A session RESTART is required to
# apply updates. Run from the project root.
#
set -uo pipefail

OFFICIAL_PLUGINS=( typescript-lsp security-guidance frontend-design commit-commands skill-creator feature-dev )

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }

command -v claude >/dev/null 2>&1 || { echo "claude CLI not found" >&2; exit 1; }

say "Refreshing marketplace metadata"
claude plugin marketplace update --all 2>&1 | tail -3 || claude plugin marketplace update claude-plugins-official 2>&1 | tail -3

say "Updating curated first-party plugins"
for p in "${OFFICIAL_PLUGINS[@]}"; do
  echo "  - $p"
  claude plugin update "${p}@claude-plugins-official" 2>&1 | tail -1 || echo "    (no update or not installed)"
done

say "The kit's own plugin (project-kit) is versioned in this repo — bump VERSION and edit files directly."
say "Done. RESTART your Claude Code session to apply updates."
