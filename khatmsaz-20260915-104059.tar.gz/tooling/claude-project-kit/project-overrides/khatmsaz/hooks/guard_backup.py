#!/usr/bin/env python3
"""KhatmSaz-specific PreToolUse guard: protect the read-only backup copy.

The authoritative working copy is /home/elyas/KhatmSaz. An older copy at
/mnt/z/KhatmSaz is a backup that must never be modified. This guard blocks any
Write/Edit whose target is under the backup path, and any Bash command that would
mutate it. Reading the backup is allowed.

Deterministic, offline, no side effects.
"""
import sys
import os
import re
import json

BACKUP = "/mnt/z/KhatmSaz"
MUTATORS = re.compile(
    r"\b(rm|mv|cp|touch|mkdir|rmdir|truncate|tee|dd|chmod|chown|ln|sed\s+-i|"
    r"git\s+(-C\s+\S+\s+)?(add|commit|checkout|reset|clean|rm|mv|apply|restore))\b"
    r"|>\s*\S|>>\s*\S"
)


def blocked(msg: str) -> int:
    sys.stderr.write(
        "BLOCKED by khatmsaz guard-backup: {}\n"
        "The authoritative copy is /home/elyas/KhatmSaz; /mnt/z/KhatmSaz is a "
        "read-only backup and must not be modified.\n".format(msg)
    )
    return 2


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except Exception:
        return 0

    tool = data.get("tool_name", "")
    ti = data.get("tool_input") or {}

    # File edits: block if the target is inside the backup path.
    path = ti.get("file_path") or ti.get("path") or ""
    if path:
        ap = os.path.abspath(path)
        if ap == BACKUP or ap.startswith(BACKUP + "/"):
            return blocked("attempt to write '{}' inside the backup.".format(path))

    # Shell commands: block only mutating commands that reference the backup path.
    cmd = ti.get("command") or ""
    if cmd and BACKUP in cmd and MUTATORS.search(cmd):
        return blocked("a mutating command references the backup path.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
