# KhatmSaz project overrides

Project-specific configuration that is **not** part of the portable kit. Do not
copy this folder into other projects.

## Backup-path guard (active)

`hooks/guard_backup.py` is a deterministic PreToolUse guard that blocks any
Write/Edit or mutating Bash command targeting `/mnt/z/KhatmSaz` — the old,
non-authoritative backup copy. It is wired into the project's
`.claude/settings.json` under `hooks`:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|Bash",
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/tooling/claude-project-kit/project-overrides/khatmsaz/hooks/guard_backup.py\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

Test it:

```bash
echo '{"tool_input":{"file_path":"/mnt/z/KhatmSaz/x"}}' | python3 hooks/guard_backup.py; echo $?   # -> 2 (blocked)
echo '{"tool_input":{"command":"cat /mnt/z/KhatmSaz/README.md"}}' | python3 hooks/guard_backup.py; echo $?   # -> 0 (read allowed)
```

## Enabled profile

KhatmSaz uses the **fullstack-typescript** profile (see `../../profiles/`). The
active plugin set and rationale are recorded in `docs/ai/CLAUDE_TOOLKIT.md`.

## Relationship to `.claude/rules/` and `docs/ai/`

The kit does not replace KhatmSaz's existing memory system. Responsibility split:

- `CLAUDE.md` — stable operating rules.
- `.claude/rules/` — scoped rules (architecture, backend, frontend, security,
  testing, documentation).
- `docs/ai/PROJECT_STATE.md` — latest authoritative state (source of truth).
- `docs/ai/DECISIONS.md` / `ROADMAP.md` / `CHANGELOG.md` — durable history.
- Kit **skills** — procedures loaded only when needed (progressive disclosure).
- Claude auto-memory — convenience only, never the source of truth.
