# Profile: frontend-premium

For UI-heavy work where design quality matters: distinctive, production-grade,
accessible, internationalized interfaces.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "frontend-design@claude-plugins-official": true,
    "typescript-lsp@claude-plugins-official": true,
    "commit-commands@claude-plugins-official": true
  }
}
```

- `frontend-design` — non-generic, high-quality UI implementation.
- this kit's `frontend-quality-gate` skill and `frontend-ux-reviewer` agent —
  RTL / mobile-first / tokens / accessibility review.

**Optional, opt-in:**
- `context7@claude-plugins-official` — current framework/library docs (remote
  MCP, network egress).
- `playwright@claude-plugins-official` — visual/interaction checking in a real
  browser (see the **testing** profile).

For animation and 3D, see the **design-3d** profile — deliberately separate so a
simple, fast product is not burdened with heavy visual tooling by default.
