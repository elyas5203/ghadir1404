# Profile: testing

For test authoring and end-to-end / browser validation.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "typescript-lsp@claude-plugins-official": true,
    "pr-review-toolkit@claude-plugins-official": true
  }
}
```

- this kit's `test-gate` skill — runs typecheck / lint / tests / build and
  reports each honestly.
- `pr-review-toolkit` — includes `pr-test-analyzer` for test-quality review.

**Optional, opt-in (heavier):**
- `playwright@claude-plugins-official` — Microsoft's browser-automation / E2E
  **MCP server**. Drives a real browser: navigate, screenshot, fill forms, click,
  assert. Enable when you have E2E work; it launches a browser and adds tool
  surface, so it is not a default. Requires the Playwright browsers to be
  installed in the project (`npx playwright install`).

Keep tests hermetic: no live network, database, or real third-party credentials
in unit/integration tests — use fakes. E2E is the place for a real browser.
