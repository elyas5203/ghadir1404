# Profile: design-3d  (OPTIONAL — not enabled for KhatmSaz)

Advanced visual work: animation, 3D, WebGL/WebGPU, motion-rich landing pages.

> **Deliberately off by default.** KhatmSaz prioritizes simplicity, speed,
> accessibility, elderly users, and mobile-first UX. Heavy 3D/animation tooling
> must never load into the KhatmSaz default profile. Use this profile only in a
> project that genuinely needs it.

## Why there is no plugin to install

As of this kit's research (Sep 2026) the official first-party marketplace has
**no** Three.js / React Three Fiber / WebGL / GSAP plugin, and no community 3D
plugin met the kit's trust bar (inspectable source, maintained, no `curl | bash`,
no unexplained network or secret access). So this profile does **not** enable a
third-party plugin. It curates trustworthy **libraries** and guidance instead.

## Recommended setup for a project that needs it

1. Enable the **frontend-premium** profile (frontend-design + this kit).
2. Add well-known, inspectable libraries as normal project dependencies:
   - `three` + `@react-three/fiber` + `@react-three/drei` — declarative 3D/WebGL.
   - `gsap` or `motion` (Framer Motion) — timeline / spring animation.
   - `@react-three/postprocessing` — effects, when justified.
3. Respect `prefers-reduced-motion`; provide a static fallback; lazy-load the 3D
   bundle so it never taxes low-end mobile first paint.

## Optional MCP for docs while building

`context7@claude-plugins-official` gives version-accurate Three.js / R3F / GSAP
documentation (remote MCP, network egress — opt-in).

Auditing note: before adding any future community 3D plugin, run it through
`AUDIT.md`'s checklist. Do not install visual tooling that executes downloaded
code or requests secrets.
