# Profile: base

The smallest safe, low-overhead setup. Good for any repository.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "security-guidance@claude-plugins-official": true,
    "commit-commands@claude-plugins-official": true
  }
}
```

- `project-kit` — workflow skills, review agents, safety hooks (this kit).
- `security-guidance` — secret/vuln guardrails (zero always-on context).
- `commit-commands` — git commit / push / PR helpers.

Always-on cost ≈ **960 tokens**. No network, no third-party code beyond
first-party Anthropic plugins.

Optional add-on: `claude-md-management@claude-plugins-official` if you want
automated CLAUDE.md auditing (overlaps this kit's memory skills).
