# Profile: backend

For API / service work without frontend concerns.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "typescript-lsp@claude-plugins-official": true,
    "security-guidance@claude-plugins-official": true,
    "feature-dev@claude-plugins-official": true,
    "commit-commands@claude-plugins-official": true
  }
}
```

- `typescript-lsp` — code intelligence (needs `typescript-language-server` on
  PATH).
- `security-guidance` — injection / SSRF / secret guardrails.
- `feature-dev` — code-explorer, code-architect, code-reviewer agents.
- this kit's `architecture-guardian` skill and `architecture-reviewer` agent —
  module-boundary and dependency-direction enforcement.

Add `pr-review-toolkit` for deeper review sessions (heavier always-on cost).
