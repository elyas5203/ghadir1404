# Profile: security

For security-focused review passes.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "security-guidance@claude-plugins-official": true,
    "pr-review-toolkit@claude-plugins-official": true
  }
}
```

- `security-guidance` — pattern warnings on edits, LLM diff review on Stop, and
  an agentic commit reviewer (injection, XSS, SSRF, hardcoded secrets, 25+
  classes). Note the Stop/commit hooks run a review each time — expected here.
- `pr-review-toolkit` — includes `silent-failure-hunter` and other agents useful
  in a security pass (~1,600 always-on tokens).
- this kit's `security-check` skill — a fast repo review checklist + `npm audit`.

**Optional, opt-in:**
- `claude-security@claude-plugins-official` — deeper, effort-tiered vulnerability
  scanning of your own code with every finding challenged before it is reported.
  A strong on-demand complement; enable when doing a dedicated audit.
