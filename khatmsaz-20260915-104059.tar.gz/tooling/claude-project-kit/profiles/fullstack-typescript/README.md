# Profile: fullstack-typescript  (KhatmSaz default)

Everything in **base**, plus TypeScript intelligence, a feature-development
workflow, skill authoring, and frontend design quality. This is the profile
KhatmSaz uses.

**Enable:**

```json
{
  "enabledPlugins": {
    "project-kit@claude-project-kit": true,
    "typescript-lsp@claude-plugins-official": true,
    "security-guidance@claude-plugins-official": true,
    "frontend-design@claude-plugins-official": true,
    "commit-commands@claude-plugins-official": true,
    "skill-creator@claude-plugins-official": true,
    "feature-dev@claude-plugins-official": true
  }
}
```

**Dependency:** `typescript-lsp` needs the TypeScript language server on PATH:

```bash
npm config set prefix ~/.local && npm install -g typescript-language-server typescript@5
```

Always-on cost ≈ **1,300 tokens** (LSP and security hooks are out-of-process /
harness-only and add ~0).

**Optional, opt-in:**
- `context7@claude-plugins-official` — up-to-date library docs via a hosted
  remote MCP. **Network egress** to `mcp.context7.com`; enable only if that is
  acceptable for your project.
- `pr-review-toolkit@claude-plugins-official` — richer PR review (~1,600
  always-on); enable for review-heavy sessions.
