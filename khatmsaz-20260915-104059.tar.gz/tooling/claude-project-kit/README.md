# claude-project-kit

A portable, curated **Claude Code** development toolkit — one copyable folder
that installs a safe, low-overhead Claude setup into any project.

It gives Claude Code: TypeScript code intelligence, security guardrails, a
feature-development workflow, frontend design quality, skill authoring, a git
workflow, plus this kit's own **reusable workflow skills**, **review subagents**,
and **deterministic safety hooks**. Everything active by default is either
first-party (Anthropic) or authored here — no untrusted third-party code, no
network access, no secrets.

## What's inside

```
claude-project-kit/
├── README.md            this file
├── VERSION              kit version
├── manifest.json        curated plugins + kit components, reasons, token cost
├── plugins.lock.json    resolved versions / install state
├── install.sh           register marketplaces + enable curated plugins (project scope)
├── verify.sh            read-only checks + hook self-tests (exits non-zero on failure)
├── update.sh            refresh marketplaces + update plugins
├── uninstall.sh         remove the kit's plugins from the current project
├── AUDIT.md             security assessment of every active/optional plugin
├── CANDIDATES.md        evaluated-but-not-installed tooling, with reasons
├── .claude-plugin/
│   └── marketplace.json local marketplace exposing the kit's own plugin
├── plugins/project-kit/ the kit's own plugin
│   ├── .claude-plugin/plugin.json
│   ├── skills/          9 workflow skills (progressive disclosure)
│   ├── agents/          3 review subagents (read-only)
│   └── hooks/           2 deterministic PreToolUse safety hooks + scripts
├── profiles/            base, fullstack-typescript, frontend-premium, backend,
│                        security, testing, design-3d  (enable snippets)
└── project-overrides/
    └── khatmsaz/        project-specific hooks/config (NOT portable)
```

## Install into a project

From the project root:

```bash
./tooling/claude-project-kit/install.sh   # registers marketplaces, enables the default profile (project scope)
./tooling/claude-project-kit/verify.sh    # confirms everything is wired correctly
```

Then **restart** the Claude Code session so the plugins load. The default profile
is **fullstack-typescript** (see `profiles/`). To use a different mix, copy the
`enabledPlugins` snippet from the profile you want into `.claude/settings.json`.

> Portability note: the kit is registered as a **local (`directory`) marketplace**
> whose path is machine-specific. `install.sh` re-registers it with the correct
> path for each checkout, so run it once per machine/clone.

## Copy to another project

Copy the whole `claude-project-kit/` folder into the other repo (e.g. under
`tooling/`), delete `project-overrides/khatmsaz/` (or replace it with your own
overrides), then run `install.sh` there.

## Dependencies

- **Claude Code** ≥ 2.1 with the `claude plugin` CLI.
- **python3** — used by the kit's safety hooks (and by `security-guidance`).
- **typescript-language-server** on PATH — for the `typescript-lsp` plugin:
  `npm config set prefix ~/.local && npm install -g typescript-language-server typescript@5`.

## Skills, agents, hooks

- **Skills** (loaded only when relevant): `project-memory-maintainer`,
  `roadmap-maintainer`, `decision-recorder`, `phase-closeout`,
  `architecture-guardian`, `debugging-librarian`, `security-check`, `test-gate`,
  `frontend-quality-gate`.
- **Agents** (read-only reviewers): `architecture-reviewer`,
  `frontend-ux-reviewer`, `documentation-reviewer`.
- **Hooks** (deterministic PreToolUse): `guard_secrets` (blocks writing secret
  files), `guard_commands` (blocks unambiguously catastrophic shell commands).

See `manifest.json` for token costs and `AUDIT.md` for the security assessment.

## Update / uninstall

```bash
./tooling/claude-project-kit/update.sh      # refresh + update plugins (restart to apply)
./tooling/claude-project-kit/uninstall.sh   # remove kit plugins from this project
```
