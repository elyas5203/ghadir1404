# Local development only: OTP and test accounts

This is a Linux/WSL convenience for manually testing the existing product without
an SMS provider. It is **not a production authentication feature**. No migration,
new role, SMS provider, public OTP route, or alternate login was introduced.

## Start

From `/home/elyas/KhatmSaz` in WSL, using Node 24 and the existing local `.env`:

```bash
npm run dev:api:otp
```

In another WSL terminal:

```bash
npm run dev -w @khatmsaz/web -- --hostname 127.0.0.1
```

`dev:api:otp` builds shared packages, loads the existing `.env` without editing it,
and explicitly sets `NODE_ENV=development KHATMSAZ_DEV_OTP=1`. Stop another API
using port 3001 first. PostgreSQL must be reachable on loopback. The ordinary API
command does not enable this feature automatically. Do not expose local servers
to the LAN. The OTP socket must never be forwarded through an HTTP tunnel.

## Seed and bind

Use your chosen phone as `<phone>`; the real developer number is not embedded in
source or this guide. A second synthetic fixture can use `+12025550123` (reserved
fictional US number). All commands below run from the repository root:

```bash
NODE_ENV=development npm run --silent dev:local -- seed '<phone>' creator
NODE_ENV=development npm run --silent dev:local -- seed '+12025550123' creator
NODE_ENV=development npm run --silent dev:local -- bind-telegram '<phone>' '<numeric-telegram-user-id>'
```

Omit `creator` to seed an ordinary participant without granting permissions.
Repeated/concurrent seeds return the same User ID and do not duplicate the verified
phone or active CREATOR grant. Existing grants are never revoked by omission.
The local CLI uses a transaction and advisory lock. All database uniqueness and
foreign-key constraints remain in force. An existing verified phone is reused only
if its account is ACTIVE; a merged account is rejected.

Binding accepts a positive safe numeric **user ID**, never a username or group/chat
ID. Repeating the binding is harmless. If it already belongs to another account,
the command fails: no silent reassignment, merge, or deletion. Investigate that
account using the existing identity/merge rules instead.

The schema has no display-name/username field and no ADMIN role. Both requested
local accounts use the existing CREATOR capability, as approved by the user.
They can manage their **own** khatms; this does not enable a global admin panel.

## Manual web login

1. Open `http://localhost:3000/login` and enter the seeded phone.
2. Click the normal request-code button.
3. In an interactive WSL terminal, retrieve the delivery:

   ```bash
   NODE_ENV=development KHATMSAZ_DEV_OTP=1 npm run --silent dev:local -- otp '<phone>'
   ```

4. Enter the displayed code in the normal form. The existing phone-first flow
   verifies the HMAC challenge and creates the normal server-side httpOnly cookie.
5. Dashboard shows `سازنده`. Create a khatm, open it, generate a plan and activate it.
6. Refresh to confirm session persistence; logout invalidates the session.

The CLI intentionally delivers the code only to an interactive terminal. Do not
record the terminal. Redirecting/piping its output is rejected. Application logs
contain neither the OTP nor phone. OTP is stored only in bounded process memory,
expires with its challenge, and retrieval consumes the delivery copy once. It
does **not** consume the actual verification challenge. Request a fresh code if
you close the API, read the code twice, or let it expire; the normal resend cooldown
and attempt limit remain active. Expected phone errors now return 400/409, and OTP
cooldown/attempt exhaustion returns 429 instead of an accidental 500.

The socket is `/tmp/khatmsaz-otp-<uid>/delivery.sock` (or the OS temp directory).
Its parent is owner-only `0700`, socket `0600`; it has no TCP port. Only opted-in
development registers the delivery provider. Production, test, staging and unset
environments use the existing no-op delivery, even if the opt-in flag is set.
`/api/dev/otp/latest` does not exist in **any** mode.

## Manual Telegram check

After binding, message the configured bot yourself:

```text
/start
/my_khatms
/create_khatm SALAWAT آزمایش محلی
/progress <khatm-id>
```

`/start` resolves the same seeded User. Creation still requires CREATOR. Actual
phone and Telegram credentials are not stored in this guide. Real Telegram-client
delivery also requires the existing webhook and outbound network setup described
in INTEGRATIONS.md. This task does not install a public tunnel or register a new
remote webhook. Integration tests exercise the same command service locally with
synthetic subjects and no outgoing messages.

## Reset without destroying history

- To discard unread OTPs, stop/restart the local API. Logout to invalidate your
  current browser session. A new login supersedes the previous challenge normally.
- Local fixture accounts persist intentionally. To reset permissions/sessions,
  first confirm the **exact** User ID printed by seed and the loopback development
  database. In a local SQL client, substitute that UUID below:

  ```sql
  BEGIN;
  UPDATE sessions SET revoked_at = NOW()
    WHERE user_id = '<fixture-uuid>'::uuid AND revoked_at IS NULL;
  UPDATE user_capabilities SET revoked_at = NOW()
    WHERE user_id = '<fixture-uuid>'::uuid AND revoked_at IS NULL;
  COMMIT;
  ```

  This keeps identity/history intact. Running `seed ... creator` again restores an
  active grant, preserving revoked grant history. To reset demo khatms use their
  normal lifecycle actions. Do not delete an account with business/merge history,
  reset the database, drop indexes, or run `db push` for this task.
- Graceful shutdown removes the socket. After a crash, verify no local API still
  owns that **exact** socket with `ss -xlpn` before removing only the stale socket
  file. The adapter never unlinks another running API's socket automatically.

## Research references

- [Node IPC socket lifecycle](https://nodejs.org/api/net.html#ipc-support)
- [NestJS shutdown lifecycle](https://docs.nestjs.com/fundamentals/lifecycle-events)
- [Prisma transaction/idempotency guidance](https://www.prisma.io/docs/orm/v6/prisma-client/queries/transactions)

The installed Node 24 and Prisma 7 APIs were checked by typechecking and executing
this implementation locally. No new application dependency was installed.
