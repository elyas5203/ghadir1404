# INTEGRATIONS

## LOCAL DEVELOPMENT ONLY — no SMS panel required

See [LOCAL_DEVELOPMENT.md](LOCAL_DEVELOPMENT.md) for `dev:api:otp`, idempotent
`dev:local seed`, interactive `dev:local otp`, and `dev:local bind-telegram`.
The OTP adapter uses private WSL/Linux IPC, not a public HTTP route; it is disabled
outside opted-in development. This is not a production authentication feature.
Real Telegram-client testing still requires the existing webhook/network setup.

Every external platform is an **adapter** behind a port owned by the domain
(DEC-0018). No domain module may import a vendor SDK.

## Status

| Integration      | Purpose                                   | Status              |
| ---------------- | ----------------------------------------- | ------------------- |
| Telegram         | Primary bot platform for the MVP          | **IMPLEMENTED (Phase 9, config-gated)** |
| Bale             | Second messaging platform, post-MVP       | **NOT IMPLEMENTED** |
| SMS provider     | OTP and fallback notifications, post-MVP  | **NOT IMPLEMENTED** (OTP delivery seam is a no-op) |
| Payment gateway  | Paid Khatm creation, wallet top-up        | **NOT IMPLEMENTED** |
| Object storage   | Quran pages, PDFs, audio, images (S3/MinIO) | **NOT IMPLEMENTED** |

Only Telegram has a real adapter (Phase 9), and it is inert until configured.

## Hard requirements

- **The repository must build, lint and test with every integration variable
  empty.** No token is required for `npm install`, `npm run build` or
  `npm test`. `.env.example` ships these keys blank on purpose.
- No integration credential is ever committed.
- An adapter translates between the vendor's shapes and the domain's port. It
  does not contain business rules.
- Vendor failures are the adapter's problem to model — the domain sees a typed
  outcome, not an SDK exception.

## Telegram (implemented — Phase 9, DEC-0065)

The Telegram channel is connected to the real Bot API, **entirely in
`apps/api/src/telegram/infrastructure`**; the domain/application never see a
Telegram-shaped object. The MVP bot stays extremely simple (DEC-0014) — Telegram is a
delivery surface, not where Khatm rules live.

- **Inbound:** `POST /telegram/webhook` (`TelegramWebhookController`) verifies the
  `X-Telegram-Bot-Api-Secret-Token` header (constant-time) against
  `TELEGRAM_WEBHOOK_SECRET`, maps the raw update to the neutral `TelegramUpdate`
  (`toTelegramUpdate`), and dispatches through the existing gateway/command service.
  No polling loop (a `getUpdates` poller could be added behind the same gateway).
- **Outbound:** `BotApiTelegramSender` implements the `TelegramSender` port with plain
  `fetch` to `…/bot<token>/sendMessage` — **no third-party SDK**. Bound only when
  `TELEGRAM_BOT_TOKEN` is set; otherwise the no-op sender.
- **Config (secrets, blank in `.env.example`):** `TELEGRAM_BOT_TOKEN`,
  `TELEGRAM_WEBHOOK_SECRET`, `TELEGRAM_API_BASE_URL`. Empty env ⇒ outbound no-op **and**
  the webhook rejects everything (403) — nothing to configure to keep it off.
- **Commands** `/start /create_khatm /my_khatms /join /progress` route through the
  application services; identity resolves via the identity capability and creating a
  khatm requires the CREATOR capability (enforced in the workflow, not here).
- **Going live (ops):** set the two secrets, then register the webhook URL + secret
  with Telegram (`setWebhook`). Tokens/secrets are never logged or committed.

### Local activation & verification (Phase 9.1, 2026-09-07)

The adapter was activated against a **real bot** (`@Khatm_Saz_bot`) and the full
inbound path verified locally. **No code changed** — this was configuration + an
operational check; DEC-0065 stands.

- **Config:** `TELEGRAM_BOT_TOKEN` + `TELEGRAM_WEBHOOK_SECRET` set in local `.env`
  only (git-ignored, never committed, never logged). Token validity confirmed via a
  read-only `getMe` (returned the bot's public username; the token was not printed).
- **Verified locally** (POSTing to `http://127.0.0.1:3001/telegram/webhook` exactly as
  Telegram would): wrong/missing secret → **403**; correct secret + `/start` → **200**
  and one `PlatformIdentity` provisioned; a duplicate `/start` → still **one** identity
  (idempotent); `/my_khatms` → 200; a malformed update → 200 (ignored); `/create_khatm`
  **without** CREATOR → 200 with a denial reply and **no khatm created** (authorization
  intact). No token/secret appeared in the logs.
- **Not done here (needs a normal-internet host + a human):** a public HTTPS **tunnel**
  and the real `setWebhook`, plus sending messages from a Telegram client. In this
  sandbox Telegram is reachable **only through the WSL proxy**, while the sender uses a
  direct `fetch` — so outbound replies do not deliver *from this sandbox* (an
  environment quirk, not an architecture issue; a normal host with direct egress
  works). No tunnel binary (cloudflared/ngrok) is installed here.

**To finish going live on a real host:**

```bash
# 1) run the API (reads TELEGRAM_* from .env)
npm run dev:api
# 2) expose it over HTTPS (either tool)
cloudflared tunnel --url http://localhost:3001     # or:  ngrok http 3001
# 3) point Telegram at the public URL, echoing the same secret on every update:
curl "https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/setWebhook" \
  --data-urlencode "url=https://<public-tunnel-host>/telegram/webhook" \
  --data-urlencode "secret_token=$TELEGRAM_WEBHOOK_SECRET"
# 4) in Telegram, message @Khatm_Saz_bot: /start, /my_khatms, /create_khatm …
```

Replies deliver only where the host has outbound internet to `api.telegram.org`.

## Bale (planned)

Bale arrives after the MVP as a second adapter implementing the same ports. If
adding Bale would require changing the domain, the port was wrong.

## Object storage (planned)

MinIO is defined locally in `infra/docker/docker-compose.yml` as an
S3-compatible stand-in, bound to `127.0.0.1:9000` (console `:9001`). Its
credentials are local-only placeholders from `.env`. As of Phase 2A the container
**runs** and was health-checked (live + console HTTP 200), but there is still no
bucket, no asset, no import pipeline, and **no application code** touches it.

## Local infrastructure runtime note (Phase 2A)

The Docker stack (PostgreSQL, Redis, MinIO) is verified running locally
(`npm run infra:up`). Only **PostgreSQL** is wired into application code, through
Prisma in the API infrastructure layer (see `docs/ai/DATABASE.md`). **Redis and
MinIO are NOT integrated into application/business code yet** — they are runtime
dependencies verified for readiness only. Redis (future BullMQ queue/schedule) and
MinIO (object storage) each get their own dedicated phase and, if reached through
a vendor SDK, an adapter behind a domain-owned port (DEC-0018).
