# UI/UX Audit — 2026-09-11

> Findings from a full review of all web pages, components, CSS, and the design
> token layer. Priority levels: **Critical** (blocks trust or usability),
> **Important** (meaningfully degrades the experience), **Nice-to-have** (polish).

---

## 1. Landing page (`/`)

### Problems
| P | Finding |
|---|---------|
| Critical | `ApiStatus` component — a live health-check badge — is visible to end-users on the landing page. This is a developer tool, not a consumer UI element. |
| Critical | `StatusCard label="وضعیت برنامه" value="در حال آماده‌سازی"` shows an internal readiness state to users. It looks broken rather than trustworthy. |
| Important | No emotional connection. The hero text is functional ("ختم‌های گروهی را بسازید…") but contains zero warmth or spiritual resonance for a product about group prayer. |
| Important | No clear primary CTA hierarchy. "ورود" and "داشبورد" are styled as equals. |
| Nice | Footer just says "خدمتگزاران" with no link or sub-text. |

### Recommended fixes
- Remove `ApiStatus` and `StatusCard` entirely from the landing page.
- Replace the developer cards section with 3 simple feature bullets or icons.
- Strengthen the hero headline to name the emotional value: جمعی، صادقانه، قابل پیگیری.
- Make "ورود" the only prominent CTA; "داشبورد" remains a ghost link.

---

## 2. Login page (`/login`)

### Problems
| P | Finding |
|---|---------|
| Important | No brand identity on the page. Users arriving directly at `/login` see "ورود به ختم‌ساز" with zero visual context for what the product is. |
| Important | The OTP step has no timer, no resend action, and no indication of how long the code is valid — users who wait too long will silently fail. |
| Important | Error messages can appear below the submit button, pushing content down (layout shift). Reserve a fixed region for errors above the submit button. |
| Nice | The phone input `placeholder="09xxxxxxxxx"` uses `x` (Latin). Use Persian zeroes: `۰۹×××××××××`. |

### Recommended fixes
- Add the brand wordmark + icon at the top of the auth card.
- Add a countdown or note about code expiry ("کد تأیید ۵ دقیقه اعتبار دارد").
- Add a "ارسال مجدد" resend action after expiry.
- Move error display above the primary button.

---

## 3. Dashboard (`/dashboard`)

### Problems
| P | Finding |
|---|---------|
| Critical | No loading state. The page renders blank until all API calls complete. On a slow connection this looks like a crash. |
| Important | The creator/participant badge logic (`me?.isCreator ? 'سازنده' : 'شرکت‌کننده'`) conflicts with DEC-0070: every authenticated user IS a creator. The badge is confusing when a user has not yet created a khatm. |
| Important | Empty state copy is passive: "هنوز ختمی نساخته‌اید. با یک لینک دعوت بپیوندید." — it does not guide the user to an action. |
| Important | Two separate creator/participant sections create cognitive load. A new user sees "ختم‌های من" with an empty state AND "شرکت در ختم‌ها" with another empty state. |
| Important | Error state shows an inline message but no retry button. |
| Important | Progress bars appear only for ACTIVE khatms; DRAFT khatms show no visual state indicator. |
| Nice | `KhatmCard` title uses `khatm-card-title` font weight but the `font-size` fallback is the same as body text on small screens — needs stronger visual hierarchy. |

### Recommended fixes
- Add a skeleton loading state (3 grey placeholder cards) while fetching.
- In the creator section empty state: make "ختم تازه" the CTA, not just a heading button.
- Add a retry button alongside error messages.
- Defer showing the role badge; remove it entirely or make it passive.

---

## 4. Create Khatm page (`/khatms/create`)

### Problems
| P | Finding |
|---|---------|
| Important | The radio type cards work, but the selected state (primary border + light background) is subtle on mobile — not obvious enough at small sizes. |
| Important | No validation feedback on the title field (only HTML `required` with browser default styles). An empty submit shows a browser-native tooltip rather than an inline Persian error. |
| Important | `canCreateKhatm(me)` guard shows a fallback "باید دسترسی سازنده داشته باشید" panel — this should never appear (DEC-0070), but if it does it offers no recovery path. |
| Nice | The OPEN type note ("شرکت‌کنندگان می‌توانند…") appears only after selection. The user has to click to see it. |

### Recommended fixes
- Increase the selected card border width or add a checkmark icon to make selection obvious.
- Add client-side title validation with an inline Persian message.
- Remove the creator-gate fallback or replace it with a redirect.

---

## 5. Khatm detail page (`/khatms/[id]`)

### Problems
| P | Finding |
|---|---------|
| Critical | Participants are shown as truncated UUIDs: `018f9a2b…`. This is completely unacceptable for a consumer product. Users cannot identify themselves or others. |
| Critical | Invitation IDs are also shown as truncated UUIDs in the invitation list. |
| Critical | The allocation form exposes raw technical numbers ("تعداد کل: 1000, اندازهٔ هر سهم: 100") without any unit labels or contextual explanation. A normal user does not know what these mean for قرآن کامل. |
| Critical | "اعلام پایان ختم" (complete khatm) is a destructive, irreversible action with no confirmation step. A creator can accidentally complete a khatm with a single tap. |
| Important | Loading state shows "در حال بارگذاری…" inline in the title area — the whole page jumps when the khatm data loads. |
| Important | "فعال‌سازی" and "ساخت برنامه" buttons appear together without a clear dependency explanation — it is not obvious that a plan must be built before activation. |
| Important | The Allocate form (`واگذاری سهم`) only appears after activation AND when participants > 0, with no guidance on how to invite participants first. |
| Important | OPEN khatm contribution form has a raw number input with no unit. How many pages? Verses? The user does not know. |
| Important | Multiple panels stacked vertically with no visual grouping — creator management, invitations, participants all appear at the same hierarchy level as basic info. |
| Nice | Progress text "X از Y سهم انجام‌شده" and progress bar appear together — redundant on small screens. |
| Nice | Help tip for "سهم" in the plan form uses a different explanation than the one in the panel header for "سهم‌های من". |

### Recommended fixes
- Show participants as "شرکت‌کننده ۱", "شرکت‌کننده ۲" (sequential index) with join date.
- Show invitations with creation date and expiry date, not the UUID.
- Replace the raw allocation plan form with a guided preset selector (قرآن کامل = 30 جزء, etc.) with a manual override mode.
- Add a confirmation modal/bar for "اعلام پایان ختم".
- Add a sticky page header with the khatm title + status badge while scrolling.
- Group creator-only sections under a collapsible "مدیریت ختم" accordion.
- Show join dates for participants.

---

## 6. Invitation acceptance (`/invitations/accept`)

### Problems
| P | Finding |
|---|---------|
| Important | The page auto-calls the accept endpoint on load with no user confirmation. If a user opens the link accidentally or opens it twice, the result is unpredictable. |
| Important | Success state "به ختم پیوستید." is too terse — it doesn't name which khatm or what to do next. |
| Important | Error state offers "بازگشت به داشبورد" as the only action, not "سعی مجدد". |
| Nice | The auth-card layout is centred, which is correct, but on wide screens it looks isolated without any background texture or brand mark. |

### Recommended fixes
- Show the khatm title in the success state: "به ختم «…» پیوستید."
- Add a confirmation step if the token is valid: "آیا می‌خواهید به این ختم بپیوندید؟" (single tap on accept).
- Add a retry button on error.

---

## 7. Cross-cutting concerns

### Missing globally
| P | Finding |
|---|---------|
| Critical | No global error boundary — a JS error in one component crashes the entire page with a blank white screen. |
| Critical | `--ks-space-5` is used in `globals.css` (`.khatm-card { padding: var(--ks-space-5) }`) but is not defined in `tokens.css`. CSS falls back to zero padding. |
| Critical | No `--ks-color-error` token defined. Error/danger states use warning amber which is semantically incorrect. |
| Important | No `btn-danger` class for destructive actions — "اعلام پایان ختم" uses plain `btn` which looks the same as neutral actions. |
| Important | Help popover (`help-popover`) is `position: absolute` with `translate: -50%` on the inline-start anchor. On mobile RTL it clips outside the viewport when the button is near the inline-end edge. |
| Important | No visible page loading indicators between route transitions (Next.js client navigation). |
| Nice | The `wordmark::before` gradient still uses the old green scale variables in its hardcoded stop (`var(--ks-green-800)`). After the palette change this will be broken. |
| Nice | No `prefers-reduced-motion` guard on the progress bar transition. (Base CSS reduces other transitions but not this one.) |
