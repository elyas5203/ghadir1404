# Product Gap Analysis — 2026-09-11

> What is missing before a meaningful public launch. Prioritised by impact.
> This is a planning document — nothing here is implemented yet.

---

## Must have before launch

### 1. OPEN khatm completion gate is broken

**Gap:** `KhatmNotCompletableError` is always thrown for OPEN khatms because the
completion check requires `all portions COMPLETED` — but OPEN khatms have no portions.
A creator cannot formally close an OPEN khatm through the UI.

**Fix:** In `KhatmWorkflowService.completeKhatm`, check the khatm type: OPEN khatms
should be completable by the owner at any time (no portion requirement).
Optionally add a goal check if a goal field is introduced.

### 2. No user profile / display name

**Gap:** Participants appear as truncated UUIDs in the creator's management UI.
Creators cannot identify who is who. This makes the product unusable for real groups.

**Fix:** Add a `displayName` optional field to the user domain (or a separate profile
table). Show the display name in participant lists and portion assignments.
Until then, show join order ("شرکت‌کننده ۱") and join date.

### 3. No notifications / reminders

**Gap:** Once a user joins a khatm and receives a portion, the app has no way to
remind them. The Telegram bot is the only async channel, but only if the user is
a Telegram user.

**Fix short-term:** Telegram bot command `/my_portions` to list current assignments.
**Fix long-term:** Scheduled reminders via Telegram or SMS when a portion is ASSIGNED
for more than N days without being completed.

### 4. Self-service onboarding: the first screen after login is confusing

**Gap:** A new user logging in for the first time sees a dashboard with two empty
sections and no guidance. There is no first-run experience.

**Fix:** Add an onboarding card/banner that appears when both lists are empty:
"ختم تازه بسازید یا با لینک دعوت به یک ختم بپیوندید."

### 5. Creator self-service elevation (DEC-0070)

**Gap:** DEC-0070 says every authenticated user may become a Creator in MVP.
But the CREATOR capability grant is currently manual (internal `grantCapability`).
No `POST /api/me/become-creator` endpoint exists.

**Fix:** Implement `POST /api/me/become-creator` that grants CREATOR to the
calling authenticated user, as planned in Phase 14.

---

## Should have before launch

### 6. Self-allocation ("درخواست سهم")

**Gap:** Creators must manually assign each portion to each participant via
a UUID-dropdown form. For a group of 30 participants this takes 30 manual steps.

**Fix:** Allow participants to claim an open portion themselves with a single tap
("درخواست سهم" button). The creator optionally reviews and approves.

### 7. Smart allocation plan defaults

**Gap:** The plan form defaults to `total=1000, chunk=100`. For a Quran Full khatm
this is wrong (should be 30 جزء). Users who do not understand the model will
create nonsensical plans.

**Fix:** Auto-detect `templateType` and pre-fill sensible defaults:
- `QURAN_FULL` → total=30, chunk=1, kind=POSITIONAL
- `QURAN_JUZ` → total=1, chunk=1
- `SALAWAT` → total=1000, chunk=100, kind=QUANTITY
- `CUSTOM` → leave blank, user enters

### 8. Progress is not visible to participants

**Gap:** Participants can see their own portions but not the group progress bar.
A participant joining a khatm has no sense of how the group is doing.

**Fix:** Show the overall progress bar to all authenticated participants on the
khatm detail page, not just the creator.

### 9. Contribution unit (OPEN khatm)

**Gap:** `OpenContribution.amount` has no unit. Two participants recording "10"
may mean آیه and جزء respectively. The aggregate sum is meaningless.

**Fix:** Add a `unit` field (enum: `PAGE`, `VERSE`, `JUZ`, `COUNT`) at the khatm
level so all contributions use the same unit.

### 10. Stuck-portion recovery

**Gap:** If a participant who holds an ASSIGNED portion leaves the khatm, the
portion is permanently ASSIGNED with no path to OPEN or re-assignment.

**Fix:** Creator can force-release a portion back to OPEN, or re-assign it to
another participant.

### 11. Invitation link sharing

**Gap:** The invitation link is copied to clipboard silently. On mobile, clipboard
access often fails (permission denied or not available in WebView). The UI falls
back with no indication that the copy failed.

**Fix:** Show the full URL in a text field (copyable). Add a native Web Share API
fallback (`navigator.share`) for mobile.

---

## Future (post-launch)

### 12. Payment / sadaqah integration

A khatm can be linked to a charity donation goal. Each completed portion
contributes a defined amount. Requires a payment gateway and a donation ledger.

### 13. Analytics for creators

Creators need to see: who has completed, who is slow, time-to-completion per
portion, overall khatm duration. Currently there is no analytics endpoint.

### 14. Bale channel support

Bale is heavily used in Iran. The telegram adapter is vendor-neutral but Bale
provisioning (webhook, bot token) is not yet configured or tested.

### 15. Admin panel

No web admin yet. Internal operations (grant CREATOR manually, view audit log,
impersonate) are done via direct database access. An admin web app is needed
before the team grows beyond 2-3 people.

### 16. Public khatm discovery

Currently all khatms are private (invitation-only). A future model allows
public khatms that anyone can find and join without an invitation.

### 17. Recurring khatm templates

A creator defines a recurring structure ("every Ramadan, auto-create a new
30-participant khatm"). Requires a scheduler and a khatm-template domain entity.

### 18. Group profiles

Display names, avatars, group history across multiple khatms. Required for
any community-facing feature.
