# DATABASE

## Status

**Khatm allocation engine is in place (Phase 4.1, 2026-09-07).**
`khatm_allocation_plans` and `khatm_portions` exist, created by the **fifth**
reviewed migration `20260907004303_khatm_allocation_engine` (a hand-written partial
unique index appended for positional non-overlap). It is **additive** — the Phase-4
tables (`khatms`, `khatm_participations`, `assignments` — migration four) are
**unchanged** (the Phase-4.1 migration ALTERs none of them). Underneath are the
identity models (`users`, `platform_identities` — Phase 2B), the phone-verification
models (`phone_claims`, `otp_challenges` — Phase 3A), and the account-merge
foundation (`account_merges`, `users.status`/`merged_into_id` — Phase 3B), all
unchanged. Not yet present: reminders/scheduling, payments/wallet, admin.

## Decided

- **PostgreSQL** is the primary database (DEC-0031).
- **Prisma** is the ORM and migration tooling, pinned **exactly** to `7.10.0`
  (`@prisma/client`, `prisma`, `@prisma/adapter-pg`; `pg@8.23.0`). "Prisma 8" was
  the project-manager's stated intent, but no stable Prisma 8 exists yet (npm
  `latest` was `8.0.0-rc.13`, an RC, on 2026-09-05) and RC packages are
  forbidden, so the current stable Prisma line (7.10.0) is used and Prisma 8 will
  be adopted at GA (DEC-0031).
- Prisma is **confined to `apps/api/src/infrastructure/database`**. Its generated
  client and types never leak into domain code (DEC-0031).
- Container data lives in **Docker named volumes**, never bind-mounted into
  `/mnt/z` (DEC-0030).
- Wallet accounting will use an **append-only ledger**; balance is a derived
  projection (DEC-0024).
- Old operational and history data is **archived, not routinely deleted**
  (DEC-0025).
- Each Khatm stores a **canonical timezone** for day boundaries and deadlines
  (DEC-0016).

## Tables (as of Phase 2B)

Migration `20260906062900_identity_foundation` created:

- **`users`** — `id uuid PK`, `created_at timestamptz default now()`,
  `updated_at timestamptz`. Identity-foundation fields only; `id` is an
  application-generated UUIDv7 (DEC-0032). No profile columns, no status column.
- **`platform_identities`** — `id uuid PK`, `user_id uuid`, `platform` (enum
  `platform`: `TELEGRAM`, `BALE`), `subject text`, timestamps.
  - **`UNIQUE (platform, subject)`** — one external identity → at most one user.
  - **index on `user_id`** — for lookups of a user's links.
  - **FK `user_id` → `users(id)` ON DELETE CASCADE**.

The `updated_at` columns are maintained by Prisma (`@updatedAt`); every write goes
through Prisma. `_prisma_migrations` now tracks applied migrations.

## Tables (added Phase 11, migration `20260908004812_khatm_invitations`)

Participant invitations (DEC-0068). All-CREATE; no ALTER to existing tables.

- **`khatm_invitations`** — `id uuid PK`, `khatm_id uuid` (FK → `khatms`, **RESTRICT**,
  indexed), `created_by_user_id uuid` (FK → `users`, RESTRICT — the issuing owner),
  `token_hash text` **UNIQUE** (SHA-256 of the opaque invite token; never the raw
  token), `expires_at`, `accepted_at timestamptz?`, `accepted_by_user_id uuid?`
  (FK → `users`, RESTRICT), `cancelled_at timestamptz?`, `created_at`. Status
  (CREATED/ACCEPTED/EXPIRED/CANCELLED) is **derived** from the timestamps in the
  domain — not a stored column. History is preserved (accept/cancel stamp a time).

## Tables (added Phase 10, migration `20260907201909_phone_login_purpose`)

Additive enum value `PHONE_LOGIN` on `otp_purpose` (DEC-0066) — the user-less
phone-first login possession-proof challenge (`user_id` null). No table change.

## Tables (added Phase 7, migration `20260907081109_authorization_capability_foundation`)

The authorization capability model (DEC-0062). All-CREATE; **no ALTER** to any
existing table (only a virtual Prisma back-relation on `User`).

- **`user_capabilities`** — `id uuid PK`, `user_id uuid` (FK → `users`, **RESTRICT** —
  a grant is a retained authorization record; users are tombstoned not deleted,
  DEC-0045), `type` (enum `capability_type`: `CREATOR`), `granted_at`, `revoked_at
  timestamptz?`. Index on `user_id`. No `updated_at` (mutations are grant/revoke).
  - **Partial unique index** `user_capabilities_active_user_type_key` = `UNIQUE
    (user_id, type) WHERE revoked_at IS NULL` — at most one **active** grant per
    (user, type); revoked rows accumulate as history (hand-written, KI-0012).

Migration review: created via `db:plan`; the partial unique index appended by hand;
SQL reviewed (all CREATE, no ALTER, no data loss); applied via `db:migrate`; `psql`
verified the enum, the FK on-delete = RESTRICT, and the partial index predicate.

## Tables (added Phase 6, migration `20260907071058_session_foundation`)

The authentication/session foundation (DEC-0059/0060). All-CREATE; **no ALTER** to
any existing table (only a virtual Prisma back-relation on the `User` model).

- **`sessions`** — `id uuid PK`, `user_id uuid` (FK → `users`, **CASCADE** —
  ephemeral auth artifact, mirrors `otp_challenges`; users are tombstoned not
  deleted, so it never fires in practice), `token_hash text` **UNIQUE** (the
  **SHA-256 hex of the opaque token — never the raw token**; lookups are by hash),
  `created_at`, `expires_at`, `revoked_at timestamptz?`, `last_used_at timestamptz?`.
  Index on `user_id`. **No stored status column** — ACTIVE/REVOKED/EXPIRED is derived
  from `revoked_at`/`expires_at` in the domain (DEC-0059). No `updated_at` (mutations
  are explicit revoke/touch).

Migration review: created via `db:plan`; SQL reviewed (all CREATE, no data loss, no
ALTER); applied via `db:migrate`; `db:status` up to date; `psql` verified the table,
the unique `token_hash` index, the `user_id` index, and the FK on-delete = CASCADE.

## Tables (added Phase 4.1, migration `20260907004303_khatm_allocation_engine`)

The Khatm allocation engine (DEC-0052, DEC-0053), **additive** — the migration
ALTERs **none** of the Phase-4 tables (only virtual Prisma back-relations were added
to the Khatm/Participation models). All new FKs are **`ON DELETE RESTRICT`**
(verified `confdeltype = r`).

- **`khatm_allocation_plans`** — `id uuid PK`, `khatm_id uuid` (FK → `khatms`,
  RESTRICT, **`UNIQUE`** → one plan per khatm, race-safe generation), `unit_kind`
  (enum `portion_unit_kind`: POSITIONAL/QUANTITY), `total_portions int`, timestamps.
- **`khatm_portions`** — `id uuid PK`, `plan_id uuid` (FK → `khatm_allocation_plans`,
  RESTRICT, indexed), `khatm_id uuid` (FK → `khatms`, RESTRICT, indexed), `sequence
  int`, `unit_kind` (enum `portion_unit_kind`), `unit_start int?`, `unit_end int?`,
  `quantity int?`, `status` (enum `khatm_portion_status`: OPEN/ASSIGNED/COMPLETED,
  default OPEN, indexed), `participation_id uuid?` (FK → `khatm_participations`,
  RESTRICT, indexed — the current holder; null when OPEN), `completed_at timestamptz?`,
  timestamps. `@@unique(plan_id, sequence)`.
  - **Partial unique index** `khatm_portions_positional_unit_key` = `UNIQUE (plan_id,
    unit_start) WHERE unit_kind = 'POSITIONAL'` — **non-overlap** of positional
    portions (DEC-0053; hand-written, KI-0012). Engine positional portions are
    **atomic** (`unit_start = unit_end`), so this is a complete non-overlap guarantee
    without a gist range-exclusion. QUANTITY portions (`unit_start` null) are not
    covered — counts do not overlap.

Migration review: created via `db:plan` (create-only); the non-overlap partial unique
index appended by hand; SQL reviewed (all CREATE — **no `ALTER` on any Phase-4
table**, no data loss); applied via `db:migrate`; `db:status` up to date; `psql`
verified the enums, the 4 FK on-delete actions (all RESTRICT), the partial index
predicate, and that `khatms` still has exactly its 8 Phase-4 columns.

## Tables (added Phase 4, migration `20260906195317_khatm_engine_foundation`)

The Khatm engine foundation (DEC-0048…DEC-0051). All new FKs are **`ON DELETE
RESTRICT`** (DEC-0051, verified `confdeltype = r`). `users` gained no columns — only
the `khatmsCreated` / `participations` back-relations.

- **`khatms`** — `id uuid PK`, `creator_user_id uuid` (FK → `users`, RESTRICT,
  indexed), `title text`, `description text?`, `template_type` (enum
  `khatm_template_type`: QURAN_FULL/QURAN_JUZ/SURAH/SALAWAT/DUA/ZIYARAT/CUSTOM),
  `status` (enum `khatm_status`: DRAFT/ACTIVE/COMPLETED/CANCELLED, default DRAFT,
  indexed), timestamps. A single template **enum**, not a table per prayer type
  (DEC-0019/0048).
- **`khatm_participations`** — `id uuid PK`, `khatm_id uuid` (FK → `khatms`,
  RESTRICT, indexed), `user_id uuid` (FK → `users`, RESTRICT, indexed), `status`
  (enum `participation_status`: ACTIVE/COMPLETED/LEFT/REMOVED, default ACTIVE),
  `joined_at timestamptz default now()`, timestamps. **Partial unique index**
  `khatm_participations_active_khatm_user_key` = `UNIQUE (khatm_id, user_id) WHERE
  status = 'ACTIVE'` — one active participation per user per khatm (DEC-0050;
  hand-written, KI-0012). Terminal statuses accumulate as history.
- **`assignments`** — `id uuid PK`, `khatm_id uuid` (FK → `khatms`, RESTRICT,
  indexed), `participation_id uuid` (FK → `khatm_participations`, RESTRICT, indexed),
  `unit_kind` (enum `assignment_unit_kind`: POSITIONAL/QUANTITY), `unit_start int?`,
  `unit_end int?`, `quantity int?`, `status` (enum `assignment_status`:
  PENDING/COMPLETED, default PENDING, indexed), `completed_at timestamptz?`,
  timestamps. The Portion is **flattened**: POSITIONAL populates `unit_start`/
  `unit_end` (quantity null); QUANTITY populates `quantity` (bounds null) — the
  domain value object enforces exactly one shape (DEC-0049). Progress is **derived**
  by counting; there is no stored progress column.

Migration review: created via `db:plan` (create-only); the participation partial
unique index appended by hand; SQL reviewed (all CREATE/ALTER ADD — **no DROP, no
data loss**); applied via `db:migrate`; `db:status` up to date; `psql` verified the
enums, the 5 FK on-delete actions (all RESTRICT), and the partial index predicate.

> **Drift caveat (KI-0012):** the `khatm_participations` partial unique index is not
> in `schema.prisma`; a future `prisma migrate dev` diff may emit a `DROP` for it
> that must be removed in review. `migrate deploy`/`migrate status` are unaffected.

## Tables / changes (added Phase 3B foundation, migration `20260906120252_account_merge_foundation`)

Schema + persistence foundation for account merge — **the merge use-case is NOT
implemented** (see DEC-0040…0046).

- **`users`** gained **`status`** (`user_status` enum `ACTIVE`/`MERGED`, default
  `ACTIVE`; DEC-0040) and **`merged_into_id uuid?`** — a self-FK tombstone pointer
  to the canonical winner (DEC-0041), `ON DELETE RESTRICT`, indexed. A MERGED user
  is retained, never deleted.
- **`account_merges`** — append-only merge audit (DEC-0043): `id`, `winner_user_id`
  + `loser_user_id` (FK → `users`, **RESTRICT**), `verified_e164`,
  `initiating_challenge_id uuid?` (**no FK** — the audit outlives OTP retention),
  `moved_platform_identities`, `moved_phone_claims`, `context`, `created_at`.
  **No `updated_at`** — the record is immutable.
- **`phone_claims`** third partial unique index **`phone_claims_verified_user_key`**
  = `UNIQUE (user_id) WHERE status = 'VERIFIED'` (DEC-0046: one verified phone per
  user), hand-written (KI-0012).
- **FK on-delete strategy applied (DEC-0045):** `platform_identities.user_id`,
  `phone_claims.user_id`, `users.merged_into_id`, and both `account_merges` FKs are
  **`RESTRICT`**; `otp_challenges.user_id` stays **`CASCADE`**. Identity-bearing
  history can no longer be destroyed by a raw user delete — termination goes through
  the (future) audited merge/tombstone path.

Migration review: created via `db:plan` (create-only); the per-user partial unique
index appended by hand; SQL reviewed (all CREATE/ALTER ADD; the only DROPs are the
two FK constraints immediately re-added as RESTRICT — a redefinition, no data loss);
applied via `db:migrate`; `db:status` up to date; `psql` verified columns, enum,
FK actions, and the partial index predicate.

## Tables (added Phase 3A)

Migration `20260906070332_phone_verification_foundation` created:

- **`phone_claims`** — `id uuid PK`, `user_id uuid` (FK → `users(id)` cascade),
  `e164 text` (canonical E.164), `region text?` (ISO alpha-2 metadata),
  `status` (enum `phone_claim_status`: `UNVERIFIED`/`VERIFIED`/`REVOKED`,
  default `UNVERIFIED`), `verified_at timestamptz?`, `revoked_at timestamptz?`,
  timestamps. Plain indexes on `user_id` and `e164`, **plus two partial unique
  indexes** (below).
- **`otp_challenges`** — `id uuid PK`, `user_id uuid?` (FK → `users(id)` cascade,
  nullable for future userless purposes), `e164 text`, `purpose` (enum
  `otp_purpose`: `PHONE_VERIFICATION`), `code_hash text` (keyed HMAC — **never the
  plaintext code**), `attempts int default 0`, `max_attempts int`,
  `expires_at timestamptz`, `consumed_at timestamptz?`, `superseded_at timestamptz?`,
  timestamps. Indexes on `(user_id, e164, purpose)` and `e164`.

### Partial unique indexes (hand-written — the core invariants)

Prisma cannot represent a filtered/partial unique index in `schema.prisma`
(DEC-0034), so these were **appended by hand** to the migration SQL and enforce the
invariants in the **database**, not only in application code:

- `phone_claims_verified_e164_key` — `UNIQUE (e164) WHERE status = 'VERIFIED'`:
  at most **one active verified owner per number, globally**. Makes concurrent
  verification safe — the loser of a race gets a `P2002`, surfaced as a
  merge-required outcome. Unverified duplicates across users are intentionally
  allowed (they are contact data, DEC-0011).
- `phone_claims_active_user_e164_key` — `UNIQUE (user_id, e164) WHERE status <> 'REVOKED'`:
  at most **one active (non-revoked) claim per (user, number)**; revoked history
  accumulates.

> **Drift caveat (KI-0012):** because these indexes are not in `schema.prisma`, a
> future `prisma migrate dev` diff may emit a `DROP` for them — that DROP must be
> removed in review. `migrate deploy` and `migrate status` (the shared/prod path)
> do no drift detection and are unaffected.

## Not decided

- Every other domain table, column, index and constraint (Khatm, ledger, …).
- User profile fields, and any User status/lifecycle (none approved yet).
- The merge **use-case** (moving data, tombstoning, writing the audit) — the
  `account_merges` table and `users` lifecycle columns now exist (above), but no
  code performs a merge yet; a conflict is only detected as `MERGE_REQUIRED`
  (DEC-0037).
- Partitioning and archival mechanics.

## Transaction boundary

Multi-aggregate atomic writes go through the Prisma-free **`UnitOfWork` port**
(`UNIT_OF_WORK`, DEC-0044): `uow.run(work)` runs a Prisma interactive transaction
(commit on success, rollback on throw). The port/token/`TransactionContext` live in
`@khatmsaz/kernel`; the `PrismaUnitOfWork` impl, the `dbClient(prisma, tx?)` router,
and the single `txClient()` unwrap live in infrastructure. **Repositories are
transaction-aware** — methods take an optional `tx?: TransactionContext` and route
writes through `dbClient`. The change-phone flow and the account-merge use-case run
inside `uow.run`, so their multi-row writes commit or roll back together.
- Multi-tenancy shape for future white-label **KhatmSaz** instances (intra-product
  branding — same identity, DEC-0047). This is **not** cross-product: separate future
  products (study/donation bots) are isolated with their own identity (DEC-0047).

## Where persistence lives

```
apps/api/
  prisma.config.ts                    # Prisma 7 tooling config (schema, migrations, datasource url)
  prisma/
    schema.prisma                     # datasource + generator ONLY — no models yet
    migrations/                       # empty until the first domain model (.gitkeep)
    scripts/verify-connection.ts      # `db:verify` — real SELECT 1, never prints the URL
  src/infrastructure/database/
    database.module.ts                # @Global infra module — the only door to persistence
    database.tokens.ts                # DATABASE_PING token + Prisma-free DatabasePing interface
    database-readiness.service.ts     # readiness probe (returns a plain status shape)
    prisma/
      prisma.service.ts               # the single, app-lifetime Prisma client
      generated/                      # generated client — GIT-IGNORED, regenerated on demand
```

The connection string is **validated** by `@khatmsaz/config` (`databaseUrl()`),
which fails fast with a secret-free message when configuration is missing or
malformed. `DATABASE_URL` is the canonical input; when unset it is derived from
the discrete `POSTGRES_*` values (the same ones that drive Docker Compose), so
the credential is not duplicated.

## Module boundary (binding)

- Prisma types stay inside `infrastructure/database`. Consumers depend on the
  abstractions the module exports — today `DatabaseReadinessService` and the
  Prisma-free `DATABASE_PING` probe — not on the generated client.
- Future domain modules depend on **repository interfaces the domain owns**;
  Prisma-backed implementations live here in infrastructure. Generated Prisma
  models are never passed deep into the domain (DEC-0031).

## Connection lifecycle

- One `PrismaClient` for the whole process (never one per request), managed by
  `PrismaService` via NestJS `onModuleInit` (`$connect`) and `onModuleDestroy`
  (`$disconnect`).
- Prisma 7 supplies the runtime connection through a **driver adapter**
  (`@prisma/adapter-pg`); the schema datasource no longer carries a `url`.
- **Malformed configuration fails fast** at startup (`databaseUrl()` throws). A
  database that is merely **unreachable** at startup does **not** crash the
  process — it is logged (without the connection string) and readiness reports
  the database as down until it recovers.

## Health vs readiness

- `GET /health` — liveness only. Never touches the database.
- `GET /health/ready` — runs a real `SELECT 1` with a short (2s) timeout. Returns
  HTTP 200 `{status:"ready",checks:{database:"up"},timestamp}` when reachable and
  HTTP 503 `{...,"not_ready",...,"down"}` when not. The body never exposes
  configuration, the connection string, or credentials.

## Migration workflow (the standard)

Checked-in, reviewable migrations are the project standard. Run scripts from the
repo root (they delegate to the API workspace):

```bash
npm run db:generate     # prisma generate  — emit the client from schema.prisma
npm run db:plan         # prisma migrate dev --create-only — CREATE a migration, do NOT apply
#   → inspect prisma/migrations/<name>/migration.sql and its data-loss implications
npm run db:migrate      # prisma migrate deploy — APPLY reviewed migrations (shared/prod)
npm run db:status       # prisma migrate status — where the DB sits in the graph
npm run db:verify       # real SELECT 1 round-trip (secret-free)
```

`npm run db:migrate:dev` (`prisma migrate dev`) is the local create-and-apply
convenience. `npm run db:push` (`prisma db push`) is a **local-only disposable**
convenience — it reconciles the schema without a migration file and is **never**
the production strategy.

> These are Prisma **7** command names. Do not substitute the Prisma 8 RC command
> surface (`orm init`, `contract emit`, `migration plan`, `db migrate`) — it is
> not the toolchain in use. Revisit at the Prisma 8 GA upgrade.

## The first migration (Phase 2B)

`20260906062900_identity_foundation` is the first reviewed, checked-in migration.
It was produced by following the recorded policy exactly: schema updated →
`db:generate` → `db:plan` (`migrate dev --create-only`, **not applied**) → the
generated SQL reviewed (all `CREATE`, no `DROP`, no data loss; the unique
`(platform, subject)` index and the `user_id` FK verified) → `db:migrate`
(`migrate deploy`) → `db:status` ("up to date") and direct `psql` verification →
tests. `db push` was **not** used.

## Identity capability layout (Phase 2B)

```
apps/api/src/identity/
  domain/            # Prisma-free: User, PlatformIdentity, Platform, errors,
                     # identity-id (UUIDv7), and the repository PORTS (interfaces + tokens)
  application/       # IdentityService use-cases (Prisma-free)
  infrastructure/    # Prisma-backed repositories + mapper (the ONLY Prisma here)
  identity.module.ts # binds the ports to the Prisma implementations
```

The domain owns the repository interfaces; the Prisma implementations depend on
`PrismaService` and translate Prisma error codes (`P2002`/`P2003`) into domain
errors. No Prisma-generated type crosses out of `identity/infrastructure`.

## Phone capability layout (Phase 3A)

```
apps/api/src/phone/
  domain/            # Prisma- AND vendor-free: PhoneNumber (E.164), PhoneClaim +
                     # PhoneClaimStatus, OtpChallenge + OtpPurpose, errors, the
                     # verification-outcome union, and PORTS — PhoneNormalizer,
                     # OtpCodeGenerator, OtpCodeHasher, OtpDelivery, Clock, and the
                     # two repositories (+ DI tokens)
  application/       # PhoneVerificationService use-cases (Prisma-free)
  infrastructure/    # Prisma repositories + mapper, libphonenumber-js normalizer,
                     # CSPRNG generator, HMAC hasher, no-op delivery adapter, system
                     # clock, Prisma-error helper (the ONLY Prisma/phone-lib here)
  phone.module.ts    # binds ports → implementations (normalizer & hasher via
                     # useFactory: they take a config string, not a provider)
```

Same shape as identity: the domain owns the interfaces; Prisma, `libphonenumber-js`,
and the (future) SMS provider live only behind infrastructure bindings. Repositories
translate `P2002` (including the partial unique indexes) / `P2003` / `P2025` into
domain errors; no Prisma-generated type crosses out of `phone/infrastructure`.

## Khatm capability layout (Phase 4)

```
apps/api/src/khatm/
  domain/            # Prisma-free: Khatm (+ lifecycle), KhatmStatus, KhatmTemplateType,
                     # Participation (+ ParticipationStatus), Assignment (+
                     # AssignmentStatus), Portion (POSITIONAL/QUANTITY) value object,
                     # errors, and the three repository PORTS (+ DI tokens)
  application/       # KhatmService use-cases (Prisma-free; no UnitOfWork — single-write ops)
  infrastructure/    # Prisma repositories + mapper + Prisma-error helper (the ONLY
                     # Prisma here); guarded status transitions
  khatm.module.ts    # binds ports → Prisma implementations
```

Same shape as identity/phone: the domain owns the interfaces and the lifecycle
rules; Prisma lives only behind infrastructure bindings. Repositories translate
`P2002` (the participation partial unique index) / `P2003` (FKs) into domain errors,
and apply lifecycle transitions as guarded `updateMany`s keyed on the prior status;
no Prisma-generated type crosses out of `khatm/infrastructure`. No transport surface
(no controller/bot) this phase.

## Allocation-engine capability layout (Phase 4.1)

```
apps/api/src/allocation/
  domain/            # Prisma-free: AllocationPlan, PlanPortion (+ PortionStatus),
                     # PortionSpec (+ PortionUnitKind), generatePortions(PlanSpec),
                     # errors, the two repository PORTS + the KhatmStateReader read
                     # port (+ DI tokens)
  application/       # AllocationService use-cases (Prisma-free; multi-row ops in UnitOfWork)
  infrastructure/    # Prisma repositories + mapper + Prisma-error helper, and the
                     # PrismaKhatmStateReader (read-only Phase-4 khatm-table access)
  allocation.module.ts # binds ports → Prisma implementations
```

Self-contained and **additive**: it binds its own domain-owned ports, imports **no**
Phase-4 domain, and reaches Phase-4 khatm/participation state only through its own
`KhatmStateReader` port (implemented by reading the khatm tables via Prisma in the
engine's infrastructure — the one, read-only coupling). The global `DatabaseModule`
supplies `PrismaService` and `UNIT_OF_WORK`. Repositories translate `P2002` (the
one-plan-per-khatm unique and the non-overlap partial unique) / `P2003` (FKs) into
domain errors, and apply portion transitions as guarded `updateMany`s. No transport
surface this phase.

## Local development

PostgreSQL 17 (`postgres:17-alpine`) is defined in
`infra/docker/docker-compose.yml`, bound to `127.0.0.1:5432`, data in the named
volume `postgres-data`. Bring the stack up with `npm run infra:up` (it reads the
repo-root `.env`). Verified running on 2026-09-05 (PostgreSQL 17.11).

## Rule for future sessions

Do not create tables or migrations opportunistically. Schema work begins in the
phase that calls for it. Follow the migration-review policy above; never use
`db push` as a shared-environment deployment strategy.
