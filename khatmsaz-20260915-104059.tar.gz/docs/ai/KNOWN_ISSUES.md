# KNOWN_ISSUES

Sections are stable: **Active**, then **Resolved**. Resolved issues stay in the
file so they remain traceable.

---

## Active

### KI-0012 — Partial unique indexes are not in `schema.prisma` (Prisma limitation)

- **Type:** Active — migration hygiene, low severity, well-contained
- **Detail:** The two phone-claim invariants are enforced by **partial unique
  indexes** (`phone_claims_verified_e164_key` — `WHERE status = 'VERIFIED'`;
  `phone_claims_active_user_e164_key` — `WHERE status <> 'REVOKED'`). Prisma 7
  cannot express a filtered/partial unique index in `schema.prisma`, so they were
  appended by hand to migration `20260906070332_phone_verification_foundation`
  (DEC-0034). Because they are absent from the schema, a future
  `prisma migrate dev` / `db:plan` diff will see them as "extra" and generate a
  `DROP INDEX` for them.
- **Impact:** `prisma migrate deploy` (`db:migrate`) and `prisma migrate status`
  (`db:status`) — the shared/production path — do **no** drift detection and are
  unaffected. Only interactive `migrate dev` diffs are affected.
- **Workaround / rule:** When authoring the **next** migration that touches
  `phone_claims`, review the generated SQL (policy step 5) and **remove any DROP of
  these two indexes** before applying — re-add them if a column they cover changes.
  This is exactly the reviewed-migration policy in `docs/ai/DATABASE.md`.
- **Planned fix:** None needed while the invariant must stay partial. Revisit at the
  Prisma 8 GA upgrade in case filtered unique indexes become expressible in-schema.

### KI-0005 — ESLint has no Next.js-specific rules

- **Type:** Active — low severity
- **Detail:** `apps/web` and `apps/admin` use `typescript-eslint` only.
  `eslint-config-next` was deliberately omitted from the bootstrap to avoid an
  unverified flat-config integration.
- **Workaround:** Type checking plus the framework's own build warnings cover
  most of the gap. Confirmed harmless in Phase 1.1: `next build` runs its own
  TypeScript pass and both apps lint and build clean.
- **Planned fix:** Add `eslint-config-next` once its flat-config shape is
  confirmed against Next 16.3.4.

### KI-0010 — `prisma` CLI devDependency carries 4 high-severity advisories

- **Type:** Active — dependency audit, dev-tooling only, not runtime-reachable
- **Detail:** `npm audit` reports 4 high advisories, all in the transitive tree
  of the pinned **`prisma@7.10.0` CLI (a devDependency)**: `mysql2@3.15.3` (a
  MySQL driver the CLI bundles — auth-downgrade credential leak + decompression
  bomb) and `deepmerge-ts` (stack exhaustion) via `@prisma/config`. `npm ls
  mysql2` confirms the only path is `apps/api → prisma → mysql2`.
- **Reachability:** KhatmSaz uses **PostgreSQL** via `@prisma/adapter-pg` + `pg`;
  `mysql2` is **never loaded** at runtime, and `prisma`/`mysql2` are not in the
  production dependency set. The runtime client (`@prisma/client`) is clean.
- **Workaround:** None required — the vulnerable code paths are not exercised.
- **Planned fix:** Adopt the next `prisma` 7.x patch (or Prisma 8 GA) that bumps
  the transitive deps. Do **NOT** run `npm audit fix --force`: its only offered
  fix downgrades `prisma` to `6.19.3`, reversing DEC-0031. An npm `overrides`
  pin of `mysql2`/`deepmerge-ts` is possible but was declined to avoid perturbing
  the pinned, tested toolchain for an unreachable advisory.

### KI-0011 — Docker daemon proxy blocks pulls; `DOCKER_INSECURE_NO_IPTABLES_RAW`

- **Type:** Active — local development environment, not code; not production-safe
- **Detail:** Two local-daemon facts observed in Phase 2A:
  1. The Docker **daemon** has `HTTP(S) Proxy = http://127.0.0.1:12334` baked in
     (from Docker Desktop). That address is the WSL/Windows proxy, which the
     daemon's own VM cannot reach, so `docker pull` fails with
     `proxyconnect … connection refused`. WSL itself reaches the proxy fine.
  2. `docker info` reports `WARNING: DOCKER_INSECURE_NO_IPTABLES_RAW is set`.
- **Workaround (used, safe):** Images were fetched in WSL over the working proxy
  with `crane` (a static, no-sudo binary) and imported via `docker load`; then
  `npm run infra:up` starts the stack from the now-local images. No Docker Desktop
  reconfiguration was performed (out of scope for this task).
- **Production note:** `DOCKER_INSECURE_NO_IPTABLES_RAW` weakens iptables
  handling and is a **development-only** posture — it must never be treated as an
  acceptable production configuration.
- **Planned fix:** Correct the Docker Desktop proxy setting (or clear it) so the
  daemon pulls directly; treat the iptables warning as a host-hardening item for
  whoever operates the production Docker host — not solved here.

### KI-0008 — Kit local marketplace uses a machine-specific path

- **Type:** Active — low severity (portability)
- **Detail:** The `claude-project-kit` local marketplace is registered in
  `.claude/settings.json` with an absolute path
  (`/home/elyas/KhatmSaz/tooling/claude-project-kit`). A fresh clone at a
  different path would not resolve the `project-kit` plugin until re-registered.
- **Workaround:** Works as-is on this machine (verified via `claude plugin
  details`).
- **Planned fix:** `tooling/claude-project-kit/install.sh` re-registers the local
  marketplace with the correct path per checkout — run it once per machine/clone.

### KI-0009 — security-guidance Stop/commit hooks add per-turn review cost

- **Type:** Active — informational
- **Detail:** The `security-guidance` plugin runs an LLM-powered diff review on
  Stop and on commit. It is valuable (catches secrets/injection) but adds work
  each time the session stops or commits, which can feel slow.
- **Workaround:** Disable just for you if it interferes:
  `claude plugin disable security-guidance@claude-plugins-official --scope local`.
- **Planned fix:** None needed; keep enabled unless it proves disruptive. New
  plugins (including this one) only activate on the next Claude Code session.

---

## Resolved

### KI-0007 — Docker daemon unavailable in this WSL distro — RESOLVED 2026-09-05

Docker Desktop **WSL integration is now active** for the Ubuntu 24.04 distro.
Verified in Phase 2A: `docker ps`, `docker compose … config` and `… up -d` all
work; the Postgres/Redis/MinIO stack was brought up and health-checked live
(PostgreSQL 17.11 `SELECT 1`, Redis `PONG`, MinIO 200). Two *new* local-daemon
environment concerns surfaced separately and are tracked as **KI-0011** (a dead
proxy baked into the daemon that blocks `docker pull`, worked around via
`crane` + `docker load`; and `DOCKER_INSECURE_NO_IPTABLES_RAW`).

### KI-0001 — Phase 1 install/build/lint/test — RESOLVED 2026-09-04

The full gate was run on the developer machine (WSL Ubuntu 24.04, Node
v24.20.0). `npm install`, `npm run typecheck`, `npm run lint`, `npm test`,
`npm run test:e2e -w @khatmsaz/api` and `npm run build` all PASS. The API, web
and admin apps were run and smoke-tested. Recorded in PROJECT_STATE.md and
CHANGELOG.md.

### KI-0002 — Dependency versions unverified — RESOLVED 2026-09-04

First authoritative `npm install` resolved every caret range without conflict or
any manual version change: `next@16.3.4`, `react@19.2.8`, `@nestjs/core@11.2.3`,
`typescript@5.9.3`, `typescript-eslint@8.69.0`, `eslint@9.39.5`, `jest@29.x`,
`ts-jest@29.x`. 0 vulnerabilities. `package-lock.json` committed to the tree.

### KI-0003 — Dev environment unverified — RESOLVED 2026-09-04

Verified: Ubuntu 24.04 / WSL2, Node v24.20.0, npm 11.19.0, Git 2.43.0. Ports
3000, 3001, 3002, 5432, 6379, 9000, 9001 all free before testing. Docker daemon
state tracked separately as KI-0007. Recorded in PROJECT_STATE.md.

### KI-0004 — Git not initialised — RESOLVED 2026-09-04

`git init -b main`; full tree staged with `git add -A` (`.env` and
`node_modules`/build output confirmed not staged). Repo-local identity set to
`Amirali Raeesi <raeesiamirali86@gmail.com>` (local scope only, not global) at
the user's explicit request, and the initial commit
`chore: bootstrap khatmsaz workspace` was created (`38bbee8`).

### KI-0006 — `.claude/rules/` and `.npmrc` staged, not in place — RESOLVED 2026-09-04

Both are now in place at the repository root (`.claude/rules/` holds the six
rule files; `.npmrc` with `engine-strict` is active). The `docs/bootstrap/`
staging directory and `FINISH_SETUP.md` have been removed.
