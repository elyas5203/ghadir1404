# CHANGELOG

## 2026-09-15 — Sprint 10: Invite Endpoint + Khatm Detail + Admin Panel Completion

**Invite slug endpoint:**
- `GET /api/khatms/:id/invite-slug`: creator-only, returns `{ slug, url }`. Enforces ownership (403 on mismatch). Uses `APP_URL` env for URL construction.
- `KhatmRepository.countByStatus`, `PrismaKhatmRepository` implementation, `KhatmService.countActiveKhatms` added.

**Admin API:**
- `GET /admin/stats` now returns `activeKhatms`.
- `GET /admin/users`: paginated endpoint (`page`/`limit`) returning `{ items: UserAdminDto[], total }` with `mobileMasked` and `khatmCount`. `PhoneModule` added to `http-api.module.ts`; `PHONE_CLAIM_REPOSITORY` injected `@Optional()` in `AdminController`.

**Web khatm detail page (Part 2):**
- "لینک دعوت دائمی" card shown for creator + ACTIVE khatms. "دریافت لینک" button fetches slug endpoint; copyable input + "کپی" button appear on success.

**Dashboard quick-mark (Part 3):**
- Joined OPEN+ACTIVE khatm cards now have `+ ثبت مشارکت` button outside the link element. Posts `{ amount: 1 }` to contributions endpoint; shows "ثبت شد" for 3 s.

**Admin panel (Part 4):**
- `apps/admin/src/app/users/page.tsx`: New page using `GET /api/admin/users` — paginated table with masked mobile, khatm count, status badge, link to customer detail.
- Admin nav: "کاربران" → `/users`; "مدیریت کاربران" → `/customers`.
- Dashboard: third stat card "ختم‌های فعال" added.

---

## 2026-09-14 — Sprint 9: OTP Wizard Tests + Public Join Page + Invite Slug

**OTP wizard unit tests (Parts 1 + 1b):**
- `telegram-command.service.spec.ts`: 10 new test cases in `describe('OTP account linking')` — covers all link:phone/link:otp/join:token paths including invalid formats, failCount, 3× lockout.
- `bale-command.service.spec.ts`: New file with 10 parallel Bale OTP wizard tests. Verifies `Platform.BALE` is used in `linkUser` call.

**Public web join page (Part 2):**
- `apps/web/src/app/join/[slug]/page.tsx`: Server component — fetches public khatm by slug, renders progress/niyyat, generates OpenGraph metadata, shows inactive status message.
- `apps/web/src/app/join/[slug]/join-client.tsx`: Client component — authenticated users get a "پیوستن به ختم" button that calls `POST /api/khatms/:id/join`; unauthenticated users get "ورود به حساب" link with `?next=` redirect.

**Invite slug (Part 4):**
- `KhatmRepository` interface: `setPublicSlug(id, slug)` method added.
- `PrismaKhatmRepository.setPublicSlug`: single `prisma.khatm.update` implementation.
- `KhatmService.getOrCreateInviteSlug(khatmId)`: returns existing `publicSlug` or generates a 10-char base58 slug via `crypto.getRandomValues` and persists it.
- `FakeKhatmRepository` in test updated to implement `setPublicSlug`.

**Batch progress (Part 3):** Already done in a prior sprint — confirmed no-op.

**Tests:** 397 API + 10 web = 407 total pass. Typecheck / Lint / Build all PASS.

---

## 2026-09-14 — Sprint 8: Bot /start OTP Account Linking + Full Command Set

**OTP account linking in /start (both Telegram and Bale bots):**
- New wizard steps: `link:phone` (validate Iranian mobile, request SMS OTP), `link:otp` (verify code, link PlatformIdentity to phone-derived userId, max 3 failures), `join:token` (accept invitation token as free text).
- `/join` without a token now starts the `join:token` wizard step instead of showing a usage message.
- `BotSharedModule` imports `SessionModule` and re-exports it so `PhoneAuthService` is available in both bot modules.
- `BotUserResolverService.linkUser(userId, platform, chatId)` added — attaches PlatformIdentity after OTP verification.
- `PhoneAuthService.linkByPhoneOtp(phone, code)` — verifies OTP and returns userId without creating an HTTP session.
- `wizard-state.types.ts` extended with the three new wizard-step variants.
- `TelegramCommandService` and `BaleCommandService`: `PhoneAuthService` and `BotUserResolverService` injected as `@Optional()`.

**Web app cleanup (QURAN_FULL/JUZ stale references):**
- `apps/web/src/lib/labels.ts`: removed QURAN_FULL/JUZ from TEMPLATE_LABEL, TEMPLATE_ICON, TEMPLATE_EXPLAIN.
- `apps/web/src/app/khatms/create/page.tsx`: removed QURAN_FULL/JUZ from filter.
- `apps/web/src/app/khatms/[id]/page.tsx`: removed dead QURAN_FULL default-spec branch.

**Tests:** 377 pass. Typecheck / Lint / Build all PASS.

---

## 2026-09-14 — Sprint 7: QURAN_FULL/JUZ removal, SNOOZE notification, BotSharedModule

**QURAN_FULL and QURAN_JUZ removed:**
- Dropped from `KhatmTemplateType`, `KhatmTemplateTypeDto`, Prisma schema enum, both bot command services.
- Migration `20260914000000_remove_quran_full_juz`: converts remaining rows to CUSTOM, recreates enum without those values.
- SURAH is now the simplest single-page Quran commitment template.
- 8 test files updated: specs using QURAN_FULL replaced with SURAH or SALAWAT.

**SNOOZE notification callback:**
- `NotificationScheduler.snoozeNotification(participationId, platform, chatId, delayMs)` added to domain interface.
- `BullmqNotificationScheduler.snoozeNotification` enqueues a delayed 'snooze' job.
- `NotificationProcessorService` handles 'snooze' jobs: resolves khatm via participationId, sends reminder with inline keyboard.
- Daily reminder messages now include `[✅ ثبت تلاوت | 🔔 بعداً یادآوری]` inline keyboard.
- `SNOOZE:<participationId>` callback dispatched from both `TelegramCommandService` and `BaleCommandService`; schedules 2-hour delay.

**BotSharedModule:**
- `apps/api/src/bot-shared/bot-user-resolver.service.ts` — `resolveUser(platform, chatId)` + `provisionUser(platform, chatId)` using PlatformIdentity.
- `apps/api/src/bot-shared/bot-shared.module.ts` — exported; imported by TelegramModule and BaleModule.

**Module wiring:**
- `NotificationModule` now exports `NOTIFICATION_SCHEDULER` (was only exporting `NotificationService`).
- `TelegramModule` and `BaleModule` import `NotificationModule` and `BotSharedModule`.
- `NOTIFICATION_SCHEDULER` injected as `@Optional()` in both command services.

## 2026-09-14 — Sprint 6: Notification Processor, Persistent Wizard State, ZarinPal Bot Flow

**BullMQ notification processor:**
- `NotificationProcessorService` created in `notification/infrastructure/`.
- Creates a BullMQ `Worker` on `khatmsaz:notifications`; only started when `REDIS_URL` is set.
- Processes "seed" jobs: expands to per-participation daily reminders.
- Per-participation: checks BANNED/SUSPENDED status, deduplicates via `NotificationLog` (same calendar day), sends via direct Bot API fetch to Telegram or Bale, records `NotificationLog` row on success.
- Retry on seed job: 3 attempts, exponential backoff 5s.
- `notification.module.ts` updated to conditionally provide processor.
- `npm install` run: `bullmq` package was missing from `node_modules` despite being declared; now installed.

**Persistent wizard state:**
- `wizard-state.types.ts`: shared `SessionState` + `WizardDraft` types extracted from command services.
- `wizard-state.service.ts`: `WizardStateStore` interface, `InMemoryWizardStateStore` (in-process), `RedisWizardStateStore` (ioredis, 30-min TTL per key, namespaced by platform).
- `WIZARD_STATE` symbol token; injected `@Optional()` into both command services.
- Both command services replace `Map<>` with `await this.store.*` async calls.
- `TelegramModule` + `BaleModule` provide Redis or in-memory store based on `REDIS_URL`.

**ZarinPal payment top-up in bot:**
- `walletCmd` shows "💳 شارژ کیف‌پول" inline button when payment is configured.
- `WALLET_TOPUP` callback: 3 amount options (10k / 50k / 200k toman).
- `WALLET_TOPUP_AMOUNT:n` callback: creates ZarinPal intent, stores in `PendingPayment`, returns payment link. Verification handled by existing REST `GET /payment/verify` endpoint.
- `ZarinpalService` + `PAYMENT_INTENT_REPOSITORY` added as `@Optional()` constructor args to both command services (positions 7 + 8).

---

## 2026-09-13 — Sprint 5: Functional Bot Journeys

**Menu button routing:**
- `BUTTON_LABELS` + `BUTTON_TO_COMMAND` map added to `telegram/domain/telegram-command.ts`.
- Both `TelegramCommandService` and `BaleCommandService` now route ReplyKeyboard button text to handlers via `BUTTON_TO_COMMAND`.
- "🚫 لغو" clears wizard state and returns to main menu from any step.

**Khatm creation wizard (full journey):**
- Multi-turn wizard state machine (`Map<chatId, SessionState>`) in both command services.
- Template selection via inline keyboard (8 types). Edition selection (3 Quran editions). Surah + repetition count steps. Quantity step for count-based types. Niyyat step with "بدون نیت" button.
- Wizard completion: `createKhatm` → `generateAllocationPlan` (COMMITMENT only) → `activateKhatm` → `createInvitation` → reply with shareable `/join <token>` message.
- Shorthand `/create_khatm TEMPLATE title` still works and does the full flow.

**Context-aware khatm selection:**
- `/my_khatms`: ACTIVE creator khatms show "دعوت‌نامه" + "پایان ختم" inline buttons; joined khatms show "بخش‌هایم" + "پیشرفت" + "خروج" inline buttons.
- `/progress`, `/portions`, `/leave` with no args: show inline list of khatms to pick from.

**Callbacks added:**
- `KHATM_INVITE:<id>` — creator gets a new invite token.
- `KHATM_PORTIONS:<id>` — shows participant's portions.
- `KHATM_PROGRESS:<id>` — shows khatm progress bar.
- `KHATM_LEAVE:<id>` — participant leaves khatm.
- `KHATM_CLOSE:<id>` — creator completes khatm.

**Other improvements:**
- Ban enforcement: inactive users blocked at service entry for all non-`/start` messages.
- Auto-allocation: 1 portion allocated to new participant on join (best-effort).
- Settings wizard: prompts for and saves `reminderHour` via `UserSettingsService`.
- `CallbackReply` extended with `inlineKeyboard` + `replyKeyboard`; gateways forward them.
- `UserSettingsModule` imported in `TelegramModule` and `BaleModule`.
- 377 tests pass (4 new tests added for button routing and wizard).

## 2026-09-13 — Sprint 4: Bot Completion + Admin Panel

**Web app disabled (feature flag):**
- `apps/web/src/middleware.ts` (new): WEB_APP_ENABLED gate; /disabled pass-through; admin routes always accessible
- `apps/web/src/app/disabled/page.tsx` (new): Persian maintenance page with Telegram bot link
- `.env.example`: WEB_APP_ENABLED=false added

**Telegram + Bale bots — full command set:**
- `apps/api/src/telegram/domain/telegram-command.ts`: MENU, LEAVE, PORTIONS, WALLET, HELP, SETTINGS, SUPPORT added
- `apps/api/src/telegram/domain/telegram-message.ts`: ReplyKeyboardButton + replyKeyboard/removeKeyboard on TelegramReply
- `apps/api/src/telegram/infrastructure/bot-api-telegram-sender.ts`: handles reply/remove keyboard
- `apps/api/src/telegram/application/telegram-command.service.ts`: full command set, MAIN_MENU keyboard, WalletService injected
- `apps/api/src/telegram/telegram.module.ts`: PaymentModule imported
- Bale mirrors: same changes in `apps/api/src/bale/`

**SMS OTP wiring:**
- `apps/api/src/phone/infrastructure/sms-otp-delivery.adapter.ts` (new): bridges SmsProvider → OtpDelivery
- `apps/api/src/phone/phone.module.ts`: factory selects Kavenegar/SMS/noop based on config

**User moderation:**
- `apps/api/prisma/migrations/20260913220000_admin_moderation/migration.sql` (new): ALTER TYPE user_status ADD WARNED/SUSPENDED/BANNED, CREATE TABLE audit_logs
- `apps/api/prisma/schema.prisma`: UserStatus enum + audit_logs model
- `apps/api/src/identity/domain/user-status.ts`: WARNED/SUSPENDED/BANNED
- `apps/api/src/identity/domain/user.repository.ts`: search/updateStatus/updateRole
- `apps/api/src/identity/infrastructure/prisma-user.repository.ts`: implements above
- `apps/api/src/identity/application/identity.service.ts`: searchUsers/updateUserStatus/updateUserRole

**Audit logs:**
- `apps/api/src/audit/application/audit.service.ts` (new): log()/list(), failures swallowed
- `apps/api/src/audit/audit.module.ts` (new)
- `apps/api/src/app.module.ts`, `apps/api/src/http-api/http-api.module.ts`: AuditModule imported

**Admin controller expanded:**
- `apps/api/src/http-api/admin/admin.controller.ts`: full moderation, search, grant/revoke CREATOR, promote, audit log endpoints

**Admin panel — fully built (`apps/admin`):**
- `src/middleware.ts`: khatmsaz_session cookie guard → /login
- `src/lib/config.ts`, `src/lib/api-client.ts`, `src/lib/api-error.ts`, `src/lib/auth-context.tsx`
- `src/components/AdminShell.tsx`: topbar + sidebar nav + logout
- `src/app/layout.tsx`: AuthProvider wrap
- `src/app/page.tsx`: redirect to /dashboard
- `src/app/globals.css`: full admin design system
- `src/app/login/page.tsx`, `/dashboard/page.tsx`, `/customers/page.tsx`, `/customers/[id]/page.tsx`
- `src/app/khatms/page.tsx`, `/khatms/[id]/page.tsx`, `/audit/page.tsx`

**Test fixes:**
- `account-merge.service.spec.ts`, `identity.service.spec.ts`: FakeUserRepository stubs for new interface
- `telegram-command.service.spec.ts`: WalletService stub + listMyKhatms/listMyPortions/leaveKhatm mocks

## 2026-09-13 — Sprint 3: Security + Deploy (v1 Launch Ready)

**Security — IDOR + Replay fix (DEC-0083):**
- `apps/api/prisma/schema.prisma`: `PendingPayment` model + back-relation on User
- `apps/api/prisma/migrations/20260913200000_add_pending_payment/migration.sql`
- `apps/api/src/payment/domain/payment-intent.repository.ts` (new port)
- `apps/api/src/payment/infrastructure/prisma-payment-intent.repository.ts` (new impl)
- `apps/api/src/payment/infrastructure/payment.controller.ts`: createPayment persists intent; verifyPayment uses stored userId/amount + atomic CAS; no session trust for charging
- `apps/api/src/payment/infrastructure/zarinpal.service.ts`: rejects code 101
- `apps/api/src/payment/payment.module.ts`: PAYMENT_INTENT_REPOSITORY + PlanService wired

**Feature — Real plan change (DEC-0085):**
- `apps/api/prisma/schema.prisma`: `UserPlan` model + `PlanTier` enum + back-relation on User
- `apps/api/prisma/migrations/20260913210000_add_user_plan/migration.sql`
- `apps/api/src/payment/application/plan.service.ts` (new)
- `apps/api/src/http-api/admin/admin.controller.ts`: setCustomerPlan calls plans.assignPlan()

**Infrastructure:**
- `docker-compose.prod.yml` (new): postgres:16 + redis:7 + api + web services; healthchecks
- `apps/api/Dockerfile` (new): Node 24 Alpine, npm workspaces, prisma migrate deploy on start
- `apps/web/Dockerfile` (new): Node 24 Alpine, standalone Next.js output
- `apps/web/next.config.mjs`: `output: 'standalone'` added
- `apps/api/prisma/seed-admin.ts` (new): ADMIN_PHONE= promote to SUPER_ADMIN via verified PhoneClaim

## 2026-09-13 — Sprint 2: Integration Fixes + Phase 06 Admin + Phase 08 SMS

**Integration fixes:**
- `khatm-workflow.service.ts`: `leaveKhatm()` added (FIX A); `activateKhatm()` calls `NotificationService.onKhatmActivated()` (FIX B)
- `khatm-workflow.module.ts`: imports `WaitingListModule`, `NotificationModule`
- `khatm-workflow.service.spec.ts`: 7 new tests covering FIX A + FIX B
- `.env.example`: all sprint env vars added (FIX C)
- `.ai-guide/INDEX.md`: sprint 2 entry + expanded Key Services table (FIX D)

**Phase 06 — Admin Dashboard:**
- `apps/api/prisma/schema.prisma`: `UserRole` enum + `role` field on `User`
- `apps/api/prisma/migrations/20260913100000_add_user_role/migration.sql`
- `apps/api/src/identity/domain/user.ts`: `UserRole` type + `role` field
- `apps/api/src/identity/infrastructure/identity.mapper.ts`: maps `role`
- `apps/api/src/identity/domain/user.repository.ts`: `listAll`, `countAll` methods
- `apps/api/src/khatm/domain/khatm.repository.ts`: `listAll`, `countAll` methods
- `apps/api/src/identity/infrastructure/prisma-user.repository.ts`: implements `listAll`/`countAll`
- `apps/api/src/khatm/infrastructure/prisma-khatm.repository.ts`: implements `listAll`/`countAll`
- `apps/api/src/identity/application/identity.service.ts`: `listAllUsers`, `countAllUsers`
- `apps/api/src/khatm/application/khatm.service.ts`: `listAllKhatms`, `countAllKhatms`
- `apps/api/src/http-api/admin/admin.guard.ts`: `AdminGuard` checks SUPER_ADMIN
- `apps/api/src/http-api/admin/admin.controller.ts`: 5 admin endpoints
- `apps/api/src/http-api/http-api.module.ts`: `AdminController` + `AdminGuard` + `PaymentModule` import; `PaymentController` moved here
- `apps/api/src/payment/payment.module.ts`: `PaymentController` removed
- `apps/api/src/app.module.ts`: `PaymentModule` removed; `SmsModule` added
- `packages/contracts/src/auth.ts`: `MeResponse.role` field added
- `apps/api/src/http-api/me.controller.ts`: returns `role` from user entity
- `apps/web/src/app/admin/layout.tsx`: role guard + admin nav
- `apps/web/src/app/admin/page.tsx`: platform stats (totalUsers, totalKhatms)
- `apps/web/src/app/admin/customers/page.tsx`: paginated user table
- `apps/web/src/app/admin/khatms/page.tsx`: searchable + paginated khatm table
- `apps/web/test/permissions.spec.ts`: added `role` field to MeResponse stubs

**Phase 08 — SMS System:**
- `packages/config/src/sms.ts`: `smsConfig()`, `smsEnabled()`
- `packages/config/src/index.ts`: exports `sms`
- `apps/api/src/sms/domain/sms.types.ts`: `SmsProvider` interface + `SMS_PROVIDER` token
- `apps/api/src/sms/infrastructure/kavenegar-sms.service.ts`: raw fetch, no SDK, key never logged
- `apps/api/src/sms/infrastructure/noop-sms.service.ts`: no-op for dev
- `apps/api/src/sms/sms.module.ts`: config-gated factory
- `apps/api/src/sms/sms.service.spec.ts`: Kavenegar + Noop unit tests

**Fake repo updates (typecheck compliance):**
- `identity.service.spec.ts`: `FakeUserRepository.listAll`/`countAll`
- `account-merge.service.spec.ts`: `FakeUserRepository.listAll`/`countAll`
- `khatm.service.spec.ts`: `FakeKhatmRepository.listAll`/`countAll`

## 2026-09-12 — Sprint: Foundation Phases 01–07

**packages/config:**
- `redis.ts`: `redisConfig()`, `redisEnabled()`
- `bale.ts`: `baleConfig()`, `baleOutboundEnabled()`
- `zarinpal.ts`: `zarinpalConfig()`

**apps/api schema (additive migrations):**
- `20260912140000_sprint_wallet_waiting_list_settings`: `NotificationJob`, `WaitingList`, `Wallet`, `WalletTransaction`, `UserSettings` + 5 enums
- `20260912150000_khatm_public_slug`: `public_slug` + `niyyat` on `khatms`

**apps/api domain:**
- `khatm.ts`: `publicSlug?`, `niyyat?` added to `KhatmProps` + `Khatm` class
- `khatm.repository.ts`: `findBySlug()` method added
- `prisma-khatm.repository.ts`: `findBySlug()` implementation
- `khatm.service.ts`: `findKhatmBySlug()` added
- `khatm.mapper.ts`: `publicSlug`/`niyyat` in `KhatmRow` + `toKhatm()`

**apps/api new modules:**
- `notification/`: `NotificationModule`, `NotificationService`, `BullmqNotificationScheduler`, `NoopNotificationScheduler`
- `waiting-list/`: `WaitingListModule`, `WaitingListService`, `PrismaWaitingListRepository` + 6 tests
- `payment/`: `PaymentModule`, `WalletService`, `PrismaWalletRepository`, `ZarinpalService`, `PaymentController`
- `bale/`: `BaleModule`, `BaleCommandService`, `BaleGateway`, `BotApiBaleSender`, `NoopBaleSender`, `BaleWebhookController`
- `user-settings/`: `UserSettingsModule`, `UserSettingsService`, `PrismaUserSettingsRepository`

**apps/api http-api:**
- `public-khatm.controller.ts`: `GET /public/khatm/:slug` (no auth)
- `http-api.module.ts`: `AllocationModule` imported; `PublicKhatmController` registered

**apps/api app.module:**
- `BaleModule`, `NotificationModule`, `WaitingListModule`, `PaymentModule`, `UserSettingsModule` registered

**apps/web:**
- `src/app/khatm/[slug]/page.tsx`: public server-component khatm page

**packages/config:**
- `index.ts`: exports `bale`, `redis`, `zarinpal`

**root:**
- `.ai-guide/` created (INDEX, FOLDER-MAP, RELATIONS, BUGS, ROADMAP, DECISIONS)

---

## 2026-09-12 — QURAN-001 follow-up — optional target count for SALAWAT/DUA/ZIYARAT/CUSTOM

**packages/contracts:**
- `src/khatm.ts`: `KhatmSummary` gains top-level `repetitionTarget?: number | null`.

**apps/api:**
- `src/http-api/khatm-view.mapper.ts`: `toKhatmSummary()` now always includes `repetitionTarget`.

**apps/web:**
- `src/app/khatms/create/page.tsx`: optional "هدف تعداد" input for SALAWAT/DUA/ZIYARAT/CUSTOM.
- `src/app/khatms/[id]/page.tsx`: khatm header shows target count when set; `defaultsForKhatm()` pre-fills plan generator from `repetitionTarget` for count types.

---

## 2026-09-12 — QURAN-001 — Two new Quran khatm modes (DEC-0076)

**packages/shared:**
- `src/quran/editions.ts` — NEW: static Quran edition registry (3 editions, page counts, `findQuranEdition`).
- `src/quran/surahs.ts` — NEW: all 114 surahs with Persian names, `findSurah`, `isValidSurahNumber`.
- `src/quran/index.ts`, `src/index.ts` — export the new quran module.

**packages/contracts:**
- `src/khatm.ts`: `KhatmTemplateTypeDto` union + `KHATM_TEMPLATE_TYPES` extended with `QURAN_PAGE`, `QURAN_SURAH`.
- `QuranPageConfigDto`, `QuranSurahConfigDto`, `QuranEditionDto`, `SurahDto` DTOs added.
- `KhatmSummary` extended with optional `quranPageConfig` / `quranSurahConfig`.
- `CreateKhatmRequest` extended with optional `quranEditionId`, `surahNumber`, `repetitionTarget`.

**apps/api:**
- `prisma/migrations/20260912100000_quran_modes/migration.sql` — NEW: adds enum values + nullable columns with CHECK constraints.
- `prisma/schema.prisma`: `QURAN_PAGE`, `QURAN_SURAH` in enum; 3 new nullable fields on Khatm model.
- `src/khatm/domain/khatm-template.ts`: 2 new values.
- `src/khatm/domain/khatm.ts`: `quranEditionId`, `surahNumber`, `repetitionTarget` on `KhatmProps` and `Khatm`.
- `src/khatm/infrastructure/khatm.mapper.ts`: `KhatmRow` and `toKhatm()` pass new fields.
- `src/khatm/infrastructure/prisma-khatm.repository.ts`: `create()` includes new fields.
- `src/khatm/application/khatm.service.ts`: `createKhatm()` accepts new optional fields.
- `src/khatm-workflow/application/khatm-workflow.service.ts`: `CreateKhatmWorkflowInput` extended.
- `src/http-api/khatm-view.mapper.ts`: `toKhatmSummary()` populates `quranPageConfig` / `quranSurahConfig`.
- `src/http-api/dto/khatm-requests.ts`: `parseCreateKhatm()` validates new fields against static registries.
- `src/http-api/quran.controller.ts` — NEW: `GET /api/quran/editions`, `GET /api/quran/surahs`.
- `src/http-api/http-api.module.ts`: `QuranController` registered.
- New tests: `quran-registry.spec.ts`, QURAN-001 suite in `khatm.spec.ts`, updated `khatm-template.spec.ts`, `khatm-requests.spec.ts`.

**apps/web:**
- `src/lib/labels.ts`: `TEMPLATE_LABEL`, `TEMPLATE_ICON`, `TEMPLATE_EXPLAIN` extended; help texts updated.
- `src/app/khatms/create/page.tsx`: edition selector for QURAN_PAGE; surah + repetition target inputs for QURAN_SURAH.
- `src/app/khatms/[id]/page.tsx`: quran config display in header; `GeneratePlan` auto-fills from khatm config.

---

## 2026-09-12 — Phase 18 — Telegram /join + Invitation no-expiry (DEC-0075)

**Domain:**
- `apps/api/src/invitation/application/invitation.service.ts`: `DEFAULT_INVITATION_TTL_SECONDS`
  changed from 7 days to 100 years (effectively indefinite). DEC-0075.

**Telegram transport:**
- `apps/api/src/telegram/domain/telegram-command.ts`: `JOIN` added to `TelegramCommandName`.
- `apps/api/src/telegram/application/telegram-command.service.ts`: `InvitationService` injected;
  `/join <token>` command implemented; InvitationNotFoundError + InvitationNotAcceptableError
  mapped to Persian replies; `unknownCommand` reply updated to include `/join`.
- `apps/api/src/telegram/telegram.module.ts`: `InvitationModule` imported.

**Tests:**
- `apps/api/src/telegram/application/telegram-command.service.spec.ts`: 3 new `/join` unit tests
  + InvitationService mock added; stale retired-/join test replaced.
- `apps/api/test/telegram-webhook.integration-spec.ts`: `/join` integration test covering the
  full path: web user creates khatm → issues invitation → Telegram user /start + /join →
  confirmed joined. Capturing OTP delivery added for owner login.

## 2026-09-12 — Phase 17 — Premium UI/UX Quality Pass

**Design system:**
- `packages/ui/src/tokens.css`: easing curves (`--ks-ease-out/inout/spring`), touch-target tokens
  (`--ks-touch-min` 44px, `--ks-touch-sm` 36px), `--ks-color-surface-raised`.

**Styles (`apps/web/src/app/globals.css`):**
- Form inputs: 48px min height, `text-md` font size, custom easing.
- Buttons: 44px min height (36px for `btn-sm`), spring press scale, easing.
- Field labels: full body color + bold — better for elderly/low-vision users.
- List rows: 44px min height, surface-raised background.
- Alerts: directional start-edge accent stripe (RTL-correct).
- Progress bar: 10px, RTL gradient, ease-out animation.
- HelpTip popover: `position: fixed` — no viewport clipping in any context.
- `.workflow-step` component added for numbered DRAFT workflow steps.
- `.empty-state` improved spacing and icon treatment.

**Components:**
- `apps/web/src/components/help-tip.tsx`: JS-based `getBoundingClientRect` centering,
  viewport clamping, scroll tracking via fixed positioning.

**Pages:**
- `apps/web/src/app/khatms/[id]/page.tsx`: DRAFT section uses `.workflow-steps` layout,
  step ✓ when plan done, activate disabled until plan exists (COMMITMENT only).
- `apps/web/src/app/invitations/accept/page.tsx`: skeleton loading, clearer Persian copy.

## 2026-09-12 — Phase 16 — Core Journey Completion + UI Fixes

**Backend:**
- `apps/api/src/khatm-workflow/application/khatm-workflow.service.ts`: `completeMyPortion` method
  resolves userId → participationId then calls `allocation.completeHeldPortion`.
- `apps/api/src/http-api/khatm.controller.ts`: `POST :id/portions/:portionId/complete` (HTTP 204).
- `apps/api/src/http-api/me.controller.ts`: `GET /api/me` auto-grants CREATOR (DEC-0074).
- `apps/api/src/khatm-workflow/application/khatm-workflow.service.spec.ts`: 2 new tests.

**Frontend:**
- `apps/web/src/lib/api-client.ts` + `auth-context.tsx`: PUT added to method union type.
- `apps/web/src/app/globals.css`: Type selector cards use CSS grid + overflow:hidden to fix RTL
  text cutoff; dashboard cards redesigned as compact single-row mobile layout.
- `apps/web/src/app/dashboard/page.tsx`: KhatmCard uses new `.khatm-card-body` structure.
- `apps/web/src/app/khatms/[id]/page.tsx`:
  - "انجام شد" button for ASSIGNED portions.
  - Allocate dropdown shows `displayName` (not index).
  - DRAFT: GeneratePlan hidden when `progress.total > 0` (plan already exists) — prevents 409.
  - 409 error mapped to Persian message.
  - GeneratePlan smart defaults per template type.
  - DRAFT workflow reordered: plan form → activate button.
- `apps/web/src/app/login/page.tsx`: Persian placeholder (`۰۹×××××××××`), maxLength=11.

## 2026-09-12 — Phase 15 — UI/UX Visual Overhaul

**Design system:**
- `packages/ui/src/tokens.css`: added gold/amber scale (`--ks-gold-*`), semantic gold tokens,
  glassmorphism tokens (`--ks-glass-bg/border/shadow`, `--ks-blur-*`), `--ks-shadow-lg`.
  Dark-mode overrides added for all new tokens.
- `apps/web/src/app/globals.css`: comprehensive visual upgrade — glassmorphism auth card,
  ambient gradient backgrounds (`page-ambient`, `auth-shell`), gradient + shadow primary button,
  sticky blurred app-bar, gradient hero heading, wider help popover (glass), improved
  type-card selection state, better khatm-card hover (lift), improved onboarding banner,
  improved empty state with icon slot, added `badge-primary`, `ks-note-gold`, `type-card-icon`.

**Font loading:**
- `apps/web/src/app/layout.tsx`: added Google Fonts `<link>` tags for Vazirmatn
  (weights 400/500/600/700/800). Font was already in the CSS stack but not fetched.

**Labels & help texts (`apps/web/src/lib/labels.ts`):**
- Added `TEMPLATE_ICON` (emoji per template type).
- Added `TEMPLATE_EXPLAIN` (one-sentence explanation shown under select).
- Expanded `HELP_TEXT` from 6 to 19 entries. All written in simple, grandparent-friendly
  Persian with concrete examples. Covers: ختم, نوع ختم, ختم تعهددار/غیرتعهددار,
  فعال‌سازی, تولید طرح, تخصیص سهم, سهم, مشارکت, پیشرفت, دعوت, نوع قرائت,
  قرآن کامل, جزء قرآن, صلوات, دعا, زیارت.

**Pages:**
- `apps/web/src/app/page.tsx` (landing): ambient gradient bg, emoji feature icons.
- `apps/web/src/app/dashboard/page.tsx`: ambient bg, ACTIVE/COMPLETED colored badges,
  template icons in card meta, improved empty states with emoji icons.
- `apps/web/src/app/khatms/create/page.tsx`: `TEMPLATE_ICON`+`TEMPLATE_EXPLAIN` under
  select; richer type-card descriptions with examples; type-card icons (📋 / 🌐).

**Validation:** typecheck PASS · lint PASS · 345 tests PASS · build PASS.

---

## 2026-09-12 — Phase 14 — Core User Journey Completion

**Bug fix:**
- `KhatmWorkflowService.completeKhatm`: OPEN khatms no longer throw `KhatmNotCompletableError`.
  The portions-completeness check now only runs for COMMITMENT khatms (DEC-0072).

**New API endpoints:**
- `POST /api/me/become-creator` — idempotently grants CREATOR capability (DEC-0070 MVP path).
- `PUT /api/me/profile` — set/clear the user's display name (DEC-0073).
- `GET /api/me` — now includes `displayName: string | null`.
- `GET /api/khatms/:id/participants` — each entry now includes `displayName: string | null`.

**Schema & domain:**
- Migration `20260911200000_user_display_name`: adds `display_name VARCHAR(64) NULLABLE` to `users`.
- `User` domain entity, `UserProps`, `UserRow`, `UserRepository`, `PrismaUserRepository`,
  `IdentityService` all updated to carry/persist/update `displayName`.

**Contracts:**
- `MeResponse`: `+ displayName: string | null`.
- `ParticipationSummary`: `+ displayName: string | null`.
- `BecomeCreatorResponse`, `UpdateProfileRequest`, `ProfileResponse` added to auth contracts.

**Frontend:**
- Khatm detail page: participant row shows `displayName` when set, falls back to "شرکت‌کننده N".
- `layout.tsx`: `themeColor` updated from old green `#2e7053` to lapis `#1E3E90`.
- Type card body: `min-width: 0` + `overflow-wrap: break-word` to prevent text overflow in RTL.

**Tests:**
- 10 new test cases: OPEN completes without portions, OPEN non-owner rejected, FakeUserRepository
  stubs updated in identity and account-merge test suites.
- Total: **345 tests** (up from 335).

---

## 2026-09-11 — Product Review + UX/UI Foundation

**Design system:**
- `packages/ui/src/tokens.css` rewritten: lapis (لاجوردی) blue palette replaces green;
  warm stone neutrals; `--ks-color-error`, `--ks-space-5` added; dark-mode tokens aligned.
- `apps/web/src/app/globals.css` rewritten: `.btn-danger`, `.empty-state`, `.skeleton`,
  `.confirm-bar`, `.onboarding-banner`, `.alert-info`, `.badge-danger`, `.auth-wordmark`,
  `.hero-features`; `--ks-space-5` usage now resolves correctly in `.khatm-card`.

**Web pages improved:**
- `page.tsx` (landing): removed `ApiStatus`/`StatusCard`; clean hero with feature bullets.
- `login/page.tsx`: brand wordmark, OTP expiry copy, errors above CTA, reset-code button state.
- `dashboard/page.tsx`: skeleton loading, retry action on error, onboarding banner,
  better empty states, dropped `canCreateKhatm` gate (DEC-0070).
- `khatms/[id]/page.tsx`: skeleton loading; participants/invitations shown with
  human-readable numbers + dates; confirmation bar for complete-khatm; plan defaults 30/1;
  OPEN contribution form keeps error state.
- `components/help-tip.tsx`: popover shows term as bold title.

**Documentation (new docs/ai files):**
- `UI_UX_AUDIT.md` — 7-page audit, 28 findings across all screens.
- `DESIGN_SYSTEM.md` — palette, typography, spacing, components, rules.
- `KHATM_LOGIC_REVIEW.md` — correctness analysis, edge cases, khatm variations.
- `PRODUCT_GAPS.md` — 18 gaps categorised as Must / Should / Future.

**Validation:** typecheck PASS · lint PASS · tests 343 PASS · build PASS.

---

## 2026-09-11 — Phase 13: Khatm Type Domain Implementation

**Domain:**
- Added `KhatmType` enum (`COMMITMENT` | `OPEN`) with `isKhatmType` guard.
- Updated `Khatm` entity: `khatmType` on `KhatmProps`, `NewKhatmProps`, `create()`,
  `restore()`. Added `UnknownKhatmTypeError`.
- New `OpenContribution` entity with `create()` / `restore()` factories.
- New `contribution.errors.ts` (`InvalidContributionAmountError`, `ContributionNotFoundError`,
  `OpenContributionNotAllowedError`).
- New `open-contribution.repository.ts` port.

**Database:**
- Migration `20260911172037_khatm_type_open_contributions`: added `khatm_type` enum and
  column to `khatms` (default COMMITMENT); added `open_contributions` table.
- Prisma client regenerated.

**Application:**
- `khatm.service.ts`: `createKhatm` accepts `khatmType`.
- New `open-contribution.service.ts`: `recordContribution`, `listMyContributions`,
  `openProgress`.
- `khatm-workflow.service.ts`: `createKhatm` passes `khatmType`; `activateKhatm`
  skips plan check for OPEN khatms (DEC-0071); new `findMyParticipation` helper.

**Infrastructure:**
- `khatm.mapper.ts`: `KhatmRow.khatmType`, `toKhatm` includes `khatmType`.
- `prisma-khatm.repository.ts`: writes `khatmType`.
- New `prisma-open-contribution.repository.ts`.
- `khatm.module.ts`: registers `OpenContributionService` and
  `PrismaOpenContributionRepository`.

**Contracts (`@khatmsaz/contracts`):**
- Added `KhatmTypeDto`, `KHATM_TYPES`, `khatmType` on `KhatmSummary` and
  `CreateKhatmRequest`.
- Added `OpenProgressResponse`, `RecordContributionRequest`, `ContributionSummary`,
  `MyContributionsResponse`.

**HTTP API:**
- `khatm.controller.ts`: `OpenContributionService` injected; 3 new endpoints:
  `GET :id/open-progress`, `POST :id/contributions`, `GET :id/my-contributions`.
- `khatm-view.mapper.ts`: `toContributionSummary`; `toKhatmSummary` includes `khatmType`.
- `dto/khatm-requests.ts`: `parseCreateKhatm` requires `khatmType`; new
  `parseRecordContribution`.

**Telegram:**
- `telegram-command.service.ts`: passes `khatmType: 'COMMITMENT'` on `/create_khatm`.

**Frontend:**
- `/khatms/create`: sends `khatmType` in POST body (COMMITMENT/OPEN).
- Dashboard: shows `KHATM_TYPE_LABEL` on khatm cards.
- `/khatms/[id]`: shows khatm type; OPEN khatms show contribution form + history +
  aggregate progress; imports updated.
- `labels.ts`: `KHATM_TYPE_LABEL`, `HELP_TEXT` centralized for HelpTip.

**Tests:** 333 API + 10 web = 343 total (PASS). Typecheck / Lint / Build: all PASS.

---

## 2026-09-11 — Phase 12: Product UI Foundation

**Backend:**
- Added `GET /api/khatms/:id` endpoint (no ownership required; returns `KhatmSummary`;
  `KhatmNotFoundError` → 404 via existing filter). `KhatmNotFoundError` import added
  to `khatm.controller.ts`.

**Frontend — new files:**
- `apps/web/src/components/help-tip.tsx` — reusable `?` icon with click popover.
- `apps/web/src/app/khatms/create/page.tsx` — dedicated create page with radio card
  type selector (commitment / open) and `HelpTip` for نوع ختم and نوع قرائت.
- `apps/web/src/app/invitations/accept/page.tsx` — accepts `?token=` from URL, calls
  `POST /api/invitations/accept`, redirects to the khatm on success.

**Frontend — modified files:**
- `apps/web/src/app/dashboard/page.tsx` — overhauled: khatm progress cards, creator
  section (`GET /api/khatms`), participant section (`GET /api/me/khatms`), progress
  bars for ACTIVE khatms, link to `/khatms/create`.
- `apps/web/src/app/khatms/[id]/page.tsx` — overhauled: uses `GET /api/khatms/:id`
  (not creator-only list), progress bar, my-portions section, invitation management
  (create link, cancel, list), participant list, conditional creator-only sections.
- `apps/web/src/app/globals.css` — added Phase 12 section: progress bar, type-card
  selector, help-tip popover, section-header, btn-sm, khatm-card, ks-note, invitation
  status badge variants.
- `apps/web/src/lib/labels.ts` — added `INVITATION_STATUS_LABEL`.

**Validation:** typecheck PASS · lint PASS · unit 326+10 PASS · build PASS.

---

## 2026-09-11 — Repository hygiene checkpoint and MVP Creator decision (DEC-0070)

- Removed `cloudflared.deb` (19 MB binary, accidentally committed in Phase 9.1)
  from git tracking; updated `.gitignore` with `*.deb`, `all_code.txt`, and related
  binary/dump patterns.
- Scanned git history for secrets — no real tokens or keys found; confirmed `.env`
  is not tracked, `.env.example` contains only safe local-dev placeholders.
- Verified authentication invariants: phone-first OTP login, httpOnly cookie sessions,
  and dev OTP all remain correct; no production bypass in any form.
- Recorded **DEC-0070**: any authenticated user may become a Creator in MVP without
  a manual approval workflow; billing/usage limits deferred to a later phase.
- Full validation gate: typecheck PASS · lint PASS · unit 326 api + 10 web PASS ·
  build PASS.

## 2026-09-08 — Local development OTP and fixtures (DEC-0069)

- Finished the existing opt-in memory/Unix-socket delivery adapter; owner-only
  permissions, expiry, bounded storage, one-read delivery and shutdown cleanup.
- Added idempotent local seed, numeric Telegram bind and interactive OTP commands.
  Seeded two local CREATOR accounts and bound the provided Telegram subject.
- Added unit and database integration coverage; 113 integration tests passed.
  Fixed expected phone errors incorrectly becoming HTTP 500.
- Added LOCAL_DEVELOPMENT.md. No migration, app dependency, `.env` edit or commit.
  User took over further manual testing; see PROJECT_STATE.md for exact validation
  timing and the final unrun unit cases.

---

Newest entries at the top.

## 2026-09-08 — Phase 11 — Product completion core

Participant invitations, participant experience reads, lifecycle-hardening review,
API completeness (DEC-0068). Migration `20260908004812_khatm_invitations`.

- **Invitations** (`apps/api/src/invitation/`): owner-issued, opaque-token (SHA-256
  hashed) grant with derived lifecycle CREATED→ACCEPTED/EXPIRED/CANCELLED; history
  preserved. `InvitationService` create/list/cancel (owner-gated) + accept
  (authenticated, joins via the workflow). HTTP `POST/GET /api/khatms/:id/invitations`,
  `POST /api/invitations/:id/cancel`, `POST /api/invitations/accept`.
- **Participant experience**: `GET /api/me/khatms`, `GET /api/khatms/:id/my-portions`
  (own portions only); supporting reads on participation/portion repos + services.
- **Lifecycle hardening**: reviewed (allocation in UnitOfWork; guarded transitions +
  DB uniques elsewhere); added a concurrent-activation test (exactly one wins).
- **Security**: no new IDOR; ownership/participant scoping on all new reads; tokens
  hashed. Deferred: CSRF double-submit token, Telegram invite-accept.
- **Verification**: typecheck/lint/build PASS; unit api 311 + web 10; integration 105;
  e2e 1.

## 2026-09-08 — Phase 10 — Product readiness foundation

Phone-first auth, httpOnly cookie sessions, creator journey, Telegram command review
(DEC-0066, DEC-0067). Migration `20260907201909_phone_login_purpose` (additive
`otp_purpose` value `PHONE_LOGIN`).

- **Phone-first auth**: user-less `PHONE_LOGIN` OTP challenge proves possession;
  Phone capability extended (`requestLoginCode`/`verifyLoginCode`/`findVerifiedOwner`/
  `establishVerifiedOwnership`/`normalize`, all reusing existing ports); session
  `PhoneAuthService.requestLogin`/`completeLogin` resolves-or-creates the user and
  mints a session. `POST /api/auth/phone/request` + `/verify`.
- **Cookie sessions**: verify sets an httpOnly/SameSite=Lax/Secure-in-prod cookie (no
  token in body); `SessionAuthGuard` reads cookie then bearer; logout revokes + clears.
- **Web**: cookie-based (`credentials:'include'`, no in-memory token); `/api/me`
  session restore; phone→code login page.
- **Telegram**: product commands `/start /create_khatm /my_khatms /progress`; raw
  `/join` retired (→ unknown-command help; invitations replace it in Phase 11).
- Legacy user-scoped `POST /api/auth/login` retained but superseded.
- **Verification**: typecheck/lint/build PASS; unit api 311 + web 10; integration 102;
  e2e 1.

---

## 2026-09-07 — Phase 9 — Real Telegram Bot adapter

Connect the Phase-5 Telegram boundary to the real Bot API — infrastructure-only,
config-gated, no business logic in the Telegram code, no schema change (DEC-0065).

**Added — `telegram/infrastructure`**

- `telegram-webhook.controller.ts` — `POST /telegram/webhook`: constant-time secret
  check (`X-Telegram-Bot-Api-Secret-Token`), maps raw update → neutral `TelegramUpdate`,
  dispatches through the existing `TelegramGateway`; 200 for verified (even ignored)
  updates, 403 on bad/missing secret. Disabled when no secret configured.
- `telegram-update.mapper.ts` — pure, defensive raw Bot API → `TelegramUpdate` (`null`
  for unsupported updates). + unit spec (9 cases).
- `bot-api-telegram-sender.ts` — `TelegramSender` over the Bot API via plain `fetch`
  (no SDK); never logs the URL or body.
- `telegram-config.tokens.ts` — `TELEGRAM_CONFIG` DI token.

**Added — config**

- `@khatmsaz/config.telegramConfig()` (`botToken`, `webhookSecret`, `apiBaseUrl`) +
  `telegramOutboundEnabled`. `.env.example`: `TELEGRAM_BOT_TOKEN`,
  `TELEGRAM_WEBHOOK_SECRET`, `TELEGRAM_API_BASE_URL` (blank secrets).

**Changed — `TelegramModule`**

- Registers the webhook controller; binds `TELEGRAM_SENDER` via a factory — real
  `BotApiTelegramSender` when a token is set, else the no-op sender; provides
  `TELEGRAM_CONFIG`.

**Decision:** DEC-0065 (webhook + fetch sender, infra-only, config-gated, no SDK, no
polling).

**Verification:** typecheck / lint / **api 312 + web 10 unit** / build PASS; **e2e**
1/1; **integration 95/95** (+7 webhook: secret verification, malformed/unknown updates,
identity resolution + duplicate idempotency, unauthorized create, CREATOR create). Live
`/health` 200; webhook disabled → 403 without a secret; no secret in the boot log.

---

## 2026-09-07 — Phase 8 — Creator experience (web) foundation

The first user-facing layer: a thin Web app (Next.js, Persian/RTL) consuming the
existing authenticated APIs — login, a creator dashboard, and khatm management. UI
holds no business logic; authorization stays server-side. No payments, notifications,
admin, marketplace, subscriptions, mobile, or production Telegram. No schema change
(DEC-0064).

**Added — web app** (`apps/web`)

- `src/lib/`: `api-client` (typed fetch, bearer injection, error envelope → `ApiError`),
  `api-error`, `auth-context` (in-memory session token + `/api/me`), `permissions`
  (pure UI gating), `labels` (Persian enum labels).
- `src/components/require-auth` (client route guard).
- `src/app/`: `login/`, `dashboard/`, `khatms/[id]/` pages; landing links; `layout`
  wraps `AuthProvider`; `globals.css` extended with token-based RTL styles.
- `test/` + `jest.config.cjs` + test script: 10 unit tests (api-client, api-error,
  permissions) — node env, outside `src`.

**Added — API (thin controllers, DTO validation only, existing contracts)**

- `GET /api/me` (`MeResponse {userId, isCreator}`), `POST /api/auth/request-otp`
  (`RequestOtpResponse {e164}`), `GET /api/khatms/:id/participants` (owner-only,
  `KhatmParticipantsResponse`). Supporting reads: `KhatmService.listParticipations`
  + `ParticipationRepository.findByKhatm`, `PhoneOtpLoginService.requestOtp`.
- New contracts: `MeResponse`, `RequestOtpRequest`/`RequestOtpResponse`,
  `ParticipationSummary`, `KhatmParticipantsResponse`. No schema change / no migration.

**Decisions:** DEC-0064 (web is a thin client; in-memory token, no client-side secret;
UI gating is a hint — backend re-authorizes; added read endpoints).

**Verification:** typecheck / lint / build (api+web+admin) PASS; unit api 303 + web 10;
integration 88/88 (+3); e2e 1/1; live `/health` 200, `/api/me` → 401, request-otp bad
body → 400, no secret in boot log.

---

## 2026-09-07 — Phase 7 — Creator capability & authorization foundation

The authorization foundation: a capability model, the Creator capability, and
resource-ownership enforcement that closes the Phase-6 IDOR. Authorization only — no
Web UI, production Telegram, payments, notifications, admin, marketplace, or
subscriptions (DEC-0061, DEC-0062, DEC-0063).

**Added — `authorization` capability** (`apps/api/src/authorization/`, `AuthorizationModule` wired into `AppModule`)

- `domain/`: `Capability` (grant/revoke history, `isActive`), `CapabilityType`
  (CREATOR only), `CapabilityRepository` port, authorization errors
  (`CapabilityRequiredError`, `ResourceOwnershipError`, both → 403).
- `application/`: `AuthorizationService` (`hasCapability`, `requireCapability`,
  `grantCapability` idempotent, `revokeCapability`) — Prisma-free, no session/HTTP.
- `infrastructure/`: `PrismaCapabilityRepository`, mapper, prisma-error helper.

**Added — migration `20260907081109_authorization_capability_foundation`** (seventh reviewed)

- `user_capabilities` table + `capability_type` enum, FK `user_id → users` RESTRICT,
  and a hand-written partial unique index `UNIQUE (user_id, type) WHERE revoked_at IS
  NULL` (one active grant per user+type). All-CREATE; no ALTER to existing tables.

**Changed — authorization enforcement (DEC-0063)**

- `KhatmWorkflowService`: `createKhatm` requires the CREATOR capability; `activateKhatm`,
  `generateAllocationPlan`, `allocatePortions`, `completeKhatm` now take the acting
  user id and require **ownership** (`requireKhatmOwner`) — closing the IDOR.
  Participant actions (join, complete own portion) stay participant logic.
- HTTP controllers pass `principal.userId` to the manage workflows; the
  `DomainExceptionFilter` maps capability/ownership denials to **403** (distinct from
  the guard's 401). Telegram maps the denial to a Persian message.

**Decisions:** DEC-0061 (authorization as a dedicated capability), DEC-0062 (capability
grant model + partial unique + explicit internal grant), DEC-0063 (Creator permission
rules: capability to create, ownership to manage).

**Verification:** typecheck / lint / **303 unit** / build PASS; **e2e** 1/1;
**integration 85/85** (+10 authorization/authz-HTTP) against real PostgreSQL; live
`/health` 200 with `AuthorizationModule` initialized, no-token create → 401, no secret
in the boot log; `psql` confirmed the partial index + FK RESTRICT.

---

## 2026-09-07 — Phase 6 — Authentication & session foundation

Authenticated principals and server-side sessions so transports stop trusting
explicit user ids. Authentication foundation only — no Web UI, payments,
notifications, admin, Creator permissions, real SMS, or OAuth (DEC-0059, DEC-0060).

**Added — `session` capability** (`apps/api/src/session/`, `SessionModule` wired into `AppModule`)

- `domain/`: `Session` (derived ACTIVE/REVOKED/EXPIRED status), `SessionStatus`,
  `SessionTokenGenerator`/`SessionTokenHasher` ports, `Clock` port,
  `SessionRepository` port, `AuthenticatedPrincipal`, session errors.
- `application/`: `AuthenticationService` (createSession/authenticate/revoke/
  revokeAllForUser), `PhoneOtpLoginService` (phone-OTP → session bridge),
  `session-policy` token.
- `infrastructure/`: `CryptoSessionTokenGenerator` (256-bit CSPRNG),
  `Sha256SessionTokenHasher` (SHA-256 + constant-time compare), `SystemClock`,
  `session.mapper`, `PrismaSessionRepository`.

**Added — migration `20260907071058_session_foundation`** (sixth reviewed)

- `sessions` table: unique `token_hash` (SHA-256 of the token, never the raw token),
  indexed `user_id`, FK `user_id → users` ON DELETE CASCADE (mirrors `otp_challenges`).
  All-CREATE; no ALTER to existing tables.

**Changed — transports (DEC-0060)**

- HTTP: `SessionAuthGuard` + `@Principal()`; `AuthController` (`/api/auth/login`,
  `/api/auth/logout`). `create`/`join`/`list` are guarded and derive the user from
  the principal; `CreateKhatmRequest` drops `creatorUserId`, join drops `userId`
  (contracts updated + `auth.ts` added). **Every** `/api/khatms` + `/api/portions`
  route requires a valid session (a security review flagged the resource-scoped
  routes as unauthenticated); per-resource **authorization** (ownership/IDOR) remains
  deferred to Creator permissions.
- Telegram: command service resolves an `AuthenticatedPrincipal` from the platform
  identity (channel-authenticated, `sessionId: null`).

**Config:** `sessionPolicyConfig()` (`SESSION_TTL_SECONDS`, `SESSION_TOKEN_BYTES`) —
non-secret; `.env.example` documented. No session server secret (token entropy).

**Decisions:** DEC-0059 (server-side opaque sessions; store only a SHA-256 hash;
derived status; no refresh yet), DEC-0060 (transports resolve an authenticated
principal; phone-OTP login bridge).

**Verification:** typecheck / lint / **286 unit** / build PASS; **e2e** 1/1;
**integration 75/75** (+8) against real PostgreSQL; live `/health` 200 with
`SessionModule` initialized, guarded route → 401 (no leak), login bad body → 400, no
secret/token in the boot log; `psql` confirmed the sessions table + unique hash + FK.

---

## 2026-09-07 — Phase 5 — Transport foundation

The transport layer that drives the existing workflows: a REST API and a Telegram
channel adapter foundation. Transport only translates external input into
application use-cases — no business logic in transport. **No Web UI, real Telegram
network, payments, notifications, or auth. No migration / no schema change**
(DEC-0057, DEC-0058).

**Added — contracts** (`packages/contracts/src/khatm.ts`, exported from `index.ts`)

- Pure DTO shapes: `CreateKhatmRequest`, `KhatmSummary`, `KhatmListResponse`,
  `AllocationPlanSpecDto` + `GenerateAllocationRequest/Response`, `JoinKhatmRequest/
  Response`, `AllocatePortionsRequest/Response`, `CompletePortionRequest`,
  `KhatmProgressResponse`, `TransportErrorResponse`, and status/template string
  unions. Shapes only — no validation, no domain leakage.

**Added — HTTP transport** (`apps/api/src/http-api/`, `HttpApiModule` wired into `AppModule`)

- Thin `KhatmController` (`/api/khatms`: create, list, plan, activate, join,
  allocate, progress, complete) + `PortionController` (`/api/portions/:id/complete`),
  calling `KhatmWorkflowService`/`KhatmService`.
- Dependency-free DTO validation (`dto/validate.ts` + `dto/khatm-requests.ts`);
  `khatm-view.mapper.ts` maps domain `Khatm` → `KhatmSummary` (no entity/Prisma on
  the wire); `DomainExceptionFilter` maps capability errors → a stable
  `{error:{code,message}}` envelope (404/400/403/409; generic 500).

**Added — Telegram transport** (`apps/api/src/telegram/`, `TelegramModule` wired)

- Vendor-neutral `TelegramUpdate`/`TelegramReply` (adapter boundary); pure
  `parseCommand`; `TelegramCommandService` (resolves platform identity via
  `IdentityService`, routes `/start /create_khatm /my_khatms /join /progress`, Persian
  replies, `/start` provisions a user); `TelegramGateway` (inbound entry) + outbound
  `TelegramSender` port bound to a **no-op** adapter (no token, no network).

**Changed — khatm capability (additive)**

- `KhatmService.listKhatmsByCreator` + `KhatmRepository.findByCreator` (Prisma impl),
  backing `GET /api/khatms` and `/my_khatms`.

**Decisions:** DEC-0057 (HTTP transport thin boundary, no domain/Prisma on the wire,
error envelope), DEC-0058 (Telegram vendor-neutral channel adapter; identity resolved/
provisioned via the identity capability).

**Verification:** typecheck / lint / **269 unit** / build PASS; **e2e** 1/1;
**integration 67/67** (+6: HTTP journey via supertest, Telegram identity→User→workflow,
no real network); live `/health` 200 with both transport modules initialized, real
HTTP calls proved routing + validation (400) + domain-error mapping (409/400), no
secret in the boot log. No schema change.

---

## 2026-09-07 — Phase 4.2 — Khatm workflow orchestration

Application-level workflows connecting the existing Khatm capabilities into an
end-to-end journey (create → activate → join → allocate → complete). **Application
only — no transport, notifications, payments, or auth. No migration / no schema
change** (DEC-0054…DEC-0056).

**Added — `khatm-workflow` capability** (`apps/api/src/khatm-workflow/`, wired into `AppModule`)

- Application-only ORCHESTRATION module (the `account-merge` pattern): imports
  IdentityModule + KhatmModule + AllocationModule, composes their exported services;
  owns no domain, persistence, or transaction of its own.
- `application/khatm-workflow.service.ts` — `KhatmWorkflowService` with six flows:
  `createKhatm` (creator must be ACTIVE), `activateKhatm` (requires a valid plan),
  `joinKhatm` (user must be ACTIVE), `generateAllocationPlan` / `allocatePortions`
  (delegate to allocation), `completePortion` (holder-checked), `completeKhatm`
  (only when every portion completed), plus a `progress` passthrough.
- `application/khatm-workflow.errors.ts` — `InactiveCreatorError`,
  `InactiveParticipantError`, `KhatmNotConfiguredError`, `KhatmNotCompletableError`.

**Changed — allocation capability (additive)**

- `AllocationService.completeHeldPortion(portionId, participationId)` — only the
  assigned holder may complete a portion (`PortionNotHeldByParticipationError`);
  a completed portion can't be completed again (guarded). Runs in `UnitOfWork`.

**Decisions:** DEC-0054 (orchestration capability + active-user gating), DEC-0055
(activation requires a valid plan), DEC-0056 (completion = every portion completed;
holder-only completion).

**Verification:** typecheck / lint / **232 unit** / build PASS; **e2e** 1/1;
**integration 61/61** (+3 workflow: full journey + duplicate-participation +
merged-user rejection) against real PostgreSQL; live `/health` + `/health/ready` 200
with `KhatmWorkflowModule` initialized, no secret in the boot log. No schema change.

---

## 2026-09-07 — Phase 4.1 — Khatm allocation engine

The generic, template-driven allocation engine, built **additively** on Phase 4
(Phase-4 tables/entities unchanged — DEC-0052). Plan generation, non-overlapping
portions, allocation, reallocation, progress, transaction safety. **No transport,
notifications, payments, or auth.**

**Added — `allocation` capability** (`apps/api/src/allocation/`, wired into `AppModule`)

- `domain/` (Prisma-free): `AllocationPlan`, `PlanPortion` (OPEN→ASSIGNED→COMPLETED,
  release/reassign), `PortionSpec` value object, `PortionUnitKind` / `PortionStatus`,
  `generatePortions` (PlanSpec → non-overlapping portions), errors, two repository
  **ports** + the **`KhatmStateReader`** read port (+ DI tokens).
- `application/allocation.service.ts`: `generatePlan`, `allocateOpenPortions`,
  `allocatePortion`, `reassignPortion`, `releaseParticipation` (reallocation),
  `completePortion`, `progress`, `findPlan` — Prisma-free; multi-row ops run in
  `uow.run` (transaction safety).
- `infrastructure/`: Prisma repositories + mapper + Prisma-error helper, and the
  `PrismaKhatmStateReader` (reads Phase-4 khatm tables read-only, no Phase-4 domain
  import). Guarded status transitions.

**Added — migration `20260907004303_khatm_allocation_engine`** (fifth reviewed)

- Tables `khatm_allocation_plans` (`UNIQUE(khatm_id)`) and `khatm_portions`; enums
  `portion_unit_kind`, `khatm_portion_status`.
- Hand-appended non-overlap partial unique index `khatm_portions_positional_unit_key`
  = `UNIQUE (plan_id, unit_start) WHERE unit_kind='POSITIONAL'` (DEC-0053, KI-0012).
- Four new FKs `ON DELETE RESTRICT`. **No ALTER to any Phase-4 table** — only virtual
  Prisma back-relations added to the Khatm/Participation models.

**Decisions:** DEC-0052 (self-contained additive engine + generic plan/portion
model), DEC-0053 (non-overlap via atomic positional units + a partial unique index).

**Verification:** typecheck / lint / **217 unit** / build PASS; **e2e** 1/1;
**integration 58/58** (+9 allocation) against real PostgreSQL; live `/health/ready`
200 with `AllocationModule` initialized, no secret in the boot log; `psql` confirmed
the partial index predicate, 4 FKs RESTRICT, and `khatms` unchanged (8 columns).

---

## 2026-09-07 — Phase 4 — Khatm engine foundation

The core business domain of KhatmSaz: the Khatm aggregate, a generic template
classification, participation, and the assignment/portion system. Domain
foundation only — **no controllers, bots, UI, reminders, payments, Creator roles,
or authentication** (DEC-0048…DEC-0051).

**Added — `khatm` capability** (`apps/api/src/khatm/`, wired into `AppModule`)

- `domain/` (Prisma-free): `Khatm` (lifecycle DRAFT→ACTIVE→COMPLETED|CANCELLED,
  immutable transitions + guards), `KhatmStatus`, `KhatmTemplateType` (single enum,
  no table-per-type — DEC-0048/0019), `Participation` + `ParticipationStatus`,
  `Assignment` + `AssignmentStatus`, `Portion` value object (POSITIONAL range /
  QUANTITY — DEC-0049), errors, and the three repository **ports** (+ DI tokens).
- `application/khatm.service.ts`: `createKhatm`, `findKhatmById`, `activate/complete/
  cancelKhatm`, `join`, `complete/leave/removeParticipation`, `assignPortion`,
  `completeAssignment`, `khatmProgress` — Prisma-free, no UnitOfWork (single-write ops).
- `infrastructure/`: Prisma repositories + mapper + a Prisma-error helper (the only
  Prisma here); guarded status transitions; partial-unique / FK violations
  translated to domain errors.

**Added — migration `20260906195317_khatm_engine_foundation`** (fourth reviewed)

- Tables `khatms`, `khatm_participations`, `assignments`; enums `khatm_status`,
  `khatm_template_type`, `participation_status`, `assignment_unit_kind`,
  `assignment_status`.
- Hand-appended partial unique index `khatm_participations_active_khatm_user_key` =
  `UNIQUE (khatm_id, user_id) WHERE status = 'ACTIVE'` (one active participation per
  user per khatm — DEC-0050, KI-0012).
- All five new FKs `ON DELETE RESTRICT` (DEC-0051); User gains `khatmsCreated` /
  `participations` back-relations.

**Decisions:** DEC-0048 (aggregate + lifecycle + generic template), DEC-0049
(portion model), DEC-0050 (participation uniqueness), DEC-0051 (FK strategy +
merge interaction, flagged for product input).

**Verification:** typecheck / lint / **173 unit** / build PASS; **e2e** 1/1;
**integration 49/49** (+8 khatm) against real PostgreSQL; live `/health` +
`/health/ready` 200 with `KhatmModule` wired, no secret in the boot log; `psql`
confirmed the partial index predicate, 5 FKs RESTRICT, and the 7-value template enum.

---

## 2026-09-06 — Phase 3B step 2 — account merge use-case + change-phone flow

The intra-product (DEC-0047) merge engine and the change-phone-via-OTP flow, on the
step-1 foundation. **No authentication, sessions, or Creator work.**

**Changed — transaction boundary (DEC-0044)**

- `UnitOfWork`, `TransactionContext`, `UNIT_OF_WORK` **moved to `@khatmsaz/kernel`**
  so domain repository ports can accept `tx?: TransactionContext` without importing
  infrastructure; `database.tokens.ts` re-exports them. Added infra `dbClient(prisma,
  tx?)` helper.
- Repository ports/impls made transaction-aware and extended: phone-claim `markVerified(tx)`,
  `revoke`, `revokeAllActiveByUser`, `reassignOwner`, `findVerifiedByUser`,
  `findVerifiedOwnerId`; otp `consume(tx)`; user `findById(tx)`, `tombstone`;
  platform-identity `reassignOwner`; account-merge `append(tx)`.

**Changed — change phone via OTP (DEC-0046)**

- `phone/application/phone-verification.service.ts` `verifyPhone`: a number verified
  by another account returns `MERGE_REQUIRED` (no consume); when the user already has
  a different verified number, it is **revoked and the new one promoted atomically**
  in one transaction (one verified phone per user). `VERIFIED` now carries an optional
  `replacedE164`.

**Added — account-merge capability (`apps/api/src/account-merge/`)**

- `AccountMergeService.mergeAccounts` (DEC-0042/0046/0047): inside `UnitOfWork`,
  reassign the loser's platform identities to the winner; revoke then reassign the
  loser's phone claims to the winner as history; tombstone the loser (MERGED,
  `mergedIntoId`, ACTIVE-guarded); append the audit record. Move-not-delete; FK
  RESTRICT respected; winner (existing verified owner) canonical.
- `account-merge.module.ts` — orchestration module importing IdentityModule +
  PhoneModule (now exporting their repository-port tokens); wired into AppModule.

**Tests**

- Unit 123 (+7): change-phone (revoke old / promote new / one verified per user) and
  `AccountMergeService` (move + tombstone + audit; winner=loser, missing phone,
  missing/inactive account rejections).
- Integration 41 (+5): change-phone against the real per-user index; merge resolves a
  real `MERGE_REQUIRED` (data moved, loser tombstoned + retained, audit written);
  loser's own verified number revoked; already-merged rejected; **rollback on
  bad winner changes nothing** (atomicity).

**Validation:** typecheck / lint / test (123) / build PASS; e2e 1/1; integration
41/41; live `/health` + `/health/ready` 200 with `AccountMergeModule`; DB cleaned.

---

## 2026-09-06 — Product boundary clarified (DEC-0047) — docs only

Product-owner scope clarification recorded; **no code change** (the architecture
already matched it).

- DEC-0047 — KhatmSaz is an **independent product**; internal identity is
  KhatmSaz-only. Telegram/Bale/Web are **channels of the one product** and share its
  identity; account merge is **intra-product**. Future products (study/donation bots)
  are separate with isolated identity. No cross-product / shared identity, no
  product/tenant dimension (there is none today).
- Reviewed: schema has no product/tenant column — single-product by construction, so
  nothing to change. The pre-3B review's multi-product suggestions (outbox *between
  products*, identity as a *shared service*) are rescoped **out of scope**.
- Clarified wording in ARCHITECTURE (new "Product boundary"), DATABASE
  (multi-tenancy = intra-product white-label), and ROADMAP (new "Out of scope").

---

## 2026-09-06 — Phase 3B step 1 — account-merge database/domain foundation

Schema + domain foundation for account merge. **The merge use-case is NOT built** —
no code moves data, tombstones an account, or writes an audit row as part of a flow.

**Added — schema + migration** (`20260906120252_account_merge_foundation`, reviewed)

- `users`: `status` (`user_status` enum `ACTIVE`/`MERGED`, default ACTIVE, DEC-0040)
  and `merged_into_id` self-FK tombstone pointer (DEC-0041, RESTRICT, indexed).
- `account_merges` append-only audit table (DEC-0043): winner/loser (FK RESTRICT),
  `verified_e164`, `initiating_challenge_id` (plain id, no FK), moved counts,
  context, `created_at`; **no `updated_at`** (immutable).
- Hand-written partial unique index `phone_claims_verified_user_key`
  = `UNIQUE(user_id) WHERE status='VERIFIED'` — one verified phone per user (DEC-0046).
- FK on-delete applied (DEC-0045): `platform_identities`, `phone_claims`,
  `users.merged_into_id`, both `account_merges` FKs → **RESTRICT**; `otp_challenges`
  stays **CASCADE**.

**Added — domain / infrastructure (identity capability)**

- `UserStatus` enum; `User` now carries `status` + `mergedIntoId` with lifecycle
  invariants (MERGED ⇒ UUIDv7 pointer; ACTIVE ⇒ none). New `AccountMerge` audit
  entity (winner≠loser, non-empty e164, non-negative counts) + `AccountMergeRepository`
  port (append/findById — append-only) + `PrismaAccountMergeRepository` + mapper +
  module binding. New errors `UnknownUserStatusError`, `InvalidUserError`,
  `InvalidAccountMergeError`. `AccountMerge` stores the phone as a plain string —
  identity stays decoupled from the phone capability.
- `UserProps.status`/`mergedIntoId` are optional (default ACTIVE/null) so existing
  `User.restore` callers are unchanged; the mapper passes explicit values from rows.

**Changed — tests**

- Existing identity/phone integration cleanups delete children before users (new
  RESTRICT FKs). +10 tests total: `account-merge-foundation.integration-spec.ts`
  (lifecycle round-trip, tombstone + self-FK reject, one-verified-per-user reject,
  FK RESTRICT on platform/phone, OTP CASCADE, audit append/read + FK reject) and
  User/AccountMerge unit specs.

**Not done (later Phase 3B steps):** merge use-case, transaction-aware repositories,
change-phone-via-OTP flow. No auth/sessions.

**Validation:** typecheck / lint / test (116) / build PASS; e2e 1/1; integration
36/36; migration applied + verified in `psql`; DB cleaned to 0 rows.

---

## 2026-09-06 — Phase 3B product decisions confirmed (DEC-0046)

Product owner resolved DEC-0042's open questions. **Decisions only — no code, no
schema change.**

- DEC-0046 — (1) existing verified owner stays canonical, the newly-verifying
  account merges into it; (2) **one verified phone per user** (stricter than
  DEC-0034); (3) merges irreversible, append-only audit required, no auto-unmerge.
- Flagged for Phase 3B (faithful translation, not invented): rule (2) needs a
  `UNIQUE(user_id) WHERE status='VERIFIED'` partial index + a "change phone via OTP"
  flow (verify-when-already-verified → revoke old, promote new), and the merge must
  resolve a loser's *different* verified number. **Not yet enforced.**
- Docs synced: DECISIONS (DEC-0046 + DEC-0042 resolution note), PROJECT_STATE,
  ROADMAP, DOMAIN_MODEL, DATABASE. Phase 3B unblocked on product input, **not
  started**.

---

## 2026-09-06 — Phase 3B preparation — architectural prerequisites

Prerequisites identified by the pre-3B architecture review. **No merge
functionality, no authentication, no sessions, no schema/migration change.** See
DEC-0039…DEC-0045.

**Decided**

- DEC-0039 — shared domain kernel `@khatmsaz/kernel` owns cross-capability
  primitives (UUIDv7); capabilities never import each other's domain. *(implemented)*
- DEC-0044 — transaction strategy: a Prisma-free `UnitOfWork` port over Prisma
  interactive transactions. *(implemented, seam only)*
- DEC-0040/0041/0042/0043/0045 — design intent for 3B (user lifecycle, tombstone/
  alias, merge policy, merge audit, FK strategy); schema/flows deferred to 3B.
  Genuine product rules (merge winner, extra states, reversibility) flagged for
  product-owner sign-off, **not invented**.

**Added — package**

- `packages/kernel` (`@khatmsaz/kernel`, framework-independent): `newUuidV7`,
  `isUuidV7`, `assertUuidV7`, `InvalidUuidV7Error`. `uuid@14.0.2` moved here from
  `apps/api`. Wired into root `workspaces`, `build:packages` (built first), `clean`.

**Changed — decoupling (review finding M1)**

- `apps/api/src/identity/domain/identity-id.ts` and `identity.errors.ts` now
  re-export the kernel under stable names (`newIdentityId`, `InvalidIdentityIdError`
  = kernel's `InvalidUuidV7Error`) — identity's public API and tests unchanged.
- `apps/api/src/phone/{domain,application}` import the kernel directly and **no
  longer import `identity`** — the capability-to-capability domain coupling is gone.

**Added — transaction boundary (apps/api infrastructure)**

- `database.tokens.ts`: `UNIT_OF_WORK` token, opaque `TransactionContext`,
  `UnitOfWork` port (all Prisma-free).
- `prisma/prisma-unit-of-work.ts`: `PrismaUnitOfWork` (Prisma interactive
  transaction) + infra-only `txClient()` unwrap helper.
- `DatabaseModule` provides/exports `UNIT_OF_WORK` (global). No merge or other
  use-case logic added.

**Tests**

- +3 integration (`test/transaction.integration-spec.ts`): commit returns result;
  rollback on throw; multi-write all-or-nothing — against real PostgreSQL.
- Unit 106 (unchanged count; phone/identity specs re-pointed at the kernel).

**Validation**

- typecheck / lint / test (106) / build PASS; e2e 1/1; integration 26/26. No `.env`
  touched; no secrets; no schema or migration change.

---

## 2026-09-06 — Phase 3A — phone claims & OTP verification foundation

Phone-claim and OTP-verification foundation. Narrow: no Creator capability, no
login/session, no registration UI, no bot handlers, no real SMS provider, no
account merge (a verified-ownership conflict is detected and handed off only). See
DEC-0033…DEC-0038, DOMAIN_MODEL.md, DATABASE.md.

**Decided**

- DEC-0033 — phone stored as canonical E.164 in a separate `PhoneClaim` model
  (not `User.phone`); normalised by `libphonenumber-js` behind a domain port;
  default region is config (`PHONE_DEFAULT_REGION=IR`).
- DEC-0034 — claimed vs verified via a `PhoneClaimStatus` enum; the two hard
  invariants (one global verified owner; one active claim per user+number) enforced
  by **partial unique indexes** in hand-written migration SQL; unverified numbers
  intentionally not globally unique.
- DEC-0035 — OTP codes protected by a server-secret **keyed HMAC** (pepper), never
  plaintext/logged/returned; CSPRNG-generated, single-use, short TTL, bounded
  attempts.
- DEC-0036 — OTP delivery behind an adapter; **no real SMS** this phase (no-op
  adapter, in-memory test fake); never logs the code or the phone number.
- DEC-0037 — verified-ownership conflict returns `MERGE_REQUIRED`; merge deferred to
  Phase 3B; no auto-transfer/merge; conflict outcome carries no enumerable detail.
- DEC-0038 — Redis/distributed rate limiting deferred; per-target cooldown enforced
  in the DB.

**Added — dependency (apps/api, exact pin)**

- `libphonenumber-js@1.13.12` (MIT, zero runtime deps, stable; phone → E.164). CJS,
  so no jest transform change needed. `npm audit`: 0 new advisories.

**Added — schema + migration**

- `prisma/schema.prisma`: models `PhoneClaim`, `OtpChallenge`; enums
  `PhoneClaimStatus` (`UNVERIFIED`/`VERIFIED`/`REVOKED`), `OtpPurpose`
  (`PHONE_VERIFICATION`); relations from `User`.
- Migration `20260906070332_phone_verification_foundation` (reviewed, applied):
  tables `phone_claims` (id, user_id, e164, region, status, verified_at, revoked_at,
  timestamps) and `otp_challenges` (id, nullable user_id, e164, purpose, code_hash,
  attempts, max_attempts, expires_at, consumed_at, superseded_at, timestamps), FKs
  to `users` (cascade), plain indexes, **plus two hand-written partial unique
  indexes** (`WHERE status = 'VERIFIED'` and `WHERE status <> 'REVOKED'`).

**Added — phone capability (apps/api/src/phone, second domain module)**

- `domain/` (Prisma- and vendor-free): `PhoneNumber`, `PhoneClaim`, `OtpChallenge`,
  their enums, errors, the verification-outcome union, and ports `PhoneNormalizer`,
  `OtpCodeGenerator`, `OtpCodeHasher`, `OtpDelivery`, `Clock`, `PhoneClaimRepository`,
  `OtpChallengeRepository` (+ DI tokens).
- `application/phone-verification.service.ts`: `claimPhone`,
  `requestPhoneVerification`, `verifyPhone` (returns VERIFIED / ALREADY_VERIFIED /
  MERGE_REQUIRED).
- `infrastructure/`: Prisma repositories + mapper, `libphonenumber-js` normalizer
  (Persian/Arabic digit folding, Iranian forms), CSPRNG generator, HMAC hasher,
  no-op delivery adapter, system clock, Prisma-error helper.
- `phone.module.ts` wired into `AppModule`. Normalizer/hasher provided via
  `useFactory` (plain-string config arg, not a provider).

**Added — config (@khatmsaz/config)**

- `otp.ts`: `otpHmacSecret()` (fail-fast in prod, dev placeholder), `otpPolicyConfig()`,
  `phoneDefaultRegion()`. `.env.example` documents `PHONE_DEFAULT_REGION`,
  `OTP_HMAC_SECRET` (blank), and the non-secret OTP knobs.

**Tests**

- Unit (Docker-free): +63 tests — Iranian normalization & Persian digits, E.164
  validity, phone-claim lifecycle invariants, OTP expiry/attempts/consumed/superseded,
  CSPRNG generator, HMAC hash/verify + (e164, purpose) binding + pepper keying, and
  the full service (claim idempotency, cooldown, wrong/expired/consumed code,
  ALREADY_VERIFIED, MERGE_REQUIRED, code never in errors). Total unit 106.
- Integration (real PostgreSQL): +10 tests — duplicate unverified claims allowed,
  one verified owner per number, **concurrent verify → exactly one wins**, history
  preserved, only-HMAC storage, migration recorded, repository round-trips. Total
  integration 23.

**Validation**

- typecheck / lint / test (106) / build PASS; e2e 1/1; integration 23/23; migration
  applied and `db:status` up to date; both partial indexes verified in psql; live
  `/health` + `/health/ready` 200 with PhoneModule; no secret in logs; audit
  unchanged (KI-0010).

---

## 2026-09-06 — Phase 2B — identity foundation

First real domain model and first reviewed, checked-in migration. Deliberately
narrow — no OTP, phone verification, registration UX, bot handlers, creator
capability, profile, Khatm, payments, wallet or admin roles. See DEC-0032,
DOMAIN_MODEL.md and DATABASE.md.

**Decided**

- DEC-0032 — canonical identity is an internal, immutable **UUIDv7** (app-
  generated, native PG `uuid`); **PlatformIdentity** is an external claim/link
  only; usernames are not identity; phone verification deferred.

**Added — dependency (apps/api, exact pin)**

- `uuid@14.0.2` (current stable; RFC 9562 UUIDv7). ESM-only — Node 24 runs it via
  `require(esm)`; Jest transforms it (`allowJs` + `uuid`-only
  `transformIgnorePatterns`).

**Added — schema + migration**

- `prisma/schema.prisma`: models `User`, `PlatformIdentity`; enum `Platform`
  (`TELEGRAM`, `BALE`).
- Migration `20260906062900_identity_foundation` (reviewed, applied): tables
  `users` (`id uuid PK`, `created_at`, `updated_at`) and `platform_identities`
  (`id`, `user_id`, `platform`, `subject`, timestamps) with **UNIQUE
  (platform, subject)**, an index on `user_id`, and an FK to `users` (cascade).

**Added — identity capability (apps/api/src/identity, first domain module)**

- `domain/` (Prisma-free): `User`, `PlatformIdentity` (+ `requireSubject`),
  `Platform` enum, `identity-id` (UUIDv7 generate/validate), domain errors, and
  repository **ports** `UserRepository` / `PlatformIdentityRepository` (+ tokens).
- `application/identity.service.ts`: `createUser`, `findUserById`,
  `findUserByPlatformIdentity`, `attachPlatformIdentity` (lenient lookups, strict
  commands; relies on the DB unique constraint, not a pre-check).
- `infrastructure/`: `PrismaUserRepository`, `PrismaPlatformIdentityRepository`,
  `identity.mapper`, `prisma-error` (translate `P2002`/`P2003` → domain errors) —
  the only Prisma in the module.
- `identity.module.ts` binds ports → Prisma impls; wired into `AppModule`. No HTTP
  controller (no registration/bot surface yet).

**Tests**

- Unit (Docker-free), 43 total: UUIDv7 validity/uniqueness, `User`/
  `PlatformIdentity` invariants, and `IdentityService` with in-memory fakes that
  emulate the unique constraint.
- Integration (Docker-gated), 13 total (8 new): migration recorded, native `uuid`
  column, create/find round-trip, attach + lookup, same-subject-different-
  platform, uniqueness violation, **concurrent attach → exactly one wins**, FK
  rejection. Jest configs updated for ESM `uuid` (`allowJs` +
  `transformIgnorePatterns`).

**Validation — all PASS**

- typecheck, lint, `npm test` (43/43), build (api/web/admin), e2e (1/1),
  `test:integration:db` (13/13), live `/health` 200 + `/health/ready` 200 (no
  secret in logs). `npm audit` unchanged (KI-0010); `uuid` added 0 vulnerabilities.

**Security**

- No tokens/credentials stored; a platform `subject` is a public external id, not
  a secret. No phone data or verification claim created (deferred). Data
  minimisation: `users` holds only `id` + timestamps. Domain errors never echo
  the subject.

**Docs**

- DEC-0032; PROJECT_STATE, DOMAIN_MODEL, DATABASE, ARCHITECTURE, ROADMAP,
  CHANGELOG, TESTING, SECURITY.

---

## 2026-09-05 — Phase 2A — persistence foundation

First production-code persistence phase. PostgreSQL + Prisma wired into the API's
infrastructure layer; local infra verified running; readiness endpoint added.
**No product feature and no domain table.** Full rationale in DEC-0031 and
`docs/ai/DATABASE.md`.

**Decided**

- DEC-0031 — PostgreSQL + **Prisma** as the persistence stack, Prisma isolated to
  `apps/api/src/infrastructure/database`. Pinned **exactly** to `7.10.0`
  (`@prisma/client`, `prisma`, `@prisma/adapter-pg`; `pg@8.23.0`). "Prisma 8" was
  the intent, but no stable Prisma 8 exists (npm `latest` = `8.0.0-rc.13`, an RC;
  RCs are forbidden) — the user chose to pin stable 7.10.0 now and adopt 8 at GA.

**Added — dependencies (apps/api, exact pins)**

- Runtime: `@prisma/client@7.10.0`, `@prisma/adapter-pg@7.10.0`, `pg@8.23.0`.
- Dev/tooling: `prisma@7.10.0`, `tsx@4.23.13`, `dotenv@17.4.2`, `@types/pg@8.23.1`.

**Added — Prisma layout (apps/api)**

- `prisma.config.ts` (self-contained; loads repo-root `.env`; derives
  `DATABASE_URL` from `POSTGRES_*` when unset), `prisma/schema.prisma`
  (datasource + generator only — **no models**), `prisma/migrations/` (empty,
  `.gitkeep`), `prisma/scripts/verify-connection.ts` (secret-free `SELECT 1`).
- Generated client emitted to
  `src/infrastructure/database/prisma/generated/` — **git-ignored**, regenerated
  via `db:generate` (wired into `pretypecheck` / `prebuild` / integration pretest).

**Added — infrastructure database layer (apps/api/src/infrastructure/database)**

- `prisma/prisma.service.ts` — single app-lifetime client (driver adapter,
  `$connect` on init / `$disconnect` on shutdown, fail-fast on bad config,
  tolerant of a down DB at startup, never logs the URL).
- `database.tokens.ts` — `DATABASE_PING` token + Prisma-free `DatabasePing`.
- `database-readiness.service.ts` — readiness probe returning a plain status shape.
- `database.module.ts` — `@Global` module, exports the abstractions only.

**Added — config, contracts, endpoint**

- `@khatmsaz/config`: `databaseUrl()` / `resolveDatabaseUrl()` /
  `assertValidDatabaseUrl()` / `databaseConfig()` — validated, fail-fast,
  secret-free.
- `@khatmsaz/contracts`: `ReadinessResponse` / `ReadinessStatus` /
  `DependencyStatus`.
- `GET /health/ready` on `HealthController` (200 up / 503 down); `GET /health`
  liveness unchanged.

**Added — scripts & tests**

- Root + API scripts: `db:generate`, `db:plan`, `db:migrate`, `db:migrate:dev`,
  `db:status`, `db:verify`, `db:push`, `test:integration:db`.
- Unit tests (Docker-free): config validation, readiness up/down + no-leak,
  controller 200/503 + key-set guards (21 unit total). Integration suite
  (`test:integration:db`, Docker-gated): real SELECT 1, ready, real
  unreachable → not_ready at timeout, no-credential-leak (5/5). `jest`
  `moduleNameMapper` strips `.js` from the generated client's specifiers.

**Infrastructure verified (Docker running)**

- `postgres:17-alpine` (PostgreSQL 17.11) — `pg_isready` + `SELECT 1`; Redis 7 —
  `PING`→PONG; MinIO — live + console HTTP 200. Ports all `127.0.0.1`, named
  volumes only. Images were sideloaded with `crane` over the WSL proxy and
  `docker load`ed (the Docker daemon's baked-in proxy is unreachable — KI-0011).

**Validation — all PASS**

- typecheck, lint, `npm test` (21/21), build (api/web/admin), e2e (1/1),
  `test:integration:db` (5/5), live `/health` 200 + `/health/ready` 200, no
  secret in logs.

**Security**

- `npm audit`: 4 high, all via the `prisma` **CLI devDependency** (`mysql2`
  MySQL driver — never loaded; `deepmerge-ts` in `@prisma/config`). Not reachable
  in the PostgreSQL runtime; **not** downgraded to Prisma 6. Tracked as KI-0010.
- `.env` still ignored/untracked; generated client git-ignored; `DATABASE_URL`
  never returned by an endpoint and never logged.

**Docs**

- DEC-0031; PROJECT_STATE, DATABASE (rewritten), ARCHITECTURE, ROADMAP,
  KNOWN_ISSUES (KI-0007 resolved; KI-0010, KI-0011 added), SECURITY, TESTING,
  INTEGRATIONS.

---

## 2026-09-05 — Phase 1.2 — Claude project kit and capability setup

Developer/AI capability system only. No product feature; no application source
changed. Full detail in `docs/ai/CLAUDE_TOOLKIT.md`.

**Added — portable toolkit** (`tooling/claude-project-kit/`)

- One copyable folder: `README.md`, `VERSION`, `manifest.json`,
  `plugins.lock.json`, `install.sh`, `verify.sh`, `update.sh`, `uninstall.sh`,
  `AUDIT.md`, `CANDIDATES.md`, `profiles/` (base, fullstack-typescript,
  frontend-premium, backend, security, testing, design-3d), and
  `project-overrides/khatmsaz/`.
- Local marketplace + `project-kit` plugin with **9 skills** (project-memory-
  maintainer, roadmap-maintainer, decision-recorder, phase-closeout,
  architecture-guardian, debugging-librarian, security-check, test-gate,
  frontend-quality-gate), **3 read-only review agents** (architecture-reviewer,
  frontend-ux-reviewer, documentation-reviewer), and **2 deterministic PreToolUse
  hooks** (guard_secrets, guard_commands).

**Added — enabled plugins (project scope, `.claude/settings.json`)**

- First-party from `anthropics/claude-plugins-official`: `typescript-lsp`,
  `security-guidance` (v2.0.7), `frontend-design`, `commit-commands`,
  `skill-creator`, `feature-dev`; plus local `project-kit`. Always-on ≈ 1,300 tok.
- `pr-review-toolkit` and `plugin-dev` were installed, measured (~1,600 / ~1,700
  always-on tokens), then **disabled** to protect context; recorded as optional.
- KhatmSaz backup-path guard hook wired into `.claude/settings.json`.

**Environment**

- Set user npm global prefix to `~/.local` (no sudo) and installed
  `typescript-language-server@6.0.0` + `typescript@5.9.3` for the LSP plugin.
- Registered marketplaces `claude-plugins-official` (github) and
  `claude-project-kit` (local directory).

**Verification**

- `claude plugin validate` (plugin + marketplace), `claude plugin details` (all
  active plugins), kit `verify.sh` (ALL CHECKS PASSED), hook unit tests.
- Regression: `npm run typecheck` / `lint` / `test` / `build` all PASS; no
  application source changed.

**Dependency changes**

- None in the application (`package.json` / `package-lock.json` untouched). The
  npm global install is a developer-machine tool, not a project dependency.

---

## 2026-09-04 — Phase 1.1 — local validation, repair and closeout

First session with real shell access on the developer machine (WSL Ubuntu 24.04,
Node v24.20.0, npm 11.19.0, Git 2.43.0). Phase 1 was validated end to end and closed.

**Environment / location**

- Project is now at the WSL-native authoritative path `/home/elyas/KhatmSaz`
  (ext4). The old Windows-mounted copy `/mnt/z/KhatmSaz` is a non-authoritative
  backup and was not modified.
- `.env` created from `.env.example` (git-ignored; not staged).

**Dependency install**

- First authoritative `npm install`: 670 packages, **0 vulnerabilities**,
  `package-lock.json` written. Every caret range resolved with **no** manual
  version change — resolved: `next@16.3.4`, `react@19.2.8`, `react-dom@19.2.8`,
  `@nestjs/core@11.2.3`, `typescript@5.9.3`, `typescript-eslint@8.69.0`,
  `eslint@9.39.5`, `jest@29.x`, `ts-jest@29.x`.

**Fixed — lint**

- Added the four missing package ESLint flat configs
  (`packages/{config,shared,contracts,ui}/eslint.config.mjs`). Each package had a
  `lint` script but no config, so `eslint` errored ("couldn't find eslint.config").
- Disabled `@typescript-eslint/consistent-type-imports` in `apps/api` only, with
  an explanatory comment. NestJS DI relies on `emitDecoratorMetadata`, which
  needs classes used only as constructor-parameter types (injected services) to
  remain value imports; the rule would rewrite the `HealthService` import to
  `import type` and break runtime DI. The rule stays enabled for web/admin.

**Fixed — tests**

- Narrowed the Jest `ts-jest` transform in `apps/api` from `^.+\.(t|j)s$` to
  `^.+\.ts$` (in `package.json` and `test/jest-e2e.json`). The old pattern
  transformed the built `@khatmsaz/shared` `.js` files and emitted an `allowJs`
  warning; workspace `.js` is plain CommonJS Node can require directly.

**Validation — all PASS**

- `npm run typecheck`, `npm run lint`, `npm test` (2/2),
  `npm run test:e2e -w @khatmsaz/api` (1/1), `npm run build` (api/web/admin).
- Runtime smoke test: API `GET /health` → HTTP 200 with the intended liveness
  shape and no config leak; web + admin serve HTTP 200 with `lang="fa" dir="rtl"`
  and Persian copy; admin carries `robots: noindex, nofollow`. Processes stopped
  afterwards.
- Docker Compose validated structurally (named volumes only, all ports loopback);
  daemon not run — WSL integration is off for this distro (KI-0007).

**Git**

- `git init -b main`; `git add -A`. Confirmed `.env`, `node_modules/`, build
  output and runtime data are not staged. Repo-local identity set to `Amirali
  Raeesi <raeesiamirali86@gmail.com>` (local scope only, at the user's request)
  and the initial commit `chore: bootstrap khatmsaz workspace` (`38bbee8`) made.
  A follow-up commit syncs these docs to reflect the commit.

**Removed**

- `docs/bootstrap/` (including `FINISH_SETUP.md`) — superseded now that setup ran.
- `nodesource_setup.sh` — an accidental environment-setup artifact, not app source.

---

## 2026-09-04 — Phase 1 bootstrap

**Added — workspace**

- npm workspaces monorepo root: `package.json`, `tsconfig.base.json`, `.nvmrc`
  (Node 24), `.npmrc` with `engine-strict`, Prettier config
- `.gitignore`, `.gitattributes` (LF normalisation for Windows + WSL),
  `.editorconfig`
- `.env.example` — placeholders only, integration tokens intentionally blank

**Added — applications**

- `apps/api` — NestJS skeleton, `AppModule`, `HealthModule`, `GET /health`
  returning `{status, service, version, timestamp, uptimeSeconds}`; unit spec and
  e2e spec; CORS allow-list; loopback binding by default
- `apps/web` — Next.js App Router shell, Persian RTL layout, hero and status
  cards, client-side API health probe
- `apps/admin` — separate Next.js App Router shell, `پنل مدیریت ختم‌ساز`,
  `noindex`, categorised placeholder overview

**Added — packages**

- `packages/config` — `readString/readInt/readBoolean/readList`, `nodeEnvironment`,
  default ports
- `packages/shared` — `Result` helpers, time constants, `isIanaTimeZone`
- `packages/contracts` — `HealthResponse`
- `packages/ui` — temporary green design tokens, RTL base layer, `StatusCard`,
  brand constants

**Added — infrastructure**

- `infra/docker/docker-compose.yml` — PostgreSQL 17, Redis 7, MinIO; named
  volumes; all ports bound to `127.0.0.1`; secrets required from `.env`
- `infra/docker/README.md`

**Added — agent memory**

- `CLAUDE.md`
- `.claude/rules/` — architecture, backend, frontend, security, testing,
  documentation
- `docs/ai/` — PROJECT_STATE, ARCHITECTURE, DOMAIN_MODEL, ROADMAP, DECISIONS,
  CHANGELOG, DATABASE, INTEGRATIONS, DEBUGGING, SECURITY, TESTING, KNOWN_ISSUES
- Decisions DEC-0001 … DEC-0030

**Delivery note**

- `.claude/rules/*.md` and `.npmrc` are staged in `docs/bootstrap/` because the
  delivery bridge refuses to write those paths. See
  `docs/bootstrap/FINISH_SETUP.md`.

**Not done**

- No dependency install, build, lint, typecheck or test was executed — the
  bootstrap session had no package-registry access and no shell on the
  development machine.
- Git was not initialised.
