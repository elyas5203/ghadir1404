# ARCHITECTURE

## Local-only development delivery (DEC-0069)

`PhoneModule` selects an in-memory Unix-socket OTP delivery adapter only with
explicit development opt-in. It implements the existing OtpDelivery port and
introduces no public application route or schema change. CLI-only infrastructure
under `src/local-development/infrastructure` seeds existing models transactionally
and binds numeric Telegram identities without reassignment. This code is not
imported into a production module. See LOCAL_DEVELOPMENT.md for local-only usage.

## Shape

KhatmSaz is a **modular monolith**. One deployable backend, with strongly
isolated modules inside it. Isolation exists so a module *could* be extracted if
scale ever demands it — extraction is not planned and is not a goal.

Microservices, Kubernetes, Kafka, event sourcing and CQRS frameworks are
explicitly out of scope (DEC-0003). Boring, stable, understandable technology
wins.

## Product boundary (DEC-0047)

KhatmSaz is a **single, independent product**. Internal identity (`User`,
`PlatformIdentity`, phone claims, account merge) exists **only within KhatmSaz**.
The **Telegram Bot, Bale Bot, and Web App are channels of the one product** and
share KhatmSaz's identity; `Platform` names a messaging *channel*, not a product.
Future products (study bot, donation bot, …) are **separate products with their own
isolated identity** — do **not** design cross-product / shared identity, and there
is no product/tenant dimension on identity. Account merge unifies the same person
across KhatmSaz's own channels — it is intra-product, not cross-product.

## Stack

| Layer            | Choice                         | Status          |
| ---------------- | ------------------------------ | --------------- |
| Language         | TypeScript                     | In use          |
| Runtime          | Node.js 24 LTS                 | In use          |
| API              | NestJS                         | In use          |
| Web / Admin      | Next.js (App Router) + React   | In use          |
| Workspace        | npm workspaces                 | In use          |
| Database         | PostgreSQL + Prisma (ORM)      | In use (Ph. 2A) |
| Queue / schedule | Redis + BullMQ                 | Planned (Redis runs locally) |
| Object storage   | S3-compatible (MinIO locally)  | Planned (MinIO runs locally) |
| Messaging        | Telegram, then Bale            | Planned         |
| Tooling          | Python, isolated utilities only | Possible later |

Python is **not** a backend language here. It may later be used for isolated
tooling such as PDF/media processing or import utilities.

## Repository layout

```
apps/
  api/        NestJS backend — future home of domain and application modules
  web/        Next.js participant + creator dashboard (Persian, RTL)
  admin/      Next.js administration interface, deliberately separate
packages/
  kernel/     framework-independent DOMAIN kernel — shared cross-capability
              primitives (canonical UUIDv7 ids). Capabilities depend on it; it
              depends on nothing in the app. No NestJS/Next/React/DB/HTTP.
  shared/     framework-independent utilities
  contracts/  DTO / API / event shapes — no business logic
  ui/         design tokens and UI primitives
  config/     non-secret configuration helpers
infra/
  docker/     local development infrastructure
docs/ai/      long-term project memory
.claude/rules/ path-scoped rules for coding agents
```

## Dependency direction

```
apps/*  ──►  packages/*
packages/* ──X──► apps/*        (forbidden)
packages/shared ──X──► any framework   (forbidden)

capability ──►  packages/kernel        (shared domain primitives)
capability ──X──►  another capability's domain   (forbidden — use the kernel)
```

**Shared domain kernel (DEC-0039).** Cross-capability domain primitives — today
canonical UUIDv7 id generation/validation — live in `@khatmsaz/kernel`, a
framework-independent package. Capabilities depend on the kernel, **never on each
other's domain**. This removed the earlier `phone/domain → identity/domain`
coupling: `phone` now imports id primitives from the kernel. `identity` re-exports
the kernel under its historical names for stability. The kernel must stay a true
kernel (only genuinely shared primitives), not a catch-all.

## Adapters

Every external platform sits behind an adapter (DEC-0018):

```
domain module  ──►  port (interface owned by the domain)
                       ▲
                       │ implements
                 adapter module  ──►  vendor SDK
```

A domain module must never import a Telegram, Bale, SMS or payment SDK. This is
what keeps a second messaging platform from rewriting the domain.

## Khatm execution engine

The engine will be **generic** — driven by Khatm templates and configuration —
rather than a hard-coded implementation per prayer type (DEC-0019). Quran will
eventually support both a structured/rotational model and a free participation
model; the MVP starts with the structured model only (DEC-0020, DEC-0021).

## Persistence boundary

PostgreSQL is reached through **Prisma**, which is confined to the API's
infrastructure layer at `apps/api/src/infrastructure/database` (DEC-0031). The
`@Global` `DatabaseModule` is the only door to persistence. It owns a single
application-lifetime Prisma client and exports **abstractions**, not Prisma: the
readiness probe today, and repository interfaces owned by the domain as real
modules arrive. The generated Prisma client and Prisma types never leave the
infrastructure layer — nothing in the domain imports Prisma, mirroring the
adapter rule for platform SDKs. Reviewable, checked-in migrations are the
standard; see `docs/ai/DATABASE.md`.

The **identity** capability (Phase 2B) is the first module to follow this shape:
`src/identity/{domain,application,infrastructure}`. The domain owns the entities
(`User`, `PlatformIdentity`), the `Platform` enum, and the repository **ports**
(`UserRepository`, `PlatformIdentityRepository`); the Prisma-backed
implementations and mapper live in `identity/infrastructure` and are the only
code there importing Prisma. The domain depends on an interface it owns, and
infrastructure implements it — the same rule as platform adapters.

The **phone** capability (Phase 3A) is the second module in the same shape:
`src/phone/{domain,application,infrastructure}`. It broadens the adapter rule
beyond persistence — the domain owns not just repository ports but also a
`PhoneNormalizer` port (phone → E.164), `OtpCodeGenerator`/`OtpCodeHasher` ports
(crypto), and an `OtpDelivery` port (the **SMS seam**). Their implementations live
in `phone/infrastructure` and are the only code importing `libphonenumber-js` or
Node crypto; `OtpDelivery`'s default binding is a no-op adapter, since **no real
SMS provider is integrated yet** (DEC-0036) — a vendor SMS adapter will implement
the same port later without touching the domain. The two hard uniqueness invariants
are enforced by partial unique indexes in the database (DEC-0034), not application
checks.

## Transaction boundary

Multi-aggregate atomic operations run through a **Prisma-free `UnitOfWork` port**
(`UNIT_OF_WORK`, DEC-0044). A use-case calls `uow.run(work)`; `work` receives an
**opaque `TransactionContext`** which it passes into transaction-aware repository
methods (`method(..., tx?)`). The port, the token, and the context type live in
**`@khatmsaz/kernel`** so both application use-cases and domain repository ports can
reference them without importing infrastructure; the `PrismaUnitOfWork`
implementation, the `dbClient(prisma, tx?)` helper, and the single `txClient()`
unwrap of the opaque handle live in infrastructure (`prisma-unit-of-work.ts`),
bound to `UNIT_OF_WORK` by the global `DatabaseModule`. Application code orchestrates
a transaction without importing Prisma. The account-merge use-case and the
change-phone flow run inside it.

## Cross-capability orchestration (account merge)

The **`account-merge`** capability (`src/account-merge/`) is an application-only
ORCHESTRATION module: it composes the identity and phone capabilities' domain-owned
repository ports (exported by `IdentityModule` / `PhoneModule`) to resolve a
verified-ownership conflict. Neither identity nor phone depends on the other; only
the orchestrator imports both. It is intra-product (DEC-0047) — winner and loser are
both KhatmSaz accounts — and does move-not-delete work atomically inside the
transaction boundary. This is the sanctioned pattern for a use-case that spans
capabilities: a dedicated orchestration module, not a domain-to-domain import.

The **`khatm-workflow`** capability (`src/khatm-workflow/`, Phase 4.2) is the second
orchestration module and the same pattern, one level up: it composes the **exported
services** of identity, khatm and allocation into end-to-end workflows (create →
activate → join → allocate → complete). It adds only the cross-capability
preconditions the individual services cannot own alone — the creator/joiner must be
an ACTIVE user (not a merged tombstone, DEC-0054), a khatm must have a valid
allocation plan before activation (DEC-0055), and a khatm completes only when every
portion is completed (DEC-0056). Unlike account-merge it composes **services rather
than repository ports**, because no workflow needs a *new* cross-capability atomic
transaction — the multi-write steps (plan generation, batch allocation, holder-checked
completion) already run inside the allocation capability's `UnitOfWork`. It owns no
domain, no persistence and no transaction of its own. No transport calls it yet.

## Transport layer (Phase 5)

Transport is a **thin outer layer that drives the application workflows** — it never
holds business logic (DEC-0057, DEC-0058). Two transports exist, each its own module:

- **HTTP/REST** (`src/http-api/`, `HttpApiModule`): thin controllers under
  `/api/khatms` and `/api/portions` that validate an untrusted request into a
  `@khatmsaz/contracts` DTO, call an application service (`KhatmWorkflowService` /
  `KhatmService`), and map the result back to a contract DTO. A domain entity or
  Prisma type never crosses the boundary; a `DomainExceptionFilter` turns capability
  errors into a stable `{error:{code,message}}` envelope. Validation policy lives in
  the transport (dependency-free parsers), not in contracts (shapes only) or the
  domain (which re-validates regardless). `/health` is unchanged.
- **Telegram** (`src/telegram/`, `TelegramModule`): a **channel adapter** in the
  DEC-0018 sense. The command layer speaks only vendor-neutral `TelegramUpdate` /
  `TelegramReply` shapes — the adapter boundary — so no Telegram SDK type reaches the
  application/domain. Commands resolve the caller's platform identity through the
  identity capability (`/start` provisions a user) and route to the khatm workflows
  with Persian replies. **Phase 9 (DEC-0065)** connected this to the **real Bot API**,
  entirely in `telegram/infrastructure`: a **secret-verified webhook**
  (`POST /telegram/webhook`) maps raw updates to the neutral shape and dispatches
  through the existing gateway, and a **`fetch`-based `BotApiTelegramSender`**
  (no SDK) implements the outbound port. It is **config-gated** — an empty
  `TELEGRAM_BOT_TOKEN` keeps the no-op sender and an empty `TELEGRAM_WEBHOOK_SECRET`
  disables the webhook — so the app builds/runs/tests with an empty environment and
  exposes no open command surface until configured.

Both transports import only the capability modules whose **exported services** they
call; neither adds persistence, a transaction, or a domain rule.

## Authentication & sessions (Phase 6)

The `session` capability (`src/session/`, DEC-0059/0060) provides **authentication**:
server-side sessions with **opaque bearer tokens**. A 256-bit CSPRNG token is issued
once and never stored; only its **SHA-256 hash** is persisted (no server pepper — the
token's entropy makes one unnecessary, the deliberate contrast with the low-entropy
OTP's keyed HMAC). Status (ACTIVE/REVOKED/EXPIRED) is derived from timestamps, so
revocation is instant (mark the row) with no JWT-blacklist machinery. A session
authenticates only when ACTIVE **and** its user is still an active account.

Transports resolve an **`AuthenticatedPrincipal`** (`{ userId, sessionId }`) instead
of trusting a caller-supplied id: HTTP via a `SessionAuthGuard` reading a bearer
token; Telegram from the platform identity (channel-authenticated, `sessionId:
null`). **Phone-first login (Phase 10, DEC-0066)** needs no caller-supplied id: a
**user-less `PHONE_LOGIN` OTP challenge** proves phone possession decoupled from any
user, then the session orchestration resolves the verified owner or creates a user
and mints the session — the Phone capability is extended, never rewritten, and never
imports Identity. **Browser sessions ride an httpOnly, `SameSite=Lax` cookie (Phase
10, DEC-0067)**: the raw opaque token never reaches JavaScript; the `SessionAuthGuard`
accepts the cookie first, then the `Authorization: Bearer` header, so bearer clients
still work. Sessions stay opaque and revocable — no JWT.

## Authorization (Phase 7)

The `authorization` capability (`src/authorization/`, DEC-0061/0062/0063) answers one
question — **"is this user allowed?"** — distinct from authentication (session, "who
is this?") and from the domain ("is this action valid?"). It models a **`Capability`**
grant (user + type, with grant/revoke history; one active grant per (user, type) via
a partial unique index); the only type is **CREATOR** (no Admin). Granting is an
**explicit internal mechanism** — there is no public onboarding/grant endpoint, and
**how** a user earns CREATOR is a product rule not decided here.

Enforcement lives in the **`khatm-workflow` orchestration layer** (where "who" meets
"what"), not in transport (which stays thin — it only passes the principal) and not
in the domain aggregate: **creating** a khatm requires the CREATOR capability;
**managing** one (activate, generate plan, allocate, complete) requires **ownership**
(`principal.userId === khatm.creatorUserId`), which closes the Phase-6 IDOR.
**Participant** actions (join, complete own portion) stay participant logic.
Authentication failure is a **401**; authorization failure a **403** — kept distinct,
with generic denial messages (no capability enumeration, no owner disclosure).

## Web app (Phase 8)

`apps/web` (Next.js App Router, Persian/RTL) is a **thin client** over the HTTP API
(DEC-0064): `Web UI → HTTP API → application services → domain`. It holds **no
business logic** and is **never a security boundary**. A small typed client library
(`src/lib`) is the only path to the backend — `api-client` injects the bearer token
and maps the `{error:{code,message}}` envelope to a typed `ApiError`; `auth-context`
holds the session token **in memory only** (no `localStorage`/cookies — "no secret
stored client-side"); `permissions`/`RequireAuth` gate what the UI *offers/routes*
but the backend re-authenticates (401) and re-authorizes (403) every action. The web
login reuses the existing user-scoped phone-OTP model (it is not a new auth system);
end-to-end login needs a real SMS provider (deferred). No Prisma or domain type ever
reaches the UI — only `@khatmsaz/contracts` DTOs.

## Time

Each Khatm carries a canonical timezone that defines its day boundary and
deadlines. Reminder display and delivery may additionally account for the
individual user's local timezone (DEC-0016, DEC-0017).

## Not decided yet

- Session and authentication mechanism for the web app (passwordless direction
  recorded in DEC-0027, mechanism undesigned)
- Deployment topology
