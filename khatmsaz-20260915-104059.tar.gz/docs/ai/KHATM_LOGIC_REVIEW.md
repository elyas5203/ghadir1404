# Khatm Logic Review — 2026-09-11

> A product-level analysis of the current division/allocation model and its
> fitness for real user scenarios. Does NOT prescribe implementation — see
> ROADMAP.md for planned phases.

---

## 1. Current model summary

### COMMITMENT khatm

1. Creator defines khatm (title, template type).
2. Creator generates an **Allocation Plan**: specifies `total` units and `chunk` size.
   - `kind: QUANTITY` → divides `total / chunk` → N portions of `chunk` units each.
   - `kind: POSITIONAL` → assigns sequential ranges (جزء 1–30 for Quran).
3. Creator activates the khatm (requires ≥1 portion in the plan).
4. Participants join via invitation link.
5. Creator allocates portions to participants manually (picks participant + count).
6. Participant marks their portion complete via `POST /completePortion/:portionId`.
7. Progress = `completed / total` portions.
8. Creator marks khatm complete when all portions are done (or forces it).

### OPEN khatm

1. Creator defines khatm (title, template type).
2. Creator activates immediately — no allocation plan required.
3. Participants join via invitation link.
4. Participants record contributions freely (`amount + note`).
5. Progress = aggregate `sum(amount)` across all contributions.
6. Completion policy: **deferred** — no automated completion trigger exists yet.

---

## 2. Are the current rules correct?

### COMMITMENT model — assessment

**Correct:**
- The allocation plan → portion → assignment chain is sound domain design.
- Portions are RESTRICT-FK-protected — deleting a plan or khatm with live
  portions is blocked, preventing accidental data loss.
- Partial unique index prevents double-allocation of positional ranges.
- COMMIT-style: progress is deterministic (not estimated).

**Edge cases and gaps:**

| # | Gap | Severity |
|---|-----|----------|
| 1 | Portions can be allocated to a participant **more than once** (multiple ASSIGNED portions). The domain allows it; no cap per participant. | Medium |
| 2 | A portion can only be completed by the **assigned participant** (via `completeHeldPortion`). If the participant leaves or is removed, the portion is stuck ASSIGNED and the khatm can never be completed. | High |
| 3 | Creator can call "اعلام پایان ختم" only when `total === completed`. But `total` includes OPEN (unassigned) portions. A khatm with 30 portions but only 25 assigned can never complete unless the creator re-assigns the remaining 5. | Medium |
| 4 | The `GeneratePlan` UI defaults to `total: 1000, chunk: 100` — meaningless defaults for a Quran khatm (30 جزء, not 1000 آیه). Users will create plans they don't understand. | High (UX) |
| 5 | Re-generating a plan does not clear prior allocations. The system may end up with 30 + 40 = 70 portions from two separate plan generations. | Medium |
| 6 | No expiry or timeout on allocated portions. A participant who disappears blocks the khatm indefinitely. | Medium |

### OPEN model — assessment

**Correct:**
- No mandatory plan is the right design for informal group recitation.
- Aggregate progress is intuitive for this model.
- `OpenContribution.amount` is a `Float`, which allows decimal values (e.g. 0.5 جزء).

**Gaps:**

| # | Gap | Severity |
|---|-----|----------|
| 1 | No completion rule. The creator has no automated way to know when the khatm goal has been reached. The "اعلام پایان ختم" button still requires all COMMITMENT portions to be done (which there are none in OPEN), so it always triggers `KhatmNotCompletableError`. | Critical |
| 2 | No target/goal defined for OPEN khatms. There is no "goal" field — the creator cannot say "we want to complete 30 جزء". Progress is an unbounded sum with no ceiling. | High |
| 3 | No unit label. The `amount` field has no attached unit — is it آیه, صفحه, جزء? Different participants may record in different units. | High |
| 4 | A participant can record contributions without having joined (if participation endpoint allows it). The workflow checks for a participation via `findMyParticipation`, but no explicit guard verifies the participation is ACTIVE. | Medium |

---

## 3. Is the model scalable?

The domain model is well-suited to groups of 5–200 participants, which covers
the primary use case (family khatm, neighbourhood group, university circle).

At scale (>500 participants, >1000 portions):
- Allocation queries become expensive without proper indexing on `participationId`.
  The schema currently has `@@index([allocationPlanId])` on portions but not on
  `participationId`. This is addressable with a migration.
- `progressForKhatm` (`completed / total / open / assigned` counts) runs a
  GROUP BY aggregation — acceptable at current scale, may need caching at 10k+.
- OPEN contributions (`sum(amount)` query) scales linearly — fine up to millions of rows.

---

## 4. Is the model understandable for normal users?

**Creator experience problems:**

1. "برنامهٔ تقسیم‌بندی" (allocation plan) is an abstract concept. Most creators
   think in terms of "ختم قرآن = 30 جزء" not "total=1000, chunk=100".
2. Allocating portions manually (picking a participant from a UUID dropdown) is
   a developer workflow, not a user workflow. Automatic fair-distribution or
   "give me X portions" is what creators expect.
3. The two-step activation (build plan → activate) is not communicated in the UI.
   Users tap "فعال‌سازی" and get a cryptic error.

**Participant experience problems:**

1. Participants see their portion as "جزء X تا Y" (positional) or "N واحد"
   (quantity). Neither tells them what that means in real terms for their prayer.
2. Completing a portion has no celebration or acknowledgement state.
3. Participants cannot see who else is participating or overall group progress
   without asking the creator.

---

## 5. Analysis of khatm variations

### 5.1 قرآن کامل (Quran Full — 30 جزء)

- Canonical COMMITMENT model.
- Natural plan: 30 portions, 1 جزء each, positional (جزء 1–30).
- The system supports this but the UI does not suggest it automatically.
- **Recommendation:** Add a "smart default" that detects `templateType === QURAN_FULL`
  and pre-fills `total=30, chunk=1, kind=POSITIONAL`.

### 5.2 صلوات / دعا (Salawat / Dua — count-based)

- COMMITMENT model with QUANTITY kind.
- Example: 1,000 صلوات, 100 per person → 10 portions.
- Works today. Creator must know to use QUANTITY kind.
- **Recommendation:** Template-specific defaults per type.

### 5.3 ختم روزانه / هفتگی (Daily / Weekly)

- Not supported. Current model has no time dimension on portions.
- Each portion has no "due by" date.
- A recurring structure (e.g. "one جزء per participant per day for 30 days")
  requires a new scheduling dimension.
- **Assessment:** Deferred. Current model is not wrong — it simply lacks time-gating.

### 5.4 ختم خیریه (Charity-linked)

- Payments/donations are not part of the current model.
- A charity khatm might say "هر جزء = 10,000 تومان".
- The payment integration is a future phase (deferred in ROADMAP).
- **Assessment:** Current model does not block this; payment is additive.

### 5.5 ختم خانوادگی (Family Khatm)

- Small group (3–15 people), all known to each other, informal.
- The full allocation plan generation is overkill; a lightweight "درخواست سهم"
  (self-claim) flow would fit better.
- The OPEN model is a reasonable substitute today.
- **Assessment:** OPEN khatm covers this use case acceptably.

### 5.6 ختم رمضانی (Ramadan)

- Typically: 30 participants, 1 جزء each, over 30 days.
- Conceptually identical to Quran Full COMMITMENT khatm + daily pacing.
- No calendar integration today.
- **Assessment:** Works structurally; lacks date-based reminders.

---

## 6. Recommended next steps (not implementation — roadmap only)

1. **Fix OPEN completion gate**: Allow creator to mark an OPEN khatm complete
   regardless of portions (there are none). Add optional `goal` field to khatm.
2. **Smart plan defaults**: Auto-suggest plan parameters based on `templateType`.
3. **Self-allocation ("درخواست سهم")**: Participants claim an open portion
   themselves rather than waiting for creator to assign.
4. **Stuck-portion recovery**: Creator can re-assign a portion from a REMOVED
   participant to another, or mark it open again.
5. **OPEN contribution unit**: Add optional unit field to `OpenContribution`
   (or to the khatm definition).
