# CLAUDE_TOOLKIT

How Claude Code is extended for this project. Added in **Phase 1.2 (2026-09-05)**.
This describes reality; the portable source lives in
`tooling/claude-project-kit/`.

## Summary

KhatmSaz uses a curated, low-overhead Claude Code setup installed at **project
scope** (declared in `.claude/settings.json`, shared via git). Everything active
is either first-party (Anthropic) or authored in this repo. No community plugin,
no network-calling plugin, and no secret-touching plugin is enabled by default.

Total always-on context added ≈ **1,300 tokens** (LSP and security hooks are
out-of-process / harness-only and add ~0).

## Active plugins (project scope)

| Plugin | Marketplace | Why | Always-on |
|--------|-------------|-----|-----------|
| `typescript-lsp` | claude-plugins-official | TS/JS code intelligence (defs, refs, diagnostics) | ~0 (out-of-process) |
| `security-guidance` | claude-plugins-official | secret/injection/XSS/SSRF guardrails on edits, Stop, commit | ~0 (harness hooks) |
| `frontend-design` | claude-plugins-official | non-generic, high-quality UI/UX — supports the Persian RTL goal | ~59 |
| `commit-commands` | claude-plugins-official | git commit / push / PR workflow | ~71 |
| `skill-creator` | claude-plugins-official | authoring/evaluating skills | ~87 |
| `feature-dev` | claude-plugins-official | feature workflow: explorer / architect / reviewer agents | ~194 |
| `project-kit` | claude-project-kit (local) | this repo's skills + review agents + safety hooks | ~886 |

### Dependency

`typescript-lsp` needs the TypeScript language server on PATH. Installed
user-level without sudo:

```bash
npm config set prefix ~/.local && npm install -g typescript-language-server typescript@5
```

Verified: `typescript-language-server` 6.0.0 on PATH; global `typescript` pinned
to 5.9.3 (classic `tsserver.js` present) to match the project and give a sane
global fallback. Inside the workspace the LSP uses the project-local
`typescript@5.9.3`.

## The `project-kit` plugin (authored here)

Source: `tooling/claude-project-kit/plugins/project-kit/`.

- **Skills (9)** — `project-memory-maintainer`, `roadmap-maintainer`,
  `decision-recorder`, `phase-closeout`, `architecture-guardian`,
  `debugging-librarian`, `security-check`, `test-gate`, `frontend-quality-gate`.
  Guidance only; loaded on demand (progressive disclosure).
- **Agents (3)** — `architecture-reviewer`, `frontend-ux-reviewer`,
  `documentation-reviewer`. Read-only reviewers (tools: Glob, Grep, LS, Read,
  Bash-for-diff). They review and report; they do not edit or change architecture.
- **Hooks (2, PreToolUse)** — `guard_secrets` blocks writing secret/credential
  files; `guard_commands` blocks unambiguously catastrophic shell commands. Pure
  python, no network, block-or-allow only.

### KhatmSaz-specific guard (not portable)

`.claude/settings.json` wires a project hook
`tooling/claude-project-kit/project-overrides/khatmsaz/hooks/guard_backup.py`
that blocks any Write/Edit or mutating Bash command targeting the
`/mnt/z/KhatmSaz` backup. Reading the backup is allowed.

## Scope strategy

- **Project scope** for all plugins, so the repo documents its expected tooling
  and the team shares it. The only user-level footprint is the official
  marketplace registration (a pointer) and the npm global prefix for the LSP.
- The kit's own local marketplace is registered with a **machine-specific
  absolute path**; `install.sh` re-registers it per checkout. See KNOWN_ISSUES.

## Optional profiles (not enabled by default)

`tooling/claude-project-kit/profiles/`: `base`, `fullstack-typescript` (the
active one), `frontend-premium`, `backend`, `security`, `testing`, `design-3d`.
Optional plugins recorded but disabled: `pr-review-toolkit`, `plugin-dev`
(both installed-then-disabled to save always-on context), and catalog-only
`context7` (remote docs MCP — network egress), `playwright` (E2E browser MCP),
`claude-security`, `claude-md-management`. See `CANDIDATES.md` and `AUDIT.md`.

## Memory responsibility split (unchanged system, clarified)

- `CLAUDE.md` — stable operating rules.
- `.claude/rules/` — scoped rules.
- `docs/ai/PROJECT_STATE.md` — latest authoritative state (source of truth).
- `docs/ai/DECISIONS.md` / `ROADMAP.md` / `CHANGELOG.md` — durable history.
- Kit **skills** — procedures loaded only when needed. They point at these docs;
  they do not duplicate them.
- Claude auto-memory — convenience only, never the source of truth.

## Install / verify / update / disable

```bash
./tooling/claude-project-kit/install.sh     # register marketplaces + enable default profile (project scope)
./tooling/claude-project-kit/verify.sh      # read-only checks + hook self-tests
./tooling/claude-project-kit/update.sh      # refresh + update plugins (restart to apply)
./tooling/claude-project-kit/uninstall.sh   # remove kit plugins from this project
```

Individual control:

```bash
claude plugin list
claude plugin details <plugin>@<marketplace>
claude plugin disable <plugin>@<marketplace> --scope local   # just for you
```

Newly enabled/updated plugins load on the **next** Claude Code session.

## Performance / context notes

- The Stop/commit hooks in `security-guidance` run an LLM diff review each time
  you stop or commit. Valuable, but if it slows a session, disable it:
  `claude plugin disable security-guidance@claude-plugins-official --scope local`.
- Heavy review/authoring plugins are intentionally disabled by default to keep
  always-on context small; enable per session when needed.
