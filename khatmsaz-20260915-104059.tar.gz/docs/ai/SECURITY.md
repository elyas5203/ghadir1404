# SECURITY

## Principles

1. Secrets never enter the repository.
2. Development services are not reachable from outside the machine.
3. No endpoint reveals configuration.
4. Sensitive personal data is exported only by authorised top-level admins.
5. Findings are reported honestly, not hidden.

## Secret handling

- `.env` and every `.env.*` variant are git-ignored; only `.env.example` is
  tracked. `.gitignore` also blocks `*.pem`, `*.key`, `*.p12`, `*.pfx`, `*.crt`,
  `secrets/`, `credentials*.json` and `service-account*.json`.
- `.env.example` contains **placeholders only**. Integration tokens
  (`TELEGRAM_BOT_TOKEN`, `BALE_BOT_TOKEN`, `SMS_PROVIDER_API_KEY`,
  `PAYMENT_GATEWAY_API_KEY`) ship blank and the repository must build and test
  with them blank.
- `POSTGRES_PASSWORD` and `S3_SECRET_KEY` in `.env.example` are
  `local_dev_only_change_me` — **local-only placeholders**, documented as such,
  never to be reused in any shared environment.
- `docker-compose.yml` uses `${VAR:?message}` for both secrets, so the stack
  refuses to start rather than falling back to a default credential.

## Network exposure

- The API binds to `127.0.0.1` by default (`API_HOST`).
- Every compose port mapping is `127.0.0.1:<port>:<port>` — PostgreSQL, Redis,
  MinIO API and MinIO console are unreachable from the LAN.
- CORS is an explicit allow-list read from `API_CORS_ORIGINS`, defaulting to the
  local web and admin origins. **Never `*`.**

## Endpoint exposure

- `GET /health` returns exactly `status`, `service`, `version`, `timestamp`,
  `uptimeSeconds`. It contains no environment values, no configuration, no
  dependency inventory, no host details. A unit test asserts the exact key set
  so this cannot regress silently.
- `poweredByHeader: false` on both Next apps.
- The admin app sets `robots: noindex, nofollow`.

## Logging rules

Never log: phone numbers, OTP codes, tokens, payment identifiers, full request
bodies, or connection strings.

## Data-handling rules

- Creators must never receive a downloadable Excel/CSV containing participant
  phone numbers (DEC-0022).
- Bulk export of sensitive data is reserved for authorised top-level
  administration and must be audit-logged (DEC-0023).
- An unverified phone number proves nothing and must never drive authorisation
  (DEC-0011).

## Identity data handling (Phase 2B)

- **Data minimisation.** `users` stores only `id`, `created_at`, `updated_at` —
  no name, email, phone or profile. `platform_identities` stores the external
  account `subject` and platform; no tokens, no credentials, no display data.
- **No secrets stored.** A platform `subject` (e.g. a Telegram numeric user id) is
  a public external identifier, not a secret. **No bot token, OTP, or credential**
  is stored by the identity models.
- **Phone deferred.** No phone column and no verification claim exists; an
  unverified number must never be modelled as identity (DEC-0011, DEC-0032).
- **No sensitive logging.** Identity domain errors never echo the `subject`;
  repositories translate Prisma error codes to domain errors without logging the
  row or query.
- **Canonical id is opaque and non-enumerable** (UUIDv7), never a phone/username.

## Phone & OTP data handling (Phase 3A)

- **OTP secrecy (DEC-0035).** Codes are generated with a CSPRNG
  (`crypto.randomInt`), are single-use, short-lived, and attempt-bounded. A code is
  **never** persisted in plaintext, logged, returned in any response, or included in
  any domain error — stored only as an **HMAC-SHA-256 keyed by a server-side pepper**
  (`OTP_HMAC_SECRET`), with the message bound to `(e164, purpose)`. The pepper is
  read via `@khatmsaz/config.otpHmacSecret()` (fail-fast in production, local
  placeholder otherwise) and is never logged or echoed. Comparison is constant-time.
- **Brute-force resistance.** ~20 bits of code entropy is protected by the keyed
  HMAC (offline brute-force needs the pepper, which is not in the DB) plus bounded
  attempts and a short TTL; a resend supersedes the prior challenge so only one is
  live.
- **Replay prevention.** A verified code consumes its challenge (`consumed_at`);
  a consumed/expired/superseded challenge is inactive. The `(e164, purpose)` binding
  prevents reusing a hash for a different number or purpose.
- **PII minimisation.** A phone number is PII: it is never logged (the no-op
  delivery adapter logs neither the code nor the number), and errors involving phone
  input never echo the value. Only canonical E.164 + optional ISO region are stored.
- **Enumeration safety (DEC-0037).** A verified-ownership conflict is surfaced as
  `MERGE_REQUIRED` with **no** detail about the other account, so a future public
  response can reveal "merge required" without disclosing whether/whom a number
  belongs to. Unverified numbers are not globally unique and prove nothing (DEC-0011),
  so claiming one reveals nothing about other accounts.
- **DB-enforced ownership.** "One active verified owner per number" is a partial
  unique index, so concurrency cannot create two verified owners even if application
  logic were bypassed.
- **No new secret in git.** `.env` (hook-protected) was **not** modified;
  `.env.example` ships `OTP_HMAC_SECRET` blank with a documented dev fallback.

## Database exposure (Phase 2A)

- `DATABASE_URL` / the connection string is **never** returned by any endpoint.
  `GET /health/ready` returns only `{status, checks:{database}, timestamp}`; a
  unit test and an integration test assert no `postgres(ql)://` and no
  `password` appears in the body.
- The connection string is **never logged**. `PrismaService` and the readiness
  probe log only fixed, secret-free messages, and deliberately never log the
  underlying error object (which can contain the URL). Configuration errors from
  `@khatmsaz/config.databaseUrl()` name only the missing variable / the protocol,
  never the value.
- Default local credentials (`POSTGRES_PASSWORD`, `S3_SECRET_KEY` =
  `local_dev_only_change_me`) are **development-only placeholders**; `.env.example`
  documents `DATABASE_URL` as optional (derived from `POSTGRES_*`) and commented
  out, so no real value ships. No cloud/hosted-database or Prisma-Cloud credential
  was introduced (Prisma is used as ORM/migration tooling against our own DB).
- The generated Prisma client is **git-ignored** and regenerated on demand — no
  generated artifact or secret is tracked.

## Local Docker daemon posture (development only)

`docker info` reports `WARNING: DOCKER_INSECURE_NO_IPTABLES_RAW is set` on the
local Docker Desktop daemon. This weakens iptables handling and is acceptable
**only** for local development — it must never be treated as a production
configuration (KI-0011). This task did not (and must not) reconfigure Docker
Desktop.

## Dependency audit

**Run 2026-09-05 (Phase 2A) — 4 high, dev-tooling only, not runtime-reachable.**
All four advisories trace to the pinned **`prisma@7.10.0` CLI devDependency**:
`mysql2@3.15.3` (a MySQL driver the CLI bundles; we use PostgreSQL and never load
it) and `deepmerge-ts` via `@prisma/config`. `npm ls mysql2` confirms the only
path is `apps/api → prisma → mysql2`; the runtime client (`@prisma/client` +
`@prisma/adapter-pg` + `pg`) is clean. **Not fixed:** the only offered fix
downgrades `prisma` to `6.19.3`, reversing DEC-0031; the vulnerable paths are not
exercised. Tracked as KI-0010. Re-run after any dependency change.

**Re-checked 2026-09-06 (Phase 2B) — unchanged.** Adding `uuid@14.0.2` introduced
**0** new advisories; the 4 highs remain confined to the `prisma` CLI
devDependency (KI-0010).

**Re-checked 2026-09-06 (Phase 3A) — unchanged.** Adding `libphonenumber-js@1.13.12`
(MIT, zero runtime deps) introduced **0** new advisories; the 4 highs remain the
same `prisma` CLI devDependency tree (KI-0010).

**Prior run 2026-09-04 (Phase 1.1) — 0 vulnerabilities** against the first
authoritative `package-lock.json`. Report critical and high findings; do not burn
a phase chasing transitive low-severity warnings.

## Phase 1 review result (2026-09-04, re-verified Phase 1.1)

| Check                                             | Result |
| ------------------------------------------------- | ------ |
| No `.env` committed (and `.env` git-ignored)       | PASS   |
| No credential, token or key in tracked source      | PASS   |
| Secrets ignored by `.gitignore`                    | PASS   |
| `node_modules` not tracked                          | PASS   |
| Compose refuses to start without real secrets      | PASS   |
| All dev ports bound to loopback                    | PASS   |
| CORS not `*` (explicit allow-list)                 | PASS   |
| `/health` returns liveness only (no env leak)      | PASS — verified at runtime + unit key-set guard |
| Admin `robots: noindex, nofollow`                  | PASS — verified at runtime |
| Dependency audit                                   | PASS — 0 vulnerabilities |

## Phase 1.2 — Claude toolkit security posture (2026-09-05)

The Claude Code toolkit (`tooling/claude-project-kit/`, see `CLAUDE_TOOLKIT.md`)
was added with a conservative posture; full assessment in the kit's `AUDIT.md`.

- **Only first-party or self-authored plugins are enabled.** No community plugin,
  no network-calling plugin, and no secret-touching plugin is active by default.
- **No `curl | bash`** from any source; nothing untrusted was executed.
- **Project scope** for all plugins; the only user-level changes are the official
  marketplace pointer and an npm global prefix (`~/.local`, no sudo).
- The kit adds **deterministic PreToolUse guard hooks**: `guard_secrets` blocks
  writing `.env`/keys/credential files; `guard_commands` blocks catastrophic
  shell commands; a KhatmSaz override blocks mutating the `/mnt/z/KhatmSaz`
  backup. All are pure-python, offline, block-or-allow only, and unit-tested.
- Networked/heavy tooling (`context7` remote docs MCP, `playwright` browser MCP)
  is **recorded but not enabled** — opt-in per project (see `CANDIDATES.md`).
- `.env` remains git-ignored and untracked; the new guard hooks actively prevent
  writing secrets into the repo.
