# DOMAIN_MODEL

> **Status: high-level concepts only**, except **User**, **Platform Identity**
> (Phase 2B), **Phone Claim** + **OTP Challenge** + **Account Merge** (Phase 3A/3B),
> **Khatm**, **Khatm Template**, **Membership/Participation** + **Assignment**
> (Phase 4), and the **Allocation Engine** — Allocation Plan + Plan Portion (Phase
> 4.1), which are implemented (see DATABASE.md for the schema). Every other
> concept below is still high-level — no tables, columns or relationships. Do not
> invent fields. If a rule is not written here, ask before assuming it.

## Concepts

### User — implemented (Phase 2B)

The canonical actor. Identified solely by an **internal, immutable UUIDv7**
generated in application code and stored as a native PostgreSQL `uuid`
(DEC-0010, DEC-0032) — never a phone number, platform account, username or email.
The id primitive (generate/validate) is owned by the shared kernel
`@khatmsaz/kernel` (DEC-0039), not the identity capability. The entity carries only
identity-foundation fields plus a lifecycle: `id`, `status` (`ACTIVE`/`MERGED`,
DEC-0040), `mergedIntoId` (the tombstone/alias pointer, DEC-0041), `createdAt`,
`updatedAt`. Profile data is still deferred; moderation/erasure states are not added
until a written requirement exists. A MERGED user is a **tombstone** retained (never
deleted) pointing at its canonical winner. The lifecycle exists as of the Phase 3B
foundation; the code that *transitions* a user to MERGED (the merge use-case) is a
later Phase 3B step.

### Platform Identity — implemented (Phase 2B)

A link between a User and an account on an external platform (`TELEGRAM`, `BALE`,
more later). It is only an external **claim/link**, never canonical identity
(DEC-0032). It stores the platform's **immutable `subject`** (e.g. a Telegram
numeric user id) — **a username is not identity** and is never the subject. A
User may have several links. A database **unique (platform, subject)** constraint
means one external identity belongs to at most one User. The domain never
branches on a specific platform (DEC-0018).

### Phone Claim — implemented (Phase 3A)

A User's claim on a phone number, and where that claim sits in its lifecycle
(DEC-0033, DEC-0034). Two meanings are kept strictly distinct via a
`PhoneClaimStatus` enum rather than booleans:

- **UNVERIFIED** — contact/profile data only. It proves nothing, is not account
  ownership, does **not** have to be globally unique (different users may claim the
  same number), and must never drive authorisation (DEC-0011).
- **VERIFIED** — an OTP-proven claim. **Globally unique among active verified
  claims** (a partial unique index), and the future basis for recovery/login and
  account merging (DEC-0012). Per DEC-0046 a user may hold **at most one VERIFIED
  claim** across all numbers (to be enforced by a `UNIQUE(user_id) WHERE
  status='VERIFIED'` index and a "change phone via OTP" flow in Phase 3B; **not yet
  enforced**).
- **REVOKED** — ended/historical, retained not deleted (DEC-0025).

Stored canonically as **E.164** (DEC-0033), normalised from raw input by
`libphonenumber-js` behind a domain-owned port; the default region is configuration
(`IR` today), not hard-coded. A User may have several claims over time; history is
preserved. Normal participants are **not** forced through OTP — verification is an
explicit action (Creator flows will require it in a later phase, DEC-0013).

### OTP Challenge — implemented (Phase 3A)

A single one-time-password verification challenge (DEC-0035). It targets a
canonical number, has a purpose (only `PHONE_VERIFICATION` today), a short TTL, a
bounded attempt count, and single-use/superseded lifecycle expressed with explicit
event timestamps. It stores **only a server-secret keyed HMAC** of the code, never
the plaintext, which is unrecoverable once delivered. Delivery is behind an adapter
with no real SMS provider yet (DEC-0036). A correct code for a number already
verified by another account yields an explicit **MERGE_REQUIRED** outcome — no
transfer, no merge here (DEC-0037; the merge engine is Phase 3B).

### Account Merge — implemented (Phase 3B)

The resolution of a `MERGE_REQUIRED` conflict (DEC-0037): when an OTP-proven phone
already belongs to another account. Implemented as `AccountMergeService` (the
`account-merge` capability). A merge is **intra-product** (DEC-0047), explicit and
audited, and runs atomically inside the transaction boundary (DEC-0044): the
**pre-existing verified owner stays canonical**; the loser's platform identities and
phone claims **move** to the winner (the loser's active claims are revoked to
history, so one-verified-phone-per-user still holds); the loser becomes a
**tombstone** (`status = MERGED`, `mergedIntoId`) — never deleted, so references
resolve (DEC-0041); an immutable audit record is appended (DEC-0043). Everything is
an UPDATE (FK RESTRICT respected, DEC-0045). Merges are **irreversible** (DEC-0046);
nothing auto-merges. Detection (`verifyPhone` → `MERGE_REQUIRED`) and resolution
(`mergeAccounts`) are separate — a transport that drives resolution is a later phase.

### Change phone via OTP — implemented (Phase 3B)

A user replacing their verified number goes through the normal OTP flow: verifying a
different number **revokes** the previous verified claim (kept as REVOKED history)
and promotes the new one, atomically, so a user holds **one verified phone**
(DEC-0046).

### Creator — capability implemented (Phase 7)

A User who may create and manage Khatms. "Creator" is modelled as an **authorization
capability** (`CREATOR`), not a role or an identity flag: a `Capability` grant with
grant/revoke history, granted through the `AuthorizationService` (DEC-0061/0062).
Creating a khatm requires the CREATOR capability; managing a khatm requires
**ownership** (`principal.userId === khatm.creatorUserId`, DEC-0063). What is **not**
implemented / not decided: **how** a user earns CREATOR — creating is intended to be a
paid action (DEC-0008) requiring phone verification (DEC-0013), but that onboarding
rule is a product decision not yet made; granting is currently an explicit internal
mechanism with no public endpoint.

### Khatm — implemented (Phase 4)

The core aggregate: a collective recitation effort a creator defines from a
template (DEC-0048). Fields: `id` (UUIDv7), `creatorUserId` (fixed at creation —
ownership is preserved), `title`, optional `description`, `templateType`, `status`,
timestamps. Lifecycle **DRAFT → ACTIVE → COMPLETED**, or **CANCELLED** from
DRAFT/ACTIVE; COMPLETED and CANCELLED are terminal. **Only an ACTIVE khatm accepts
participants and assignments.** Transition legality lives on the entity (immutable
methods); the repository applies each change guarded on the prior status. A
**canonical timezone** for day boundaries/deadlines (DEC-0016) is **not yet a field**
— it arrives with the scheduling/reminder work, not invented now. The creator FK is
`RESTRICT` (DEC-0051): a merged creator becomes a tombstone the khatm still resolves
to; merge does not yet re-attribute khatms (flagged for product input, DEC-0051).

### Khatm Template — implemented (Phase 4 + QURAN-001)

The content template a Khatm is instantiated from — a single classifying enum
`KhatmTemplateType` (QURAN_FULL, QURAN_JUZ, SURAH, SALAWAT, DUA, ZIYARAT, CUSTOM,
**QURAN_PAGE**, **QURAN_SURAH**) on the khatm, **not** a table or class per prayer
type (DEC-0019/0048). QURAN-001 (DEC-0076) added two new values:

- **QURAN_PAGE** — progress tracked as accumulated pages; the Quran edition (stored as
  `quranEditionId` on the Khatm, referencing the static registry in `packages/shared`)
  provides the total page count. Cycles = accumulated pages / edition.totalPages.
- **QURAN_SURAH** — creator selects one surah (`surahNumber` 1–114) and a collective
  repetition target (`repetitionTarget` ≥ 1). Progress = completed repetitions / target.
  Not a full-Quran cycle.

The static **Quran registry** (`packages/shared/src/quran/`) holds all editions (page
counts) and all 114 surahs with Persian names. It is framework-free and importable by
both API and web. How each template divides into portions is the **allocation engine's**
concern; the domain never branches on a specific template value (DEC-0018).

### Membership / Participation — implemented (Phase 4)

A User's participation in a Khatm (DEC-0050); the entity is `Participation`. Fields:
`khatmId`, `userId`, `status` (ACTIVE/COMPLETED/LEFT/REMOVED), `joinedAt`,
timestamps. Born ACTIVE; the terminal states are **retained as history** (DEC-0025),
so a user who LEFT may join again as a new ACTIVE row. **At most one ACTIVE
participation per (khatm, user)** — a database partial unique index, not a pre-check
(DEC-0050). Joining is free (DEC-0008) and requires the khatm to be ACTIVE.

### Invitation — implemented (Phase 11)

An owner-issued grant to join a khatm (DEC-0068); the entity is `Invitation`. It is
created by the khatm's **owner**, carries an **opaque token** stored only as a
SHA-256 hash (the raw token — the shareable invite — is returned once), and has a
**derived** lifecycle **CREATED → ACCEPTED / EXPIRED / CANCELLED** (from
`expiresAt`/`acceptedAt`/`cancelledAt`; history preserved). **Accepting requires
authentication** and joins the khatm through the existing workflow, so the
one-active-participation invariant and authorization are never bypassed. Open
(untargeted) invites are supported; per-invitee targeting and use-limits are deferred.

### Assignment — implemented (Phase 4)

A unit of content (a **Portion**) allocated to a participation within a Khatm
(DEC-0049). It belongs to a participation, is scoped to that participation's khatm,
and is tracked PENDING → COMPLETED (with `completedAt`). A Portion is generic across
templates: **POSITIONAL** (`unitStart..unitEnd`, e.g. Qur'an Juz 1-30) or
**QUANTITY** (`quantity`, e.g. 500 Salawat). Khatm progress is **derived** by
counting assignments (total vs completed), never stored. This is the **low-level
manual** assignment primitive; the generic **planned** allocation is the Allocation
Engine below (Phase 4.1, DEC-0052), a separate model that does not modify this one.

### Allocation Engine — Allocation Plan + Plan Portion — implemented (Phase 4.1)

The generic, template-driven execution engine (DEC-0019, DEC-0052), a **separate,
additive** capability that leaves the Phase-4 models untouched. An **AllocationPlan**
is a khatm's content target — one per khatm — produced by a pure generator from a
`PlanSpec`: **POSITIONAL** `{from,to}` → atomic single units (a full Qur'an by Juz is
`{1,30}` → 30 units); **QUANTITY** `{total,chunk}` → chunks summing to the total (1000
Salawat by 100 → ten chunks). The numbers are **caller-supplied configuration** — no
per-template count or granularity is hard-coded. The plan's **PlanPortion**s are the
allocatable "slots": lifecycle **OPEN → ASSIGNED (holder = a participation) →
COMPLETED**, with **ASSIGNED → OPEN** release for **reallocation** when a participant
leaves. **Non-overlap** (no two positional portions cover the same unit) is enforced
by atomic units + a DB partial unique index (DEC-0053). **Progress** is derived by
counting portions by status. Batch operations (generate, allocate, release) are
**atomic** (`UnitOfWork`, DEC-0044). The engine reads khatm/participation state
through its own read port and imports no Phase-4 domain. Wiring auto-release into
Participation `leave`/`remove`, and any transport that drives the engine, are later
phases.

### Reminder

A scheduled nudge toward an Assignment or a Khatm event. Delivery and display
may respect the user's local timezone (DEC-0017).

### Waiting List

Prospective participants held when a Khatm cannot accept them yet. Detail pending.

### Backup Reader

A participant who can absorb an Assignment that is at risk of being missed.
Selection rules pending.

### Wallet / Ledger

Accounting for paid actions. **Append-only ledger**; balance is derived, never a
mutable number (DEC-0024).

### Content Asset

Quran pages, PDFs, audio and images, stored in S3-compatible object storage.
Nothing is imported yet.

### Admin

An authorised operator. Sensitive bulk export is restricted to top-level
administration and must be audited (DEC-0022, DEC-0023).

## Explicitly undecided

- Entity attributes, identifiers, and relationships
- Khatm lifecycle states and transitions
- Assignment allocation and reallocation rules
- Waiting-list and backup-reader promotion rules
- Ledger entry taxonomy
- Permission model for Admin

## Not implemented

Everything above **except User, Platform Identity, Phone Claim, OTP Challenge,
Account Merge, Khatm, Khatm Template, Membership/Participation, Assignment and the
Allocation Engine (Allocation Plan + Plan Portion)** is high-level only and does not
exist in code. Implemented so far: a health/readiness endpoint, the persistence
foundation (Phase 2A), the identity foundation — User + PlatformIdentity (Phase 2B),
the phone-claim & OTP verification foundation — PhoneClaim + OtpChallenge (Phase 3A),
the account-merge & change-phone flows (Phase 3B), the Khatm engine foundation —
Khatm + Participation + Assignment (Phase 4), the Khatm allocation engine —
AllocationPlan + PlanPortion with the fifth reviewed migration (Phase 4.1), and the
application-level **workflow orchestration** connecting them (Phase 4.2), the
**transport layer** — HTTP/REST + a Telegram channel adapter (Phase 5), the
**authentication & session** foundation (Phase 6), and the **authorization** layer —
the Creator capability + resource-ownership enforcement (Phase 7). Still **not**
implemented: **reminders**, auto-release of portions when a participant leaves, the
**onboarding rule for earning CREATOR** (payment/OTP gate, DEC-0008/0013), a real SMS
provider, a production Telegram Bot API adapter, registration/Web UI, payments/wallet,
Admin, marketplace, and subscriptions.
