# TESTING

## Current state

As of Phase 3A (2026-09-06, Node v24.20.0) the suites below **pass**. Unit tests
require **no** Docker and **no** database; the DB integration suite is separate
and explicitly Docker-gated. See PROJECT_STATE.md.

| File | Kind | Docker? | Result |
| ---- | ---- | ------- | ------ |
| `src/health/health.controller.spec.ts` | unit | no | PASS |
| `src/infrastructure/database/database-readiness.service.spec.ts` | unit | no | PASS |
| `src/infrastructure/database/database-config.spec.ts` | unit | no | PASS |
| `src/identity/domain/identity-id.spec.ts` | unit | no | PASS |
| `src/identity/domain/user.spec.ts` | unit | no | PASS |
| `src/identity/domain/platform-identity.spec.ts` | unit | no | PASS |
| `src/identity/application/identity.service.spec.ts` | unit | no | PASS |
| `src/phone/domain/phone-number.spec.ts` | unit | no | PASS |
| `src/phone/domain/phone-claim.spec.ts` | unit | no | PASS |
| `src/phone/domain/otp-challenge.spec.ts` | unit | no | PASS |
| `src/phone/infrastructure/libphonenumber-phone-normalizer.spec.ts` | unit | no | PASS |
| `src/phone/infrastructure/crypto-otp-code-generator.spec.ts` | unit | no | PASS |
| `src/phone/infrastructure/hmac-otp-code-hasher.spec.ts` | unit | no | PASS |
| `src/phone/application/phone-verification.service.spec.ts` | unit | no | PASS |
| `test/health.e2e-spec.ts` | e2e | no (DB optional) | PASS (1/1) |
| `test/database.integration-spec.ts` | integration | **yes** | PASS (5/5) |
| `test/identity.integration-spec.ts` | integration | **yes** | PASS (8/8) |
| `src/account-merge/application/account-merge.service.spec.ts` | unit | no | PASS |
| `test/phone.integration-spec.ts` | integration | **yes** | PASS (11/11) |
| `test/account-merge-foundation.integration-spec.ts` | integration | **yes** | PASS (10/10) |
| `test/transaction.integration-spec.ts` | integration | **yes** | PASS (3/3) |
| `test/account-merge.integration-spec.ts` | integration | **yes** | PASS (4/4) |

- **Unit** — `npm test` (root) → 123 tests. Never touches Docker/DB.
- **e2e** — `npm run test:e2e -w @khatmsaz/api`. Loads the repo-root `.env` so the
  app can construct DB config; liveness does not require a live database.
- **DB integration** — `npm run test:integration:db` (or
  `-w @khatmsaz/api`). **Requires** the local PostgreSQL (`npm run infra:up`).
  Runs `--runInBand --forceExit`.

The health unit spec asserts the `/health` key set is exactly `service, status,
timestamp, uptimeSeconds, version` (guard against config leak through liveness).
The readiness and integration specs assert `/health/ready` returns only
`status, checks, timestamp` and that **no connection string or password** appears
in the body or in surfaced errors.

### Identity coverage (Phase 2B)

- UUIDv7 generation, validity and rejection of non-v7 uuids — unit.
- `User` / `PlatformIdentity` invariants (id is UUIDv7, platform known, subject
  trimmed/non-empty, username never used as identity) — unit.
- `IdentityService` use-cases with in-memory fakes that emulate the unique
  constraint — unit.
- Real repository round-trips, native `uuid` storage, attach + lookup by platform
  identity, same subject on different platforms, uniqueness violation, and
  **concurrent attach of one identity to two users → exactly one wins** with a
  domain error — integration; plus a check that the migration is recorded in
  `_prisma_migrations`.

> **ESM `uuid` in Jest:** `uuid@14` is ESM-only. Every jest config transforms it
> via ts-jest `allowJs` plus `transformIgnorePatterns: ["/node_modules/(?!uuid/)"]`.
> Node 24 runs it directly at runtime (`require(esm)`); do not downgrade for CJS.

### Phone / OTP coverage (Phase 3A)

- **Unit** — Iranian phone normalization for every required input form (`09…`,
  `9…`, `989…`, `+989…`, `00989…`, spaced/dashed/parenthesised) plus
  Persian/Arabic-Indic digit folding and a non-IR number; invalid inputs rejected;
  the error never echoes the input. E.164 validity. `PhoneClaim` lifecycle
  invariants (UUIDv7 ids, canonical E.164, status/verifiedAt/revokedAt consistency).
  `OtpChallenge` expiry, attempt exhaustion, consumed, superseded, `isActive`.
  CSPRNG generator (length, leading zeros, non-constant, range). HMAC hasher:
  hash ≠ plaintext, verify true/false, binding to `(e164, purpose)`, pepper keying,
  malformed-hash → false. Full `PhoneVerificationService`: claim idempotency across
  formats, duplicate unverified across users allowed, resend cooldown + supersession,
  wrong/expired/exhausted/consumed code, ALREADY_VERIFIED, **MERGE_REQUIRED** (no
  transfer, no consume), UUIDv7 invariants, and **the code never appears in an
  error message or stack**.
- **Integration (real PostgreSQL)** — migration recorded; native `uuid` id;
  duplicate **unverified** claims by different users allowed; a correct code marks
  VERIFIED; **one active verified owner per number, globally** (both the sequential
  conflict and the **concurrent two-user race → exactly one wins**); **only the
  keyed HMAC is persisted**, never the plaintext code; **historical (revoked)
  claims are retained** alongside a fresh claim; wrong code counts an attempt and a
  consumed challenge is single-use; the ownership conflict surfaces at the
  repository/partial-index boundary.

### Account merge & change-phone coverage (Phase 3B)

- **Unit** — `AccountMergeService`: moves platform identities + phone claims to the
  winner, revokes the loser's active claims, tombstones the loser (MERGED +
  `mergedIntoId`), appends the audit with correct counts; rejects winner===loser,
  missing verified phone, and a missing/inactive account. Change-phone in the phone
  service: verifying a new number revokes the previous verified one and keeps exactly
  one verified per user; no `replacedE164` when there was none.
- **Integration (real PostgreSQL)** — the transaction boundary commits / rolls back /
  is atomic across multi-writes; the foundation (lifecycle round-trip, tombstone +
  self-FK reject, one-verified-per-user reject, FK RESTRICT/CASCADE, audit
  round-trip); change-phone against the real per-user index; and the **full merge**:
  resolving a real `MERGE_REQUIRED` (data moved, loser tombstoned + retained, audit
  written), revoking the loser's own different verified number, rejecting an
  already-merged loser, and **rolling back with no change when the winner does not
  exist** (atomicity).

### DB integration coverage (Phase 2A)

- configuration validation (missing / malformed / composed-from-parts, secret-free
  errors) — unit;
- real database connection + `SELECT 1` — integration;
- readiness **ready** while PostgreSQL runs — integration;
- readiness **not_ready** on a real unreachable endpoint, bounded by the 2s
  timeout (not flaky) — integration; also covered deterministically by a unit
  mock;
- no credentials in the readiness response/errors — unit + integration.

## Tooling

- Jest + ts-jest in `apps/api`. Unit config is inline in `apps/api/package.json`;
  the e2e config is `apps/api/test/jest-e2e.json`.
- `apps/web` and `apps/admin` have no tests yet. Root `npm run test` uses
  `--workspaces --if-present`, and the API script passes `--passWithNoTests`, so
  an empty suite never fails the pipeline.

## Rules

- Test the boundary a caller depends on, not internal implementation detail.
- The **portable suite** (`npm test`) must never require the network, a real
  Telegram/Bale token, a payment gateway, or a live database. Use fakes. It must
  pass with **every** integration environment variable empty.
- A test that genuinely needs a live database belongs in the **separate**,
  explicitly-invoked `test:integration:db` suite (local PostgreSQL only, never a
  production or shared database), not in the portable suite.
- Never mark a check PASS unless you ran it and saw it pass.

## The validation gate

```bash
npm run typecheck
npm run lint
npm run test
npm run build
```

Record the outcome of each as PASS / FAIL / NOT RUN with a reason.

## Claude toolkit checks (Phase 1.2, 2026-09-05)

The Claude toolkit has its own read-only verifier, independent of the app gate:

```bash
./tooling/claude-project-kit/verify.sh
```

It checks marketplaces, enabled plugins, `claude plugin validate`, the LSP
executable, shell-script syntax, and runs **unit tests for the safety hooks**
(guard_secrets, guard_commands). All passed on 2026-09-05. The app gate above was
re-run green in the same phase with no application source changed.
