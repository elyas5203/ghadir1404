# ROADMAP

## Implementation Sprint 3 — Security + Deploy — 2026-09-13

**Status: COMPLETED. v1 LAUNCH READY.**

| Item | Status |
| ---- | ------ |
| **Security** — IDOR fix (`PendingPayment` table, authority→userId stored server-side) | Completed — DEC-0083 |
| **Security** — Replay fix (atomic CAS `markUsed`, ZarinPal code 101 rejected) | Completed |
| **Feature** — Plan change real implementation (`UserPlan` table, `PlanService`) | Completed — DEC-0085 |
| **Infra** — `docker-compose.prod.yml` (postgres + redis + api + web) | Completed |
| **Infra** — `apps/api/Dockerfile` + `apps/web/Dockerfile` (Node 24 Alpine, standalone) | Completed |
| **Infra** — `apps/web/next.config.mjs` standalone output | Completed |
| **Seed** — `apps/api/prisma/seed-admin.ts` (promote by verified phone) | Completed |
| **Health** — `/health` (liveness) + `/health/ready` (readiness, DB probe) | Already existed |
| **DB migrations** — `20260913200000_add_pending_payment`, `20260913210000_add_user_plan` | Completed |
| Tests: 373 total passing | Completed |
| Validation: typecheck / lint / unit (373) / build / docker config | Completed — all PASS |
| Docs: PROJECT_STATE, CHANGELOG, DECISIONS (DEC-0085), ROADMAP, .ai-guide updated | Completed |
| **Deferred v2 items** — Multi-language, audio player, gamification, QR export, analytics PDF | Not started — v2 |

---

## Implementation Sprint 2 — Fixes + Phase 06 + Phase 08 — 2026-09-13

**Status: COMPLETED.**

| Item | Status |
| ---- | ------ |
| **FIX A** — `KhatmWorkflowService.leaveKhatm()` + `WaitingListService.promoteNext()` hook | Completed |
| **FIX B** — `NotificationService.onKhatmActivated()` hook in `activateKhatm()` | Completed |
| **FIX C** — `.env.example` updated with all new env vars | Completed |
| **FIX D** — `.ai-guide/INDEX.md` updated with sprint 2 entry + expanded services table | Completed |
| **Phase 06 (backend)** — `UserRole` enum, `AdminGuard`, `AdminController` (5 endpoints), `listAll`/`countAll` on user/khatm repositories + services | Completed — DEC-0083, DEC-0084 |
| **Phase 06 (frontend)** — `apps/web/src/app/admin/` layout + stats + customers + khatms pages; `MeResponse.role` field | Completed |
| **Phase 08** — SMS System: `SmsProvider`, `KavenegarSmsService`, `NoopSmsService`, `SmsModule`, `packages/config/src/sms.ts` | Completed |
| Tests: FIX A/B tests (7 new), SMS tests, fake repo stubs (373 total) | Completed |
| Validation: typecheck / lint / unit (373) / build | Completed — all PASS |
| Docs: PROJECT_STATE, CHANGELOG, DECISIONS (DEC-0083, DEC-0084), ROADMAP updated | Completed |
| **Security** — `PaymentController` IDOR + replay vulnerabilities | Deferred — needs `PaymentIntent` table |
| **SMS OTP integration** — wire `SMS_PROVIDER` into OTP delivery | Deferred |
| **Admin `/library`** — approve/reject custom khatm requests | Deferred |
| **Customer plan change persistence** — stub only for now | Deferred |

---

## Implementation Sprint — Phases 01–05 — 2026-09-12

**Status: COMPLETED (Phase 06 Admin Dashboard and Phase 08 SMS deferred to Sprint 2).**

| Item | Status |
| ---- | ------ |
| **Schema** — `NotificationJob`, `WaitingList`, `Wallet`, `WalletTransaction`, `UserSettings` models + 5 enums | Completed — DEC-0077 |
| **Schema** — `publicSlug` + `niyyat` nullable columns on `khatms` | Completed — DEC-0080 |
| **Phase 01** — Notification engine: `NotificationScheduler` port, `BullmqNotificationScheduler`, `NoopNotificationScheduler`, `NotificationModule` (config-gated) | Completed — DEC-0077 |
| **Phase 02** — Waiting List: `WaitingListService`, `PrismaWaitingListRepository`, `WaitingListModule` | Completed |
| **Phase 03** — Payment: `WalletService`, `ZarinpalService`, `PaymentController`, `PaymentModule` | Completed — DEC-0078, DEC-0079 |
| **Phase 04** — Bale adapter: `BaleSender` port, `BotApiBaleSender`, `NoopBaleSender`, `BaleCommandService`, `BaleGatewayService`, `BaleWebhookController`, `BaleModule` | Completed — DEC-0081 |
| **Phase 05** — User Settings: `UserSettingsService`, `PrismaUserSettingsRepository`, `UserSettingsModule` | Completed — DEC-0082 |
| **Phase 05** — Public khatm page: `GET /public/khatm/:slug`, `apps/web/src/app/khatm/[slug]/page.tsx` | Completed — DEC-0080 |
| `packages/config` — `redisConfig`, `baleConfig`, `zarinpalConfig` helpers | Completed |
| `.ai-guide/` — INDEX.md, FOLDER-MAP.md, RELATIONS.md, BUGS.md, ROADMAP.md, DECISIONS.md | Completed |
| Tests: WaitingListService (6 new tests, 372 total) | Completed |
| Validation: typecheck / lint / unit (372) / build | Completed — all PASS |
| Docs: PROJECT_STATE, CHANGELOG updated | Completed |
| **Phase 06** — Admin & Customer Dashboard (`apps/web/src/app/admin/`) | Deferred |
| **Phase 08** — SMS System (Kavenegar/Melipayamak, config-gated) | Deferred |
| WaitingList hook into `KhatmWorkflowService.cancelParticipation()` | Deferred |
| Notification lifecycle calls in `KhatmWorkflowService` | Deferred |
| Telegram /settings command (conversation state machine) | Deferred |
| `.env.example` updated with all new env vars | Deferred |

---

## QURAN-001 — Two new Quran khatm modes — 2026-09-12

**Status: COMPLETED.**

| Item | Status |
| ---- | ------ |
| `QURAN_PAGE` and `QURAN_SURAH` template types (domain + DB enum) | Completed — DEC-0076 |
| Static Quran edition registry (3 editions) in `packages/shared` | Completed |
| Static surah registry (all 114 surahs) in `packages/shared` | Completed |
| Prisma migration: nullable columns + CHECK constraints | Completed |
| Domain `Khatm` entity extended with quran config fields | Completed |
| Mapper + repository pass-through | Completed |
| `createKhatm()` service + `CreateKhatmWorkflowInput` extended | Completed |
| `parseCreateKhatm()` validates edition id + surah number | Completed |
| `toKhatmSummary()` populates `quranPageConfig` / `quranSurahConfig` | Completed |
| `GET /api/quran/editions` + `GET /api/quran/surahs` endpoints | Completed |
| Web create page: edition selector + surah/target inputs | Completed |
| Khatm detail page: config display + auto-filled plan defaults | Completed |
| Persian labels + help texts for both modes | Completed |
| Tests: registry, domain, request parsing | Completed — 356 total |
| Validation: typecheck / lint / unit (356) / build | Completed — all PASS |
| Docs: PROJECT_STATE, CHANGELOG, DECISIONS (DEC-0076), ROADMAP, DOMAIN_MODEL | Completed |
| Progress accumulation display for QURAN_PAGE (cycle counting) | Deferred — follow-up |
| Open contribution recording connected to Quran page counting | Deferred — follow-up |

---

## Phase 14 — Core User Journey Completion — 2026-09-12

**Status: COMPLETED (partial — integration e2e tests and full participant journey deferred).**

| Item | Status |
| ---- | ------ |
| Fix OPEN khatm completion gate (always threw KhatmNotCompletableError) | Completed — DEC-0072 |
| `POST /api/me/become-creator` — idempotent CREATOR grant (DEC-0070 MVP) | Completed |
| User displayName: schema migration + domain + infra + service | Completed — DEC-0073 |
| `PUT /api/me/profile` — set/clear displayName | Completed |
| displayName in `GET /api/me` and `GET /api/khatms/:id/participants` | Completed |
| Participant list shows displayName (falls back to "شرکت‌کننده N") | Completed |
| `layout.tsx` themeColor updated to lapis `#1E3E90` | Completed |
| Type card text overflow fix (`min-width: 0`, `overflow-wrap`) | Completed |
| 10 new test cases (OPEN completion, stubs) | Completed — 345 total |
| Validation gate — typecheck / lint / unit (345) / build | Completed — all PASS |
| Integration e2e tests (full Commitment + OPEN flows) | Deferred — next phase |
| Participant journey UX (/invitations/accept improvements) | Deferred — next phase |

---

## Product Review + UX/UI Foundation — 2026-09-11

**Status: COMPLETED.**

| Item | Status |
| ---- | ------ |
| Full UI/UX audit of all pages | Completed → `docs/ai/UI_UX_AUDIT.md` |
| Design system document | Completed → `docs/ai/DESIGN_SYSTEM.md` |
| Lapis colour palette (replaces green placeholder) | Completed → `packages/ui/src/tokens.css` |
| Fix missing `--ks-space-5` token | Completed |
| Add `--ks-color-error` token | Completed |
| `globals.css` rewrite: btn-danger, empty-state, skeleton, confirm-bar, onboarding-banner | Completed |
| Landing page: remove ApiStatus/StatusCard, proper consumer landing | Completed |
| Login page: brand wordmark, OTP expiry note, error placement | Completed |
| Dashboard: loading skeleton, retry, onboarding banner, better empty states | Completed |
| Khatm detail: no-UUID participant/invitation display, completion confirmation, plan UX | Completed |
| HelpTip: term shown as popover title | Completed |
| Khatm logic review document | Completed → `docs/ai/KHATM_LOGIC_REVIEW.md` |
| Product gap analysis document | Completed → `docs/ai/PRODUCT_GAPS.md` |
| Validation gate — typecheck / lint / unit (343) / build | Completed — all PASS |

---

## Phase 13 — Khatm Type Domain Implementation — 2026-09-11

**Status: COMPLETED.**

| Item | Status |
| ---- | ------ |
| `KhatmType` enum (`COMMITMENT` \| `OPEN`) as first-class domain property | Completed |
| DB migration: `khatm_type` column (default COMMITMENT), `open_contributions` table | Completed |
| `OpenContribution` domain entity + repository port | Completed |
| `PrismaOpenContributionRepository` infrastructure adapter | Completed |
| `OpenContributionService` application service | Completed |
| Activation gate: OPEN khatms skip plan check (DEC-0071) | Completed |
| `khatmType` in `KhatmSummary` and `CreateKhatmRequest` contracts DTOs | Completed |
| 3 new API endpoints: `GET :id/open-progress`, `POST :id/contributions`, `GET :id/my-contributions` | Completed |
| Frontend create page sends `khatmType` | Completed |
| Dashboard shows khatm type label | Completed |
| Khatm detail page: OPEN contribution form + list + aggregate progress | Completed |
| `KHATM_TYPE_LABEL` and `HELP_TEXT` centralized in labels.ts | Completed |
| 14 new/updated test cases across all layers | Completed |
| DEC-0071 recorded in DECISIONS.md | Completed |
| Validation gate — typecheck / lint / unit (343) / build | Completed — all PASS |

---

## Phase 12 — Product UI Foundation — 2026-09-11

**Status: COMPLETED.**

| Item | Status |
| ---- | ------ |
| `GET /api/khatms/:id` endpoint (no ownership required) | Completed |
| `HelpTip` reusable popover component | Completed |
| `/khatms/create` dedicated creation page with type selector | Completed |
| `/invitations/accept` landing page | Completed |
| Dashboard overhaul: creator cards + participant section + progress bars | Completed |
| Khatm manage page: progress, my portions, invitation mgmt, participants | Completed |
| CSS additions: progress bar, type-card, help-tip, khatm-card, btn-sm | Completed |
| `INVITATION_STATUS_LABEL` in labels.ts | Completed |
| Validation gate — typecheck / lint / unit (326+10) / build | Completed — all PASS |

**Known gap (not implemented this phase):**
- No `POST /api/me/become-creator` self-service endpoint yet — Creator elevation still
  requires manual `grantCapability` internal call (DEC-0070).
- Domain does not distinguish ختم غیرتعهددار from تعهددار; both are created
  identically. A note is shown on the create form.

---

## Repository hygiene checkpoint & MVP Creator model — 2026-09-11

**Status: COMPLETED.** No feature code added. Cleanup + documentation + readiness only.

| Item | Status |
| ---- | ------ |
| Remove `cloudflared.deb` binary (19 MB) from git tracking | Completed — `git rm --cached`; added to `.gitignore` |
| Add `all_code.txt` and `*.deb` patterns to `.gitignore` | Completed |
| Scan git history for leaked secrets | Completed — no real secrets found; all values are dev placeholders |
| Verify `.env` not tracked, `.env.example` safe | Completed — both confirmed |
| Verify auth state: phone-first, cookie sessions, dev OTP opt-in only | Completed — all invariants hold |
| Record MVP Creator model decision (DEC-0070) | Completed — any authenticated user may become Creator; approval deferred |
| Update PROJECT_STATE, ROADMAP, CHANGELOG, DECISIONS | Completed |
| Validation gate — typecheck / lint / unit (326+10) / build | Completed — all PASS |

## Local development support — 2026-09-08

Implementation completed: opted-in OTP delivery, idempotent user fixtures and
numeric Telegram binding, without migration or new authentication architecture.
Two CREATOR fixtures are present. User has taken over further manual validation.
See PROJECT_STATE.md and LOCAL_DEVELOPMENT.md; no subsequent phase is scheduled.

Completed items are marked **Completed** and kept forever. Never delete history
to shorten this file.

---

## Phase 1 — Bootstrap and project foundation

**Status: COMPLETED (2026-09-04, validated in Phase 1.1)** — all deliverables
authored AND the full validation gate ran green on the developer machine
(install, typecheck, lint, test, e2e, build) with the API, web and admin apps
run and smoke-tested. The one remaining item is the initial Git commit, which is
staged and waiting only on the user configuring a Git identity (KI-0004). Docker
daemon is unavailable in this WSL distro (KI-0007) but the compose file was
validated structurally; no application code depends on it yet.

| Item                                                    | Status                  |
| ------------------------------------------------------- | ----------------------- |
| Verify working directory `Z:\KhatmSaz` is empty          | Completed               |
| npm workspaces monorepo skeleton                         | Completed               |
| `apps/api` NestJS shell with `GET /health`               | Completed (unvalidated) |
| `apps/web` Persian RTL shell                             | Completed (unvalidated) |
| `apps/admin` Persian RTL admin shell                     | Completed (unvalidated) |
| `packages/config`, `shared`, `contracts`, `ui`           | Completed (unvalidated) |
| Temporary green design tokens + RTL base layer           | Completed               |
| `infra/docker` Postgres + Redis + MinIO definitions      | Completed (unvalidated) |
| `.gitignore` / `.gitattributes` / `.editorconfig`        | Completed               |
| `.env.example` with no real secrets                      | Completed               |
| `CLAUDE.md` and `.claude/rules/`                         | Completed               |
| `docs/ai/` twelve-document memory system                 | Completed               |
| Foundational decisions DEC-0001 … DEC-0030               | Completed               |
| Verify development environment on the dev machine        | Completed (Phase 1.1)   |
| `npm install`                                            | Completed (Phase 1.1) — 0 vulns |
| Build / lint / typecheck / test                          | Completed (Phase 1.1)   |
| Run API, web, admin and verify `/health`                 | Completed (Phase 1.1)   |
| `docker compose config` validation                       | Completed (structural; daemon off) |
| Git init                                                 | Completed (Phase 1.1)   |
| Initial commit                                           | Completed (Phase 1.1) — `38bbee8` |

**Phase 1 closed on 2026-09-04.** The validation gate ran green, the three
applications were verified on the development machine (recorded in
PROJECT_STATE.md), and the bootstrap tree was committed (`38bbee8`).

### Phase 1.1 — Local validation, repair and closeout (2026-09-04)

- Moved to WSL-native authoritative path `/home/elyas/KhatmSaz`
- First real `npm install`; ran and passed typecheck, lint, test, e2e, build
- Repaired: added four missing package ESLint configs; resolved NestJS DI /
  `consistent-type-imports` conflict; removed benign ts-jest `.js` transform warning
- Smoke-tested API `/health`, web and admin (Persian, RTL, admin noindex)
- Security review + `npm audit` (0 vulnerabilities)
- `git init -b main` + `git add -A` (commit pending user identity)
- Removed bootstrap staging (`docs/bootstrap/`) and `nodesource_setup.sh`

---

## Phase 1.2 — Claude project kit and capability setup

**Status: COMPLETED (2026-09-05).** Developer/AI capability system only — no
product feature. See `docs/ai/CLAUDE_TOOLKIT.md`.

| Item | Status |
| ---- | ------ |
| Research current Claude Code ecosystem (docs + official marketplace) | Completed |
| Register official marketplace `anthropics/claude-plugins-official` | Completed |
| Curate + enable lean first-party plugin set (project scope) | Completed |
| Install TypeScript language server (user-level, no sudo) + verify | Completed |
| Build portable `tooling/claude-project-kit/` (one copyable folder) | Completed |
| Author `project-kit` plugin: 9 skills, 3 review agents, 2 safety hooks | Completed |
| KhatmSaz backup-path guard hook | Completed |
| Validate plugin/marketplace; verify.sh; hook self-tests | Completed |
| Regression gate (typecheck/lint/test/build) — no app code changed | Completed |
| Document (CLAUDE_TOOLKIT.md + PROJECT_STATE/CHANGELOG/etc.) | Completed |
| Install every evaluated plugin | Deferred by design — optional profiles recorded, not enabled |

## Phase 2A — Persistence foundation

**Status: COMPLETED (2026-09-05).** First production-code persistence phase. No
product feature and no domain table. See DEC-0031, `docs/ai/DATABASE.md`, and the
PROJECT_STATE/CHANGELOG entries.

| Item | Status |
| ---- | ------ |
| Verify + run local infra (Postgres/Redis/MinIO) with real health checks | Completed — PG 17.11 SELECT 1, Redis PONG, MinIO 200 |
| Choose ORM + migration tooling, record as a decision | Completed — DEC-0031 (PostgreSQL + Prisma, pinned 7.10.0) |
| Prisma in an isolated API infrastructure boundary | Completed — `src/infrastructure/database`, Prisma-free exports |
| Validated, fail-fast database configuration layer | Completed — `@khatmsaz/config.databaseUrl()` |
| Managed single-connection lifecycle (connect/disconnect) | Completed — `PrismaService` |
| Liveness preserved + real readiness endpoint | Completed — `/health` unchanged, `/health/ready` (SELECT 1) |
| Migration workflow + scripts (plan/migrate/status/verify) | Completed — Prisma 7 commands, review policy recorded |
| Portable unit tests + separate DB integration suite | Completed — 21 unit (Docker-free), 5 integration (`test:integration:db`) |
| First domain migration | **Not done — deliberately.** No fake model; first migration lands with the first real domain model |

**Note on "Prisma 8":** the project-manager decision named Prisma 8, but no
stable Prisma 8 exists yet (npm `latest` = `8.0.0-rc.13`, an RC) and RCs are
forbidden. Pinned stable **7.10.0**; adopt Prisma 8 at GA (DEC-0031).

## Phase 2B — Identity foundation

**Status: COMPLETED (2026-09-06).** First real domain model and first reviewed
migration. Deliberately narrow. See DEC-0032, DOMAIN_MODEL.md, DATABASE.md.

| Item | Status |
| ---- | ------ |
| Canonical User identity — internal UUIDv7, app-generated, native PG uuid | Completed — DEC-0032 |
| PlatformIdentity link (TELEGRAM/BALE + future), unique (platform, subject) | Completed |
| First reviewed, checked-in migration (create-only → review → deploy) | Completed — `20260906062900_identity_foundation` |
| Domain-owned repository ports; Prisma only in infrastructure | Completed — `src/identity/{domain,application,infrastructure}` |
| Concurrency-safe attach via DB constraint (not pre-check) | Completed — `P2002` → domain error; concurrency test |
| Unit tests (Docker-free) + repository integration tests | Completed — 43 unit, 13 integration |
| Existing /health + /health/ready still green | Completed |
| OTP / phone verification / registration / bot handlers / profile / Khatm | Not done — out of scope, deferred |

## Phase 3A — Phone claims & OTP verification foundation

**Status: COMPLETED (2026-09-06).** Phone-claim and OTP-verification foundation.
Deliberately narrow. See DEC-0033…DEC-0038, DOMAIN_MODEL.md, DATABASE.md.

| Item | Status |
| ---- | ------ |
| Phone as a separate `PhoneClaim` model, canonical E.164, `libphonenumber-js` behind a port | Completed — DEC-0033 |
| Claimed vs verified as a lifecycle enum; unverified NOT globally unique | Completed — DEC-0034 |
| One global verified owner + one active claim per (user, number) via **partial unique indexes** | Completed — hand-written migration SQL, verified in psql |
| OTP challenge model (TTL, attempts, consume, supersede, cooldown) | Completed |
| OTP codes CSPRNG-generated, single-use, **keyed-HMAC** at rest, never logged/returned | Completed — DEC-0035 |
| OTP delivery behind an adapter; **no real SMS provider** | Completed — DEC-0036 (no-op adapter + test fake) |
| Application flows: claim, request verification, verify OTP | Completed — `PhoneVerificationService` |
| Verified-ownership conflict → explicit `MERGE_REQUIRED`; **no merge** | Completed — DEC-0037 |
| Second reviewed, checked-in migration (create-only → hand-edit → deploy) | Completed — `20260906070332_phone_verification_foundation` |
| Concurrency safe under real PostgreSQL (two users, same number → one wins) | Completed — integration test |
| Unit (Docker-free) + repository integration tests | Completed — 106 unit, 23 integration |
| Redis/distributed rate limiting | Deferred — DEC-0038 (per-target cooldown in DB now) |
| Creator capability / login / registration UI / bot handlers / real SMS / account merge | Not done — out of scope, deferred |

## Phase 3B preparation — architectural prerequisites

**Status: COMPLETED (2026-09-06).** Prerequisites identified by the pre-3B
architecture review. **No merge functionality, authentication, or sessions.** See
DEC-0039…DEC-0045, ARCHITECTURE.md, DOMAIN_MODEL.md.

| Item | Status |
| ---- | ------ |
| ADRs for merge policy, user lifecycle, tombstone/alias, merge audit, transaction strategy, shared kernel | Completed — DEC-0039…DEC-0045 (product rules flagged, not invented) |
| Extract UUIDv7 / id primitives into a shared kernel package | Completed — `@khatmsaz/kernel`; `phone` decoupled from `identity` (review M1) |
| Design + implement the transaction boundary abstraction (no merge) | Completed — `UnitOfWork`/`UNIT_OF_WORK` + `PrismaUnitOfWork`, tested (commit/rollback/atomic) |
| Review cascade-delete strategy; propose safest FK behavior | Completed — DEC-0045 (RESTRICT for identity-bearing tables; CASCADE for OTP); migration deferred to 3B |
| Update docs/ai (ROADMAP, DECISIONS, DOMAIN_MODEL, ARCHITECTURE, PROJECT_STATE) | Completed |
| Account merge / authentication / sessions | Not done — deliberately out of scope |

## Phase 3B — Account-merge workflow (in progress)

Product rules confirmed (DEC-0046): existing verified owner stays canonical; **one
verified phone per user**; merges irreversible with an append-only audit.

### Step 1 — database / domain foundation — **COMPLETED (2026-09-06)**

Schema + domain models only; **no merge use-case.** Migration
`20260906120252_account_merge_foundation`.

| Item | Status |
| ---- | ------ |
| `users.status` lifecycle (`ACTIVE`/`MERGED`, DEC-0040) | Completed |
| `users.merged_into_id` tombstone/alias self-FK (DEC-0041) | Completed |
| Append-only `account_merges` audit table + domain `AccountMerge` + repo (DEC-0043) | Completed |
| `UNIQUE(user_id) WHERE status='VERIFIED'` partial index — one verified phone per user (DEC-0046) | Completed (hand-written SQL, KI-0012) |
| FK strategy: RESTRICT for identity-bearing tables, CASCADE for OTP (DEC-0045) | Completed + verified |
| Unit + integration tests (real PostgreSQL) | Completed — 116 unit, 36 integration |

### Step 2 — merge engine + flows — **COMPLETED (2026-09-06)**

Intra-product only (DEC-0047). No auth/session/Creator.

| Item | Status |
| ---- | ------ |
| Transaction-aware repositories via the `UnitOfWork` seam (DEC-0044) | Completed — `dbClient` helper; boundary moved to `@khatmsaz/kernel` |
| "Change phone via OTP" — revoke old verified, promote new, one verified per user (DEC-0046) | Completed — atomic in `verifyPhone` |
| Merge use-case: existing owner canonical, move platform identities + phone claims, revoke a losing second verified number, tombstone loser, append audit (DEC-0042/0037) | Completed — `AccountMergeService` (new `account-merge` capability) |
| Move-not-delete; FK RESTRICT respected; atomic inside `UnitOfWork` | Completed + verified (rollback test) |
| Unit + integration tests (real PostgreSQL) | Completed — 123 unit, 41 integration |
| HTTP/bot transport that drives verify/merge · auth/session/Creator | Not done — out of scope |

## Phase 3C — Creator identity & sessions (largely delivered)

- **Sessions delivered in Phase 6**: passwordless server-side sessions via phone-OTP
  login (DEC-0027, DEC-0059/0060).
- **Creator capability + per-resource authorization delivered in Phase 7**
  (DEC-0061/0062/0063).
- Still planned: **how** a user earns CREATOR (OTP-gated onboarding / payment,
  DEC-0008/0013) — a product rule not yet decided.

## Phase 7 — Creator capability & authorization foundation

**Status: COMPLETED (2026-09-07).** The authorization foundation — capability model,
Creator capability, and resource-ownership enforcement closing the Phase-6 IDOR.
Authorization only — no Web UI, production Telegram, payments, notifications, admin,
marketplace, or subscriptions. See DEC-0061…DEC-0063, ARCHITECTURE.md, DATABASE.md.

| Item | Status |
| ---- | ------ |
| Authorization architecture (dedicated capability; allowed vs valid vs who) + ADR | Completed — DEC-0061 |
| Capability model (grant/revoke history, one active per (user,type)) + ADR | Completed — DEC-0062 |
| Creator permission rules (capability to create, ownership to manage) + ADR | Completed — DEC-0063 |
| `authorization` capability (domain/application/infrastructure) | Completed — `src/authorization/` |
| `AuthorizationService` — hasCapability / grantCapability / revokeCapability (+ requireCapability) | Completed |
| Protect create (CREATOR) + manage (ownership) in the workflow; participant actions kept separate | Completed — closes the IDOR |
| Transport thin — controllers pass the principal, no ownership/role/Prisma logic | Completed |
| Seventh reviewed migration (`user_capabilities`; FK RESTRICT; partial unique index) | Completed — `20260907081109_authorization_capability_foundation` |
| Security: capability lifecycle, grant/revoke, decisions, no enumeration leak, 401≠403 | Completed |
| Unit (capability lifecycle, grant/revoke, decisions) + integration (6 required scenarios + DB constraint) | Completed — 303 unit, 85 integration |
| Web UI · production Telegram · payments · notifications · admin · marketplace · subscriptions | Not done — explicitly out of scope |

**Deferred:** how a user earns CREATOR (onboarding/payment); whether revoking CREATOR
freezes management of already-owned khatms; Admin capability.

## Phase 9.1 — Telegram local activation & verification

**Status: DONE (2026-09-07) — operational, no code change.** The Phase-9 adapter was
activated against the real bot (`@Khatm_Saz_bot`) and the full inbound path verified
locally (secret 403; `/start` provisioning + idempotency; `/my_khatms`; malformed
ignored; unauthorized `/create_khatm` blocked). Token/secret in local `.env` only,
never logged. DEC-0065 stands (no new decision). Remaining live steps — a public HTTPS
tunnel, real `setWebhook`, and messaging from a Telegram client — require a
normal-internet host and a human; exact commands are in INTEGRATIONS.md. No migration.

## Phase 9 — Real Telegram Bot adapter

**Status: COMPLETED (2026-09-07).** Connect the Phase-5 Telegram boundary to the real
Bot API, infrastructure-only and config-gated; the domain/application and all Phase
6/7 rules are untouched. No payments, notifications, admin, marketplace, or web
redesign. No schema change. See DEC-0065, ARCHITECTURE.md, INTEGRATIONS.md.

| Item | Status |
| ---- | ------ |
| Inbound webhook `POST /telegram/webhook` — secret-verified (constant-time), maps raw→neutral, dispatches via existing gateway | Completed |
| Raw→neutral update mapper (pure, defensive) | Completed + unit-tested |
| Outbound `BotApiTelegramSender` over the Bot API via `fetch` (no SDK) | Completed |
| Config-gated (`telegramConfig`): empty token → no-op sender; empty secret → webhook disabled | Completed + verified |
| Commands `/start /create_khatm /my_khatms /join /progress` route through existing services; no business logic in Telegram code | Completed |
| Identity via the identity capability; CREATOR required to create (workflow-enforced) | Completed |
| Security: unknown commands, invalid updates, unauthorized creator actions, identity resolution, duplicate Telegram users | Completed — 7 webhook integration cases |
| Telegram SDK/vendor surface confined to infrastructure | Completed |
| No migration | Completed |
| getUpdates polling · real setWebhook registration (ops) · Bale adapter · vendor SDK · rich conversation state | Not done — deferred |

## Phase 8 — Creator experience (web) foundation

**Status: COMPLETED (2026-09-07).** The first user-facing layer — a thin Web app
(Next.js, Persian/RTL) over the existing authenticated APIs: login, creator
dashboard, khatm management. UI holds no business logic; authorization stays
server-side. No payments, notifications, admin, marketplace, subscriptions, mobile,
or production Telegram. No schema change. See DEC-0064, ARCHITECTURE.md.

| Item | Status |
| ---- | ------ |
| Web app setup — API client layer, error handling, protected routes (no arch change) | Completed — `apps/web/src/lib`, `RequireAuth` |
| Authentication UI — login (request-OTP → verify), session handling, logout, guards | Completed — `/login`, `AuthProvider` |
| Creator dashboard — current user, creator status, own khatms, gated create | Completed — `/dashboard` |
| Khatm management view — status, participants, progress; activate/plan/allocate/complete | Completed — `/khatms/[id]` |
| API layer — thin endpoints where missing (`/api/me`, request-otp, participants) | Completed — DTO validation only, existing contracts |
| UI design — clean layout, Persian, RTL (logical properties), responsive, tokens | Completed |
| Backend full gate + frontend component/logic tests | Completed — api 303 + web 10 unit, 88 integration, e2e 1 |
| Security — no token in logs, no client-side secret (in-memory), backend authoritative, UI never trusts its state | Completed — DEC-0064 |
| Payments · notifications · admin · marketplace · subscription · mobile · production Telegram | Not done — explicitly out of scope |

**Deferred:** persistent sessions (httpOnly cookies), "sign in by phone" without a
userId field (needs a phone→owner lookup), real SMS delivery, screenshots.

## Phase 6 — Authentication & session foundation

**Status: COMPLETED (2026-09-07).** Authenticated principals and server-side
sessions so transports stop relying on explicit user ids. Authentication foundation
only — no Web UI, payments, notifications, admin, Creator permissions, real SMS, or
OAuth. See DEC-0059…DEC-0060, ARCHITECTURE.md, DATABASE.md, PROJECT_STATE.md.

| Item | Status |
| ---- | ------ |
| Session model / token strategy / storage rules / refresh / lifecycle designed + ADR | Completed — DEC-0059 (opaque server-side; SHA-256 hash; derived status; no refresh yet) |
| `session` capability (domain/application/infrastructure) | Completed — `src/session/` |
| Session entity + derived ACTIVE/REVOKED/EXPIRED; repository ports; errors | Completed |
| `AuthenticationService` — createSession / authenticate / revoke | Completed |
| Token hashing (SHA-256), CSPRNG generation, constant-time compare; raw token returned once | Completed |
| Transports resolve an authenticated principal (HTTP bearer; Telegram platform identity) (DEC-0060) | Completed |
| Phone-OTP → session bridge (consumes existing verified state; phone unchanged) | Completed — `PhoneOtpLoginService` |
| Sixth reviewed migration (`sessions`; FK CASCADE; unique token_hash) → psql verified | Completed — `20260907071058_session_foundation` |
| Security: hashing, expiration, revocation, no secret logging, no token in errors, constant-time | Completed |
| Unit (lifecycle/token/expiry/revocation/not-plaintext) + integration (create/authenticate/revoke/expired, phone→session, HTTP bearer, Telegram principal) | Completed — 286 unit, 75 integration |
| Web UI · payments · notifications · admin · Creator permissions · production SMS · OAuth | Not done — explicitly out of scope |

**Deferred:** per-resource authorization (Creator permissions), refresh-token
rotation, idle timeout, and guarding the resource-scoped khatm routes.

## Phase 4 — Khatm engine foundation

**Status: COMPLETED (2026-09-07).** The core business domain: the Khatm aggregate
and lifecycle, a generic template classification, participation, and the
assignment/portion system. Domain foundation only — no controllers, bots, UI,
reminders, payments, Creator roles, or authentication. See DEC-0048…DEC-0051,
DOMAIN_MODEL.md, DATABASE.md.

| Item | Status |
| ---- | ------ |
| Khatm aggregate — id/creator/title/description?/template/status/timestamps; DRAFT→ACTIVE→COMPLETED\|CANCELLED (DEC-0048) | Completed |
| Only ACTIVE accepts participants/assignments; creator ownership preserved; terminal states frozen | Completed |
| Generic template — single `KhatmTemplateType` enum, no table/class per type (DEC-0019/0048) | Completed |
| Participation — status ACTIVE/COMPLETED/LEFT/REMOVED, joinedAt; one ACTIVE per (khatm,user) via partial unique index; history retained (DEC-0050) | Completed |
| Assignment/Portion — belongs to participation, POSITIONAL range / QUANTITY, completion tracked, progress derived (DEC-0049) | Completed |
| Layering — domain owns ports (no Prisma); application no DB knowledge; Prisma only in infrastructure; UnitOfWork only where needed (not needed this phase) | Completed |
| Fourth reviewed migration (create-only → hand-edit partial index → deploy → psql verify) | Completed — `20260906195317_khatm_engine_foundation` |
| FK strategy RESTRICT for all new FKs; relations to existing User identity checked (DEC-0051) | Completed + verified |
| Unit (lifecycle/invalid states/participant/assignment rules) + integration (persistence/constraints/uniqueness/migration) | Completed — 173 unit, 49 integration |
| Telegram/Bale bot · WebApp UI · HTTP controllers · notifications/reminders · payments · wallet · creator roles · authentication | Not done — explicitly out of scope |

**Deferred to the later Khatm allocation engine:** auto-splitting a template into
portions across participants, positional-portion non-overlap enforcement,
reallocation when a participant leaves, and reminders.

## Phase 4.1 — Khatm allocation engine

**Status: COMPLETED (2026-09-07).** The generic, template-driven allocation engine,
built additively on Phase 4 (Phase-4 tables/entities unchanged). No transport,
notifications, payments, or auth. See DEC-0052…DEC-0053, DOMAIN_MODEL.md, DATABASE.md.

| Item | Status |
| ---- | ------ |
| Template → portion generation — pure `generatePortions(PlanSpec)`: POSITIONAL `{from,to}` → atomic units, QUANTITY `{total,chunk}` → chunks; numbers caller-supplied (DEC-0052) | Completed |
| Assignment allocation — `AllocationPlan` + `PlanPortion` (OPEN→ASSIGNED→COMPLETED); batch + single allocation to active participations | Completed |
| Non-overlapping rules — atomic positional units + hand-written partial unique index `UNIQUE(plan_id,unit_start) WHERE unit_kind='POSITIONAL'` (DEC-0053) | Completed + verified |
| Reallocation support — `releaseParticipation` (ASSIGNED→OPEN) + `reassignPortion`; released units re-allocatable | Completed |
| Progress calculation — derived counts `{total,open,assigned,completed}` | Completed |
| Transaction safety — plan generation / batch allocation / release run in `UnitOfWork`; guards read in-transaction (DEC-0044) | Completed |
| Additive — Phase 4 tables/entities unmodified; engine reads Phase-4 state via its own `KhatmStateReader` port (DEC-0052) | Completed + verified (`khatms` still 8 columns) |
| Fifth reviewed migration (create-only → hand-edit index → deploy → psql verify); 4 FKs RESTRICT | Completed — `20260907004303_khatm_allocation_engine` |
| Unit + integration tests (generation/non-overlap/allocation/reallocation/progress/constraints) | Completed — 217 unit, 58 integration |
| Telegram/Bale/Web UI · notifications · payments · auth · auto-release wired into Phase-4 leave/remove | Not done — explicitly out of scope |

## Phase 4.2 — Khatm workflow orchestration

**Status: COMPLETED (2026-09-07).** Application-level workflows connecting the
existing Khatm capabilities (create → activate → join → allocate → complete).
Application only — no transport, notifications, payments, or auth. No schema change.
See DEC-0054…DEC-0056, ARCHITECTURE.md, PROJECT_STATE.md.

| Item | Status |
| ---- | ------ |
| Create-khatm flow — validate creator is ACTIVE, delegate create (DRAFT); ownership preserved (DEC-0054) | Completed |
| Activate-khatm flow — require a valid allocation plan (≥1 portion) before DRAFT→ACTIVE (DEC-0055) | Completed |
| Join-khatm flow — validate user ACTIVE; ACTIVE-khatm + duplicate rules stay in khatm capability (DEC-0054) | Completed |
| Generate-allocation flow — delegate to the allocation capability; no logic duplicated | Completed |
| Complete-portion flow — holder-only completion; cannot complete twice (`completeHeldPortion`, DEC-0056) | Completed |
| Complete-khatm flow — only when every portion is completed (DEC-0056) | Completed |
| Dedicated orchestration capability (`khatm-workflow`), account-merge pattern; capabilities stay independent; UnitOfWork reused (no new tx) | Completed |
| No migration (application only) | Completed — no schema change |
| Unit (create/join/activation/completion rules) + integration (full journey, constraints, tx behavior) | Completed — 232 unit, 61 integration |
| Telegram/Bale/Web UI · HTTP controllers · notifications · payments · auth | Not done — explicitly out of scope |

**Deferred:** auto-completion of a khatm, auto-release of a leaving participant's
portions (offered as explicit calls), and any transport that drives the workflows.

## Phase 5 — Transport foundation

**Status: COMPLETED (2026-09-07).** The transport layer that drives the existing
workflows: a REST API and a Telegram channel adapter foundation. Transport only
translates external input into application use-cases. No Web UI, real Telegram
network/deployment, payments, notifications, or auth. No schema change. See
DEC-0057…DEC-0058, ARCHITECTURE.md, PROJECT_STATE.md.

| Item | Status |
| ---- | ------ |
| Shared transport contracts in `packages/contracts` (shapes only, no domain leakage) | Completed — `contracts/src/khatm.ts` |
| HTTP/API boundary — thin controllers over the workflows (create/activate/join/progress/complete + plan/allocate/list); DTO validation; no Prisma/domain on the wire (DEC-0057) | Completed — `http-api/` |
| Stable HTTP error envelope via `DomainExceptionFilter` (domain errors → status by kind) | Completed |
| Telegram adapter boundary — vendor-neutral update/reply shapes; no SDK in app/domain (DEC-0058) | Completed — `telegram/` |
| Platform identity lookup through the identity capability; `/start` provisioning | Completed |
| Command routing foundation — `/start /create_khatm /my_khatms /join /progress`, Persian replies | Completed |
| Outbound `TelegramSender` port + no-op adapter (no token, no network) | Completed |
| Additive read `KhatmService.listKhatmsByCreator` (+ repo) for `/my_khatms` and `GET /api/khatms` | Completed |
| Unit (command mapping/parse, DTO validation, error filter) + integration (HTTP journey via supertest; Telegram identity→User→workflow, no real network) | Completed — 269 unit, 67 integration |
| Web UI · React pages · real Bot API/webhook/deployment · payments · notifications · authentication · admin | Not done — explicitly out of scope |

**Deferred:** a real Telegram Bot API adapter + webhook/long-poll behind the port;
bot commands for plan-generation/activation; authentication/session so transport can
use an authenticated principal instead of explicit ids.

## Phase 10 — Product readiness foundation

**Status: COMPLETED (2026-09-08).** Phone-first authentication, httpOnly cookie
browser sessions, the creator journey over real auth, and a Telegram command review.
See DEC-0066/0067, ARCHITECTURE.md, PROJECT_STATE.md.

| Item | Status |
| ---- | ------ |
| Phone-first auth — user-less `PHONE_LOGIN` OTP; resolve-or-create user; opaque session (DEC-0066) | Completed |
| Phone capability extended, not rewritten; verification stays separate from sessions | Completed |
| httpOnly cookie sessions; token never in JS; logout invalidates; cookie-or-bearer guard (DEC-0067) | Completed |
| Web migrated to cookie auth (`credentials:'include'`, `/api/me` restore, phone→code login) | Completed |
| Creator journey over cookie auth + non-creator (403) + ownership (403) tests | Completed |
| Telegram product commands (`/start`/`/create_khatm`/`/my_khatms`/`/progress`); raw `/join` retired | Completed |
| Additive migration `phone_login_purpose`; tests (unit + integration); full gate | Completed |
| Deferred: double-submit CSRF token; remove legacy user-scoped login; real SMS | Deferred |

## Phase 11 — Product completion core

**Status: COMPLETED (2026-09-08).** Participant invitations, participant experience,
lifecycle-hardening review, API completeness. See DEC-0068, PROJECT_STATE.md.

| Item | Status |
| ---- | ------ |
| Invitation system — owner-issued opaque-token grant, derived lifecycle CREATED/ACCEPTED/EXPIRED/CANCELLED, history preserved (DEC-0068) | Completed |
| Create/list/cancel (owner-gated) + accept (authenticated, joins via workflow, authz not bypassed) | Completed |
| Migration `20260908004812_khatm_invitations` (FKs RESTRICT, unique token_hash) | Completed |
| Participant experience — joined khatms, own assigned portions, complete own portions | Completed |
| Lifecycle hardening — reviewed (UnitOfWork + guarded transitions + DB uniques); concurrent-activation test | Completed |
| API completeness — invitations, participant status, my-portions, progress, dashboard reads | Completed |
| Security review — no new IDOR; ownership/participant scoping; tokens hashed | Completed |
| Telegram — no new command required (invite-accept deferred; web serves it) | Reviewed |
| Deferred: CSRF double-submit token; Telegram invite-accept; remove legacy user-scoped login | Deferred |

## Later (explicitly after MVP)

Bale adapter · SMS · additional languages · advertising rewards · referral ·
white-label bots · advanced premium reports · free Quran participation model

## Out of scope (DEC-0047)

KhatmSaz is an independent product. **Cross-product / shared identity is out of
scope** — separate future products (study bot, donation bot, …) are isolated with
their own users and identity. "White-label bots" above means white-labeled KhatmSaz
instances (same product's identity), not separate products. The pre-3B architecture
review's cross-product suggestions (an event outbox *between products*, extracting
identity into a *shared service*) are **not** on this roadmap; account merge stays
intra-product.
