# DEBUGGING

Only genuinely recurring or hard-to-diagnose problems belong here, each with a
proven fix. This is not a log of ordinary command failures.

---

## DBG-0001 — Line endings differ between Windows and WSL

**Symptom.** Files appear entirely modified in `git diff`, or a shell script
fails with `bad interpreter: /bin/bash^M`.

**Cause.** The repository sits on `Z:\KhatmSaz` and is edited from both Windows
tools and WSL. Without normalisation, CRLF and LF alternate.

**Fix (already applied).** `.gitattributes` sets `* text=auto eol=lf`, with
`.bat/.cmd/.ps1` kept as CRLF and binary assets marked `binary`.
`.editorconfig` sets `end_of_line = lf`. If a file was committed before this,
renormalise once:

```bash
git add --renormalize .
```

**Status.** Prevented by configuration. No occurrence recorded yet.

---

## DBG-0002 — Never put container data on `/mnt/z`

**Symptom.** PostgreSQL fails to start, or is extremely slow, when its data
directory is bind-mounted from the Windows drive.

**Cause.** `/mnt/z` is a Windows drive surfaced through WSL's 9p/DrvFs layer. It
does not give PostgreSQL the filesystem semantics it needs, and it is slow.

**Fix (already applied).** `infra/docker/docker-compose.yml` uses Docker **named
volumes** for every service. Do not change this to a bind mount (DEC-0030).

**Status.** Prevented by configuration.

---

## DBG-0003 — Workspace package changes not visible to the API

**Symptom.** An edit in `packages/shared`, `packages/contracts` or
`packages/config` has no effect in `apps/api`, or the API fails to resolve the
module.

**Cause.** Those three packages are consumed as **compiled output**
(`dist/index.js`), not as source. `apps/web` and `apps/admin` consume
`packages/ui` as source through `transpilePackages`, which is why UI edits do
appear immediately and backend ones do not.

**Fix.**

```bash
npm run build:packages
```

`npm run dev` and `npm run typecheck` already do this first.

**Status.** By design (DEC-0028).
