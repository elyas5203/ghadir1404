# Design System — KhatmSaz

> Version: 2026-09-11.
> Replaces the temporary green palette. Effective for all future UI work.
> Source of truth for token values is `packages/ui/src/tokens.css`.

---

## Design principles

| Principle | Meaning |
|-----------|---------|
| **Calm** | No flashy animations, no aggressive colours, no noise. The user is often reciting or praying. |
| **Trustworthy** | Honest about state. No phantom loading. No fake data. Every number is real. |
| **Minimal** | Show only what the user needs right now. Creator controls are hidden from participants. |
| **Premium** | Intentional typography, generous whitespace, cohesive palette. Never feels like a developer dashboard. |
| **Spiritual** | The colour language references Persian and Islamic visual heritage without parody. |

---

## Colour palette

### Lapis (لاجوردی) — primary

The deep blue of lapis lazuli has been central to Persian and Islamic art for
over a millennium: mosque tiles, manuscript illumination, calligraphy ink.
It reads as trustworthy and premium in digital contexts.

| Token | Hex | Use |
|-------|-----|-----|
| `--ks-lapis-50` | `#EEF2FA` | tinted backgrounds |
| `--ks-lapis-100` | `#CFDAEF` | soft highlights |
| `--ks-lapis-200` | `#9EB4E0` | borders on focus surfaces |
| `--ks-lapis-300` | `#6E8ED1` | dark-mode primary |
| `--ks-lapis-400` | `#4168C2` | interactive mid |
| `--ks-lapis-500` | `#2B52B0` | primary in focus/hover |
| `--ks-lapis-600` | `#1E3E90` | **primary** (light mode) |
| `--ks-lapis-700` | `#172E70` | primary-strong |
| `--ks-lapis-800` | `#102054` | dark headers |
| `--ks-lapis-900` | `#0A1438` | darkest |

### Stone (خاکی) — neutral

Warm stone replaces cold grey. It gives the app a parchment-like warmth
appropriate for a product about reading and recitation.

| Token | Hex | Use |
|-------|-----|-----|
| `--ks-stone-0` | `#FFFFFF` | surface |
| `--ks-stone-50` | `#F9F7F4` | page background |
| `--ks-stone-100` | `#F0EDE8` | panel background (alt) |
| `--ks-stone-200` | `#E0DBD3` | borders |
| `--ks-stone-300` | `#C8C2B8` | disabled borders |
| `--ks-stone-500` | `#948E82` | subtle text |
| `--ks-stone-700` | `#524D46` | muted text |
| `--ks-stone-900` | `#1C1A16` | body text |

### Semantic tokens (light mode)

```
--ks-color-bg:             #F9F7F4  (stone-50)
--ks-color-surface:        #FFFFFF  (stone-0)
--ks-color-border:         #E0DBD3  (stone-200)
--ks-color-text:           #1C1A16  (stone-900)
--ks-color-text-muted:     #524D46  (stone-700)
--ks-color-text-subtle:    #948E82  (stone-500)
--ks-color-primary:        #1E3E90  (lapis-600)
--ks-color-primary-strong: #172E70  (lapis-700)
--ks-color-primary-soft:   #EEF2FA  (lapis-50)
--ks-color-on-primary:     #FFFFFF
--ks-color-focus:          #2B52B0  (lapis-500)
--ks-color-success:        #2D6A4F  (forest green — reserved for COMPLETED state)
--ks-color-warning:        #8B5B0A  (amber — caution, not error)
--ks-color-error:          #9B1C1C  (crimson — destructive / failed)
```

### Dark mode overrides

```
--ks-color-bg:             #0D1220
--ks-color-surface:        #151E30
--ks-color-border:         #232E44
--ks-color-text:           #ECF0F8
--ks-color-text-muted:     #B0BBCF
--ks-color-text-subtle:    #7A869E
--ks-color-primary:        #6E8ED1  (lapis-300)
--ks-color-primary-strong: #9EB4E0  (lapis-200)
--ks-color-primary-soft:   #152040
--ks-color-on-primary:     #0A1438
--ks-color-focus:          #6E8ED1
--ks-color-success:        #4B9E72
--ks-color-warning:        #C49040
--ks-color-error:          #D45C5C
```

---

## Typography

### Font stack

```
--ks-font-fa: 'Vazirmatn', 'IRANSans', 'Segoe UI', Tahoma, 'Noto Sans Arabic', system-ui, sans-serif;
```

Vazirmatn is loaded via Google Fonts (the one external host allowed by CSP).
It is a well-hinted, open-weight Persian font that degrades gracefully.

### Type scale

| Token | Size | Use |
|-------|------|-----|
| `--ks-text-xs` | `0.8125rem` (13px) | captions, badges, meta |
| `--ks-text-sm` | `0.9375rem` (15px) | form labels, secondary content |
| `--ks-text-md` | `1.0625rem` (17px) | body / default |
| `--ks-text-lg` | `1.25rem` (20px) | card titles, section headings |
| `--ks-text-xl` | `1.625rem` (26px) | page headings (h1 within panels) |
| `--ks-text-2xl` | `2.25rem` (36px) | hero headings |

### Leading

```
--ks-leading-tight:  1.35  (headings)
--ks-leading-normal: 1.75  (body — generous for Persian script)
```

---

## Spacing scale

| Token | Value | Notes |
|-------|-------|-------|
| `--ks-space-1` | `0.25rem` | hairline |
| `--ks-space-2` | `0.5rem` | tight gap |
| `--ks-space-3` | `0.75rem` | default gap |
| `--ks-space-4` | `1rem` | standard padding |
| `--ks-space-5` | `1.25rem` | card inner padding |
| `--ks-space-6` | `1.5rem` | section gap |
| `--ks-space-8` | `2rem` | large gap |
| `--ks-space-12` | `3rem` | page breathing room |

**Note:** `--ks-space-5` was missing from the original token file; it is now defined.

---

## Radius

| Token | Value | Use |
|-------|-------|-----|
| `--ks-radius-sm` | `8px` | inputs, buttons, badges |
| `--ks-radius-md` | `14px` | panels, cards |
| `--ks-radius-lg` | `22px` | large modals, hero cards |

---

## Elevation

| Token | Value | Use |
|-------|-------|-----|
| `--ks-shadow-sm` | `0 1px 2px rgb(22 42 70 / 7%)` | cards, panels |
| `--ks-shadow-md` | `0 8px 28px -12px rgb(22 42 70 / 20%)` | popovers, modals |

---

## Components

### Button

```css
.btn             — neutral (border, surface bg)
.btn-primary     — primary fill (lapis-600, white text)
.btn-ghost       — no background, no border
.btn-danger      — error fill (crimson) — destructive actions only
.btn-sm          — small variant (xs font, reduced padding)
```

**Rules:**
- Primary CTA: one per view.
- Ghost: cancel / back only.
- Danger: always requires confirmation before the action executes.
- Disabled: `opacity: 0.55`, `cursor: not-allowed`.

### Card

```
.panel         — white surface, stone-200 border, md radius, sm shadow
.khatm-card    — clickable panel variant; hover lifts border to primary
```

Use `panel` for non-navigable content blocks. Use `khatm-card` for khatm list items.

### Badge

```
.badge              — neutral (stone border, muted text)
.badge-on           — success (green border/text)
.badge-danger       — error (crimson border/text)
.badge-inv-created  — primary (lapis)
.badge-inv-accepted — success
.badge-inv-expired  — faded
.badge-inv-cancelled — warning
```

Status colours map directly to semantic tokens — never hard-code hex in component styles.

### Input / select

```
border: 1px solid stone-200
border-radius: radius-sm
focus: outline 2px solid lapis-500
background: stone-0 (white)
```

### HelpTip popover

- 18px circle button, subtle border, question mark character.
- Popover: 240px wide, opens above the button.
- On RTL, anchors to `inset-inline-start: 50%` then translates -50%; at viewport edges,
  clip detection should flip the side (deferred — for now constrain popover to 220px).

### Progress indicator

```
.progress-wrap  — 8px tall, stone-200 bg, pill radius
.progress-fill  — lapis primary, transitions on inline-size
```

### Empty state

```
.empty-state       — centred block, ks-muted text, optional CTA below
.empty-state-icon  — 32px placeholder glyph or SVG (no emoji in production)
```

### Alert / notice

```
.alert      — warning (amber 12% background + amber border) — errors, warnings
.alert-ok   — success (green 12% background + green border)
.alert-info — primary-soft background + lapis-100 border — neutral info
```

### Loading skeleton

```
.skeleton      — rounded rect, animated pulse (opacity 0.4 → 0.7)
@media (prefers-reduced-motion) — no animation, static opacity 0.5
```

---

## Iconography

No icon library is introduced. Use Unicode characters or minimal inline SVG only.
- ختم‌ساز wordmark icon: an abstract square with rounded corners (CSS `::before` pseudo).
- Type cards use text, not icons.
- HelpTip uses the "?" character.

---

## Do not

- Do not hard-code hex values in component or page CSS. Always use tokens.
- Do not use `left` / `right` for layout. Use CSS logical properties.
- Do not use the old `--ks-green-*` variables after the palette migration.
- Do not use emoji in production UI copy.
- Do not introduce a CSS-in-JS library, icon pack, or component framework.
