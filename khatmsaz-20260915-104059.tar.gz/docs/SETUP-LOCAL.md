# راهنمای راه‌اندازی محیط توسعه (لوکال)

## پیش‌نیازها

| ابزار | نسخه | دانلود |
|-------|------|--------|
| Node.js | 24 LTS | https://nodejs.org |
| npm | همراه Node | — |
| Docker Desktop | هر نسخه پایدار | https://www.docker.com/products/docker-desktop |
| Git | هر نسخه | https://git-scm.com |

---

## مرحله ۱ — کلون و نصب

```bash
git clone https://github.com/YOUR_ORG/khatmsaz.git
cd khatmsaz
npm install
```

---

## مرحله ۲ — سرویس‌های لوکال (PostgreSQL + Redis)

```bash
npm run infra:up
```

صبر کن تا هر دو سرویس سبز بشن:

```bash
docker compose --project-directory . -f infra/docker/docker-compose.yml ps
```

---

## مرحله ۳ — فایل محیطی

```bash
cp .env.example .env
```

فایل `.env` را باز کن و حداقل این متغیرها را پر کن:

```env
DATABASE_URL=postgresql://khatmsaz:local_dev_only_change_me@127.0.0.1:5432/khatmsaz
REDIS_URL=redis://127.0.0.1:6379
```

بقیه متغیرها در `.env.example` با کامنت توضیح داده شده‌اند.

---

## مرحله ۴ — دیتابیس

```bash
# اجرای مایگریشن‌ها:
npm run db:migrate

# ست کردن اولین ادمین (بعد از اینکه با شماره موردنظر ثبت‌نام کردی):
ADMIN_PHONE=+989XXXXXXXXX npm run -w @khatmsaz/api tsx -- prisma/seed-admin.ts
```

---

## مرحله ۵ — اجرا

**حالت یک‌پارچه (همه با هم):**

```bash
npm run dev
```

**یا هر سرویس جداگانه در ترمینال‌های مجزا:**

```bash
# ترمینال ۱ — API (پورت 3001):
npm run dev:api

# ترمینال ۲ — اپ وب (پورت 3000):
npm run dev:web

# ترمینال ۳ — پنل ادمین (پورت 3002):
npm run dev:admin
```

آدرس وب: http://localhost:3000  
آدرس API: http://localhost:3001  
پنل ادمین: http://localhost:3002

---

## مرحله ۶ — OTP لوکال (بدون SMS)

برای دریافت کد تأیید OTP در لوکال بدون نیاز به SMS:

```bash
npm run dev:api:otp
```

این دستور API را با `KHATMSAZ_DEV_OTP=1` اجرا می‌کند. کد OTP از طریق یک Unix socket در
`/tmp/khatmsaz-otp-<uid>/delivery.sock` تحویل داده می‌شود.

یا از ابزار CLI:

```bash
npm run dev:local
```

---

## مرحله ۷ — ربات تلگرام/بله (webhook لوکال با ngrok)

برای تست ربات در محیط لوکال به یک آدرس HTTPS عمومی نیاز داری:

```bash
# نصب ngrok:
npm install -g ngrok

# در یک ترمینال جداگانه:
ngrok http 3001
```

آدرس `https://XXXX.ngrok.io` را در `.env` ذخیره کن:

```env
BASE_URL=https://XXXX.ngrok.io
```

ثبت webhook تلگرام:

```bash
source .env
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -d "url=${BASE_URL}/telegram/webhook" \
  -d "secret_token=${TELEGRAM_WEBHOOK_SECRET}"
```

ثبت webhook بله:

```bash
curl -X POST "https://tapi.bale.ai/bot${BALE_BOT_TOKEN}/setWebhook" \
  -d "url=${BASE_URL}/bale/webhook" \
  -d "secret_token=${BALE_WEBHOOK_SECRET}"
```

تأیید وضعیت webhook:

```bash
curl "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getWebhookInfo"
```

---

## تست و اعتبارسنجی

```bash
npm run typecheck
npm run lint
npm run test
npm run build
```

تست‌های integration (نیاز به PostgreSQL لوکال):

```bash
npm run test:integration:db
```

---

## متوقف کردن سرویس‌ها

```bash
npm run infra:down
```
