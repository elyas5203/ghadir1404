# راهنمای استقرار روی سرور (Ubuntu 22.04)

## مشخصات سرور پیشنهادی

| مورد | حداقل | پیشنهاد |
|------|--------|---------|
| CPU  | 2 هسته | 4 هسته |
| RAM  | 2 GB   | 4 GB   |
| دیسک | 20 GB  | 40 GB  |
| سیستم‌عامل | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |

---

## مرحله ۱ — آماده‌سازی سرور

```bash
# به عنوان root:
apt update && apt upgrade -y
apt install -y curl git ufw

# فایروال:
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable

# Docker:
curl -fsSL https://get.docker.com | sh
systemctl enable docker && systemctl start docker
apt install -y docker-compose-plugin

# کاربر بدون root برای deploy:
adduser deploy
usermod -aG docker deploy
```

---

## مرحله ۲ — کلون و پیکربندی

```bash
su - deploy
git clone https://github.com/YOUR_ORG/khatmsaz.git /opt/khatmsaz
cd /opt/khatmsaz
cp .env.example .env.prod
nano .env.prod
```

حداقل این مقادیر را تنظیم کن:

```env
NODE_ENV=production
DATABASE_URL=postgresql://khatmsaz:STRONG_PASSWORD@postgres:5432/khatmsaz
DB_PASSWORD=STRONG_PASSWORD
REDIS_URL=redis://:REDIS_PASSWORD@redis:6379
REDIS_PASSWORD=REDIS_PASSWORD
BASE_URL=https://YOURDOMAIN.IR
NEXT_PUBLIC_API_BASE_URL=https://YOURDOMAIN.IR
TELEGRAM_BOT_TOKEN=...
TELEGRAM_WEBHOOK_SECRET=...
BALE_BOT_TOKEN=...
BALE_WEBHOOK_SECRET=...
ZARINPAL_MERCHANT_ID=...
ZARINPAL_SANDBOX=false
SMS_PROVIDER=kavenegar
KAVENEGAR_API_KEY=...
LOG_LEVEL=warn
```

---

## مرحله ۳ — SSL با Let's Encrypt

```bash
# به عنوان root:
apt install -y certbot
# توجه: پورت 80 باید آزاد باشه (Docker هنوز اجرا نشده باشه)
certbot certonly --standalone -d YOURDOMAIN.IR
# گواهی‌ها در: /etc/letsencrypt/live/YOURDOMAIN.IR/
```

---

## مرحله ۴ — پیکربندی Nginx با SSL

فایل `nginx/khatmsaz.conf` را با دامنه واقعی‌ات ویرایش کن.
جایگزین‌های لازم: همه مقادیر `YOURDOMAIN.IR`

---

## مرحله ۵ — اجرا

```bash
cd /opt/khatmsaz
docker compose -f docker-compose.prod.yml up -d
```

لاگ اجرا:

```bash
docker compose -f docker-compose.prod.yml logs -f api
```

---

## مرحله ۶ — migration و ادمین اول

```bash
# مایگریشن دیتابیس:
docker compose -f docker-compose.prod.yml exec api npm run db:migrate

# ادمین اول (بعد از ثبت‌نام با شماره موردنظر):
docker compose -f docker-compose.prod.yml exec api \
  sh -c "ADMIN_PHONE=+989XXXXXXXXX npx tsx prisma/seed-admin.ts"
```

---

## مرحله ۷ — ثبت webhook

```bash
source .env.prod

curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -d "url=https://YOURDOMAIN.IR/telegram/webhook" \
  -d "secret_token=${TELEGRAM_WEBHOOK_SECRET}"

curl -X POST "https://tapi.bale.ai/bot${BALE_BOT_TOKEN}/setWebhook" \
  -d "url=https://YOURDOMAIN.IR/bale/webhook" \
  -d "secret_token=${BALE_WEBHOOK_SECRET}"

# تأیید:
curl "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getWebhookInfo"
```

---

## مرحله ۸ — تجدید SSL خودکار

```bash
# به عنوان root:
crontab -e
# اضافه کن:
0 3 * * * certbot renew --quiet && docker compose -f /opt/khatmsaz/docker-compose.prod.yml restart nginx
```

---

## مانیتورینگ سریع

```bash
# وضعیت سرویس‌ها:
docker compose -f docker-compose.prod.yml ps

# لاگ API:
docker compose -f docker-compose.prod.yml logs --tail=50 -f api

# health check:
curl https://YOURDOMAIN.IR/health

# فضای دیسک:
df -h

# RAM:
free -m
```

---

## بروزرسانی (deploy جدید)

```bash
cd /opt/khatmsaz
git pull origin main
docker compose -f docker-compose.prod.yml build --no-cache api web
docker compose -f docker-compose.prod.yml up -d
docker compose -f docker-compose.prod.yml exec api npm run db:migrate
```
