# KhatmSaz — Phase Roadmap

## Completed

- [x] Phase 1-2B: Monorepo bootstrap, DB foundation, identity (User + PlatformIdentity)
- [x] Phase 3A: Phone claims + OTP verification
- [x] Phase 3B: Account merge / tombstone
- [x] Phase 4: Khatm domain (DRAFT→ACTIVE→COMPLETED/CANCELLED, generic template enum, Participation, Assignment)
- [x] Phase 4.1: Allocation engine (plan generation, non-overlapping portions, reallocation)
- [x] Phase 4.2: KhatmWorkflow orchestration service
- [x] Phase 5: Transport layer (HTTP REST + Telegram webhook)
- [x] Phase 6: Sessions (server-side opaque tokens, phone-OTP login bridge)
- [x] Phase 7: Authorization (CREATOR capability, ownership check, IDOR fix)
- [x] Phase 8: Web app (Next.js dashboard, create khatm, detail page)
- [x] Phase 9: Real Telegram Bot API webhook (config-gated, noop when empty)
- [x] Phase 10: Phone-first login (OTP login purpose)
- [x] Phase 11: Invitation links (KhatmInvitation, token, accept, cancel)
- [x] Phase 12: Participant web view (dashboard, join via invitation, my portions)
- [x] Phase 13: OPEN khatm type (free contributions, no assigned portions)
- [x] Phase 14: Participant enrichment (display names in management view)
- [x] Phase 15-17: UI/UX overhaul (RTL design tokens, premium visuals)
- [x] Phase 18: Telegram /join command + invitation no-expiry (DEC-0075)
- [x] QURAN-001: QURAN_PAGE + QURAN_SURAH khatm modes; static Quran registries

## In Progress

- [ ] **Phase 19: Notification Engine** — BullMQ scheduler; daily reminders per participation; DONE/SNOOZE callbacks
  - DB foundation done (NotificationPreference, NotificationLog)
  - BullMQ module: TODO
  - Notification processor: TODO
  - Telegram SNOOZE callback: TODO

## Planned (sprint)

- [ ] **Step 2 extras: WaitingList, Wallet, UserSettings DB models**
- [ ] **Phase 01: Notification Engine** (BullMQ, scheduleKhatmNotifications, snooze)
- [ ] **Phase 02: Waiting List + Auto-Replacement** (WaitingListModule, replaceParticipant)
- [ ] **Phase 03: Payment System** (Wallet, ZarinPal, plan gating)
- [ ] **Phase 04: Bale Platform Adapter** (mirrors Telegram; BasePlatformCommandService)
- [ ] **Phase 05: Public Khatm Page** (web /khatm/[slug], QR code, join deep link)
- [ ] **Phase 06: Admin & Customer Dashboard** (super-admin, analytics, broadcast)
- [ ] **Phase 07: User Profile & Settings** (UserSettings, /settings Telegram command)
- [ ] **Phase 08: SMS System** (provider adapter, OTP migration, daily reminders)
