# KhatmSaz — Module Import Graph

## Dependency direction
`apps/*` → `packages/*`  (never the reverse)
`packages/shared` → nothing (no framework deps)
`packages/contracts` → nothing (shapes only)

## API module dependencies (at application/domain level)

```
KhatmWorkflowModule
  imports: IdentityModule, KhatmModule, AllocationModule, AuthorizationModule

HttpApiModule
  imports: KhatmWorkflowModule, InvitationModule, SessionModule, (all controllers)

TelegramModule
  imports: IdentityModule, KhatmWorkflowModule, KhatmModule, InvitationModule

InvitationModule
  imports: KhatmModule

AllocationModule
  imports: KhatmModule (for state reader)

SessionModule
  imports: IdentityModule, PhoneModule

PhoneModule
  imports: IdentityModule (for user ops)
```

## Planned new modules (not yet built)
```
NotificationModule
  will import: KhatmWorkflowModule, TelegramModule, BaleModule

WaitingListModule
  will import: KhatmModule, KhatmWorkflowModule

PaymentModule (wallet + ZarinPal)
  independent, imported by HttpApiModule

BaleModule
  mirrors TelegramModule; imports: IdentityModule, KhatmWorkflowModule, KhatmModule, InvitationModule

SmsModule
  imports: PaymentModule (wallet deduction)

UserSettingsModule
  imports: IdentityModule
```

## Key interface boundaries
- `TelegramSender` (domain interface) → `BotApiTelegramSender` / `NoopTelegramSender` (infrastructure)
- `AllocationPlan.repository.ts` (domain interface) → `PrismaAllocationPlanRepository` (infra)
- Domain modules NEVER import Prisma directly; only infra files do.
