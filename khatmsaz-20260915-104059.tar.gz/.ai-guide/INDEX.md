# KhatmSaz AI Guide — Updated: 2026-09-12

## Architecture
- **Monorepo**: `apps/api` (NestJS) | `apps/web` (Next.js) | `apps/admin` (Next.js)
- **Packages**: `packages/shared` (framework-free) | `packages/contracts` (DTOs) | `packages/config` | `packages/kernel` | `packages/ui`
- **Auth**: UUIDv7 internal IDs + phone/OTP login + httpOnly cookie sessions
- **Platforms**: Telegram (webhook) | Bale (TODO) | Web (Next.js)
- **DB**: PostgreSQL + Prisma 7.10.0 (adapter-pg, CJS output)
- **Queue**: `@nestjs/schedule` (existing); BullMQ/Redis (Phase 19+ notifications)
- **Node**: 24 LTS

## Domain Model
- **Khatm**: DRAFT → ACTIVE → COMPLETED / CANCELLED
- **Types**: QURAN_FULL | QURAN_JUZ | SURAH | QURAN_PAGE | QURAN_SURAH | SALAWAT | DUA | ZIYARAT | CUSTOM
- **KhatmType**: COMMITMENT (تعهدی — portions assigned) | OPEN (آزاد — free contribution)
- **Allocation**: POSITIONAL | QUANTITY; DB-enforced non-overlap partial unique index
- **Portion lifecycle**: OPEN → ASSIGNED → COMPLETED (ASSIGNED → OPEN for reallocation)
- **Participation lifecycle**: ACTIVE → COMPLETED / LEFT / REMOVED (history preserved)

## Module Map
```
app.module.ts
├── DatabaseModule          infrastructure — global Prisma client
├── HealthModule            /health liveness probe
├── IdentityModule          User + PlatformIdentity (no business logic)
├── PhoneModule             PhoneClaim + OtpChallenge
├── AccountMergeModule      account merge/tombstone workflow
├── KhatmModule             Khatm aggregate, Participation, Assignment
├── AllocationModule        plan generation + portion allocation engine
├── KhatmWorkflowModule     cross-capability orchestration (no extra DB)
├── AuthorizationModule     UserCapability grants (CREATOR only)
├── InvitationModule        KhatmInvitation (token, accept, cancel)
├── SessionModule           server-side opaque-token sessions
├── HttpApiModule           REST controllers (thin transport)
└── TelegramModule          Telegram webhook adapter
```

## Key Services
| Service | File | What it does |
|---|---|---|
| KhatmWorkflowService | khatm-workflow/application | orchestrates create/activate/join/leave/complete across modules |
| TelegramCommandService | telegram/application | dispatches Telegram commands to workflows |
| BaleGatewayService | bale/application | mirrors TelegramGatewayService for Bale platform |
| AllocationService | allocation/application | plan generation, portion allocation, progress |
| IdentityService | identity/application | user + platform-identity CRUD |
| InvitationService | invitation/application | create/accept/cancel invitations |
| AuthorizationService | authorization/application | CREATOR capability grant/check |
| NotificationService | notification/application | schedules BullMQ jobs for daily portion delivery reminders |
| WaitingListService | waiting-list/application | manages queue and auto-replacement for COMMITMENT khatms |
| WalletService | payment/application | manages user balance, ZarinPal payments, plan checks |
| UserSettingsService | user-settings/application | user preferences (timezone, reminder time, font, reciter) |

## Validation commands
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

## Last Changes (newest first)
### 2026-09-13 — Sprint 5 Complete — Setup Guides + DI Bugfix
Bug: PAYMENT_INTENT_REPOSITORY added to PaymentModule exports (was missing — caused UnknownDependenciesException at runtime).
Docs: docs/SETUP-LOCAL.md (فارسی، npm-based, ngrok webhook, OTP لوکال).
Docs: docs/DEPLOY-SERVER.md (فارسی، Ubuntu 22.04، SSL certbot، docker-compose.prod.yml).
Infra: nginx/khatmsaz.conf updated with HTTP→HTTPS redirect + SSL blocks (YOURDOMAIN.IR placeholder).
Infra: docker-compose.prod.yml nginx service now mounts /etc/letsencrypt:ro.
Scripts: scripts/backup-db.sh (pg_dump → gzip, 14-day retention, cron-ready).
Config: .env.example rewritten with Persian comments + LOG_LEVEL + DB_PASSWORD/REDIS_PASSWORD for docker-compose.
Tests: 373 unit passing. Typecheck / Lint: PASS.

### 2026-09-13 — Sprint 4 Complete — Production-Hardened
Rate limiting: @nestjs/throttler global guard (10/min), OTP endpoints 3/5min, payment create 5/min; /health and /public/khatm/:slug skip throttle; ZarinPal verify callback skips throttle.
Structured logging: nestjs-pino replaces NestJS default logger; redacts req.headers.authorization + body.mobile + body.otp; pino-pretty in dev, JSON in prod; LOG_LEVEL env var.
CI: .github/workflows/ci.yml (Node 24, npm, postgres:16 + redis:7 services, prisma migrate deploy, typecheck → lint → test → build → test:e2e).
Nginx: nginx/khatmsaz.conf upstream proxy config; nginx:alpine service added to docker-compose.prod.yml.
E2E smoke test: apps/api/test/payment-flow.e2e-spec.ts — happy path, replay 409, IDOR protection verified.
Tests: 373 unit passing. Typecheck / Lint / Build: all PASS.
STATUS: Production-hardened. CI pipeline live.

### 2026-09-13 — Sprint 3 Complete — v1 LAUNCH READY
Security: IDOR fix (PendingPayment table + atomic CAS), replay protection (code 101 rejected), verifyPayment no longer trusts session userId.
Feature: Plan assignment real implementation (UserPlan table, PlanService, Admin endpoint wired).
Infra: docker-compose.prod.yml, apps/api/Dockerfile, apps/web/Dockerfile (Node 24 Alpine, npm workspaces, standalone Next.js output), Health endpoint already present at /health + /health/ready.
Seed: apps/api/prisma/seed-admin.ts (promote user to SUPER_ADMIN by verified phone).
DB migrations: 20260913200000_add_pending_payment, 20260913210000_add_user_plan (run npx prisma migrate deploy).
Tests: 373 total passing. Typecheck / Lint / Build / docker compose config: all PASS.
STATUS: Feature-complete. Ready for production deployment.

### 2026-09-12 — Sprint 2 started
Sprint 1 complete: notification engine, waiting-list, payment (wallet + ZarinPal), Bale adapter, user-settings, public khatm page.
Tests: 372 passing (all validation: typecheck / lint / build PASS).
Fixes in this sprint: cancelParticipation hook (FIX A), notification lifecycle (FIX B), .env.example (FIX C).
New in this sprint: Phase 06 Admin Dashboard, Phase 08 SMS System.
New modules added by Sprint 1: NotificationModule, WaitingListModule, PaymentModule, BaleModule, UserSettingsModule.

### 2026-09-12 — Phase 19 DB foundation
- `NotificationPreference` and `NotificationLog` added to schema + migration
- BullMQ notification engine implementation (see ROADMAP)

### 2026-09-12 — QURAN-001 follow-up: repetitionTarget in contracts
- `KhatmSummary.repetitionTarget` added; web UI shows "هدف: N بار"

### 2026-09-12 — QURAN-001: QURAN_PAGE + QURAN_SURAH modes
- Two new KhatmTemplateType values; static Quran registries in packages/shared
- 3 editions, 114 surahs; edition/surah selector on web create form

### 2026-09-12 — Phase 18: Telegram /join + invitation no-expiry (DEC-0075)
