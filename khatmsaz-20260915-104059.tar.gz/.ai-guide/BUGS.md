# KhatmSaz — Known Bugs and Debugging

## Active issues

### Tunnel limitation (Telegram webhook)
**Symptom**: `setWebhook` and real message delivery fail from WSL.
**Root cause**: WSL environment blocks direct outbound to `api.telegram.org`.
**Workaround**: Use supertest / integration tests for local validation. Deploy to a host with direct egress for live bot testing.
**Status**: Active — environmental, not code bug.

## Resolved

### HelpTip popover clips at viewport edge
**Fixed in**: Phase 17
**Fix**: `position: fixed` + JS `getBoundingClientRect` clamping.

### Invitation expiry locks out users
**Fixed in**: Phase 18 (DEC-0075)
**Fix**: `DEFAULT_INVITATION_TTL_SECONDS` set to 100 years (never expires unless explicitly cancelled).

## Debugging patterns

### "CapabilityRequiredError" on create_khatm
User does not have the CREATOR capability. Grant it via admin or local seeding:
```sql
INSERT INTO user_capabilities (id, user_id, type, granted_at)
VALUES (gen_random_uuid(), '<userId>', 'CREATOR', now());
```

### Prisma "P2002 unique constraint" on participation
Duplicate active participation. The partial unique index `UNIQUE (khatm_id, user_id) WHERE status = 'ACTIVE'` fired. User already joined.

### BullMQ queue not processing
Check Redis connection: `REDIS_URL` env var. If empty, the notification module uses a no-op scheduler.
