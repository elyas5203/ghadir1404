# KhatmSaz — Folder Map

## Root
```
KhatmSaz/
├── apps/
│   ├── api/          NestJS API (the modular monolith)
│   ├── web/          Next.js user-facing web app
│   └── admin/        Next.js admin panel
├── packages/
│   ├── shared/       Framework-free utilities and static data (Quran registries)
│   ├── contracts/    DTOs / API shapes only (no business rules)
│   ├── config/       Non-secret configuration helpers
│   ├── kernel/       Error base classes, transaction port
│   └── ui/           Presentation primitives, design tokens
├── docs/ai/          Long-term project memory (PROJECT_STATE, DECISIONS, etc.)
├── .ai-guide/        AI session guide (this folder)
└── .claude/          Claude Code rules and skills
```

## apps/api/src
```
src/
├── app.module.ts                     Root module
├── main.ts                           Bootstrap
├── infrastructure/
│   └── database/                     Prisma service, DatabaseModule (global)
├── health/                           /health endpoint
├── identity/                         User + PlatformIdentity capability
│   ├── domain/                       user.ts, platform-identity.ts, platform.ts
│   ├── application/                  identity.service.ts
│   └── infrastructure/               prisma-user.repository.ts etc.
├── phone/                            PhoneClaim + OtpChallenge
├── account-merge/                    Merge workflow
├── session/                          Server-side sessions (opaque tokens)
├── authorization/                    UserCapability (CREATOR grant)
├── khatm/                            Core Khatm domain
│   ├── domain/                       khatm.ts, khatm-template.ts, participation.ts
│   ├── application/                  khatm.service.ts
│   └── infrastructure/               prisma-khatm.repository.ts, khatm.mapper.ts
├── allocation/                       Plan generation + portion allocation
│   ├── domain/                       allocation-plan.ts, plan-portion.ts, plan-spec.ts
│   ├── application/                  allocation.service.ts
│   └── infrastructure/               prisma-*.repository.ts
├── khatm-workflow/                   Cross-capability orchestration
│   └── application/                  khatm-workflow.service.ts
├── invitation/                       Invitation links (KhatmInvitation)
├── http-api/                         REST transport (thin controllers)
│   ├── dto/                          khatm-requests.ts, validate.ts
│   ├── auth/                         SessionAuthGuard, principal.decorator.ts
│   └── *.controller.ts               khatm, invitation, me, auth, portion, quran
└── telegram/                         Telegram channel adapter
    ├── domain/                       telegram-message.ts, telegram-command.ts
    ├── application/                  telegram-command.service.ts, telegram-gateway.service.ts
    └── infrastructure/               bot-api-telegram-sender.ts, noop-telegram-sender.ts
```

## apps/web/src
```
src/
├── app/
│   ├── page.tsx                      Landing / redirect
│   ├── login/                        Phone+OTP login flow
│   ├── dashboard/                    Creator + participant dashboard
│   ├── khatms/
│   │   ├── create/                   Create khatm wizard
│   │   └── [id]/                     Khatm detail (creator + participant view)
│   └── invitations/accept/           Accept invitation web flow
├── components/                       help-tip.tsx, shared UI components
└── lib/
    ├── api-client.ts                 Fetch wrapper
    ├── labels.ts                     Persian labels / icons for all KhatmTemplateTypes
    └── permissions.ts                Client-side permission helpers
```

## packages/shared/src
```
src/
├── quran/
│   ├── editions.ts                   3 Quran editions (Madina 604p, Iran Simple 560p, Pocket 286p)
│   ├── surahs.ts                     114 surahs with Persian names
│   └── index.ts
├── result.ts                         Result<T, E> monad
├── time.ts                           Time utilities
└── index.ts
```
