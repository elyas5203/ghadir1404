# KhatmSaz — Architecture Decisions (AI Guide)

For the full, authoritative decision log see `docs/ai/DECISIONS.md`.
This file captures decisions made during AI-guided sprint sessions.

## Sprint 2026-09-12

### SPRINT-001: BullMQ for notification scheduling
**Decision**: Use BullMQ + Redis for notification job scheduling.
**Reason**: `@nestjs/schedule` (cron) cannot target per-user timezones precisely. BullMQ delayed-jobs allow scheduling to a specific UTC timestamp per participation. Redis is the only new infrastructure dependency.
**Config-gate**: when `REDIS_URL` is empty, `NotificationModule` registers a `NoopNotificationScheduler` that satisfies the interface but does nothing — the app starts and tests pass without Redis.

### SPRINT-002: Bale reuses same command logic via shared base
**Decision**: Extract `BasePlatformCommandService` that both `TelegramCommandService` and `BaleCommandService` extend.
**Reason**: Bale Bot API is structurally identical to Telegram Bot API. The command logic (/start, /join, /my_khatms, /progress) is 100% identical; only the platform enum value and sender type differ.

### SPRINT-003: Public khatm slug is separate from internal UUID
**Decision**: Add `public_slug` column (URL-safe, human-readable short string) to `khatms` table for public URLs.
**Reason**: Exposing internal UUIDs in public-facing URLs is acceptable but non-shareable. A slug like `khatm-fatima-1403` is more memorable for QR codes and shared links. Uniqueness enforced by UNIQUE index.

### SPRINT-004: Wallet is a separate model, not balance on User
**Decision**: `Wallet` is a standalone model with `@unique userId` — it is created on first charge, not eagerly.
**Reason**: Not every user will ever use the payment system. Eager wallet creation adds unnecessary rows. Lazy creation via `getOrCreate` in `WalletService` is cleaner.

### SPRINT-005: ZarinPal sandbox for development
**Decision**: `ZARINPAL_SANDBOX=true` routes to the ZarinPal sandbox endpoint.
**Reason**: No real money in development. The sandbox authority tokens are distinct from production. The config-gate follows the same pattern as Telegram.

### SPRINT-006: UserSettings uses @id = userId (1:1 table)
**Decision**: `user_settings.user_id` is both PK and FK — no surrogate id.
**Reason**: The settings are a 1:1 extension of User. No history needed. A missing row means "use defaults" — the service returns defaults without creating a row, settings are created lazily on first save.
