/**
 * Session configuration — NON-SECRET operational knobs only.
 *
 * Unlike the OTP pepper, session tokens need no server-side secret: a session
 * token is high-entropy (256 bits of CSPRNG) and is stored only as a SHA-256 hash,
 * so a leaked database cannot be reversed without brute-forcing the full token
 * space (infeasible). Therefore this file holds only the token lifetime, which is a
 * safe-to-log policy value with a conservative default.
 */

import { readInt } from './env';

export interface SessionPolicyConfig {
  /** Absolute lifetime of a session, in seconds, from creation to expiry. */
  readonly ttlSeconds: number;
  /** Number of random bytes in a raw session token (entropy). */
  readonly tokenBytes: number;
}

/**
 * Resolve the session policy from the environment, applying conservative defaults:
 * a 30-day absolute lifetime and a 32-byte (256-bit) token. Non-secret; safe to log.
 */
export function sessionPolicyConfig(): SessionPolicyConfig {
  return {
    ttlSeconds: readInt('SESSION_TTL_SECONDS', 60 * 60 * 24 * 30),
    tokenBytes: readInt('SESSION_TOKEN_BYTES', 32),
  };
}
