/**
 * Telegram channel configuration (Phase 9).
 *
 * All values are OPTIONAL: with an empty environment the channel is simply
 * DISABLED (no bot token → no outbound sends; no webhook secret → the webhook
 * rejects everything). This keeps the repository building and testing with every
 * integration variable empty (TESTING.md).
 *
 * SECURITY: `botToken` and `webhookSecret` are SECRETS — read here, never logged,
 * never surfaced in an error or response. Only `.env.example` placeholders are
 * committed.
 */

import { readString } from './env';

export interface TelegramConfig {
  /** Bot API token. Empty = outbound disabled (no-op sender). */
  readonly botToken: string;
  /**
   * Shared secret Telegram echoes in the `X-Telegram-Bot-Api-Secret-Token` header.
   * Empty = the webhook is disabled and rejects all requests.
   */
  readonly webhookSecret: string;
  /** Bot API base URL (overridable for tests/self-hosted). */
  readonly apiBaseUrl: string;
}

export function telegramConfig(): TelegramConfig {
  return {
    botToken: readString('TELEGRAM_BOT_TOKEN', ''),
    webhookSecret: readString('TELEGRAM_WEBHOOK_SECRET', ''),
    apiBaseUrl: readString('TELEGRAM_API_BASE_URL', 'https://api.telegram.org'),
  };
}

/** Whether the outbound Bot API sender should be active (a token is configured). */
export function telegramOutboundEnabled(config: TelegramConfig): boolean {
  return config.botToken.trim().length > 0;
}
