/** Default local development ports. Overridable through the environment. */
export const DEFAULT_PORTS = {
  api: 3001,
  web: 3000,
  admin: 3002,
  postgres: 5432,
  redis: 6379,
  minioApi: 9000,
  minioConsole: 9001,
} as const;

export type ServiceName = keyof typeof DEFAULT_PORTS;
