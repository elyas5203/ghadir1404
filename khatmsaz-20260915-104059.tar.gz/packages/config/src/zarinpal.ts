/**
 * ZarinPal payment gateway configuration (Sprint Phase 03).
 * Empty ZARINPAL_MERCHANT_ID → payment creation will fail with a clear error.
 * ZARINPAL_SANDBOX=true → uses ZarinPal sandbox (no real money).
 */

import { readString } from './env';

export interface ZarinpalConfig {
  readonly merchantId: string;
  readonly sandbox: boolean;
  readonly callbackBaseUrl: string;
}

export function zarinpalConfig(): ZarinpalConfig {
  return {
    merchantId: readString('ZARINPAL_MERCHANT_ID', ''),
    sandbox: readString('ZARINPAL_SANDBOX', 'true') === 'true',
    callbackBaseUrl: readString('BASE_URL', 'http://localhost:3000'),
  };
}
