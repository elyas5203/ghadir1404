/**
 * Database connection configuration.
 *
 * This module holds NO secret values and NO business logic. It reads and
 * validates the PostgreSQL connection configuration that already exists in
 * process.env, and fails fast with a clear message when it is malformed.
 *
 * Rules honoured here:
 *   - The connection string is NEVER included in any thrown error message or
 *     log. Only non-secret facts (which variable is missing, the protocol) are
 *     surfaced. See .claude/rules/security.md.
 *   - `DATABASE_URL` is the canonical input. For local development convenience
 *     it may instead be composed from the discrete POSTGRES_* variables that
 *     also drive the Docker Compose stack, so the same secret is not duplicated.
 */

export interface DatabaseConfig {
  /** PostgreSQL connection string (`postgresql://…`). */
  readonly url: string;
}

/** URL-encode a connection-string component (user, password, database name). */
function encodeComponent(value: string): string {
  return encodeURIComponent(value);
}

/**
 * Compose a PostgreSQL URL from the discrete POSTGRES_* variables.
 * Returns `undefined` when the required parts are not all present — this never
 * throws, so it is safe to call from tooling that does not need a live database
 * (for example `prisma generate`).
 */
function composeUrlFromParts(): string | undefined {
  const host = process.env.POSTGRES_HOST?.trim();
  const db = process.env.POSTGRES_DB?.trim();
  const user = process.env.POSTGRES_USER?.trim();
  const password = process.env.POSTGRES_PASSWORD;
  const port = process.env.POSTGRES_PORT?.trim() ?? '';

  if (!host || !db || !user || password === undefined || password.length === 0) {
    return undefined;
  }

  const portSegment = port.length > 0 ? `:${port}` : '';
  return (
    `postgresql://${encodeComponent(user)}:${encodeComponent(password)}` +
    `@${host}${portSegment}/${encodeComponent(db)}?schema=public`
  );
}

/**
 * Resolve the effective connection string WITHOUT throwing.
 * Prefers an explicit `DATABASE_URL`; otherwise composes one from POSTGRES_*.
 * Returns `undefined` when neither is available.
 */
export function resolveDatabaseUrl(): string | undefined {
  const explicit = process.env.DATABASE_URL?.trim();
  if (explicit && explicit.length > 0) return explicit;
  return composeUrlFromParts();
}

/**
 * Validate the SHAPE of a connection string. Throws a clear, secret-free error
 * when it is not a usable PostgreSQL URL. The offending value is never echoed.
 */
export function assertValidDatabaseUrl(url: string): void {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error(
      'Database configuration is invalid: the connection string is not a valid URL.',
    );
  }

  if (parsed.protocol !== 'postgres:' && parsed.protocol !== 'postgresql:') {
    throw new Error(
      `Database configuration is invalid: expected a "postgresql://" URL, received protocol "${parsed.protocol}".`,
    );
  }
  if (parsed.hostname.length === 0) {
    throw new Error('Database configuration is invalid: the connection string has no host.');
  }
  const database = parsed.pathname.replace(/^\//, '');
  if (database.length === 0) {
    throw new Error('Database configuration is invalid: the connection string has no database name.');
  }
}

/**
 * Return a validated PostgreSQL connection string, failing fast when the
 * configuration is missing or malformed. Use this at application startup and
 * wherever a live database connection is required.
 */
export function databaseUrl(): string {
  const url = resolveDatabaseUrl();
  if (!url) {
    throw new Error(
      'Database configuration is missing: set DATABASE_URL, or all of ' +
        'POSTGRES_HOST, POSTGRES_DB, POSTGRES_USER and POSTGRES_PASSWORD.',
    );
  }
  assertValidDatabaseUrl(url);
  return url;
}

/** Convenience wrapper returning the validated configuration object. */
export function databaseConfig(): DatabaseConfig {
  return { url: databaseUrl() };
}
