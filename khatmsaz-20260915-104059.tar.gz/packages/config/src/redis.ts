/**
 * Redis configuration for BullMQ notification queue (Sprint Phase 01).
 * Empty REDIS_URL → notification module uses no-op scheduler; app starts without Redis.
 */

import { readString } from './env';

export interface RedisConfig {
  readonly url: string;
}

export function redisConfig(): RedisConfig {
  return {
    url: readString('REDIS_URL', ''),
  };
}

export function redisEnabled(config: RedisConfig): boolean {
  return config.url.trim().length > 0;
}
