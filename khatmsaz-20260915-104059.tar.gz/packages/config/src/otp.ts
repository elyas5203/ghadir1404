/**
 * OTP and phone-verification configuration.
 *
 * This module holds NO secret VALUES in source and NO business rules beyond
 * reading and normalising values that already exist in process.env. It follows
 * the same shape as the database helper: read from the environment, apply safe
 * defaults, and fail fast (in production) when a required secret is absent.
 *
 * Rules honoured here (see .claude/rules/security.md):
 *   - The OTP keying secret (pepper) is NEVER written to source, NEVER logged,
 *     and NEVER echoed in an error message. Only the fact that it is missing is
 *     surfaced, never its value.
 *   - A six-digit OTP has low entropy, so codes are protected in storage by a
 *     server-side keyed HMAC (this pepper), not a bare fast hash. The secret is
 *     read here and injected into the hasher, keeping it testable.
 */

import { isProduction } from './env';
import { readInt } from './env';

/**
 * Development-only fallback pepper. It is NOT a production secret — it is a
 * clearly-marked local placeholder, exactly like `local_dev_only_change_me` for
 * the local database. In production `otpHmacSecret()` throws instead of using it,
 * so this constant can never protect real user codes.
 */
export const DEV_OTP_HMAC_SECRET = 'local_dev_only_change_me_otp_pepper';

/**
 * The keying secret (pepper) for OTP code hashing. Read from `OTP_HMAC_SECRET`.
 *
 * In production a missing/blank secret is a fatal misconfiguration and throws a
 * secret-free error. In development/test a well-known local placeholder is used
 * so the repository builds and its tests run with every integration variable
 * empty. The returned value is a secret: never log it.
 */
export function otpHmacSecret(): string {
  const raw = process.env.OTP_HMAC_SECRET?.trim();
  if (raw && raw.length > 0) return raw;
  if (isProduction()) {
    throw new Error('OTP configuration is missing: set OTP_HMAC_SECRET.');
  }
  return DEV_OTP_HMAC_SECRET;
}

/** Non-secret OTP policy knobs. All have safe defaults and are overridable. */
export interface OtpPolicyConfig {
  /** Number of decimal digits in a generated code. */
  readonly codeLength: number;
  /** Lifetime of a challenge, in seconds, from creation to expiry. */
  readonly ttlSeconds: number;
  /** Maximum number of wrong submissions before a challenge is exhausted. */
  readonly maxAttempts: number;
  /** Minimum seconds between two verification requests for the same target. */
  readonly resendCooldownSeconds: number;
}

/**
 * Resolve the OTP policy from the environment, applying conservative defaults.
 * These are non-secret operational limits, safe to log.
 */
export function otpPolicyConfig(): OtpPolicyConfig {
  return {
    codeLength: readInt('OTP_CODE_LENGTH', 6),
    ttlSeconds: readInt('OTP_TTL_SECONDS', 300),
    maxAttempts: readInt('OTP_MAX_ATTEMPTS', 5),
    resendCooldownSeconds: readInt('OTP_RESEND_COOLDOWN_SECONDS', 60),
  };
}

/** Default region used to interpret national-format phone numbers (ISO 3166-1 alpha-2). */
export function phoneDefaultRegion(): string {
  const raw = process.env.PHONE_DEFAULT_REGION?.trim();
  return raw && raw.length > 0 ? raw.toUpperCase() : 'IR';
}
