import { databaseUrl } from './database';

/** Deliberately strict: unset/unknown NODE_ENV must never enable dev credentials. */
export function localOtpEnabled(): boolean {
  return process.env.NODE_ENV === 'development' && process.env.KHATMSAZ_DEV_OTP === '1';
}

export function assertLocalDevelopment(): void {
  if (process.env.NODE_ENV !== 'development') {
    throw new Error('Local tooling requires NODE_ENV=development.');
  }
  const url = new URL(databaseUrl());
  if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname) || url.searchParams.has('host')) {
    throw new Error('Local tooling requires a loopback PostgreSQL database.');
  }
}
