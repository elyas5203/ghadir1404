/**
 * Non-secret environment helpers.
 *
 * This module deliberately contains NO secret values and NO business logic.
 * It only reads and normalises values that already exist in process.env.
 */

export type NodeEnvironment = 'development' | 'test' | 'production';

/** Reads an optional string variable, returning `fallback` when unset or blank. */
export function readString(name: string, fallback: string): string {
  const raw = process.env[name];
  if (raw === undefined) return fallback;
  const trimmed = raw.trim();
  return trimmed.length === 0 ? fallback : trimmed;
}

/** Reads an integer variable, throwing when the value is present but not numeric. */
export function readInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw.trim().length === 0) return fallback;
  const parsed = Number.parseInt(raw, 10);
  if (Number.isNaN(parsed)) {
    throw new Error(`Environment variable ${name} must be an integer, received "${raw}".`);
  }
  return parsed;
}

/** Reads a boolean variable. Accepts 1/true/yes/on (case-insensitive). */
export function readBoolean(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined || raw.trim().length === 0) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(raw.trim().toLowerCase());
}

/** Reads a comma-separated list, dropping blank entries. */
export function readList(name: string, fallback: readonly string[]): string[] {
  const raw = process.env[name];
  if (raw === undefined || raw.trim().length === 0) return [...fallback];
  return raw
    .split(',')
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
}

/** Current NODE_ENV, normalised. Unknown values fall back to 'development'. */
export function nodeEnvironment(): NodeEnvironment {
  const raw = readString('NODE_ENV', 'development').toLowerCase();
  if (raw === 'production' || raw === 'test') return raw;
  return 'development';
}

export function isProduction(): boolean {
  return nodeEnvironment() === 'production';
}
