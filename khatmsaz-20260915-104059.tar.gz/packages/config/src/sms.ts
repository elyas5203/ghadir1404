import { readString } from './env';

export interface SmsConfig {
  readonly provider: string;
  readonly kavenegarApiKey: string;
  readonly kavenegarSender: string;
}

export function smsConfig(): SmsConfig {
  return {
    provider: readString('SMS_PROVIDER', 'noop'),
    kavenegarApiKey: readString('KAVENEGAR_API_KEY', ''),
    kavenegarSender: readString('KAVENEGAR_SENDER', '10004346'),
  };
}

export function smsEnabled(config: SmsConfig): boolean {
  return config.provider !== 'noop' && config.kavenegarApiKey.length > 0;
}
