/**
 * Bale channel configuration (Sprint Phase 04).
 * Mirrors the Telegram config pattern: empty token → channel disabled (no-op sender).
 *
 * SECURITY: botToken and webhookSecret are SECRETS — read here, never logged.
 */

import { readString } from './env';

export interface BaleConfig {
  /** Bale Bot API token. Empty = outbound disabled. */
  readonly botToken: string;
  /** Shared webhook secret header value. Empty = webhook disabled. */
  readonly webhookSecret: string;
  /** Bale Bot API base URL (default: https://tapi.bale.ai). */
  readonly apiBaseUrl: string;
}

export function baleConfig(): BaleConfig {
  return {
    botToken: readString('BALE_BOT_TOKEN', ''),
    webhookSecret: readString('BALE_WEBHOOK_SECRET', ''),
    apiBaseUrl: readString('BALE_API_BASE_URL', 'https://tapi.bale.ai'),
  };
}

export function baleOutboundEnabled(config: BaleConfig): boolean {
  return config.botToken.trim().length > 0;
}
