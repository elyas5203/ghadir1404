/**
 * Kernel-level errors. Framework- and Prisma-independent, like the whole kernel.
 */

/**
 * A value that must be a canonical identifier (UUIDv7, RFC 9562) was not one.
 * This is a KERNEL invariant, not a capability-specific one: every aggregate id
 * in KhatmSaz is a UUIDv7, so the check and its error belong to the shared kernel
 * (DEC-0039). `label` names the field that failed, never a secret or PII value.
 */
export class InvalidUuidV7Error extends Error {
  constructor(label: string) {
    super(`Invalid identifier: ${label} must be a UUIDv7.`);
    this.name = 'InvalidUuidV7Error';
  }
}
