/**
 * The transaction boundary — a framework-free Unit of Work abstraction (DEC-0044).
 *
 * These live in the kernel (not in a capability or in infrastructure) so that both
 * application use-cases and domain repository ports can reference them without
 * importing infrastructure or any persistence-tool type. The Prisma-backed
 * implementation lives in the API's infrastructure layer and is bound to
 * {@link UNIT_OF_WORK}.
 */

/** DI token for the Prisma-free {@link UnitOfWork}. */
export const UNIT_OF_WORK = Symbol('UNIT_OF_WORK');

/**
 * An OPAQUE handle to an in-progress database transaction. Application code
 * receives it from the Unit of Work and passes it straight back into
 * transaction-aware repositories — `method(..., tx?: TransactionContext)`; ONLY
 * the infrastructure layer unwraps it into a concrete transaction client. It is
 * branded so it cannot be confused with an arbitrary object and carries no
 * behaviour of its own.
 */
export interface TransactionContext {
  /** @internal opaque brand — never read this. */
  readonly __transaction: unique symbol;
}

/**
 * The transaction boundary. A use-case calls {@link UnitOfWork.run} to execute
 * several repository operations atomically without importing Prisma: if `work`
 * throws, the transaction rolls back and the error propagates unchanged; if it
 * resolves, the transaction commits and its value is returned. `work` receives an
 * opaque {@link TransactionContext} to hand to transaction-aware repositories.
 */
export interface UnitOfWork {
  run<T>(work: (tx: TransactionContext) => Promise<T>): Promise<T>;
}
