/**
 * Canonical identifier primitives for the whole platform: a UUIDv7 (RFC 9562),
 * generated in application code and stored as a native PostgreSQL `uuid`.
 *
 * These live in the shared kernel (DEC-0039) rather than any one capability,
 * because every aggregate id in KhatmSaz — User, PlatformIdentity, PhoneClaim,
 * OtpChallenge, and every future aggregate — is a UUIDv7. Capabilities depend on
 * the kernel, never on each other, so this is the one place id generation and
 * validation are defined. Time-ordered v7 keeps primary keys roughly
 * insertion-ordered (index-friendly) while staying opaque and non-guessable; a
 * canonical id is never a phone number, platform account, username or email
 * (DEC-0010, DEC-0032).
 */

import { v7 as uuidV7, validate as uuidValidate, version as uuidVersion } from 'uuid';
import { InvalidUuidV7Error } from './errors';

/** Generate a fresh canonical identifier (UUIDv7). */
export function newUuidV7(): string {
  return uuidV7();
}

/** True when `value` is a syntactically valid UUID of version 7. */
export function isUuidV7(value: string): boolean {
  return uuidValidate(value) && uuidVersion(value) === 7;
}

/** Throw {@link InvalidUuidV7Error} unless `value` is a UUIDv7. */
export function assertUuidV7(value: string, label: string): void {
  if (!isUuidV7(value)) {
    throw new InvalidUuidV7Error(label);
  }
}
