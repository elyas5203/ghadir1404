/**
 * @khatmsaz/kernel — the framework-independent domain kernel.
 *
 * It holds only cross-capability domain primitives that every capability shares
 * (today: canonical UUIDv7 identifiers). It must never depend on NestJS, Next.js,
 * React, a database driver, an HTTP client, or any capability module. Capabilities
 * depend on the kernel; the kernel depends on nothing in the app (DEC-0039).
 */

export * from './errors';
export * from './uuid';
export * from './transaction';
