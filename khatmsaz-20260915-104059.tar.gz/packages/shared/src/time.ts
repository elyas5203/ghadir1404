/**
 * Time helpers.
 *
 * Every Khatm carries its own canonical timezone for day boundaries and
 * deadlines (see DECISIONS.md, DEC-0016). These helpers stay deliberately
 * minimal until the scheduling engine is designed.
 */

/** Milliseconds in one second. */
export const SECOND_MS = 1_000;
/** Milliseconds in one minute. */
export const MINUTE_MS = 60 * SECOND_MS;
/** Milliseconds in one hour. */
export const HOUR_MS = 60 * MINUTE_MS;
/** Milliseconds in one day (nominal — not DST-aware). */
export const DAY_MS = 24 * HOUR_MS;

/** Returns the current instant as an ISO-8601 UTC string. */
export function nowIso(clock: () => Date = () => new Date()): string {
  return clock().toISOString();
}

/** Narrow check for an IANA timezone identifier such as "Asia/Tehran". */
export function isIanaTimeZone(value: string): boolean {
  if (value.trim().length === 0) return false;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: value });
    return true;
  } catch {
    return false;
  }
}
