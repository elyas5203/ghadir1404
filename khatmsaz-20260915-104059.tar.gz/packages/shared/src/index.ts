export * from './result';
export * from './time';
export * from './quran';
