/**
 * Quran edition registry — static, never hardcoded page counts.
 *
 * An "edition" defines the physical print format of the Quran; page counts vary
 * between prints. The total page count drives PAGE_BASED (QURAN_PAGE) allocation.
 * New editions are added here as data; no code change anywhere else is needed.
 * (QURAN-001, DEC-0076)
 */

export interface QuranEdition {
  /** Stable identifier — stored in the khatms table as `quran_edition_id`. */
  readonly id: string;
  /** Persian display name. */
  readonly nameFa: string;
  /** Total page count for this edition. */
  readonly totalPages: number;
}

/**
 * All supported Quran editions.
 * Add new entries here to expose them product-wide.
 */
export const QURAN_EDITIONS: readonly QuranEdition[] = [
  {
    id: 'MADINA_HAFS',
    nameFa: 'مصحف مدینه (حفص) — ۶۰۴ صفحه',
    totalPages: 604,
  },
  {
    id: 'IRAN_SIMPLE',
    nameFa: 'مصحف رایج ایران — ۵۶۰ صفحه',
    totalPages: 560,
  },
  {
    id: 'IRAN_POCKET',
    nameFa: 'مصحف جیبی ایران — ۲۸۶ صفحه',
    totalPages: 286,
  },
];

/** Map keyed by edition id for fast O(1) lookup. */
export const QURAN_EDITION_MAP: ReadonlyMap<string, QuranEdition> = new Map(
  QURAN_EDITIONS.map((e) => [e.id, e]),
);

/** Find an edition by its stable id, or `null` when not found. */
export function findQuranEdition(id: string): QuranEdition | null {
  return QURAN_EDITION_MAP.get(id) ?? null;
}
