/**
 * Static Quran surah registry — all 114 chapters with Persian display names.
 *
 * Used by QURAN_SURAH (SURAH_REPETITION) mode: the creator selects one surah
 * and sets a repetition target. (QURAN-001, DEC-0076)
 */

export interface Surah {
  /** Surah number 1–114. */
  readonly number: number;
  /** Arabic name transliterated in Persian script. */
  readonly nameFa: string;
}

export const SURAHS: readonly Surah[] = [
  { number: 1, nameFa: 'حمد (فاتحه)' },
  { number: 2, nameFa: 'بقره' },
  { number: 3, nameFa: 'آل عمران' },
  { number: 4, nameFa: 'نساء' },
  { number: 5, nameFa: 'مائده' },
  { number: 6, nameFa: 'انعام' },
  { number: 7, nameFa: 'اعراف' },
  { number: 8, nameFa: 'انفال' },
  { number: 9, nameFa: 'توبه' },
  { number: 10, nameFa: 'یونس' },
  { number: 11, nameFa: 'هود' },
  { number: 12, nameFa: 'یوسف' },
  { number: 13, nameFa: 'رعد' },
  { number: 14, nameFa: 'ابراهیم' },
  { number: 15, nameFa: 'حجر' },
  { number: 16, nameFa: 'نحل' },
  { number: 17, nameFa: 'اسراء (بنی‌اسرائیل)' },
  { number: 18, nameFa: 'کهف' },
  { number: 19, nameFa: 'مریم' },
  { number: 20, nameFa: 'طه' },
  { number: 21, nameFa: 'انبیاء' },
  { number: 22, nameFa: 'حج' },
  { number: 23, nameFa: 'مؤمنون' },
  { number: 24, nameFa: 'نور' },
  { number: 25, nameFa: 'فرقان' },
  { number: 26, nameFa: 'شعراء' },
  { number: 27, nameFa: 'نمل' },
  { number: 28, nameFa: 'قصص' },
  { number: 29, nameFa: 'عنکبوت' },
  { number: 30, nameFa: 'روم' },
  { number: 31, nameFa: 'لقمان' },
  { number: 32, nameFa: 'سجده' },
  { number: 33, nameFa: 'احزاب' },
  { number: 34, nameFa: 'سبأ' },
  { number: 35, nameFa: 'فاطر' },
  { number: 36, nameFa: 'یس' },
  { number: 37, nameFa: 'صافات' },
  { number: 38, nameFa: 'ص' },
  { number: 39, nameFa: 'زمر' },
  { number: 40, nameFa: 'غافر (مؤمن)' },
  { number: 41, nameFa: 'فصلت (حم سجده)' },
  { number: 42, nameFa: 'شوری' },
  { number: 43, nameFa: 'زخرف' },
  { number: 44, nameFa: 'دخان' },
  { number: 45, nameFa: 'جاثیه' },
  { number: 46, nameFa: 'احقاف' },
  { number: 47, nameFa: 'محمد' },
  { number: 48, nameFa: 'فتح' },
  { number: 49, nameFa: 'حجرات' },
  { number: 50, nameFa: 'ق' },
  { number: 51, nameFa: 'ذاریات' },
  { number: 52, nameFa: 'طور' },
  { number: 53, nameFa: 'نجم' },
  { number: 54, nameFa: 'قمر' },
  { number: 55, nameFa: 'رحمن' },
  { number: 56, nameFa: 'واقعه' },
  { number: 57, nameFa: 'حدید' },
  { number: 58, nameFa: 'مجادله' },
  { number: 59, nameFa: 'حشر' },
  { number: 60, nameFa: 'ممتحنه' },
  { number: 61, nameFa: 'صف' },
  { number: 62, nameFa: 'جمعه' },
  { number: 63, nameFa: 'منافقون' },
  { number: 64, nameFa: 'تغابن' },
  { number: 65, nameFa: 'طلاق' },
  { number: 66, nameFa: 'تحریم' },
  { number: 67, nameFa: 'ملک (تبارک)' },
  { number: 68, nameFa: 'قلم' },
  { number: 69, nameFa: 'حاقه' },
  { number: 70, nameFa: 'معارج' },
  { number: 71, nameFa: 'نوح' },
  { number: 72, nameFa: 'جن' },
  { number: 73, nameFa: 'مزمل' },
  { number: 74, nameFa: 'مدثر' },
  { number: 75, nameFa: 'قیامه' },
  { number: 76, nameFa: 'انسان (دهر)' },
  { number: 77, nameFa: 'مرسلات' },
  { number: 78, nameFa: 'نبأ (عم)' },
  { number: 79, nameFa: 'نازعات' },
  { number: 80, nameFa: 'عبس' },
  { number: 81, nameFa: 'تکویر' },
  { number: 82, nameFa: 'انفطار' },
  { number: 83, nameFa: 'مطففین' },
  { number: 84, nameFa: 'انشقاق' },
  { number: 85, nameFa: 'بروج' },
  { number: 86, nameFa: 'طارق' },
  { number: 87, nameFa: 'اعلی' },
  { number: 88, nameFa: 'غاشیه' },
  { number: 89, nameFa: 'فجر' },
  { number: 90, nameFa: 'بلد' },
  { number: 91, nameFa: 'شمس' },
  { number: 92, nameFa: 'لیل' },
  { number: 93, nameFa: 'ضحی' },
  { number: 94, nameFa: 'انشراح (شرح)' },
  { number: 95, nameFa: 'تین' },
  { number: 96, nameFa: 'علق (اقرأ)' },
  { number: 97, nameFa: 'قدر' },
  { number: 98, nameFa: 'بینه' },
  { number: 99, nameFa: 'زلزله' },
  { number: 100, nameFa: 'عادیات' },
  { number: 101, nameFa: 'قارعه' },
  { number: 102, nameFa: 'تکاثر' },
  { number: 103, nameFa: 'عصر' },
  { number: 104, nameFa: 'همزه' },
  { number: 105, nameFa: 'فیل' },
  { number: 106, nameFa: 'قریش' },
  { number: 107, nameFa: 'ماعون' },
  { number: 108, nameFa: 'کوثر' },
  { number: 109, nameFa: 'کافرون' },
  { number: 110, nameFa: 'نصر' },
  { number: 111, nameFa: 'مسد (لهب)' },
  { number: 112, nameFa: 'اخلاص (توحید)' },
  { number: 113, nameFa: 'فلق' },
  { number: 114, nameFa: 'ناس' },
];

/** Map keyed by surah number for fast O(1) lookup. */
export const SURAH_MAP: ReadonlyMap<number, Surah> = new Map(SURAHS.map((s) => [s.number, s]));

/** Find a surah by its number (1–114), or `null` when out of range. */
export function findSurah(number: number): Surah | null {
  return SURAH_MAP.get(number) ?? null;
}

/** Validate that a surah number is in 1–114 range. */
export function isValidSurahNumber(n: unknown): n is number {
  return typeof n === 'number' && Number.isInteger(n) && n >= 1 && n <= 114;
}
