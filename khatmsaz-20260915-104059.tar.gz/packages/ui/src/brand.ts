/**
 * Temporary brand constants.
 *
 * The final Khedmatgozaran logo and official brand assets have NOT been
 * provided yet. Everything here is a restrained placeholder chosen to be
 * calm and neutral, and is expected to be replaced once real assets arrive.
 * No asset has been copied from any existing website.
 */
export const BRAND = {
  productNameFa: 'ختم‌ساز',
  productNameEn: 'KhatmSaz',
  organisationFa: 'خدمتگزاران',
  organisationEn: 'Khedmatgozaran',
} as const;
