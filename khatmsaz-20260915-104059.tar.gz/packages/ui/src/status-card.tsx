import type { ReactNode } from 'react';

export type StatusTone = 'neutral' | 'success' | 'warning';

export interface StatusCardProps {
  /** Short Persian label describing what the card reports. */
  readonly label: string;
  /** The value shown prominently. */
  readonly value: string;
  /** Optional supporting line. Keep it short — this is user-facing copy. */
  readonly hint?: string;
  readonly tone?: StatusTone;
  readonly children?: ReactNode;
}

const TONE_COLOR: Record<StatusTone, string> = {
  neutral: 'var(--ks-color-text-subtle)',
  success: 'var(--ks-color-success)',
  warning: 'var(--ks-color-warning)',
};

/**
 * A single calm status tile. Intentionally minimal: the bootstrap shell only
 * needs to prove that tokens, RTL and typography work end to end.
 */
export function StatusCard({
  label,
  value,
  hint,
  tone = 'neutral',
  children,
}: StatusCardProps): ReactNode {
  return (
    <section
      style={{
        background: 'var(--ks-color-surface)',
        border: '1px solid var(--ks-color-border)',
        borderRadius: 'var(--ks-radius-md)',
        boxShadow: 'var(--ks-shadow-sm)',
        padding: 'var(--ks-space-6)',
        display: 'grid',
        gap: 'var(--ks-space-2)',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--ks-space-2)',
          color: 'var(--ks-color-text-subtle)',
          fontSize: 'var(--ks-text-sm)',
        }}
      >
        <span
          aria-hidden="true"
          style={{
            inlineSize: '8px',
            blockSize: '8px',
            borderRadius: '50%',
            background: TONE_COLOR[tone],
            flexShrink: 0,
          }}
        />
        {label}
      </div>
      <div
        className="ks-numeric"
        style={{
          fontSize: 'var(--ks-text-lg)',
          lineHeight: 'var(--ks-leading-tight)',
          color: 'var(--ks-color-text)',
        }}
      >
        {value}
      </div>
      {hint ? (
        <p style={{ margin: 0, fontSize: 'var(--ks-text-sm)', color: 'var(--ks-color-text-muted)' }}>
          {hint}
        </p>
      ) : null}
      {children}
    </section>
  );
}
