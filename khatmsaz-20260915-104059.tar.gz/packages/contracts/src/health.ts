/**
 * Health contract shared between the API and its consumers.
 *
 * Contracts describe the SHAPE of data crossing a boundary. They must never
 * contain business rules, validation policy, or persistence concerns.
 */

export type HealthStatus = 'ok' | 'degraded';

export interface HealthResponse {
  /** Overall service status. */
  readonly status: HealthStatus;
  /** Logical service name. */
  readonly service: string;
  /** Application version as published by the service. */
  readonly version: string;
  /** ISO-8601 UTC timestamp of the response. */
  readonly timestamp: string;
  /** Whole seconds the process has been running. */
  readonly uptimeSeconds: number;
}
