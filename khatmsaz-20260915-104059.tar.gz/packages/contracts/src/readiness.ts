/**
 * Readiness contract shared between the API and its consumers.
 *
 * Contracts describe the SHAPE of data crossing a boundary. They must never
 * contain business rules, validation policy, or persistence concerns.
 *
 * Readiness answers "can this instance serve requests that need its
 * dependencies?" — distinct from liveness (see ./health.ts), which only answers
 * "is the process running?". The response is deliberately small and stable and
 * must never expose configuration, connection strings, or dependency versions.
 */

export type ReadinessStatus = 'ready' | 'not_ready';

/** Status of a single dependency the service needs in order to be ready. */
export type DependencyStatus = 'up' | 'down';

export interface ReadinessResponse {
  /** Overall readiness. `not_ready` maps to HTTP 503. */
  readonly status: ReadinessStatus;
  /** Per-dependency results. Extend this as new required dependencies appear. */
  readonly checks: {
    /** PostgreSQL connectivity. */
    readonly database: DependencyStatus;
  };
  /** ISO-8601 UTC timestamp of the response. */
  readonly timestamp: string;
}
