/**
 * Invitation & participant transport contracts (Phase 11, DEC-0068) — shapes only.
 */

export type InvitationStatusDto = 'CREATED' | 'ACCEPTED' | 'EXPIRED' | 'CANCELLED';

/** An invitation as shown to the khatm's owner (management view). */
export interface InvitationSummary {
  readonly invitationId: string;
  readonly khatmId: string;
  readonly status: InvitationStatusDto;
  /** ISO-8601 UTC timestamps. */
  readonly createdAt: string;
  readonly expiresAt: string;
  readonly acceptedAt: string | null;
}

/** POST /api/khatms/:id/invitations — the raw token is returned ONCE (the invite link). */
export interface CreateInvitationResponse {
  readonly invitationId: string;
  readonly token: string;
  readonly expiresAt: string;
}

/** GET /api/khatms/:id/invitations */
export interface KhatmInvitationsResponse {
  readonly invitations: readonly InvitationSummary[];
}

/** POST /api/invitations/accept */
export interface AcceptInvitationRequest {
  readonly token: string;
}

export interface AcceptInvitationResponse {
  readonly khatmId: string;
  readonly participationId: string | null;
}

/** A participant's own portion of a khatm (participant view). */
export interface PortionSummary {
  readonly portionId: string;
  readonly sequence: number;
  readonly unitKind: 'POSITIONAL' | 'QUANTITY';
  readonly unitStart: number | null;
  readonly unitEnd: number | null;
  readonly quantity: number | null;
  readonly status: 'OPEN' | 'ASSIGNED' | 'COMPLETED';
}

/** GET /api/khatms/:id/my-portions */
export interface MyPortionsResponse {
  readonly portions: readonly PortionSummary[];
}
