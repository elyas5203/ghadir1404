/**
 * Authentication transport contracts (Phase 6, DEC-0059/0060) — shapes only.
 *
 * A session is created by proving a phone number over OTP. On success the raw
 * session token is returned EXACTLY ONCE, here; it is never returned again and is
 * stored server-side only as a hash. Clients send it back as `Authorization:
 * Bearer <token>`.
 */

/**
 * POST /api/auth/login — verify a phone (OTP) and, on success, mint a session. The
 * phone model is user-scoped, so the `userId` whose claim is verified is supplied;
 * the `code` is the credential (delivered out-of-band).
 */
export interface PhoneLoginRequest {
  readonly userId: string;
  readonly phone: string;
  readonly code: string;
}

/** A minted session — the raw `token` is shown once and never again. */
export interface SessionResponse {
  readonly token: string;
  readonly sessionId: string;
  /** ISO-8601 UTC expiry. */
  readonly expiresAt: string;
}

/**
 * The login outcome. VERIFIED/ALREADY_VERIFIED carry a session; MERGE_REQUIRED does
 * not (the number belongs to another account — route to the account-merge flow).
 */
export type PhoneLoginResponse =
  | ({ readonly outcome: 'VERIFIED' | 'ALREADY_VERIFIED' } & SessionResponse)
  | { readonly outcome: 'MERGE_REQUIRED' };

/**
 * POST /api/auth/request-otp — issue (or re-issue) an OTP for a phone. Pre-auth, part
 * of the login flow; the phone model is user-scoped so `userId` identifies whose
 * claim is being verified. Delivery is out-of-band (no real SMS provider yet).
 */
export interface RequestOtpRequest {
  readonly userId: string;
  readonly phone: string;
}

export interface RequestOtpResponse {
  /** The canonical E.164 the code was issued for (never the code itself). */
  readonly e164: string;
}

/** POST /api/auth/phone/request — phone-first login step 1 (issue an OTP). */
export interface PhoneLoginStartRequest {
  readonly phone: string;
}

/** POST /api/auth/phone/verify — phone-first login step 2 (verify + create session). */
export interface PhoneVerifyRequest {
  readonly phone: string;
  readonly code: string;
}

/**
 * Response to a successful phone-first verify. The raw session token is delivered
 * ONLY as an httpOnly cookie (DEC-0067) and is deliberately NOT in this body, so it
 * never reaches frontend JavaScript.
 */
export interface PhoneSessionResponse {
  readonly userId: string;
  readonly sessionId: string;
  /** ISO-8601 UTC expiry. */
  readonly expiresAt: string;
  /** True when this login created the account. */
  readonly isNewUser: boolean;
}

/**
 * GET /api/me — the authenticated principal and its authorization state, for the UI
 * to render itself. The UI must treat this as a hint only — the backend re-checks
 * every action (DEC-0061).
 */
export interface MeResponse {
  readonly userId: string;
  /** Whether the user currently holds the CREATOR capability. */
  readonly isCreator: boolean;
  /** The user's chosen display name, or null when unset (Phase 14, DEC-0073). */
  readonly displayName: string | null;
  /** The user's platform role (Phase 06). */
  readonly role: 'USER' | 'SUPER_ADMIN';
}

/**
 * POST /api/me/become-creator — idempotently grant the CREATOR capability to the
 * authenticated user (DEC-0070). Every authenticated user may become a creator in
 * the MVP — no approval flow.
 */
export interface BecomeCreatorResponse {
  readonly isCreator: true;
}

/** PUT /api/me/profile — update the user's display name. */
export interface UpdateProfileRequest {
  /** Max 64 characters. Null or empty string clears the name. */
  readonly displayName?: string | null;
}

/** Response to a successful profile update. */
export interface ProfileResponse {
  readonly displayName: string | null;
}
