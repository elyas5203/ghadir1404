# KhatmSaz — ختم‌ساز

Persian-first platform for organising group Khatms, under the خدمتگزاران
(Khedmatgozaran) brand.

**Phase 1 — bootstrap.** No business features are implemented. The repository
contains a runnable skeleton: an API with a health endpoint and two Persian RTL
shells.

> ⚠️ **Nothing here has been installed, built or tested yet.** See
> `docs/ai/KNOWN_ISSUES.md` (KI-0001). Run the validation gate below first.

## Requirements

- **Node.js 24 LTS** (not Node 26 Current) — `.nvmrc` pins `24`
- npm 10+
- Docker Desktop with WSL 2 integration, for the local infrastructure (optional
  in Phase 1 — the applications do not use it yet)

`engine-strict=true` is set, so npm refuses to install on the wrong major.

## First run

```bash
cd /home/elyas/KhatmSaz     # WSL-native authoritative working copy
cp .env.example .env        # skip if .env already exists
npm install
```

## Everyday commands

| Command                | What it does                                        |
| ---------------------- | --------------------------------------------------- |
| `npm run dev`          | Builds shared packages, then runs API + web + admin  |
| `npm run dev:api`      | API only                                             |
| `npm run dev:web`      | Web app only                                         |
| `npm run dev:admin`    | Admin app only                                       |
| `npm run build`        | Builds packages, then all three applications         |
| `npm run lint`         | ESLint across every workspace                        |
| `npm run typecheck`    | `tsc --noEmit` across every workspace                |
| `npm test`             | Jest (API)                                           |
| `npm run format`       | Prettier write                                       |
| `npm run clean`        | Removes build output                                 |
| `npm run infra:config` | Validates the compose file (no Docker daemon needed) |
| `npm run infra:up`     | Starts PostgreSQL, Redis, MinIO                      |
| `npm run infra:down`   | Stops them, keeping data                             |

## Local URLs

| Surface        | URL                            |
| -------------- | ------------------------------ |
| Web app        | http://localhost:3000          |
| API            | http://localhost:3001          |
| API health     | http://localhost:3001/health   |
| Admin          | http://localhost:3002          |
| MinIO console  | http://localhost:9001          |

Check the API directly:

```bash
curl http://localhost:3001/health
```

## Validation gate

Run all four before considering any change complete:

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

## Layout

```
apps/api        NestJS backend (modular monolith)
apps/web        Next.js participant + creator dashboard
apps/admin      Next.js administration interface
packages/config non-secret configuration helpers
packages/shared framework-independent utilities
packages/ui     design tokens and UI primitives
packages/contracts  DTO / API / event shapes
infra/docker    local PostgreSQL, Redis, MinIO
docs/ai         long-term project memory — start with PROJECT_STATE.md
.claude/rules   rules for coding agents
```

## Secrets

`.env` is never committed. Only `.env.example` is tracked, and every value in it
is a local development placeholder. Telegram, Bale, SMS and payment variables
ship blank on purpose — the repository must build and test without them.

## Working on Windows + WSL

The authoritative working copy lives on the WSL-native filesystem at
`/home/elyas/KhatmSaz` (ext4). An older Windows-mounted copy may remain at
`/mnt/z/KhatmSaz` (`Z:\KhatmSaz` on Windows) — it is a stale backup only; do not
edit it. Container data never touches the project path — Docker named volumes are
used instead (`docs/ai/DEBUGGING.md`, DBG-0002).

## For coding agents

Read `CLAUDE.md`, then `docs/ai/PROJECT_STATE.md`.
