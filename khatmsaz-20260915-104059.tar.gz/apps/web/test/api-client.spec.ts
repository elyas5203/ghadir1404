import { apiRequest } from '../src/lib/api-client';
import { ApiError } from '../src/lib/api-error';

type FetchArgs = [string, RequestInit];
function mockFetch(status: number, body: string): jest.Mock {
  const fn = jest.fn(async () =>
    ({
      ok: status >= 200 && status < 300,
      status,
      text: async () => body,
    }) as unknown as Response,
  );
  (globalThis as { fetch?: unknown }).fetch = fn;
  return fn;
}

describe('apiRequest', () => {
  afterEach(() => {
    delete (globalThis as { fetch?: unknown }).fetch;
  });

  it('sends the JSON body with credentials (cookie), and parses the response', async () => {
    const fetchMock = mockFetch(200, JSON.stringify({ ok: true }));
    const result = await apiRequest<{ ok: boolean }>('/api/thing', {
      method: 'POST',
      body: { a: 1 },
    });
    expect(result).toEqual({ ok: true });
    const [, init] = fetchMock.mock.calls[0] as FetchArgs;
    expect(init.credentials).toBe('include'); // session rides an httpOnly cookie (DEC-0067)
    expect((init.headers as Record<string, string>)['Content-Type']).toBe('application/json');
    expect(init.body).toBe(JSON.stringify({ a: 1 }));
  });

  it('never sets an Authorization header (no client-side token)', async () => {
    const fetchMock = mockFetch(200, '{}');
    await apiRequest('/api/open');
    const [, init] = fetchMock.mock.calls[0] as FetchArgs;
    expect((init.headers as Record<string, string>).Authorization).toBeUndefined();
    expect(init.credentials).toBe('include');
  });

  it('returns undefined for 204 without parsing', async () => {
    mockFetch(204, '');
    await expect(apiRequest('/api/thing', { method: 'POST' })).resolves.toBeUndefined();
  });

  it('throws a typed ApiError on a non-2xx envelope', async () => {
    mockFetch(403, JSON.stringify({ error: { code: 'CapabilityRequiredError', message: 'nope' } }));
    await expect(apiRequest('/api/khatms', { method: 'POST' })).rejects.toMatchObject({
      status: 403,
      code: 'CapabilityRequiredError',
    });
    await expect(apiRequest('/api/khatms', { method: 'POST' })).rejects.toBeInstanceOf(ApiError);
  });
});
