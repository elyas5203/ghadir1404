import { ApiError, parseErrorBody } from '../src/lib/api-error';

describe('parseErrorBody', () => {
  it('maps the backend envelope to a typed ApiError', () => {
    const err = parseErrorBody(403, { error: { code: 'ResourceOwnershipError', message: 'no' } });
    expect(err).toBeInstanceOf(ApiError);
    expect(err.status).toBe(403);
    expect(err.code).toBe('ResourceOwnershipError');
    expect(err.message).toBe('no');
    expect(err.isForbidden).toBe(true);
    expect(err.isUnauthenticated).toBe(false);
  });

  it('flags 401 as unauthenticated (distinct from 403)', () => {
    const err = parseErrorBody(401, { error: { code: 'HTTP_401', message: 'x' } });
    expect(err.isUnauthenticated).toBe(true);
    expect(err.isForbidden).toBe(false);
  });

  it('falls back safely when the body is not an envelope', () => {
    const err = parseErrorBody(500, 'boom');
    expect(err.code).toBe('HTTP_500');
    expect(err.message).not.toContain('boom');
  });
});
