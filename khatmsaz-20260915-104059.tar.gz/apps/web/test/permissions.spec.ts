import { canCreateKhatm, shouldRedirectToLogin } from '../src/lib/permissions';

describe('canCreateKhatm (UI gating only — backend re-authorizes)', () => {
  it('is true only for a user holding CREATOR', () => {
    expect(canCreateKhatm({ userId: 'u', isCreator: true, displayName: null, role: 'USER' })).toBe(true);
  });
  it('is false for a non-creator or missing user', () => {
    expect(canCreateKhatm({ userId: 'u', isCreator: false, displayName: null, role: 'USER' })).toBe(false);
    expect(canCreateKhatm(null)).toBe(false);
  });
});

describe('shouldRedirectToLogin', () => {
  it('redirects only an anonymous visitor', () => {
    expect(shouldRedirectToLogin('anonymous')).toBe(true);
    expect(shouldRedirectToLogin('loading')).toBe(false);
    expect(shouldRedirectToLogin('authenticated')).toBe(false);
  });
});
