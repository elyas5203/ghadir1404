/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Workspace packages ship TypeScript source and are compiled by Next.
  transpilePackages: ['@khatmsaz/ui'],
  // Do not advertise the framework to the public.
  poweredByHeader: false,
  // Produce a standalone server bundle for Docker deployment (Sprint 3).
  output: 'standalone',
};

export default nextConfig;
