/**
 * Jest for the web app's pure client logic (API client, error mapping, permission
 * gating). Tests live in `test/` (outside `src`, so `eslint src` and the Next build
 * ignore them) and run in a node environment — no jsdom/React DOM harness. The
 * ts-jest transform overrides the module system to CommonJS for the test run, the
 * same pattern the API workspace uses.
 */
module.exports = {
  rootDir: '.',
  testMatch: ['<rootDir>/test/**/*.spec.ts'],
  testEnvironment: 'node',
  moduleNameMapper: { '^(\\.{1,2}/.*)\\.js$': '$1' },
  transform: {
    '^.+\\.ts$': [
      'ts-jest',
      { tsconfig: { module: 'CommonJS', moduleResolution: 'Node', jsx: 'react-jsx', esModuleInterop: true } },
    ],
  },
};
