'use client';

import { useCallback, useEffect, useState } from 'react';
import { ApiError } from '../../../lib/api-error';
import { useAuth } from '../../../lib/auth-context';

interface CustomerRow {
  id: string;
  displayName: string | null;
  role: string;
  status: string;
  createdAt: string;
}

const STATUS_FA: Record<string, string> = {
  ACTIVE: 'فعال',
  MERGED: 'ادغام‌شده',
  SUSPENDED: 'معلق',
};

const ROLE_FA: Record<string, string> = {
  USER: 'کاربر',
  SUPER_ADMIN: 'مدیر ارشد',
};

export default function CustomersPage() {
  const { authed } = useAuth();
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const limit = 50;

  const load = useCallback(async (off: number) => {
    setError(null);
    setLoading(true);
    try {
      const data = await authed<CustomerRow[]>(`/api/admin/customers?limit=${limit}&offset=${off}`);
      setRows(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'بارگذاری ناموفق بود.');
    } finally {
      setLoading(false);
    }
  }, [authed]);

  useEffect(() => {
    void load(offset);
  }, [load, offset]);

  return (
    <section className="panel">
      <div className="section-header">
        <h2>کاربران</h2>
      </div>

      {error ? (
        <div className="alert" role="alert">
          <span>{error}</span>
          <button className="btn btn-sm" type="button" onClick={() => void load(offset)} style={{ marginInlineStart: 'var(--ks-space-3)' }}>
            تلاش مجدد
          </button>
        </div>
      ) : loading ? (
        <div className="stack">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton" style={{ blockSize: '3rem', borderRadius: 'var(--ks-radius-sm)' }} />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <p className="ks-muted">کاربری یافت نشد.</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ inlineSize: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ borderBlockEnd: '1px solid var(--ks-border)' }}>
                <Th>نام</Th>
                <Th>نقش</Th>
                <Th>وضعیت</Th>
                <Th>تاریخ ثبت</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.id}
                  style={{ borderBlockEnd: '1px solid var(--ks-border-subtle)' }}
                >
                  <Td>{row.displayName ?? <span className="ks-muted">—</span>}</Td>
                  <Td>
                    <span className={`badge${row.role === 'SUPER_ADMIN' ? ' badge-primary' : ''}`}>
                      {ROLE_FA[row.role] ?? row.role}
                    </span>
                  </Td>
                  <Td>
                    <span className={`badge${row.status === 'ACTIVE' ? ' badge-on' : ''}`}>
                      {STATUS_FA[row.status] ?? row.status}
                    </span>
                  </Td>
                  <Td>{new Date(row.createdAt).toLocaleDateString('fa-IR')}</Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div style={{ display: 'flex', gap: 'var(--ks-space-2)', marginBlockStart: 'var(--ks-space-4)', justifyContent: 'center' }}>
        <button
          className="btn btn-ghost btn-sm"
          type="button"
          disabled={offset === 0}
          onClick={() => setOffset((o) => Math.max(0, o - limit))}
        >
          قبلی
        </button>
        <button
          className="btn btn-ghost btn-sm"
          type="button"
          disabled={rows.length < limit}
          onClick={() => setOffset((o) => o + limit)}
        >
          بعدی
        </button>
      </div>
    </section>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th style={{ padding: 'var(--ks-space-2) var(--ks-space-3)', textAlign: 'start', fontWeight: 600, color: 'var(--ks-muted)' }}>
      {children}
    </th>
  );
}

function Td({ children }: { children: React.ReactNode }) {
  return (
    <td style={{ padding: 'var(--ks-space-2) var(--ks-space-3)' }}>
      {children}
    </td>
  );
}
