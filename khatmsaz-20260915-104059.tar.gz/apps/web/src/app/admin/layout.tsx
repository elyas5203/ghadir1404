'use client';

import { useEffect } from 'react';
import type { ReactNode } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '../../lib/auth-context';

/**
 * Admin layout: UX-level role guard + navigation shell.
 * Security enforcement happens at the backend; this is a rendering convenience.
 */
export default function AdminLayout({ children }: { children: ReactNode }) {
  const { phase, me } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (phase === 'anonymous') router.replace('/login');
    if (phase === 'authenticated' && me?.role !== 'SUPER_ADMIN') router.replace('/dashboard');
  }, [phase, me, router]);

  if (phase !== 'authenticated' || me?.role !== 'SUPER_ADMIN') {
    return <p className="ks-muted" style={{ padding: 'var(--ks-space-8)' }}>در حال بارگذاری…</p>;
  }

  const navItems = [
    { href: '/admin', label: 'آمار کلی' },
    { href: '/admin/customers', label: 'کاربران' },
    { href: '/admin/khatms', label: 'ختم‌ها' },
  ];

  return (
    <div className="page page-ambient">
      <header className="shell app-bar">
        <span className="wordmark">پنل مدیریت</span>
        <nav style={{ display: 'flex', gap: 'var(--ks-space-2)', alignItems: 'center' }}>
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`btn btn-ghost btn-sm${pathname === item.href ? ' btn-active' : ''}`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="app-bar-end">
          <Link href="/dashboard" className="btn btn-ghost btn-sm">
            بازگشت
          </Link>
        </div>
      </header>
      <main className="shell stack">{children}</main>
    </div>
  );
}
