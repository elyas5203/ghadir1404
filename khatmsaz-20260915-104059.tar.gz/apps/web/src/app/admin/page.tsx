'use client';

import { useCallback, useEffect, useState } from 'react';
import { ApiError } from '../../lib/api-error';
import { useAuth } from '../../lib/auth-context';

interface AdminStats {
  totalUsers: number;
  totalKhatms: number;
}

export default function AdminStatsPage() {
  const { authed } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const data = await authed<AdminStats>('/api/admin/stats');
      setStats(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'بارگذاری ناموفق بود.');
    } finally {
      setLoading(false);
    }
  }, [authed]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <section className="panel">
      <h2>آمار کلی سامانه</h2>

      {error ? (
        <div className="alert" role="alert">
          <span>{error}</span>
          <button className="btn btn-sm" type="button" onClick={() => void load()} style={{ marginInlineStart: 'var(--ks-space-3)' }}>
            تلاش مجدد
          </button>
        </div>
      ) : loading ? (
        <div className="stats-grid">
          <div className="skeleton" style={{ blockSize: '6rem', borderRadius: 'var(--ks-radius-md)' }} />
          <div className="skeleton" style={{ blockSize: '6rem', borderRadius: 'var(--ks-radius-md)' }} />
        </div>
      ) : stats ? (
        <div className="stats-grid">
          <StatCard label="مجموع کاربران" value={stats.totalUsers} />
          <StatCard label="مجموع ختم‌ها" value={stats.totalKhatms} />
        </div>
      ) : null}
    </section>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div
      className="panel"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 'var(--ks-space-1)',
        padding: 'var(--ks-space-5)',
      }}
    >
      <span
        style={{
          fontSize: 'clamp(2rem, 5vw, 3rem)',
          fontWeight: 700,
          color: 'var(--ks-accent)',
          lineHeight: 1,
        }}
      >
        {value.toLocaleString('fa-IR')}
      </span>
      <span className="ks-muted" style={{ fontSize: '0.9rem' }}>{label}</span>
    </div>
  );
}
