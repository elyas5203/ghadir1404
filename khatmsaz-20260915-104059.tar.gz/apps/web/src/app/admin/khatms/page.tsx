'use client';

import { useCallback, useEffect, useState } from 'react';
import { ApiError } from '../../../lib/api-error';
import { useAuth } from '../../../lib/auth-context';
import type { KhatmStatusDto, KhatmTemplateTypeDto, KhatmTypeDto } from '@khatmsaz/contracts';
import { TEMPLATE_LABEL, STATUS_LABEL, KHATM_TYPE_LABEL } from '../../../lib/labels';

interface AdminKhatmRow {
  id: string;
  title: string;
  status: string;
  templateType: string;
  khatmType: string;
  creatorUserId: string;
  createdAt: string;
}

export default function AdminKhatmsPage() {
  const { authed } = useAuth();
  const [rows, setRows] = useState<AdminKhatmRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 50;

  const load = useCallback(async (off: number) => {
    setError(null);
    setLoading(true);
    try {
      const data = await authed<AdminKhatmRow[]>(`/api/admin/khatms?limit=${limit}&offset=${off}`);
      setRows(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'بارگذاری ناموفق بود.');
    } finally {
      setLoading(false);
    }
  }, [authed]);

  useEffect(() => {
    void load(offset);
  }, [load, offset]);

  const filtered = search.trim()
    ? rows.filter((r) => r.title.includes(search))
    : rows;

  return (
    <section className="panel">
      <div className="section-header">
        <h2>همه ختم‌ها</h2>
      </div>

      <div style={{ marginBlockEnd: 'var(--ks-space-4)' }}>
        <input
          className="input"
          type="search"
          placeholder="جستجو در عنوان…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ inlineSize: '100%', maxInlineSize: '24rem' }}
        />
      </div>

      {error ? (
        <div className="alert" role="alert">
          <span>{error}</span>
          <button className="btn btn-sm" type="button" onClick={() => void load(offset)} style={{ marginInlineStart: 'var(--ks-space-3)' }}>
            تلاش مجدد
          </button>
        </div>
      ) : loading ? (
        <div className="stack">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton" style={{ blockSize: '3rem', borderRadius: 'var(--ks-radius-sm)' }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <p className="ks-muted">{search ? 'نتیجه‌ای یافت نشد.' : 'ختمی ثبت نشده است.'}</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ inlineSize: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ borderBlockEnd: '1px solid var(--ks-border)' }}>
                <Th>عنوان</Th>
                <Th>نوع</Th>
                <Th>قالب</Th>
                <Th>وضعیت</Th>
                <Th>تاریخ ساخت</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.id} style={{ borderBlockEnd: '1px solid var(--ks-border-subtle)' }}>
                  <Td><span style={{ fontWeight: 500 }}>{row.title}</span></Td>
                  <Td>{KHATM_TYPE_LABEL[row.khatmType as KhatmTypeDto] ?? row.khatmType}</Td>
                  <Td>{TEMPLATE_LABEL[row.templateType as KhatmTemplateTypeDto] ?? row.templateType}</Td>
                  <Td>
                    <span className={`badge${row.status === 'ACTIVE' ? ' badge-on' : row.status === 'COMPLETED' ? ' badge-primary' : ''}`}>
                      {STATUS_LABEL[row.status as KhatmStatusDto] ?? row.status}
                    </span>
                  </Td>
                  <Td>{new Date(row.createdAt).toLocaleDateString('fa-IR')}</Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div style={{ display: 'flex', gap: 'var(--ks-space-2)', marginBlockStart: 'var(--ks-space-4)', justifyContent: 'center' }}>
        <button
          className="btn btn-ghost btn-sm"
          type="button"
          disabled={offset === 0}
          onClick={() => setOffset((o) => Math.max(0, o - limit))}
        >
          قبلی
        </button>
        <button
          className="btn btn-ghost btn-sm"
          type="button"
          disabled={filtered.length < limit}
          onClick={() => setOffset((o) => o + limit)}
        >
          بعدی
        </button>
      </div>
    </section>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th style={{ padding: 'var(--ks-space-2) var(--ks-space-3)', textAlign: 'start', fontWeight: 600, color: 'var(--ks-muted)' }}>
      {children}
    </th>
  );
}

function Td({ children }: { children: React.ReactNode }) {
  return (
    <td style={{ padding: 'var(--ks-space-2) var(--ks-space-3)' }}>
      {children}
    </td>
  );
}
