'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import type { AcceptInvitationResponse } from '@khatmsaz/contracts';
import { RequireAuth } from '../../../components/require-auth';
import { useAuth } from '../../../lib/auth-context';
import { ApiError } from '../../../lib/api-error';

export default function AcceptInvitationPage() {
  return (
    <RequireAuth>
      <AcceptInvitation />
    </RequireAuth>
  );
}

function AcceptInvitation() {
  const router = useRouter();
  const params = useSearchParams();
  const token = params.get('token') ?? '';
  const { authed } = useAuth();

  const [status, setStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [result, setResult] = useState<AcceptInvitationResponse | null>(null);

  useEffect(() => {
    if (!token) return;
    setStatus('loading');
    authed<AcceptInvitationResponse>('/api/invitations/accept', {
      method: 'POST',
      body: { token },
    })
      .then((res) => {
        setResult(res);
        setStatus('done');
      })
      .catch((err: unknown) => {
        setErrorMsg(err instanceof ApiError ? err.message : 'پذیرش دعوت‌نامه ناموفق بود.');
        setStatus('error');
      });
  }, [token, authed]);

  const goToKhatm = () => {
    if (result?.khatmId) router.push(`/khatms/${result.khatmId}`);
    else router.push('/dashboard');
  };

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <span className="wordmark">ختم‌ساز</span>

        {!token ? (
          <>
            <p className="alert" role="alert">
              این لینک معتبر نیست یا منقضی شده. لینک دعوت را دوباره از سازنده بگیرید.
            </p>
            <Link href="/dashboard" className="btn btn-primary">
              بازگشت به داشبورد
            </Link>
          </>
        ) : status === 'loading' ? (
          <div style={{ display: 'grid', gap: 'var(--ks-space-3)' }}>
            <div className="skeleton skeleton-line" style={{ inlineSize: '70%' }} />
            <div className="skeleton skeleton-line skeleton-line-short" />
          </div>
        ) : status === 'error' ? (
          <>
            <p className="alert" role="alert">
              {errorMsg}
            </p>
            <Link href="/dashboard" className="btn">
              بازگشت به داشبورد
            </Link>
          </>
        ) : (
          <>
            <p className="alert alert-ok" role="status">
              به ختم پیوستید. سهم‌های شما در صفحهٔ ختم نمایش داده می‌شود.
            </p>
            <button className="btn btn-primary" type="button" onClick={goToKhatm}>
              مشاهدهٔ ختم
            </button>
          </>
        )}
      </div>
    </div>
  );
}
