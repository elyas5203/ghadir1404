'use client';

import { useState } from 'react';
import type { FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { ApiError } from '../../lib/api-error';
import { useAuth } from '../../lib/auth-context';

type Step = 'request' | 'verify';

export default function LoginPage() {
  const router = useRouter();
  const { requestLoginCode, verifyLoginCode } = useAuth();
  const [step, setStep] = useState<Step>('request');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const request = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await requestLoginCode(phone.trim());
      setStep('verify');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'ارسال کد ناموفق بود.');
    } finally {
      setBusy(false);
    }
  };

  const verify = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await verifyLoginCode(phone.trim(), code.trim());
      router.replace('/dashboard');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'ورود ناموفق بود.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="auth-shell">
      <section className="auth-card">
        <div className="auth-wordmark">
          <span className="auth-wordmark-icon" aria-hidden="true" />
          <div>
            <div className="auth-wordmark-label">ختم‌ساز</div>
            <div className="auth-wordmark-sub">خدمتگزاران</div>
          </div>
        </div>

        {step === 'request' ? (
          <>
            <div>
              <h1>ورود به ختم‌ساز</h1>
              <p className="ks-muted" style={{ marginBlockStart: 'var(--ks-space-1)' }}>
                با شمارهٔ تلفن خود وارد شوید.
              </p>
            </div>

            {error ? (
              <p className="alert" role="alert">
                {error}
              </p>
            ) : null}

            <form className="form" onSubmit={request}>
              <label className="field">
                <span className="field-label-row">شمارهٔ تلفن</span>
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  dir="ltr"
                  inputMode="tel"
                  placeholder="۰۹×××××××××"
                  maxLength={11}
                  autoComplete="tel"
                />
              </label>
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? 'در حال ارسال…' : 'ارسال کد تأیید'}
              </button>
            </form>
          </>
        ) : (
          <>
            <div>
              <h1>کد تأیید</h1>
              <p className="ks-muted" style={{ marginBlockStart: 'var(--ks-space-1)' }}>
                کد ۵ رقمی برای {phone} ارسال شد. کد تا ۵ دقیقه معتبر است.
              </p>
            </div>

            {error ? (
              <p className="alert" role="alert">
                {error}
              </p>
            ) : null}

            <form className="form" onSubmit={verify}>
              <label className="field">
                <span className="field-label-row">کد تأیید</span>
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  required
                  dir="ltr"
                  inputMode="numeric"
                  autoFocus
                  autoComplete="one-time-code"
                />
              </label>
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? 'در حال ورود…' : 'ورود'}
              </button>
              <button
                className="btn btn-ghost"
                type="button"
                onClick={() => {
                  setStep('request');
                  setCode('');
                  setError(null);
                }}
                disabled={busy}
              >
                ویرایش شماره
              </button>
            </form>
          </>
        )}
      </section>
    </main>
  );
}
