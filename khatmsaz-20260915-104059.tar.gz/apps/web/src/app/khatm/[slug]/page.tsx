/**
 * Public khatm page (Sprint Phase 05) — no authentication required.
 * Shows progress, title, organizer, and a join deep-link for Telegram/Bale.
 */
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { API_BASE_URL } from '../../../lib/config';

interface PublicKhatmData {
  id: string;
  slug: string;
  title: string;
  type: string;
  khatmType: string;
  status: string;
  niyyat: string | null;
  organizerName: string | null;
  progress: { total: number; completed: number; percent: number };
  activeMemberCount: number;
}

async function fetchPublicKhatm(slug: string): Promise<PublicKhatmData | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/public/khatm/${slug}`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return res.json() as Promise<PublicKhatmData>;
  } catch {
    return null;
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await fetchPublicKhatm(slug);
  if (!data) return { title: 'ختم‌ساز' };
  return { title: `${data.title} — ختم‌ساز` };
}

export default async function PublicKhatmPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await fetchPublicKhatm(slug);
  if (!data) notFound();

  const isActive = data.status === 'ACTIVE';
  const joinTelegramUrl = `https://t.me/${process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME ?? 'khatmsazbot'}?start=join_${data.id}`;

  return (
    <main
      dir="rtl"
      lang="fa"
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '2rem 1rem',
        background: 'var(--ks-color-bg)',
        color: 'var(--ks-color-text)',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '520px',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.5rem',
        }}
      >
        {/* Header */}
        <header>
          <p style={{ color: 'var(--ks-color-muted)', fontSize: 'var(--ks-text-sm)', marginBottom: '0.25rem' }}>
            ختم‌ساز
          </p>
          <h1 style={{ fontSize: 'var(--ks-text-xl)', fontWeight: 700, margin: 0 }}>
            {data.title}
          </h1>
          {data.organizerName && (
            <p style={{ color: 'var(--ks-color-muted)', marginTop: '0.25rem' }}>
              برگزارکننده: {data.organizerName}
            </p>
          )}
        </header>

        {/* Niyyat */}
        {data.niyyat && (
          <section
            style={{
              background: 'var(--ks-color-surface)',
              border: '1px solid var(--ks-color-border)',
              borderRadius: 'var(--ks-radius-md)',
              padding: '1rem',
              borderInlineStart: '4px solid var(--ks-color-primary)',
            }}
          >
            <p style={{ margin: 0, fontStyle: 'italic' }}>{data.niyyat}</p>
          </section>
        )}

        {/* Progress */}
        <section>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '0.5rem',
              fontSize: 'var(--ks-text-sm)',
            }}
          >
            <span>{data.progress.completed} از {data.progress.total} بخش</span>
            <span style={{ fontWeight: 700 }}>{data.progress.percent}٪</span>
          </div>
          <div
            style={{
              height: '10px',
              background: 'var(--ks-color-border)',
              borderRadius: '999px',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                height: '100%',
                width: `${data.progress.percent}%`,
                background: 'var(--ks-color-primary)',
                borderRadius: '999px',
                transition: 'width 0.4s ease-out',
              }}
            />
          </div>
          <p
            style={{
              color: 'var(--ks-color-muted)',
              fontSize: 'var(--ks-text-sm)',
              marginTop: '0.5rem',
            }}
          >
            {data.activeMemberCount} شرکت‌کننده فعال
          </p>
        </section>

        {/* Join */}
        {isActive && (
          <section style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <a
              href={joinTelegramUrl}
              style={{
                display: 'block',
                textAlign: 'center',
                background: 'var(--ks-color-primary)',
                color: '#fff',
                padding: '0.875rem 1.5rem',
                borderRadius: 'var(--ks-radius-md)',
                fontWeight: 700,
                textDecoration: 'none',
                fontSize: 'var(--ks-text-md)',
              }}
            >
              پیوستن از طریق تلگرام
            </a>
          </section>
        )}

        {!isActive && (
          <p style={{ color: 'var(--ks-color-muted)', textAlign: 'center' }}>
            این ختم در حال حاضر{data.status === 'COMPLETED' ? ' تکمیل شده' : ' فعال نیست'}.
          </p>
        )}
      </div>
    </main>
  );
}
