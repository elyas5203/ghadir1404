import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { API_BASE_URL } from '../../../lib/config';
import { JoinClient } from './join-client';

interface PublicKhatmData {
  id: string;
  slug: string;
  title: string;
  type: string;
  khatmType: string;
  status: string;
  niyyat: string | null;
  organizerName: string | null;
  progress: { total: number; completed: number; percent: number };
  activeMemberCount: number;
}

async function fetchPublicKhatm(slug: string): Promise<PublicKhatmData | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/public/khatm/${slug}`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return res.json() as Promise<PublicKhatmData>;
  } catch {
    return null;
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await fetchPublicKhatm(slug);
  if (!data) return { title: 'ختم‌ساز' };
  return {
    title: `پیوستن به ${data.title} — ختم‌ساز`,
    description: data.niyyat ?? `به ختم «${data.title}» بپیوندید.`,
    openGraph: {
      title: `پیوستن به ${data.title}`,
      description: data.niyyat ?? `به ختم «${data.title}» بپیوندید.`,
      siteName: 'ختم‌ساز',
    },
  };
}

export default async function JoinPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await fetchPublicKhatm(slug);
  if (!data) notFound();

  const isActive = data.status === 'ACTIVE';

  return (
    <main dir="rtl" lang="fa" className="page">
      <header className="shell app-bar">
        <span className="wordmark">ختم‌ساز</span>
      </header>

      <div className="shell stack">
        <section className="panel">
          <h1>{data.title}</h1>
          {data.organizerName ? (
            <p className="ks-muted">برگزارکننده: {data.organizerName}</p>
          ) : null}

          {data.niyyat ? (
            <blockquote className="ks-note" style={{ marginBlock: '0.75rem' }}>
              {data.niyyat}
            </blockquote>
          ) : null}

          <div style={{ marginBlock: '1rem' }}>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '0.5rem',
                fontSize: 'var(--ks-text-sm)',
              }}
            >
              <span>{data.progress.completed} از {data.progress.total} بخش</span>
              <span style={{ fontWeight: 700 }}>{data.progress.percent}٪</span>
            </div>
            <div
              style={{
                height: '10px',
                background: 'var(--ks-color-border)',
                borderRadius: '999px',
                overflow: 'hidden',
              }}
            >
              <div
                style={{
                  height: '100%',
                  width: `${data.progress.percent}%`,
                  background: 'var(--ks-color-primary)',
                  borderRadius: '999px',
                }}
              />
            </div>
            <p className="ks-muted" style={{ fontSize: 'var(--ks-text-sm)', marginTop: '0.5rem' }}>
              {data.activeMemberCount} شرکت‌کننده فعال
            </p>
          </div>

          {isActive ? (
            <JoinClient khatmId={data.id} />
          ) : (
            <p className="ks-muted" style={{ textAlign: 'center' }}>
              {data.status === 'COMPLETED' ? 'این ختم تکمیل شده است.' : 'این ختم در حال حاضر فعال نیست.'}
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
