'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../../../lib/auth-context';
import { ApiError } from '../../../lib/api-error';

interface Props {
  khatmId: string;
}

export function JoinClient({ khatmId }: Props) {
  const { phase, authed } = useAuth();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  if (phase === 'loading') return null;

  if (phase !== 'authenticated') {
    return (
      <div className="stack" style={{ gap: '0.75rem' }}>
        <p className="ks-muted" style={{ textAlign: 'center' }}>
          برای پیوستن به این ختم ابتدا وارد شوید.
        </p>
        <a
          href={`/login?next=${encodeURIComponent(`/join/${khatmId}`)}`}
          className="btn btn-primary"
          style={{ textAlign: 'center', display: 'block' }}
        >
          ورود به حساب
        </a>
      </div>
    );
  }

  if (done) {
    return (
      <div style={{ textAlign: 'center' }}>
        <p style={{ fontWeight: 700 }}>به ختم پیوستید.</p>
        <button className="btn" onClick={() => router.push('/dashboard')}>
          رفتن به داشبورد
        </button>
      </div>
    );
  }

  const handleJoin = async () => {
    setBusy(true);
    setError(null);
    try {
      await authed(`/api/khatms/${khatmId}/join`, { method: 'POST' });
      setDone(true);
    } catch (err) {
      if (err instanceof ApiError && err.message.includes('پیش‌تر')) {
        setDone(true);
      } else {
        setError(err instanceof ApiError ? err.message : 'پیوستن ناموفق بود.');
        setBusy(false);
      }
    }
  };

  return (
    <div className="stack" style={{ gap: '0.75rem' }}>
      {error ? (
        <p className="alert" role="alert">{error}</p>
      ) : null}
      <button
        className="btn btn-primary"
        onClick={handleJoin}
        disabled={busy}
      >
        {busy ? 'در حال پیوستن…' : 'پیوستن به ختم'}
      </button>
    </div>
  );
}
