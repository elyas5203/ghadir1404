'use client';

import { useCallback, useEffect, useState } from 'react';
import type React from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import type {
  AllocatePortionsResponse,
  ContributionSummary,
  CreateInvitationResponse,
  GenerateAllocationResponse,
  InvitationSummary,
  KhatmInvitationsResponse,
  KhatmParticipantsResponse,
  KhatmProgressResponse,
  KhatmSummary,
  MyContributionsResponse,
  MyPortionsResponse,
  OpenProgressResponse,
  ParticipationSummary,
  PortionSummary,
} from '@khatmsaz/contracts';
import { RequireAuth } from '../../../components/require-auth';
import { useAuth } from '../../../lib/auth-context';
import { ApiError } from '../../../lib/api-error';
import { HelpTip } from '../../../components/help-tip';
import {
  STATUS_LABEL,
  TEMPLATE_LABEL,
  KHATM_TYPE_LABEL,
  PARTICIPATION_STATUS_LABEL,
  INVITATION_STATUS_LABEL,
} from '../../../lib/labels';

export default function KhatmManagePage() {
  return (
    <RequireAuth>
      <Manage />
    </RequireAuth>
  );
}

function Manage() {
  const params = useParams<{ id: string }>();
  const khatmId = params.id;
  const { me, authed } = useAuth();

  const [khatm, setKhatm] = useState<KhatmSummary | null>(null);
  const [progress, setProgress] = useState<KhatmProgressResponse | null>(null);
  const [participants, setParticipants] = useState<ParticipationSummary[]>([]);
  const [invitations, setInvitations] = useState<InvitationSummary[]>([]);
  const [myPortions, setMyPortions] = useState<PortionSummary[]>([]);
  const [myContributions, setMyContributions] = useState<ContributionSummary[]>([]);
  const [openProgress, setOpenProgress] = useState<OpenProgressResponse | null>(null);
  const [contributionAmount, setContributionAmount] = useState<string>('');
  const [contributionNote, setContributionNote] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirmComplete, setConfirmComplete] = useState(false);
  const [inviteLink, setInviteLink] = useState<string | null>(null);
  const [inviteLinkBusy, setInviteLinkBusy] = useState(false);

  const isOwner = khatm?.creatorUserId === me?.userId;

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const [khatmData, prog] = await Promise.all([
        authed<KhatmSummary>(`/api/khatms/${khatmId}`),
        authed<KhatmProgressResponse>(`/api/khatms/${khatmId}/progress`).catch(() => null),
      ]);
      setKhatm(khatmData);
      setProgress(prog);

      const [parts, invs, portions] = await Promise.all([
        khatmData.creatorUserId === me?.userId
          ? authed<KhatmParticipantsResponse>(`/api/khatms/${khatmId}/participants`).catch(() => ({
              participants: [] as ParticipationSummary[],
            }))
          : Promise.resolve({ participants: [] as ParticipationSummary[] }),
        khatmData.creatorUserId === me?.userId
          ? authed<KhatmInvitationsResponse>(`/api/khatms/${khatmId}/invitations`).catch(() => ({
              invitations: [] as InvitationSummary[],
            }))
          : Promise.resolve({ invitations: [] as InvitationSummary[] }),
        authed<MyPortionsResponse>(`/api/khatms/${khatmId}/my-portions`).catch(() => ({
          portions: [] as PortionSummary[],
        })),
      ]);
      setParticipants([...parts.participants]);
      setInvitations([...invs.invitations]);
      setMyPortions([...portions.portions]);

      if (khatmData.khatmType === 'OPEN') {
        const [contribs, openProg] = await Promise.all([
          authed<MyContributionsResponse>(`/api/khatms/${khatmId}/my-contributions`).catch(() => ({
            contributions: [] as ContributionSummary[],
          })),
          authed<OpenProgressResponse>(`/api/khatms/${khatmId}/open-progress`).catch(() => null),
        ]);
        setMyContributions([...contribs.contributions]);
        setOpenProgress(openProg);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'بارگذاری ناموفق بود.');
    } finally {
      setLoading(false);
    }
  }, [authed, khatmId, me?.userId]);

  useEffect(() => {
    void load();
  }, [load]);

  const run = async (action: () => Promise<unknown>, ok: string) => {
    setError(null);
    setNotice(null);
    try {
      await action();
      if (ok) setNotice(ok);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'عملیات ناموفق بود.');
    }
  };

  const pct =
    progress && progress.total > 0
      ? Math.round((progress.completed / progress.total) * 100)
      : null;

  return (
    <div className="page">
      <header className="shell app-bar">
        <Link href="/dashboard" className="wordmark">
          ختم‌ساز
        </Link>
      </header>

      <main className="shell stack">
        {/* ── Khatm header panel ── */}
        <section className="panel">
          {loading ? (
            <div style={{ display: 'grid', gap: 'var(--ks-space-3)' }}>
              <div className="skeleton skeleton-line" style={{ inlineSize: '60%', blockSize: '28px' }} />
              <div className="skeleton skeleton-line skeleton-line-short" />
            </div>
          ) : khatm ? (
            <>
              <div className="khatm-card-header">
                <h1 style={{ fontSize: 'var(--ks-text-xl)', fontWeight: 700, lineHeight: 'var(--ks-leading-tight)' }}>
                  {khatm.title}
                </h1>
                <span className="badge">{STATUS_LABEL[khatm.status]}</span>
              </div>
              <span className="ks-muted">
                {TEMPLATE_LABEL[khatm.templateType]} · {KHATM_TYPE_LABEL[khatm.khatmType]}
              </span>
              {khatm.quranPageConfig ? (
                <span className="ks-muted">
                  {khatm.quranPageConfig.editionNameFa}
                </span>
              ) : null}
              {khatm.quranSurahConfig ? (
                <span className="ks-muted">
                  {khatm.quranSurahConfig.surahNameFa} — هدف: {persianNumber(khatm.quranSurahConfig.repetitionTarget)} بار
                </span>
              ) : null}
              {khatm.repetitionTarget != null && khatm.templateType !== 'QURAN_SURAH' ? (
                <span className="ks-muted">
                  هدف: {persianNumber(khatm.repetitionTarget)} بار
                </span>
              ) : null}
              {pct !== null ? (
                <div>
                  <div className="progress-wrap" style={{ blockSize: '10px' }} title={`${pct}٪ انجام‌شده`}>
                    <div className="progress-fill" style={{ inlineSize: `${pct}%` }} />
                  </div>
                  <p className="ks-muted" style={{ marginBlockStart: 'var(--ks-space-2)' }}>
                    {progress?.completed} از {progress?.total} سهم انجام‌شده ({pct}٪)
                  </p>
                </div>
              ) : null}
            </>
          ) : null}

          {notice ? (
            <p className="alert alert-ok" role="status">
              {notice}
            </p>
          ) : null}
          {error ? (
            <p className="alert" role="alert">
              {error}
            </p>
          ) : null}
        </section>

        {/* ── My portions (participant) ── */}
        {myPortions.length > 0 ? (
          <section className="panel">
            <div className="section-header">
              <h2>
                سهم‌های من
                <HelpTip
                  term="سهم"
                  explanation="بخشی از ختم که به شما واگذار شده و شما مسئول انجام آن هستید."
                />
              </h2>
            </div>
            <ul className="list">
              {myPortions.map((p) => (
                <li key={p.portionId} className="list-row">
                  <span>
                    {p.unitKind === 'POSITIONAL'
                      ? `جزء ${p.unitStart} تا ${p.unitEnd}`
                      : `${p.quantity} واحد`}
                  </span>
                  <div className="actions" style={{ gap: 'var(--ks-space-2)', flexWrap: 'nowrap' }}>
                    <span className={`badge ${p.status === 'COMPLETED' ? 'badge-on' : ''}`}>
                      {p.status === 'OPEN' ? 'باز' : p.status === 'ASSIGNED' ? 'واگذارشده' : 'انجام‌شده'}
                    </span>
                    {p.status === 'ASSIGNED' ? (
                      <button
                        className="btn btn-primary btn-sm"
                        type="button"
                        onClick={() =>
                          void run(
                            () => authed(`/api/khatms/${khatmId}/portions/${p.portionId}/complete`, { method: 'POST' }),
                            'سهم انجام شد.',
                          )
                        }
                      >
                        انجام شد
                      </button>
                    ) : null}
                  </div>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {/* ── OPEN khatm contributions ── */}
        {khatm?.khatmType === 'OPEN' && khatm.status === 'ACTIVE' ? (
          <section className="panel">
            <div className="section-header">
              <h2>
                مشارکت من
                <HelpTip
                  term="مشارکت"
                  explanation="در ختم‌های غیرتعهددار، هر بار که مقداری انجام می‌دهید آن را ثبت کنید. پیشرفت کل از مجموع مشارکت‌ها محاسبه می‌شود."
                />
              </h2>
            </div>
            {openProgress ? (
              <p className="ks-muted">
                مجموع مشارکت‌ها: <strong>{openProgress.totalContributed}</strong> · شرکت‌کنندگان: {openProgress.participantCount}
              </p>
            ) : null}
            <form
              className="form form-inline"
              onSubmit={async (e) => {
                e.preventDefault();
                const amount = Number(contributionAmount);
                if (!amount || amount <= 0) return;
                try {
                  await authed(`/api/khatms/${khatmId}/contributions`, {
                    method: 'POST',
                    body: { amount, note: contributionNote || null },
                  });
                  setContributionAmount('');
                  setContributionNote('');
                  await load();
                } catch (err) {
                  setError(err instanceof ApiError ? err.message : 'ثبت مشارکت ناموفق بود.');
                }
              }}
            >
              <label className="field">
                <span>مقدار</span>
                <input
                  type="number"
                  min={1}
                  value={contributionAmount}
                  onChange={(e) => setContributionAmount(e.target.value)}
                  dir="ltr"
                  required
                />
              </label>
              <label className="field">
                <span>یادداشت (اختیاری)</span>
                <input
                  value={contributionNote}
                  onChange={(e) => setContributionNote(e.target.value)}
                  maxLength={200}
                />
              </label>
              <button className="btn btn-primary" type="submit" style={{ alignSelf: 'end' }}>
                ثبت مشارکت
              </button>
            </form>
            {myContributions.length > 0 ? (
              <ul className="list">
                {myContributions.map((c) => (
                  <li key={c.id} className="list-row">
                    <span>{c.amount}</span>
                    {c.note ? <span className="ks-muted">{c.note}</span> : null}
                    <span className="ks-muted">
                      {new Date(c.recordedAt).toLocaleDateString('fa-IR')}
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
          </section>
        ) : null}

        {/* ── Creator management ── */}
        {isOwner && khatm ? (
          <>
            <section className="panel">
              <h2>مدیریت ختم</h2>

              {khatm.status === 'DRAFT' ? (
                <div className="workflow-steps">
                  {khatm.khatmType === 'COMMITMENT' ? (
                    <div className="workflow-step">
                      <span className={`workflow-step-num${progress && progress.total > 0 ? ' done' : ''}`}>
                        {progress && progress.total > 0 ? '✓' : '۱'}
                      </span>
                      <div className="workflow-step-body">
                        <p className="workflow-step-label">برنامهٔ تقسیم‌بندی</p>
                        {progress && progress.total > 0 ? (
                          <p className="alert alert-ok">
                            {persianNumber(progress.total)} سهم ساخته شد. به مرحلهٔ بعد بروید.
                          </p>
                        ) : (
                          <GeneratePlan
                            khatmId={khatmId}
                            khatm={khatm}
                            authed={authed}
                            onError={setError}
                            onNotice={setNotice}
                            reload={load}
                          />
                        )}
                      </div>
                    </div>
                  ) : (
                    <p className="alert alert-info">
                      ختم غیرتعهددار نیازی به برنامهٔ تقسیم ندارد — مستقیم فعال کنید.
                    </p>
                  )}
                  <div className="workflow-step">
                    <span className="workflow-step-num">
                      {khatm.khatmType === 'COMMITMENT' ? '۲' : '۱'}
                    </span>
                    <div className="workflow-step-body">
                      <p className="workflow-step-label">فعال‌سازی ختم</p>
                      <div className="actions">
                        <button
                          className="btn btn-primary"
                          type="button"
                          disabled={khatm.khatmType === 'COMMITMENT' && !(progress && progress.total > 0)}
                          onClick={() =>
                            void run(
                              () => authed(`/api/khatms/${khatmId}/activate`, { method: 'POST' }),
                              'ختم فعال شد.',
                            )
                          }
                        >
                          فعال‌سازی
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}

              {khatm.status === 'ACTIVE' ? (
                confirmComplete ? (
                  <div className="confirm-bar">
                    <span className="confirm-bar-text">
                      اعلام پایان ختم برگشت‌پذیر نیست. آیا مطمئن هستید؟
                    </span>
                    <button
                      className="btn btn-danger btn-sm"
                      type="button"
                      onClick={() => {
                        setConfirmComplete(false);
                        void run(
                          () => authed(`/api/khatms/${khatmId}/complete`, { method: 'POST' }),
                          'ختم تمام شد.',
                        );
                      }}
                    >
                      بله، پایان ختم
                    </button>
                    <button
                      className="btn btn-ghost btn-sm"
                      type="button"
                      onClick={() => setConfirmComplete(false)}
                    >
                      انصراف
                    </button>
                  </div>
                ) : (
                  <div className="actions">
                    <button
                      className="btn"
                      type="button"
                      onClick={() => setConfirmComplete(true)}
                    >
                      اعلام پایان ختم
                    </button>
                  </div>
                )
              ) : null}

              {khatm.status === 'ACTIVE' && participants.length > 0 ? (
                <Allocate
                  khatmId={khatmId}
                  participants={participants}
                  authed={authed}
                  onError={setError}
                  onNotice={setNotice}
                  reload={load}
                />
              ) : null}
            </section>

            {/* ── Invitations ── */}
            <section className="panel">
              <div className="section-header">
                <h2>
                  دعوت‌نامه‌ها
                  <HelpTip
                    term="دعوت"
                    explanation="لینک اختصاصی که دیگران با آن به ختم می‌پیوندند. هر لینک یک‌بار قابل استفاده است و ۷ روز اعتبار دارد."
                  />
                </h2>
                <button
                  className="btn btn-sm btn-primary"
                  type="button"
                  onClick={() =>
                    void run(async () => {
                      const res = await authed<CreateInvitationResponse>(
                        `/api/khatms/${khatmId}/invitations`,
                        { method: 'POST' },
                      );
                      const link = `${window.location.origin}/invitations/accept?token=${res.token}`;
                      await navigator.clipboard.writeText(link).catch(() => undefined);
                      setNotice(`لینک دعوت در کلیپ‌بورد ذخیره شد.`);
                    }, '')
                  }
                >
                  لینک دعوت تازه
                </button>
              </div>
              {invitations.length === 0 ? (
                <p className="ks-muted">هنوز دعوت‌نامه‌ای صادر نشده است.</p>
              ) : (
                <ul className="list">
                  {invitations.map((inv, idx) => (
                    <li key={inv.invitationId} className="list-row">
                      <span className="ks-muted">دعوت‌نامه {persianNumber(idx + 1)}</span>
                      <div className="actions" style={{ gap: 'var(--ks-space-2)' }}>
                        <span className={`badge badge-inv-${inv.status.toLowerCase()}`}>
                          {INVITATION_STATUS_LABEL[inv.status]}
                        </span>
                        {inv.status === 'CREATED' ? (
                          <button
                            className="btn btn-ghost btn-sm"
                            type="button"
                            onClick={() =>
                              void run(
                                () =>
                                  authed(`/api/invitations/${inv.invitationId}/cancel`, {
                                    method: 'POST',
                                  }),
                                'دعوت‌نامه لغو شد.',
                              )
                            }
                          >
                            لغو
                          </button>
                        ) : null}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* ── Permanent invite link ── */}
            {khatm.status === 'ACTIVE' ? (
              <section className="panel">
                <div className="section-header">
                  <h2>
                    لینک دعوت دائمی
                    <HelpTip
                      term="لینک دائمی"
                      explanation="این لینک همیشه معتبر است و هر کسی با آن می‌تواند به ختم بپیوندد. با هر بار دریافت، همان لینک برگردانده می‌شود."
                    />
                  </h2>
                </div>
                {inviteLink ? (
                  <div className="form-inline form" style={{ gap: 'var(--ks-space-2)' }}>
                    <input
                      readOnly
                      value={inviteLink}
                      dir="ltr"
                      style={{ flex: 1, fontSize: 'var(--ks-text-sm)' }}
                      onFocus={(e) => e.target.select()}
                    />
                    <button
                      className="btn btn-sm"
                      type="button"
                      onClick={() => void navigator.clipboard.writeText(inviteLink).then(() => setNotice('لینک کپی شد.'))}
                    >
                      کپی
                    </button>
                  </div>
                ) : (
                  <button
                    className="btn btn-primary"
                    type="button"
                    disabled={inviteLinkBusy}
                    onClick={async () => {
                      setInviteLinkBusy(true);
                      try {
                        const res = await authed<{ slug: string; url: string }>(`/api/khatms/${khatmId}/invite-slug`);
                        setInviteLink(res.url);
                      } catch (err) {
                        setError(err instanceof ApiError ? err.message : 'دریافت لینک ناموفق بود.');
                      } finally {
                        setInviteLinkBusy(false);
                      }
                    }}
                  >
                    {inviteLinkBusy ? 'در حال دریافت…' : 'دریافت لینک'}
                  </button>
                )}
              </section>
            ) : null}

            {/* ── Participants ── */}
            <section className="panel">
              <h2>شرکت‌کنندگان ({participants.length})</h2>
              {participants.length === 0 ? (
                <p className="ks-muted">هنوز کسی نپیوسته است. لینک دعوت بفرستید.</p>
              ) : (
                <ul className="list">
                  {participants.map((p, idx) => (
                    <li key={p.participationId} className="list-row">
                      <span>{p.displayName ?? `شرکت‌کننده ${persianNumber(idx + 1)}`}</span>
                      <div className="actions" style={{ gap: 'var(--ks-space-2)', flexWrap: 'nowrap' }}>
                        <span className="ks-muted" style={{ fontSize: 'var(--ks-text-xs)' }}>
                          {new Date(p.joinedAt).toLocaleDateString('fa-IR')}
                        </span>
                        <span className="badge">{PARTICIPATION_STATUS_LABEL[p.status]}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        ) : null}
      </main>
    </div>
  );
}

function persianNumber(n: number): string {
  return n.toLocaleString('fa-IR');
}

type AuthedFn = <T>(path: string, options?: { method?: 'GET' | 'POST' | 'PUT'; body?: unknown }) => Promise<T>;

function defaultsForKhatm(khatm: KhatmSummary): { total: number; chunk: number } {
  if (khatm.templateType === 'QURAN_PAGE' && khatm.quranPageConfig) {
    return { total: khatm.quranPageConfig.totalPages, chunk: 1 };
  }
  if (khatm.templateType === 'QURAN_SURAH' && khatm.quranSurahConfig) {
    return { total: khatm.quranSurahConfig.repetitionTarget, chunk: 1 };
  }
  // SALAWAT / DUA / ZIYARAT / CUSTOM: use creator-defined target when available
  if (khatm.repetitionTarget != null && khatm.repetitionTarget > 0) {
    const chunk = Math.max(1, Math.floor(khatm.repetitionTarget / 10));
    return { total: khatm.repetitionTarget, chunk };
  }
  if (khatm.templateType === 'SALAWAT') return { total: 1000, chunk: 100 };
  return { total: 10, chunk: 1 };
}

function GeneratePlan(props: {
  khatmId: string;
  khatm: KhatmSummary;
  authed: AuthedFn;
  onError: (m: string) => void;
  onNotice: (m: string) => void;
  reload: () => Promise<void>;
}) {
  const defaults = defaultsForKhatm(props.khatm);
  const [total, setTotal] = useState(defaults.total);
  const [chunk, setChunk] = useState(defaults.chunk);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    props.onError('');
    try {
      await props.authed<GenerateAllocationResponse>(`/api/khatms/${props.khatmId}/plan`, {
        method: 'POST',
        body: { spec: { kind: 'QUANTITY', total, chunk } },
      });
      props.onNotice('برنامهٔ تقسیم ساخته شد.');
      await props.reload();
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        props.onError('برنامهٔ تقسیم از پیش وجود دارد. صفحه را بارگذاری مجدد کنید.');
      } else {
        props.onError(err instanceof ApiError ? err.message : 'ساخت برنامه ناموفق بود.');
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <form style={{ display: 'grid', gap: 'var(--ks-space-4)' }} onSubmit={submit}>
      <div className="form-inline form">
        <label className="field">
          <span className="field-label-row">
            تعداد کل سهم
            <HelpTip
              term="تعداد کل"
              explanation="برای قرآن کامل ۳۰ جزء وارد کنید. برای صلوات مثلاً ۱۰۰۰. این عدد بین تعداد زیر تقسیم می‌شود."
            />
          </span>
          <input
            type="number"
            min={1}
            value={total}
            onChange={(e) => setTotal(Number(e.target.value))}
            dir="ltr"
          />
        </label>
        <label className="field">
          <span className="field-label-row">
            اندازهٔ هر سهم
            <HelpTip
              term="سهم"
              explanation="تعداد واحدی که به هر نفر می‌رسد. اگر ۳۰ جزء را بین ۱۰ نفر تقسیم می‌کنید، هر سهم ۳ جزء می‌شود."
            />
          </span>
          <input
            type="number"
            min={1}
            value={chunk}
            onChange={(e) => setChunk(Number(e.target.value))}
            dir="ltr"
          />
        </label>
        <button className="btn" type="submit" disabled={busy} style={{ alignSelf: 'end' }}>
          {busy ? 'در حال ساخت…' : 'ساخت برنامه'}
        </button>
      </div>
      <p className="ks-muted" style={{ fontSize: 'var(--ks-text-xs)' }}>
        {total > 0 && chunk > 0
          ? `${persianNumber(Math.ceil(total / chunk))} سهم ساخته می‌شود.`
          : null}
      </p>
    </form>
  );
}

function Allocate(props: {
  khatmId: string;
  participants: ParticipationSummary[];
  authed: AuthedFn;
  onError: (m: string) => void;
  onNotice: (m: string) => void;
  reload: () => Promise<void>;
}) {
  const [participationId, setParticipationId] = useState('');
  const [count, setCount] = useState(1);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    props.onError('');
    try {
      await props.authed<AllocatePortionsResponse>(`/api/khatms/${props.khatmId}/allocate`, {
        method: 'POST',
        body: {
          participationId: participationId || props.participants[0]?.participationId,
          count,
        },
      });
      props.onNotice('سهم‌ها واگذار شد.');
      await props.reload();
    } catch (err) {
      props.onError(err instanceof ApiError ? err.message : 'واگذاری ناموفق بود.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="form form-inline" onSubmit={submit}>
      <label className="field">
        <span>شرکت‌کننده</span>
        <select value={participationId} onChange={(e) => setParticipationId(e.target.value)}>
          {props.participants.map((p, idx) => (
            <option key={p.participationId} value={p.participationId}>
              {p.displayName ?? `شرکت‌کننده ${persianNumber(idx + 1)}`}
            </option>
          ))}
        </select>
      </label>
      <label className="field">
        <span>تعداد سهم</span>
        <input
          type="number"
          min={1}
          value={count}
          onChange={(e) => setCount(Number(e.target.value))}
          dir="ltr"
        />
      </label>
      <button
        className="btn"
        type="submit"
        disabled={busy || props.participants.length === 0}
        style={{ alignSelf: 'end' }}
      >
        واگذاری سهم
      </button>
    </form>
  );
}
