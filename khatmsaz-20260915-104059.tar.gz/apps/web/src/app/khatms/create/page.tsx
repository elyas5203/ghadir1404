'use client';

import { useState } from 'react';
import type { FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { KHATM_TEMPLATE_TYPES } from '@khatmsaz/contracts';
import type { KhatmSummary, KhatmTemplateTypeDto } from '@khatmsaz/contracts';
import { QURAN_EDITIONS, SURAHS } from '@khatmsaz/shared';
import { RequireAuth } from '../../../components/require-auth';
import { useAuth } from '../../../lib/auth-context';
import { ApiError } from '../../../lib/api-error';
import { canCreateKhatm } from '../../../lib/permissions';
import { TEMPLATE_LABEL, TEMPLATE_ICON, TEMPLATE_EXPLAIN } from '../../../lib/labels';
import { HelpTip } from '../../../components/help-tip';

export default function CreateKhatmPage() {
  return (
    <RequireAuth>
      <CreateKhatmForm />
    </RequireAuth>
  );
}

type KhatmKind = 'commitment' | 'open';

const KIND_HELP =
  'نوع ختم تعیین می‌کند سهم‌بندی چگونه کار کند.\n\n' +
  'تعهددار: مثل تقسیم قرآن بین خانواده — هر نفر می‌داند دقیقاً چه بخشی باید بخواند.\n\n' +
  'غیرتعهددار: مثل صندوق خیریه — هر کس هر قدر توانست می‌دهد، بدون تعهد از پیش تعیین‌شده.';

const TEMPLATE_HELP =
  'نوع چیزی که قرار است خوانده شود.\n\n' +
  '📑 ختم قرآن صفحه‌ای: پیشرفت بر اساس صفحات خوانده‌شده.\n' +
  '🔖 ختم سوره‌ای: یک سوره را به تعداد مشخص بخوانید.\n' +
  '💫 صلوات، 🤲 دعا، 🌟 زیارت: قرائت متون دینی.\n' +
  '⚙️ دلخواه: هر عملی که خودتان تعریف کنید.';

function CreateKhatmForm() {
  const router = useRouter();
  const { me, authed } = useAuth();
  const [kind, setKind] = useState<KhatmKind>('commitment');
  const [title, setTitle] = useState('');
  const [templateType, setTemplateType] = useState<KhatmTemplateTypeDto>('QURAN_PAGE');
  const [quranEditionId, setQuranEditionId] = useState<string>(QURAN_EDITIONS[0]?.id ?? '');
  const [surahNumber, setSurahNumber] = useState<number>(36); // سوره یس
  const [repetitionTarget, setRepetitionTarget] = useState<string>('1');
  const [countTarget, setCountTarget] = useState<string>(''); // optional for SALAWAT/DUA/ZIYARAT/CUSTOM
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!canCreateKhatm(me)) {
    return (
      <div className="page">
        <header className="shell app-bar">
          <Link href="/dashboard" className="wordmark">ختم‌ساز</Link>
        </header>
        <main className="shell stack">
          <div className="panel">
            <p>برای ساخت ختم باید دسترسی سازنده داشته باشید.</p>
            <Link href="/dashboard" className="btn">بازگشت به داشبورد</Link>
          </div>
        </main>
      </div>
    );
  }

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const body: Record<string, unknown> = {
        title: title.trim(),
        templateType,
        khatmType: kind === 'open' ? 'OPEN' : 'COMMITMENT',
      };
      if (templateType === 'QURAN_PAGE') {
        body['quranEditionId'] = quranEditionId;
      }
      if (templateType === 'QURAN_SURAH') {
        body['surahNumber'] = surahNumber;
        body['repetitionTarget'] = parseInt(repetitionTarget, 10);
      }
      const COUNT_TYPES = ['SALAWAT', 'DUA', 'ZIYARAT', 'CUSTOM'];
      if (COUNT_TYPES.includes(templateType) && countTarget.trim()) {
        const parsed = parseInt(countTarget, 10);
        if (!isNaN(parsed) && parsed > 0) body['repetitionTarget'] = parsed;
      }
      const khatm = await authed<KhatmSummary>('/api/khatms', { method: 'POST', body });
      router.push(`/khatms/${khatm.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'ساخت ختم ناموفق بود.');
      setBusy(false);
    }
  };

  const templateExplain = TEMPLATE_EXPLAIN[templateType] ?? '';

  return (
    <div className="page">
      <header className="shell app-bar">
        <Link href="/dashboard" className="wordmark">ختم‌ساز</Link>
      </header>

      <main className="shell stack">
        <section className="panel">
          <h1>ساخت ختم تازه</h1>

          <form className="form" onSubmit={submit}>
            <div className="field">
              <span className="field-label-row">
                نوع ختم
                <HelpTip term="نوع ختم" explanation={KIND_HELP} />
              </span>
              <div className="type-cards">
                <label className="type-card">
                  <input
                    type="radio"
                    name="kind"
                    value="commitment"
                    checked={kind === 'commitment'}
                    onChange={() => setKind('commitment')}
                  />
                  <div className="type-card-body">
                    <span className="type-card-title">
                      <span className="type-card-icon">📋</span>
                      ختم تعهددار
                    </span>
                    <span className="type-card-desc">
                      سهم مشخصی به هر نفر داده می‌شود. مثلاً «جزء ۳ قرآن» برای شما.
                      هر کس می‌داند دقیقاً چه وظیفه‌ای دارد.
                    </span>
                  </div>
                </label>
                <label className="type-card">
                  <input
                    type="radio"
                    name="kind"
                    value="open"
                    checked={kind === 'open'}
                    onChange={() => setKind('open')}
                  />
                  <div className="type-card-body">
                    <span className="type-card-title">
                      <span className="type-card-icon">🌐</span>
                      ختم غیرتعهددار
                    </span>
                    <span className="type-card-desc">
                      هر کس هر قدر خواند ثبت می‌کند. بدون تعهد از پیش تعیین‌شده.
                      مناسب وقتی نمی‌دانید چند نفر می‌آیند.
                    </span>
                  </div>
                </label>
              </div>
            </div>

            <label className="field">
              <span className="field-label-row">عنوان ختم</span>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثلاً: ختم قرآن برای رمضان ۱۴۰۴"
                required
                maxLength={120}
              />
            </label>

            <div className="field">
              <span className="field-label-row">
                نوع قرائت
                <HelpTip term="نوع قرائت" explanation={TEMPLATE_HELP} />
              </span>
              <select
                value={templateType}
                onChange={(e) => setTemplateType(e.target.value as KhatmTemplateTypeDto)}
              >
                {KHATM_TEMPLATE_TYPES.filter(
                  (t) => t !== 'SURAH',
                ).map((t) => (
                  <option key={t} value={t}>
                    {TEMPLATE_ICON[t]} {TEMPLATE_LABEL[t]}
                  </option>
                ))}
              </select>
              {templateExplain ? (
                <span className="ks-muted" style={{ lineHeight: '1.7' }}>{templateExplain}</span>
              ) : null}
            </div>

            {templateType === 'QURAN_PAGE' ? (
              <label className="field">
                <span className="field-label-row">
                  چاپ قرآن
                  <HelpTip
                    term="چاپ قرآن"
                    explanation={'چاپ‌های مختلف قرآن تعداد صفحات متفاوتی دارند.\n\nمثلاً مصحف مدینه ۶۰۴ صفحه دارد. پیشرفت بر اساس همین تعداد کل محاسبه می‌شود.'}
                  />
                </span>
                <select value={quranEditionId} onChange={(e) => setQuranEditionId(e.target.value)}>
                  {QURAN_EDITIONS.map((ed) => (
                    <option key={ed.id} value={ed.id}>{ed.nameFa}</option>
                  ))}
                </select>
              </label>
            ) : null}

            {templateType === 'QURAN_SURAH' ? (
              <>
                <label className="field">
                  <span className="field-label-row">
                    سوره
                    <HelpTip
                      term="سوره"
                      explanation={'سوره‌ای که قرار است به تعداد مشخص خوانده شود.\n\nمثال: سوره یس را ۴۰ بار — مثلاً برای چهلم یا هفتگی.'}
                    />
                  </span>
                  <select
                    value={surahNumber}
                    onChange={(e) => setSurahNumber(parseInt(e.target.value, 10))}
                  >
                    {SURAHS.map((s) => (
                      <option key={s.number} value={s.number}>
                        {s.number}. {s.nameFa}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  <span className="field-label-row">
                    هدف تعداد
                    <HelpTip
                      term="هدف تعداد"
                      explanation={'چند بار در مجموع این سوره خوانده شود.\n\nمثال: ۴۰ بار، ۱۰۰ بار، ۱۰۰۰ بار. شرکت‌کنندگان هر بار که می‌خوانند ثبت می‌کنند و پیشرفت نشان داده می‌شود.'}
                    />
                  </span>
                  <input
                    type="number"
                    min="1"
                    value={repetitionTarget}
                    onChange={(e) => setRepetitionTarget(e.target.value)}
                    placeholder="مثلاً ۱۰۰۰"
                    required
                  />
                </label>
              </>
            ) : null}

            {['SALAWAT', 'DUA', 'ZIYARAT', 'CUSTOM'].includes(templateType) ? (
              <label className="field">
                <span className="field-label-row">
                  هدف تعداد (اختیاری)
                  <HelpTip
                    term="هدف تعداد"
                    explanation={'تعداد کل مورد نظر برای این ختم.\n\nمثال: ۱۰۰۰۰۰ صلوات یا ۱۴۰۰ دعا. اگر خالی بگذارید ختم بدون هدف عددی خواهد بود.'}
                  />
                </span>
                <input
                  type="number"
                  min="1"
                  value={countTarget}
                  onChange={(e) => setCountTarget(e.target.value)}
                  placeholder="مثلاً ۱۰۰۰۰۰"
                />
              </label>
            ) : null}

            {kind === 'open' ? (
              <p className="ks-note">
                <strong>ختم غیرتعهددار:</strong> شرکت‌کنندگان می‌توانند مشارکت خود را
                آزادانه ثبت کنند. پیشرفت به‌صورت مجموع کل مشارکت‌ها نمایش داده می‌شود.
              </p>
            ) : null}

            {error ? (
              <p className="alert" role="alert">
                {error}
              </p>
            ) : null}

            <div className="actions">
              <button
                className="btn btn-primary"
                type="submit"
                disabled={busy || !title.trim()}
              >
                {busy ? 'در حال ساخت…' : 'ساخت ختم'}
              </button>
              <Link href="/dashboard" className="btn btn-ghost">
                انصراف
              </Link>
            </div>
          </form>
        </section>
      </main>
    </div>
  );
}
