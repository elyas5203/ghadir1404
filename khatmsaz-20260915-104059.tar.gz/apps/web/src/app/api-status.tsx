'use client';

import { useEffect, useState } from 'react';
import { StatusCard, type StatusTone } from '@khatmsaz/ui';
import type { HealthResponse } from '@khatmsaz/contracts';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3001';

type Phase = 'checking' | 'online' | 'offline';

const LABEL: Record<Phase, { value: string; hint: string; tone: StatusTone }> = {
  checking: { value: 'در حال بررسی', hint: 'اتصال به سرویس', tone: 'neutral' },
  online: { value: 'برقرار', hint: 'سرویس در دسترس است', tone: 'success' },
  offline: { value: 'در دسترس نیست', hint: 'سرویس محلی اجرا نشده است', tone: 'warning' },
};

export function ApiStatus() {
  const [phase, setPhase] = useState<Phase>('checking');

  useEffect(() => {
    const controller = new AbortController();

    fetch(`${API_BASE_URL}/health`, { signal: controller.signal, cache: 'no-store' })
      .then((response) => (response.ok ? (response.json() as Promise<HealthResponse>) : null))
      .then((body) => setPhase(body?.status === 'ok' ? 'online' : 'offline'))
      .catch(() => {
        if (!controller.signal.aborted) setPhase('offline');
      });

    return () => controller.abort();
  }, []);

  const { value, hint, tone } = LABEL[phase];

  return <StatusCard label="ارتباط با سرویس" value={value} hint={hint} tone={tone} />;
}
