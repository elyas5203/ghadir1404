import Link from 'next/link';

const FEATURES = [
  {
    icon: '📖',
    text: 'ختم تعهددار یا آزاد — سهم‌بندی دقیق یا مشارکت آزاد، هر دو پشتیبانی می‌شوند',
  },
  {
    icon: '🔗',
    text: 'دعوت با لینک اختصاصی — شرکت‌کننده بدون نصب برنامه می‌پیوندد',
  },
  {
    icon: '📊',
    text: 'پیگیری پیشرفت گروه در لحظه — همه می‌بینند چقدر مانده است',
  },
];

export default function HomePage() {
  return (
    <div className="page page-ambient">
      <header className="shell masthead">
        <span className="wordmark">خدمتگزاران</span>
      </header>

      <main className="shell hero">
        <div>
          <h1>ختم‌ساز</h1>
          <p>
            ختم‌های گروهی را بسازید، سهم هر نفر را مشخص کنید و روند کار را
            با آرامش دنبال کنید.
          </p>

          <div className="hero-features" style={{ marginBlockStart: 'var(--ks-space-5)' }}>
            {FEATURES.map((f) => (
              <div className="hero-feature" key={f.icon}>
                <span className="hero-feature-icon" aria-hidden="true">{f.icon}</span>
                <span>{f.text}</span>
              </div>
            ))}
          </div>

          <div className="actions" style={{ marginBlockStart: 'var(--ks-space-6)' }}>
            <Link href="/login" className="btn btn-primary">
              ورود یا ثبت‌نام
            </Link>
          </div>
        </div>
      </main>

      <footer className="shell footer">خدمتگزاران · نسخهٔ آزمایشی</footer>
    </div>
  );
}
