import type { Metadata } from 'next';

/**
 * Public-access disabled page. Shown when WEB_APP_ENABLED != "true".
 * Code is preserved; no data is deleted. Re-enable via env var + restart.
 */
export const metadata: Metadata = {
  title: 'ختم‌ساز — در دسترس نیست',
  robots: { index: false, follow: false },
};

export default function DisabledPage() {
  return (
    <div
      style={{
        minHeight: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem',
        textAlign: 'center',
        fontFamily: 'Vazirmatn, system-ui, sans-serif',
        direction: 'rtl',
        background: 'var(--ks-color-bg, #f8f5f0)',
        color: 'var(--ks-color-text, #1a1a1a)',
        gap: '1.5rem',
      }}
    >
      <div style={{ fontSize: '3rem', lineHeight: 1 }}>📿</div>

      <h1
        style={{
          fontSize: 'clamp(1.4rem, 4vw, 2rem)',
          fontWeight: 700,
          margin: 0,
          color: 'var(--ks-color-primary-strong, #1e3e90)',
        }}
      >
        ختم‌ساز
      </h1>

      <p
        style={{
          maxWidth: '28rem',
          fontSize: '1rem',
          lineHeight: 1.8,
          color: 'var(--ks-color-text-muted, #555)',
          margin: 0,
        }}
      >
        در حال حاضر دسترسی به وب‌اپلیکیشن متوقف شده است.
        <br />
        برای استفاده از خدمات ختم‌ساز، از ربات تلگرام یا بله استفاده کنید.
      </p>

      {process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME ? (
        <a
          href={`https://t.me/${process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME}`}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            padding: '0.75rem 1.5rem',
            background: '#0088cc',
            color: '#fff',
            borderRadius: '0.75rem',
            textDecoration: 'none',
            fontWeight: 600,
            fontSize: '1rem',
          }}
        >
          ربات تلگرام
        </a>
      ) : null}

      <p style={{ fontSize: '0.8rem', color: 'var(--ks-color-text-muted, #888)', margin: 0 }}>
        خدمتگزاران · ختم‌ساز
      </p>
    </div>
  );
}
