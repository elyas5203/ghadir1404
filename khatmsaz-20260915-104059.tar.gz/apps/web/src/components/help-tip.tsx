'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

interface HelpTipProps {
  term: string;
  explanation: string;
}

interface PopoverPos {
  top: number;
  left: number;
}

export function HelpTip({ term, explanation }: HelpTipProps) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<PopoverPos | null>(null);
  const wrapRef = useRef<HTMLSpanElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  const popoverRef = useRef<HTMLSpanElement>(null);

  const computePos = useCallback(() => {
    if (!btnRef.current) return;
    const btn = btnRef.current.getBoundingClientRect();
    const popW = 280;
    const gap = 8;
    // Center horizontally on the button, clamped to viewport
    const rawLeft = btn.left + btn.width / 2 - popW / 2;
    const margin = 12;
    const left = Math.max(margin, Math.min(rawLeft, window.innerWidth - popW - margin));
    // Place above button
    const top = btn.top - gap;
    setPos({ top, left });
  }, []);

  useEffect(() => {
    if (!open) { setPos(null); return; }
    computePos();
    window.addEventListener('resize', computePos);
    window.addEventListener('scroll', computePos, true);
    return () => {
      window.removeEventListener('resize', computePos);
      window.removeEventListener('scroll', computePos, true);
    };
  }, [open, computePos]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        wrapRef.current && !wrapRef.current.contains(e.target as Node) &&
        popoverRef.current && !popoverRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <span className="help-tip" ref={wrapRef}>
      <button
        ref={btnRef}
        type="button"
        className="help-tip-btn"
        aria-label={`راهنما: ${term}`}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        ?
      </button>
      {open && pos ? (
        <span
          ref={popoverRef}
          className="help-popover"
          role="tooltip"
          style={{
            top: pos.top,
            left: pos.left,
            transform: 'translateY(-100%)',
          }}
        >
          <span className="help-popover-title">{term}</span>
          {explanation}
        </span>
      ) : null}
    </span>
  );
}
