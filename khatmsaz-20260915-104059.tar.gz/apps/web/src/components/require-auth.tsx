'use client';

import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../lib/auth-context';
import { shouldRedirectToLogin } from '../lib/permissions';

/**
 * Client-side route guard: sends an unauthenticated visitor to /login. This is a UX
 * convenience ONLY — it is not a security control. Every protected API call is
 * authenticated and authorized by the backend regardless of what the UI renders.
 */
export function RequireAuth({ children }: { children: ReactNode }): ReactNode {
  const { phase } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (shouldRedirectToLogin(phase)) router.replace('/login');
  }, [phase, router]);

  if (phase !== 'authenticated') {
    return <p className="ks-muted" style={{ padding: 'var(--ks-space-8)' }}>در حال بارگذاری…</p>;
  }
  return <>{children}</>;
}
