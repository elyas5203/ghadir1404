import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Web-app access gate (DEC-NEXT-001).
 *
 * When WEB_APP_ENABLED is not "true", all public routes are rewritten to /disabled.
 * Admin routes (/admin/*) remain accessible regardless.
 * Re-enable by setting WEB_APP_ENABLED=true and restarting the web server.
 */
const WEB_ENABLED = process.env.WEB_APP_ENABLED === 'true';

export function middleware(request: NextRequest): NextResponse {
  if (WEB_ENABLED) return NextResponse.next();

  const { pathname } = request.nextUrl;

  // Admin section stays accessible
  if (pathname.startsWith('/admin')) return NextResponse.next();

  // Next.js internals and static assets pass through
  if (
    pathname.startsWith('/_next') ||
    pathname === '/favicon.ico' ||
    pathname.startsWith('/icons') ||
    pathname.startsWith('/images')
  ) {
    return NextResponse.next();
  }

  // Already on the disabled page — do not loop
  if (pathname === '/disabled') return NextResponse.next();

  // Everything else → disabled page
  const url = request.nextUrl.clone();
  url.pathname = '/disabled';
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon\\.ico).*)'],
};
