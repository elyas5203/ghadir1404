'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { MeResponse, PhoneSessionResponse, RequestOtpResponse } from '@khatmsaz/contracts';
import { apiRequest } from './api-client';
import type { AuthPhase } from './permissions';

interface AuthState {
  readonly phase: AuthPhase;
  readonly me: MeResponse | null;
  /** Phone-first login step 1: request an OTP for a number. */
  requestLoginCode: (phone: string) => Promise<RequestOtpResponse>;
  /** Step 2: verify the code (the server sets the session cookie), then load /api/me. */
  verifyLoginCode: (phone: string, code: string) => Promise<void>;
  /** Revoke the session server-side (clears the cookie) and clear local state. */
  logout: () => Promise<void>;
  /** Run an API call within the current (cookie) session. */
  authed: <T>(path: string, options?: { method?: 'GET' | 'POST' | 'PUT'; body?: unknown }) => Promise<T>;
}

const AuthContext = createContext<AuthState | null>(null);

/**
 * Cookie-based session state (DEC-0067). The session token lives ONLY in an httpOnly
 * cookie the browser sends automatically — this code never sees or stores it. On
 * mount it asks `/api/me` to restore the session across reloads. The backend remains
 * the single authority; `me` is a rendering hint, never a security decision.
 */
export function AuthProvider({ children }: { children: ReactNode }): ReactNode {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [phase, setPhase] = useState<AuthPhase>('loading');

  const refresh = useCallback(async () => {
    try {
      const principal = await apiRequest<MeResponse>('/api/me');
      setMe(principal);
      setPhase('authenticated');
    } catch {
      setMe(null);
      setPhase('anonymous');
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const requestLoginCode = useCallback(
    (phone: string): Promise<RequestOtpResponse> =>
      apiRequest<RequestOtpResponse>('/api/auth/phone/request', { method: 'POST', body: { phone } }),
    [],
  );

  const verifyLoginCode = useCallback(
    async (phone: string, code: string): Promise<void> => {
      await apiRequest<PhoneSessionResponse>('/api/auth/phone/verify', {
        method: 'POST',
        body: { phone, code },
      });
      await refresh();
    },
    [refresh],
  );

  const logout = useCallback(async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    setMe(null);
    setPhase('anonymous');
  }, []);

  const authed = useCallback(
    <T,>(path: string, options?: { method?: 'GET' | 'POST' | 'PUT'; body?: unknown }): Promise<T> =>
      apiRequest<T>(path, options),
    [],
  );

  const value = useMemo<AuthState>(
    () => ({ phase, me, requestLoginCode, verifyLoginCode, logout, authed }),
    [phase, me, requestLoginCode, verifyLoginCode, logout, authed],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider.');
  return ctx;
}
