/**
 * Pure UI-gating helpers. These decide what the interface OFFERS — never what is
 * ALLOWED. The backend re-authorizes every action (DEC-0061); the UI must never
 * trust its own permission state. Kept pure so they are unit-testable.
 */

import type { MeResponse } from '@khatmsaz/contracts';

export type AuthPhase = 'loading' | 'authenticated' | 'anonymous';

/** Whether to show the "create khatm" affordance. A missing/plain user → false. */
export function canCreateKhatm(me: MeResponse | null): boolean {
  return me?.isCreator === true;
}

/** Whether an unauthenticated visitor should be redirected to the login page. */
export function shouldRedirectToLogin(phase: AuthPhase): boolean {
  return phase === 'anonymous';
}
