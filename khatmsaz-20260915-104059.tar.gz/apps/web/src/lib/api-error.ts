/**
 * A typed transport error mirroring the backend's stable `{ error: { code, message } }`
 * envelope (DEC-0057). Pure and framework-free so it is unit-testable. The `message`
 * is safe to surface to the user (the backend guarantees it carries no secret/PII).
 */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }

  /** Authentication failure (no/expired/invalid session) — the UI redirects to login. */
  get isUnauthenticated(): boolean {
    return this.status === 401;
  }

  /** Authorization failure (not allowed) — distinct from authentication. */
  get isForbidden(): boolean {
    return this.status === 403;
  }
}

/** Build an {@link ApiError} from an HTTP status and a parsed response body. */
export function parseErrorBody(status: number, body: unknown): ApiError {
  if (body !== null && typeof body === 'object' && 'error' in body) {
    const err = (body as { error?: unknown }).error;
    if (err !== null && typeof err === 'object') {
      const code = (err as { code?: unknown }).code;
      const message = (err as { message?: unknown }).message;
      return new ApiError(
        status,
        typeof code === 'string' ? code : `HTTP_${status}`,
        typeof message === 'string' ? message : 'خطای ناشناخته رخ داد.',
      );
    }
  }
  return new ApiError(status, `HTTP_${status}`, 'خطای ناشناخته رخ داد.');
}
