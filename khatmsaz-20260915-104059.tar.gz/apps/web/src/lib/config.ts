/** The KhatmSaz HTTP API base URL. Public (non-secret) build-time value. */
export const API_BASE_URL: string =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3001';
