/**
 * The single HTTP boundary the web app talks through. It serialises JSON and turns
 * a non-2xx response into a typed {@link ApiError} using the backend's stable error
 * envelope. Authentication rides an httpOnly session cookie (DEC-0067): every
 * request is sent with `credentials: 'include'` and the raw token is NEVER seen by
 * this code. It contains NO business logic — the backend owns every rule and
 * re-authorizes every action (DEC-0061).
 */

import { API_BASE_URL } from './config';
import { parseErrorBody } from './api-error';

export interface RequestOptions {
  readonly method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  readonly body?: unknown;
  readonly signal?: AbortSignal;
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? 'GET',
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    cache: 'no-store',
    credentials: 'include',
    signal: options.signal,
  });

  if (response.status === 204) return undefined as T;

  const text = await response.text();
  let body: unknown;
  if (text.length > 0) {
    try {
      body = JSON.parse(text);
    } catch {
      body = undefined;
    }
  }

  if (!response.ok) throw parseErrorBody(response.status, body);
  return body as T;
}
