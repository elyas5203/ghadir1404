import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Admin panel route guard. Unauthenticated visitors are redirected to /login.
 * The actual admin role check is done server-side; the middleware only checks
 * the presence of the session cookie (not its value).
 */
export function middleware(request: NextRequest): NextResponse {
  const { pathname } = request.nextUrl;

  if (pathname === '/login') return NextResponse.next();
  if (pathname.startsWith('/_next') || pathname === '/favicon.ico') return NextResponse.next();

  const hasSession = request.cookies.has('khatmsaz_session');
  if (!hasSession) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon\\.ico).*)'],
};
