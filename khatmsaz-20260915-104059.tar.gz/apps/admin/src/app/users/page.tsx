'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AdminShell } from '../../components/AdminShell';
import { useAuth } from '../../lib/auth-context';

interface UserAdminDto {
  id: string;
  displayName: string | null;
  mobileMasked: string | null;
  role: string;
  status: string;
  createdAt: string;
  khatmCount: number;
}

const PAGE_SIZE = 20;

function statusLabel(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'فعال';
    case 'WARNED': return 'اخطار';
    case 'SUSPENDED': return 'تعلیق';
    case 'BANNED': return 'مسدود';
    case 'MERGED': return 'ادغام‌شده';
    default: return s;
  }
}

function statusBadgeClass(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'badge badge--active';
    case 'WARNED': return 'badge badge--warned';
    case 'SUSPENDED': return 'badge badge--suspended';
    case 'BANNED': return 'badge badge--banned';
    default: return 'badge badge--merged';
  }
}

export default function UsersPage() {
  const { phase, authed } = useAuth();
  const router = useRouter();

  const [users, setUsers] = useState<UserAdminDto[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(
    async (p: number) => {
      setLoading(true);
      setError('');
      try {
        const params = new URLSearchParams({ page: String(p), limit: String(PAGE_SIZE) });
        const data = await authed<{ items: UserAdminDto[]; total: number }>(
          `/api/admin/users?${params.toString()}`,
        );
        setUsers(data.items);
        setTotal(data.total);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطا در بارگذاری کاربران.');
      } finally {
        setLoading(false);
      }
    },
    [authed],
  );

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    void load(page);
  }, [phase, router, load, page]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <AdminShell>
      <h1 className="admin-page-title">فهرست کاربران</h1>

      {error && <p style={{ color: '#dc2626' }}>{error}</p>}

      <div className="table-toolbar">
        <span className="table-total">{total.toLocaleString('fa-IR')} کاربر</span>
      </div>

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>نام</th>
              <th>موبایل (ماسک‌شده)</th>
              <th>نقش</th>
              <th>وضعیت</th>
              <th>ختم‌ها</th>
              <th>تاریخ ثبت</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={7} style={{ textAlign: 'center', padding: '2rem' }}>در حال بارگذاری…</td>
              </tr>
            ) : users.length === 0 ? (
              <tr>
                <td colSpan={7} style={{ textAlign: 'center', padding: '2rem' }}>کاربری یافت نشد.</td>
              </tr>
            ) : (
              users.map((u) => (
                <tr key={u.id}>
                  <td>{u.displayName ?? '—'}</td>
                  <td dir="ltr" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {u.mobileMasked ?? '—'}
                  </td>
                  <td>{u.role === 'SUPER_ADMIN' ? 'مدیر ارشد' : 'کاربر'}</td>
                  <td><span className={statusBadgeClass(u.status)}>{statusLabel(u.status)}</span></td>
                  <td>{u.khatmCount.toLocaleString('fa-IR')}</td>
                  <td>{new Date(u.createdAt).toLocaleDateString('fa-IR')}</td>
                  <td>
                    <Link href={`/customers/${u.id}`} className="btn btn--secondary btn--sm">
                      جزئیات
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 ? (
        <div className="pagination" style={{ display: 'flex', gap: 'var(--space-2)', justifyContent: 'center', marginBlockStart: 'var(--space-4)' }}>
          <button
            className="btn btn--secondary btn--sm"
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
          >
            قبلی
          </button>
          <span style={{ alignSelf: 'center' }}>{page.toLocaleString('fa-IR')} / {totalPages.toLocaleString('fa-IR')}</span>
          <button
            className="btn btn--secondary btn--sm"
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
          >
            بعدی
          </button>
        </div>
      ) : null}
    </AdminShell>
  );
}
