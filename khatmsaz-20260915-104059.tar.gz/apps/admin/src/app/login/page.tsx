'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../../lib/auth-context';

type LoginStep = 'phone' | 'otp';

export default function LoginPage() {
  const { requestLoginCode, verifyLoginCode, phase } = useAuth();
  const router = useRouter();

  const [step, setStep] = useState<LoginStep>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (phase === 'authenticated') {
    router.replace('/dashboard');
    return null;
  }

  async function handleRequestCode(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await requestLoginCode(phone);
      setStep('otp');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در ارسال کد.');
    } finally {
      setBusy(false);
    }
  }

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await verifyLoginCode(phone, code);
      router.replace('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'کد نامعتبر است.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-box">
        <h1 className="login-title">پنل مدیریت ختم‌ساز</h1>
        <p className="login-subtitle">ورود با شماره موبایل</p>

        {step === 'phone' ? (
          <form className="admin-form" onSubmit={(e) => void handleRequestCode(e)}>
            <label>
              شماره موبایل
              <input
                type="tel"
                dir="ltr"
                placeholder="+989..."
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                autoComplete="tel"
              />
            </label>
            {error && <p className="error-msg">{error}</p>}
            <button className="btn btn--primary" type="submit" disabled={busy}>
              {busy ? 'در حال ارسال...' : 'دریافت کد تأیید'}
            </button>
          </form>
        ) : (
          <form className="admin-form" onSubmit={(e) => void handleVerify(e)}>
            <label>
              کد تأیید
              <input
                type="text"
                inputMode="numeric"
                dir="ltr"
                placeholder="------"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
                autoComplete="one-time-code"
              />
            </label>
            {error && <p className="error-msg">{error}</p>}
            <button className="btn btn--primary" type="submit" disabled={busy}>
              {busy ? 'در حال بررسی...' : 'ورود'}
            </button>
            <button
              type="button"
              className="btn btn--secondary"
              onClick={() => { setStep('phone'); setCode(''); setError(''); }}
            >
              تغییر شماره
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
