'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AdminShell } from '../../components/AdminShell';
import { useAuth } from '../../lib/auth-context';

interface KhatmRow {
  id: string;
  title: string;
  status: string;
  templateType: string;
  khatmType: string;
  creatorUserId: string;
  createdAt: string;
}

const PAGE_SIZE = 50;

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'پیش‌نویس',
  ACTIVE: 'فعال',
  COMPLETED: 'تمام‌شده',
  CANCELLED: 'لغوشده',
};

export default function KhatmsPage() {
  const { phase, authed } = useAuth();
  const router = useRouter();

  const [khatms, setKhatms] = useState<KhatmRow[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    setLoading(true);
    setError('');
    const params = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(offset) });
    if (statusFilter) params.set('status', statusFilter);
    authed<KhatmRow[]>(`/api/admin/khatms?${params.toString()}`)
      .then(setKhatms)
      .catch((err) => setError(err instanceof Error ? err.message : 'خطا در بارگذاری.'))
      .finally(() => setLoading(false));
  }, [phase, authed, offset, statusFilter, router]);

  if (phase === 'loading') return null;

  return (
    <AdminShell>
      <h1 className="admin-page-title">ختم‌ها</h1>

      <div style={{ display: 'flex', gap: 'var(--ks-space-3)', marginBottom: 'var(--ks-space-5)', flexWrap: 'wrap' }}>
        {['', 'DRAFT', 'ACTIVE', 'COMPLETED', 'CANCELLED'].map((s) => (
          <button
            key={s}
            className={`btn btn--sm ${statusFilter === s ? 'btn--primary' : 'btn--secondary'}`}
            onClick={() => { setStatusFilter(s); setOffset(0); }}
          >
            {s ? (STATUS_LABELS[s] ?? s) : 'همه'}
          </button>
        ))}
      </div>

      {error && <p style={{ color: '#dc2626', marginBottom: '1rem' }}>{error}</p>}

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>عنوان</th>
              <th>وضعیت</th>
              <th>نوع قالب</th>
              <th>تاریخ ایجاد</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  در حال بارگذاری...
                </td>
              </tr>
            )}
            {!loading && khatms.length === 0 && (
              <tr>
                <td colSpan={5} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  ختمی یافت نشد.
                </td>
              </tr>
            )}
            {khatms.map((k) => (
              <tr key={k.id}>
                <td>{k.title}</td>
                <td>{STATUS_LABELS[k.status] ?? k.status}</td>
                <td>{k.templateType}</td>
                <td dir="ltr" style={{ fontVariantNumeric: 'tabular-nums', fontSize: 'var(--ks-text-xs)' }}>
                  {new Date(k.createdAt).toLocaleDateString('fa-IR')}
                </td>
                <td>
                  <Link href={`/khatms/${k.id}`} className="btn btn--secondary btn--sm">
                    جزئیات
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <span className="pagination__info">{offset + 1}–{offset + khatms.length}</span>
        <button
          className="btn btn--secondary btn--sm"
          disabled={offset === 0}
          onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
        >
          قبلی
        </button>
        <button
          className="btn btn--secondary btn--sm"
          disabled={khatms.length < PAGE_SIZE}
          onClick={() => setOffset(offset + PAGE_SIZE)}
        >
          بعدی
        </button>
      </div>
    </AdminShell>
  );
}
