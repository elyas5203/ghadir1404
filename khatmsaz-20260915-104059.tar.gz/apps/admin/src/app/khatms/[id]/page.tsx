'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { AdminShell } from '../../../components/AdminShell';
import { useAuth } from '../../../lib/auth-context';

interface KhatmDetail {
  id: string;
  title: string;
  description: string | null;
  status: string;
  templateType: string;
  khatmType: string;
  creatorUserId: string;
  createdAt: string;
}

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'پیش‌نویس',
  ACTIVE: 'فعال',
  COMPLETED: 'تمام‌شده',
  CANCELLED: 'لغوشده',
};

export default function KhatmDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { phase, authed } = useAuth();
  const router = useRouter();
  const [khatm, setKhatm] = useState<KhatmDetail | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    authed<KhatmDetail>(`/api/admin/khatms/${id}`)
      .then(setKhatm)
      .catch((err) => setError(err instanceof Error ? err.message : 'خطا در بارگذاری.'));
  }, [phase, authed, id, router]);

  if (phase === 'loading' || !khatm) return null;

  return (
    <AdminShell>
      <div style={{ marginBottom: 'var(--ks-space-4)' }}>
        <Link href="/khatms" className="btn btn--secondary btn--sm">← بازگشت</Link>
      </div>

      <h1 className="admin-page-title">{khatm.title}</h1>
      {error && <p style={{ color: '#dc2626', marginBottom: '1rem' }}>{error}</p>}

      <div className="detail-card">
        <div className="detail-card__row">
          <span className="detail-card__label">شناسه</span>
          <span className="detail-card__value" dir="ltr">{khatm.id}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">وضعیت</span>
          <span className="detail-card__value">{STATUS_LABELS[khatm.status] ?? khatm.status}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">نوع قالب</span>
          <span className="detail-card__value">{khatm.templateType}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">نوع ختم</span>
          <span className="detail-card__value">{khatm.khatmType}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">سازنده</span>
          <span className="detail-card__value">
            <Link href={`/customers/${khatm.creatorUserId}`} dir="ltr">
              {khatm.creatorUserId}
            </Link>
          </span>
        </div>
        {khatm.description && (
          <div className="detail-card__row">
            <span className="detail-card__label">توضیحات</span>
            <span className="detail-card__value">{khatm.description}</span>
          </div>
        )}
        <div className="detail-card__row">
          <span className="detail-card__label">تاریخ ایجاد</span>
          <span className="detail-card__value" dir="ltr">
            {new Date(khatm.createdAt).toLocaleDateString('fa-IR')}
          </span>
        </div>
      </div>
    </AdminShell>
  );
}
