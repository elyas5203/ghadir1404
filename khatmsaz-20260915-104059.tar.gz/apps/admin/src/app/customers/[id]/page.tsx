'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { AdminShell } from '../../../components/AdminShell';
import { useAuth } from '../../../lib/auth-context';

interface KhatmSummary {
  id: string;
  title: string;
  status: string;
  templateType: string;
  khatmType: string;
}

interface CustomerDetail {
  id: string;
  displayName: string | null;
  role: string;
  status: string;
  createdAt: string;
  hasCreatorCapability: boolean;
  khatms: KhatmSummary[];
}

function statusLabel(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'فعال';
    case 'WARNED': return 'اخطار';
    case 'SUSPENDED': return 'تعلیق';
    case 'BANNED': return 'مسدود';
    case 'MERGED': return 'ادغام‌شده';
    default: return s;
  }
}

function statusBadgeClass(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'badge badge--active';
    case 'WARNED': return 'badge badge--warned';
    case 'SUSPENDED': return 'badge badge--suspended';
    case 'BANNED': return 'badge badge--banned';
    default: return 'badge badge--merged';
  }
}

export default function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { phase, authed } = useAuth();
  const router = useRouter();

  const [user, setUser] = useState<CustomerDetail | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [actionMsg, setActionMsg] = useState('');

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    authed<CustomerDetail>(`/api/admin/customers/${id}`)
      .then(setUser)
      .catch((err) => setError(err instanceof Error ? err.message : 'خطا در بارگذاری.'));
  }, [phase, authed, id, router]);

  async function doAction(path: string, body?: object) {
    setBusy(true);
    setActionMsg('');
    setError('');
    try {
      await authed(`/api/admin/customers/${id}/${path}`, { method: 'POST', body });
      const updated = await authed<CustomerDetail>(`/api/admin/customers/${id}`);
      setUser(updated);
      setActionMsg('عملیات با موفقیت انجام شد.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در انجام عملیات.');
    } finally {
      setBusy(false);
    }
  }

  if (phase === 'loading' || !user) return null;

  const isMergeable = user.status !== 'MERGED';

  return (
    <AdminShell>
      <div style={{ marginBottom: 'var(--ks-space-4)' }}>
        <Link href="/customers" className="btn btn--secondary btn--sm">← بازگشت</Link>
      </div>

      <h1 className="admin-page-title">{user.displayName ?? 'کاربر بدون نام'}</h1>

      {error && <p style={{ color: '#dc2626', marginBottom: '1rem' }}>{error}</p>}
      {actionMsg && <p style={{ color: '#065f46', marginBottom: '1rem' }}>{actionMsg}</p>}

      <div className="detail-card">
        <div className="detail-card__row">
          <span className="detail-card__label">شناسه</span>
          <span className="detail-card__value" dir="ltr">{user.id}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">نقش</span>
          <span className="detail-card__value">{user.role === 'SUPER_ADMIN' ? 'مدیر ارشد' : 'کاربر'}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">وضعیت</span>
          <span className="detail-card__value">
            <span className={statusBadgeClass(user.status)}>{statusLabel(user.status)}</span>
          </span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">قابلیت سازنده</span>
          <span className="detail-card__value">{user.hasCreatorCapability ? 'دارد' : 'ندارد'}</span>
        </div>
        <div className="detail-card__row">
          <span className="detail-card__label">تاریخ ثبت</span>
          <span className="detail-card__value" dir="ltr">
            {new Date(user.createdAt).toLocaleDateString('fa-IR')}
          </span>
        </div>
      </div>

      {isMergeable && (
        <>
          <h2 style={{ fontSize: 'var(--ks-text-md)', fontWeight: 600, margin: '0 0 var(--ks-space-3)' }}>
            اقدامات مدیریتی
          </h2>
          <div className="action-group">
            {user.status !== 'ACTIVE' && (
              <button
                className="btn btn--primary btn--sm"
                disabled={busy}
                onClick={() => void doAction('status', { status: 'ACTIVE' })}
              >
                فعال‌سازی مجدد
              </button>
            )}
            {user.status !== 'WARNED' && (
              <button
                className="btn btn--warn btn--sm"
                disabled={busy}
                onClick={() => void doAction('status', { status: 'WARNED' })}
              >
                اخطار
              </button>
            )}
            {user.status !== 'SUSPENDED' && (
              <button
                className="btn btn--warn btn--sm"
                disabled={busy}
                onClick={() => void doAction('status', { status: 'SUSPENDED' })}
              >
                تعلیق
              </button>
            )}
            {user.status !== 'BANNED' && (
              <button
                className="btn btn--danger btn--sm"
                disabled={busy}
                onClick={() => void doAction('status', { status: 'BANNED' })}
              >
                مسدودسازی دائم
              </button>
            )}
          </div>

          <div className="action-group">
            {user.hasCreatorCapability ? (
              <button
                className="btn btn--secondary btn--sm"
                disabled={busy}
                onClick={() => void doAction('revoke-creator')}
              >
                لغو قابلیت سازنده
              </button>
            ) : (
              <button
                className="btn btn--secondary btn--sm"
                disabled={busy}
                onClick={() => void doAction('grant-creator')}
              >
                اعطای قابلیت سازنده
              </button>
            )}
            {user.role !== 'SUPER_ADMIN' && (
              <button
                className="btn btn--secondary btn--sm"
                disabled={busy}
                onClick={() => void doAction('promote')}
              >
                ارتقا به مدیر ارشد
              </button>
            )}
          </div>
        </>
      )}

      <h2 style={{ fontSize: 'var(--ks-text-md)', fontWeight: 600, margin: '0 0 var(--ks-space-3)' }}>
        ختم‌های ایجادشده ({user.khatms.length})
      </h2>
      {user.khatms.length === 0 ? (
        <p style={{ color: 'var(--ks-color-text-muted)' }}>ختمی ثبت نشده است.</p>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>عنوان</th>
                <th>وضعیت</th>
                <th>نوع قالب</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {user.khatms.map((k) => (
                <tr key={k.id}>
                  <td>{k.title}</td>
                  <td>{k.status}</td>
                  <td>{k.templateType}</td>
                  <td>
                    <Link href={`/khatms/${k.id}`} className="btn btn--secondary btn--sm">
                      جزئیات
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminShell>
  );
}
