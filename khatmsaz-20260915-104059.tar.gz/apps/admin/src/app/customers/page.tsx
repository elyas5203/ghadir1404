'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AdminShell } from '../../components/AdminShell';
import { useAuth } from '../../lib/auth-context';

interface Customer {
  id: string;
  displayName: string | null;
  role: string;
  status: string;
  createdAt: string;
}

const PAGE_SIZE = 50;

function statusLabel(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'فعال';
    case 'WARNED': return 'اخطار';
    case 'SUSPENDED': return 'تعلیق';
    case 'BANNED': return 'مسدود';
    case 'MERGED': return 'ادغام‌شده';
    default: return s;
  }
}

function statusBadgeClass(s: string): string {
  switch (s) {
    case 'ACTIVE': return 'badge badge--active';
    case 'WARNED': return 'badge badge--warned';
    case 'SUSPENDED': return 'badge badge--suspended';
    case 'BANNED': return 'badge badge--banned';
    default: return 'badge badge--merged';
  }
}

export default function CustomersPage() {
  const { phase, authed } = useAuth();
  const router = useRouter();

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(
    async (q: string, off: number) => {
      setLoading(true);
      setError('');
      try {
        const params = new URLSearchParams({
          limit: String(PAGE_SIZE),
          offset: String(off),
        });
        if (q.trim()) params.set('search', q.trim());
        const data = await authed<Customer[]>(`/api/admin/customers?${params.toString()}`);
        setCustomers(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطا در بارگذاری.');
      } finally {
        setLoading(false);
      }
    },
    [authed],
  );

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    void load(search, offset);
  }, [phase, load, search, offset, router]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setOffset(0);
    void load(search, 0);
  }

  if (phase === 'loading') return null;

  return (
    <AdminShell>
      <h1 className="admin-page-title">کاربران</h1>

      <form className="admin-search" onSubmit={handleSearch}>
        <input
          type="search"
          placeholder="جستجو بر اساس نام یا شناسه..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button className="btn btn--primary" type="submit">جستجو</button>
        {search && (
          <button
            className="btn btn--secondary"
            type="button"
            onClick={() => { setSearch(''); setOffset(0); void load('', 0); }}
          >
            پاک‌کردن
          </button>
        )}
      </form>

      {error && <p style={{ color: '#dc2626', marginBottom: '1rem' }}>{error}</p>}

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>نام</th>
              <th>نقش</th>
              <th>وضعیت</th>
              <th>تاریخ ثبت</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  در حال بارگذاری...
                </td>
              </tr>
            )}
            {!loading && customers.length === 0 && (
              <tr>
                <td colSpan={5} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  کاربری یافت نشد.
                </td>
              </tr>
            )}
            {customers.map((c) => (
              <tr key={c.id}>
                <td>{c.displayName ?? <em style={{ color: 'var(--ks-color-text-muted)' }}>بدون نام</em>}</td>
                <td>{c.role === 'SUPER_ADMIN' ? 'مدیر' : 'کاربر'}</td>
                <td>
                  <span className={statusBadgeClass(c.status)}>{statusLabel(c.status)}</span>
                </td>
                <td dir="ltr" style={{ fontVariantNumeric: 'tabular-nums', fontSize: 'var(--ks-text-xs)' }}>
                  {new Date(c.createdAt).toLocaleDateString('fa-IR')}
                </td>
                <td>
                  <Link href={`/customers/${c.id}`} className="btn btn--secondary btn--sm">
                    مشاهده
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <span className="pagination__info">
          {offset + 1}–{offset + customers.length}
        </span>
        <button
          className="btn btn--secondary btn--sm"
          disabled={offset === 0}
          onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
        >
          قبلی
        </button>
        <button
          className="btn btn--secondary btn--sm"
          disabled={customers.length < PAGE_SIZE}
          onClick={() => setOffset(offset + PAGE_SIZE)}
        >
          بعدی
        </button>
      </div>
    </AdminShell>
  );
}
