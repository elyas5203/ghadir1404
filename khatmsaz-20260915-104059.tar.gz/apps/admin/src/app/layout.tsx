import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import '@khatmsaz/ui/tokens.css';
import '@khatmsaz/ui/base.css';
import './globals.css';
import { AuthProvider } from '../lib/auth-context';

export const metadata: Metadata = {
  title: 'پنل مدیریت ختم‌ساز',
  description: 'مدیریت ختم‌ساز',
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#1e4736',
};

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
