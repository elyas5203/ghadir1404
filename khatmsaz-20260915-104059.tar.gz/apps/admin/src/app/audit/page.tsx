'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { AdminShell } from '../../components/AdminShell';
import { useAuth } from '../../lib/auth-context';

interface AuditRow {
  id: string;
  actor_id: string | null;
  actor_type: string;
  action: string;
  target_type: string | null;
  target_id: string | null;
  meta: Record<string, unknown> | null;
  created_at: string;
}

const PAGE_SIZE = 50;

export default function AuditPage() {
  const { phase, authed } = useAuth();
  const router = useRouter();

  const [rows, setRows] = useState<AuditRow[]>([]);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    setLoading(true);
    setError('');
    authed<AuditRow[]>(`/api/admin/audit?limit=${PAGE_SIZE}&offset=${offset}`)
      .then(setRows)
      .catch((err) => setError(err instanceof Error ? err.message : 'خطا در بارگذاری.'))
      .finally(() => setLoading(false));
  }, [phase, authed, offset, router]);

  if (phase === 'loading') return null;

  return (
    <AdminShell>
      <h1 className="admin-page-title">گزارش فعالیت</h1>

      {error && <p style={{ color: '#dc2626', marginBottom: '1rem' }}>{error}</p>}

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>زمان</th>
              <th>اقدام</th>
              <th>هدف</th>
              <th>اطلاعات</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={4} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  در حال بارگذاری...
                </td>
              </tr>
            )}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={4} style={{ color: 'var(--ks-color-text-muted)', padding: '2rem' }}>
                  رکوردی یافت نشد.
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr key={r.id}>
                <td dir="ltr" style={{ fontVariantNumeric: 'tabular-nums', fontSize: 'var(--ks-text-xs)', whiteSpace: 'nowrap' }}>
                  {new Date(r.created_at).toLocaleString('fa-IR')}
                </td>
                <td>
                  <code style={{ fontSize: 'var(--ks-text-xs)' }}>{r.action}</code>
                </td>
                <td style={{ fontSize: 'var(--ks-text-xs)', color: 'var(--ks-color-text-muted)' }}>
                  {r.target_type && `${r.target_type}:`}
                  {r.target_id && <span dir="ltr">{r.target_id.slice(0, 8)}…</span>}
                </td>
                <td style={{ fontSize: 'var(--ks-text-xs)', color: 'var(--ks-color-text-muted)' }}>
                  {r.meta ? JSON.stringify(r.meta) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <span className="pagination__info">{offset + 1}–{offset + rows.length}</span>
        <button
          className="btn btn--secondary btn--sm"
          disabled={offset === 0}
          onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
        >
          قبلی
        </button>
        <button
          className="btn btn--secondary btn--sm"
          disabled={rows.length < PAGE_SIZE}
          onClick={() => setOffset(offset + PAGE_SIZE)}
        >
          بعدی
        </button>
      </div>
    </AdminShell>
  );
}
