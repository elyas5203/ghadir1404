'use client';

import type { ReactNode } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '../lib/auth-context';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'داشبورد' },
  { href: '/users', label: 'کاربران' },
  { href: '/customers', label: 'مدیریت کاربران' },
  { href: '/khatms', label: 'ختم‌ها' },
  { href: '/audit', label: 'گزارش فعالیت' },
];

export function AdminShell({ children }: { children: ReactNode }) {
  const { me, logout } = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await logout();
    router.replace('/login');
  }

  return (
    <div className="admin-shell">
      <header className="admin-topbar">
        <div className="admin-topbar__inner">
          <span className="admin-topbar__brand">ختم‌ساز — مدیریت</span>
          <div className="admin-topbar__user">
            {me?.displayName ?? 'مدیر'}
            <button className="btn btn--secondary btn--sm" onClick={() => void handleLogout()}>
              خروج
            </button>
          </div>
        </div>
      </header>

      <nav className="admin-sidebar" aria-label="ناوبری اصلی">
        <ul className="admin-nav">
          {NAV_ITEMS.map((item) => (
            <li key={item.href} className="admin-nav__item">
              <Link href={item.href} aria-current={pathname === item.href ? 'page' : undefined}>
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <main className="admin-main">{children}</main>
    </div>
  );
}
