'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { apiRequest } from './api-client';
import { ApiError } from './api-error';

export interface AdminUser {
  id: string;
  displayName: string | null;
  role: string;
  status: string;
}

type AuthPhase = 'loading' | 'authenticated' | 'anonymous';

interface AuthState {
  phase: AuthPhase;
  me: AdminUser | null;
  requestLoginCode: (phone: string) => Promise<void>;
  verifyLoginCode: (phone: string, code: string) => Promise<void>;
  logout: () => Promise<void>;
  authed: <T>(path: string, options?: { method?: 'GET' | 'POST'; body?: unknown }) => Promise<T>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }): ReactNode {
  const [me, setMe] = useState<AdminUser | null>(null);
  const [phase, setPhase] = useState<AuthPhase>('loading');

  const refresh = useCallback(async () => {
    try {
      const principal = await apiRequest<AdminUser>('/api/me');
      if (principal.role !== 'SUPER_ADMIN') {
        setMe(null);
        setPhase('anonymous');
        return;
      }
      setMe(principal);
      setPhase('authenticated');
    } catch {
      setMe(null);
      setPhase('anonymous');
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const requestLoginCode = useCallback(async (phone: string): Promise<void> => {
    await apiRequest('/api/auth/phone/request', { method: 'POST', body: { phone } });
  }, []);

  const verifyLoginCode = useCallback(
    async (phone: string, code: string): Promise<void> => {
      await apiRequest('/api/auth/phone/verify', { method: 'POST', body: { phone, code } });
      await refresh();
    },
    [refresh],
  );

  const logout = useCallback(async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    setMe(null);
    setPhase('anonymous');
  }, []);

  const authed = useCallback(
    <T,>(path: string, options?: { method?: 'GET' | 'POST'; body?: unknown }): Promise<T> =>
      apiRequest<T>(path, options),
    [],
  );

  const value = useMemo<AuthState>(
    () => ({ phase, me, requestLoginCode, verifyLoginCode, logout, authed }),
    [phase, me, requestLoginCode, verifyLoginCode, logout, authed],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider.');
  return ctx;
}

export { ApiError };
