export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }

  get isUnauthenticated(): boolean {
    return this.status === 401;
  }

  get isForbidden(): boolean {
    return this.status === 403;
  }
}

export function parseErrorBody(status: number, body: unknown): ApiError {
  if (body !== null && typeof body === 'object' && 'error' in body) {
    const err = (body as { error?: unknown }).error;
    if (err !== null && typeof err === 'object') {
      const code = (err as { code?: unknown }).code;
      const message = (err as { message?: unknown }).message;
      return new ApiError(
        status,
        typeof code === 'string' ? code : `HTTP_${status}`,
        typeof message === 'string' ? message : 'خطای ناشناخته رخ داد.',
      );
    }
  }
  return new ApiError(status, `HTTP_${status}`, 'خطای ناشناخته رخ داد.');
}
