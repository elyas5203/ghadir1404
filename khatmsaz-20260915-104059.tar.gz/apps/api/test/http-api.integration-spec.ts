import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityService } from '../src/identity/application/identity.service';
import { AuthenticationService } from '../src/session/application/authentication.service';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';

/**
 * HTTP transport integration (requires local PostgreSQL,
 * `npm run test:integration:db`). Drives the REST boundary with supertest through
 * the real workflows and asserts responses, the error envelope, DB state, and
 * authentication (Phase 6): the user-scoped routes require a bearer token and derive
 * the user from the authenticated principal, not the body. Teardown is child-first.
 */
describe('http api transport (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let app: INestApplication;
  let prisma: PrismaService;
  let identity: IdentityService;
  let auth: AuthenticationService;
  let authz: AuthorizationService;

  const userIds: string[] = [];
  const khatmIds: string[] = [];
  let http: ReturnType<typeof request>;

  /** Create a user and an authenticated session; returns the id and a bearer token. */
  const newUserWithToken = async (): Promise<{ userId: string; token: string }> => {
    const user = await identity.createUser();
    userIds.push(user.id);
    const { token } = await auth.createSession(user.id);
    return { userId: user.id, token };
  };
  /** A user with the CREATOR capability granted (may create khatms). */
  const newCreatorWithToken = async (): Promise<{ userId: string; token: string }> => {
    const u = await newUserWithToken();
    await authz.grantCapability(u.userId, CapabilityType.CREATOR);
    return u;
  };
  const bearer = (token: string): string => `Bearer ${token}`;

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    await app.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    auth = moduleRef.get(AuthenticationService);
    authz = moduleRef.get(AuthorizationService);
    http = request(app.getHttpServer());
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.participation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('runs the full HTTP journey: create → plan → activate → join → allocate → complete', async () => {
    const creator = await newCreatorWithToken();
    const joiner = await newUserWithToken();

    // Create (201, DRAFT). The creator is the authenticated principal, not the body.
    const createRes = await http
      .post('/api/khatms')
      .set('Authorization', bearer(creator.token))
      .send({ title: 'ختم قرآن', templateType: 'QURAN_FULL' })
      .expect(201);
    expect(createRes.body).toMatchObject({ creatorUserId: creator.userId, status: 'DRAFT', title: 'ختم قرآن' });
    const khatmId = createRes.body.id as string;
    khatmIds.push(khatmId);

    // Generate plan (5 units) and activate. All khatm routes require a session.
    await http
      .post(`/api/khatms/${khatmId}/plan`)
      .set('Authorization', bearer(creator.token))
      .send({ spec: { kind: 'POSITIONAL', from: 1, to: 5 } })
      .expect(201)
      .expect((r) => expect(r.body).toMatchObject({ khatmId, unitKind: 'POSITIONAL', totalPortions: 5 }));
    await http.post(`/api/khatms/${khatmId}/activate`).set('Authorization', bearer(creator.token)).expect(204);

    // Join (principal = joiner) + allocate all 5 portions.
    const joinRes = await http
      .post(`/api/khatms/${khatmId}/join`)
      .set('Authorization', bearer(joiner.token))
      .expect(201);
    const participationId = joinRes.body.participationId as string;
    const allocRes = await http
      .post(`/api/khatms/${khatmId}/allocate`)
      .set('Authorization', bearer(creator.token))
      .send({ participationId, count: 5 })
      .expect(201);
    expect(allocRes.body.assignedPortionIds).toHaveLength(5);

    await http
      .get(`/api/khatms/${khatmId}/progress`)
      .set('Authorization', bearer(creator.token))
      .expect(200)
      .expect((r) => expect(r.body).toMatchObject({ total: 5, assigned: 5, completed: 0 }));

    // An unauthenticated mutation is rejected (401) before any work.
    await http.post(`/api/khatms/${khatmId}/activate`).expect(401);

    // A non-holder cannot complete a portion (403) — authenticated, but not the holder.
    const other = await newUserWithToken();
    const otherJoin = await http
      .post(`/api/khatms/${khatmId}/join`)
      .set('Authorization', bearer(other.token))
      .expect(201);
    const firstPortion = (allocRes.body.assignedPortionIds as string[])[0];
    await http
      .post(`/api/portions/${firstPortion}/complete`)
      .set('Authorization', bearer(other.token))
      .send({ participationId: otherJoin.body.participationId })
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('PortionNotHeldByParticipationError'));

    // The holder completes every portion, then the khatm completes.
    for (const portionId of allocRes.body.assignedPortionIds as string[]) {
      await http
        .post(`/api/portions/${portionId}/complete`)
        .set('Authorization', bearer(joiner.token))
        .send({ participationId })
        .expect(204);
    }
    await http.post(`/api/khatms/${khatmId}/complete`).set('Authorization', bearer(creator.token)).expect(204);

    // The creator's own listing shows the khatm COMPLETED.
    const listRes = await http
      .get(`/api/khatms`)
      .set('Authorization', bearer(creator.token))
      .expect(200);
    expect(listRes.body.khatms).toEqual([expect.objectContaining({ id: khatmId, status: 'COMPLETED' })]);
  });

  it('rejects an unauthenticated create with 401', async () => {
    await http.post('/api/khatms').send({ title: 't', templateType: 'DUA' }).expect(401);
  });

  it('rejects a garbage bearer token with 401', async () => {
    await http
      .post('/api/khatms')
      .set('Authorization', 'Bearer not-a-real-token')
      .send({ title: 't', templateType: 'DUA' })
      .expect(401);
  });

  it('rejects an invalid body with a 400 error envelope (authenticated)', async () => {
    const { token } = await newUserWithToken();
    const res = await http
      .post('/api/khatms')
      .set('Authorization', bearer(token))
      .send({ templateType: 'QURAN_FULL' })
      .expect(400);
    expect(res.body).toEqual({ error: { code: 'BAD_REQUEST', message: expect.any(String) } });
  });

  it('distinguishes authentication (401) from authorization (403): a valid session without CREATOR cannot create', async () => {
    const { token } = await newUserWithToken(); // authenticated, but NOT a creator
    const res = await http
      .post('/api/khatms')
      .set('Authorization', bearer(token))
      .send({ title: 'ختم', templateType: 'QURAN_FULL' })
      .expect(403);
    expect(res.body.error.code).toBe('CapabilityRequiredError');
  });

  it('another authenticated user cannot manage someone else\'s khatm (403)', async () => {
    const owner = await newCreatorWithToken();
    const intruder = await newCreatorWithToken(); // a creator, but not the owner
    const createRes = await http
      .post('/api/khatms')
      .set('Authorization', bearer(owner.token))
      .send({ title: 'مال من', templateType: 'DUA' })
      .expect(201);
    khatmIds.push(createRes.body.id);
    await http
      .post(`/api/khatms/${createRes.body.id}/plan`)
      .set('Authorization', bearer(intruder.token))
      .send({ spec: { kind: 'QUANTITY', total: 10, chunk: 5 } })
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('ResourceOwnershipError'));
  });

  it('GET /api/me reflects the principal and creator status; 401 unauthenticated', async () => {
    await http.get('/api/me').expect(401);

    const plain = await newUserWithToken();
    await http
      .get('/api/me')
      .set('Authorization', bearer(plain.token))
      .expect(200)
      .expect((r) => expect(r.body).toEqual({ userId: plain.userId, isCreator: false }));

    const creator = await newCreatorWithToken();
    await http
      .get('/api/me')
      .set('Authorization', bearer(creator.token))
      .expect(200)
      .expect((r) => expect(r.body).toEqual({ userId: creator.userId, isCreator: true }));
  });

  it('GET participants is owner-only: owner sees the joiner, a non-owner gets 403', async () => {
    const owner = await newCreatorWithToken();
    const joiner = await newUserWithToken();
    const createRes = await http
      .post('/api/khatms')
      .set('Authorization', bearer(owner.token))
      .send({ title: 'ختم', templateType: 'SALAWAT' })
      .expect(201);
    const khatmId = createRes.body.id as string;
    khatmIds.push(khatmId);
    await http
      .post(`/api/khatms/${khatmId}/plan`)
      .set('Authorization', bearer(owner.token))
      .send({ spec: { kind: 'QUANTITY', total: 20, chunk: 10 } })
      .expect(201);
    await http.post(`/api/khatms/${khatmId}/activate`).set('Authorization', bearer(owner.token)).expect(204);
    await http.post(`/api/khatms/${khatmId}/join`).set('Authorization', bearer(joiner.token)).expect(201);

    const list = await http
      .get(`/api/khatms/${khatmId}/participants`)
      .set('Authorization', bearer(owner.token))
      .expect(200);
    expect(list.body.participants).toEqual([
      expect.objectContaining({ userId: joiner.userId, status: 'ACTIVE' }),
    ]);

    await http
      .get(`/api/khatms/${khatmId}/participants`)
      .set('Authorization', bearer(joiner.token))
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('ResourceOwnershipError'));
  });

  it('request-otp returns the canonical E.164 (login step one)', async () => {
    const { userId } = await newUserWithToken();
    const res = await http
      .post('/api/auth/request-otp')
      .send({ userId, phone: '09120000000' })
      .expect(201);
    expect(res.body.e164).toMatch(/^\+/);
  });

  it('maps an activate-without-plan precondition to 409', async () => {
    const creator = await newCreatorWithToken();
    const res = await http
      .post('/api/khatms')
      .set('Authorization', bearer(creator.token))
      .send({ title: 'بدون برنامه', templateType: 'DUA' })
      .expect(201);
    khatmIds.push(res.body.id);
    await http
      .post(`/api/khatms/${res.body.id}/activate`)
      .set('Authorization', bearer(creator.token))
      .expect(409)
      .expect((r) => expect(r.body.error.code).toBe('KhatmNotConfiguredError'));
  });
});
