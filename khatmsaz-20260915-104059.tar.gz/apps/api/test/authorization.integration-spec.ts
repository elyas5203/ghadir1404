import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { KhatmModule } from '../src/khatm/khatm.module';
import { AllocationModule } from '../src/allocation/allocation.module';
import { AuthorizationModule } from '../src/authorization/authorization.module';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { KhatmWorkflowModule } from '../src/khatm-workflow/khatm-workflow.module';
import { KhatmWorkflowService } from '../src/khatm-workflow/application/khatm-workflow.service';
import { CapabilityRequiredError, ResourceOwnershipError } from '../src/authorization/domain/authorization.errors';
import { KhatmTemplateType } from '../src/khatm/domain/khatm-template';
import { PortionUnitKind } from '../src/allocation/domain/portion-unit-kind';

const MIGRATION_NAME = '20260907081109_authorization_capability_foundation';

/**
 * Authorization persistence & enforcement integration (requires local PostgreSQL,
 * `npm run test:integration:db`). Proves the capability lifecycle against real
 * PostgreSQL and the Creator authorization rules through the real workflow.
 */
describe('authorization (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let authz: AuthorizationService;
  let workflow: KhatmWorkflowService;

  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const newUser = async (): Promise<string> => {
    const u = await identity.createUser();
    userIds.push(u.id);
    return u.id;
  };
  const createKhatm = (creatorUserId: string) =>
    workflow.createKhatm({ creatorUserId, title: 'ختم', templateType: KhatmTemplateType.DUA });

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [
        DatabaseModule,
        IdentityModule,
        KhatmModule,
        AllocationModule,
        AuthorizationModule,
        KhatmWorkflowModule,
      ],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    authz = moduleRef.get(AuthorizationService);
    workflow = moduleRef.get(KhatmWorkflowService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the authorization migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('(1) a user WITHOUT the CREATOR capability cannot create a khatm', async () => {
    const user = await newUser();
    await expect(createKhatm(user)).rejects.toBeInstanceOf(CapabilityRequiredError);
  });

  it('(2) a user WITH the CREATOR capability can create a khatm', async () => {
    const user = await newUser();
    await authz.grantCapability(user, CapabilityType.CREATOR);
    const khatm = await createKhatm(user);
    khatmIds.push(khatm.id);
    expect(khatm.creatorUserId).toBe(user);
  });

  it('(3) the creator can manage their own khatm', async () => {
    const creator = await newUser();
    await authz.grantCapability(creator, CapabilityType.CREATOR);
    const khatm = await createKhatm(creator);
    khatmIds.push(khatm.id);
    await workflow.generateAllocationPlan(khatm.id, creator, {
      kind: PortionUnitKind.QUANTITY,
      total: 10,
      chunk: 5,
    });
    await expect(workflow.activateKhatm(khatm.id, creator)).resolves.toBeUndefined();
  });

  it('(4) another authenticated user cannot manage someone else\'s khatm', async () => {
    const creator = await newUser();
    await authz.grantCapability(creator, CapabilityType.CREATOR);
    const khatm = await createKhatm(creator);
    khatmIds.push(khatm.id);

    const intruder = await newUser();
    await authz.grantCapability(intruder, CapabilityType.CREATOR); // a creator, but not the owner
    await expect(
      workflow.generateAllocationPlan(khatm.id, intruder, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 5 }),
    ).rejects.toBeInstanceOf(ResourceOwnershipError);
    await expect(workflow.activateKhatm(khatm.id, intruder)).rejects.toBeInstanceOf(ResourceOwnershipError);
  });

  it('(5) a revoked capability removes access', async () => {
    const user = await newUser();
    await authz.grantCapability(user, CapabilityType.CREATOR);
    const khatm = await createKhatm(user);
    khatmIds.push(khatm.id);

    await authz.revokeCapability(user, CapabilityType.CREATOR);
    await expect(createKhatm(user)).rejects.toBeInstanceOf(CapabilityRequiredError);
  });

  it('persists an active grant and retains history on revoke', async () => {
    const user = await newUser();
    await authz.grantCapability(user, CapabilityType.CREATOR);
    let rows = await prisma.userCapability.findMany({ where: { userId: user } });
    expect(rows).toHaveLength(1);
    expect(rows[0]?.revokedAt).toBeNull();

    await authz.revokeCapability(user, CapabilityType.CREATOR);
    rows = await prisma.userCapability.findMany({ where: { userId: user } });
    expect(rows).toHaveLength(1); // retained, not deleted
    expect(rows[0]?.revokedAt).toBeInstanceOf(Date);
  });

  it('enforces one active grant per (user, type) at the DB (partial unique index)', async () => {
    const user = await newUser();
    await authz.grantCapability(user, CapabilityType.CREATOR);
    // A second ACTIVE grant of the same type must be rejected by the partial unique index.
    await expect(
      prisma.userCapability.create({
        data: { id: newUuidV7(), userId: user, type: CapabilityType.CREATOR },
      }),
    ).rejects.toBeDefined();
  });
});
