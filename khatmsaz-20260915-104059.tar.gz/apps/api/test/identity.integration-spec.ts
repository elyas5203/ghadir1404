import { randomUUID } from 'node:crypto';
import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { isUuidV7 } from '../src/identity/domain/identity-id';
import { newIdentityId } from '../src/identity/domain/identity-id';
import { Platform } from '../src/identity/domain/platform';
import {
  PlatformIdentityAlreadyLinkedError,
  UserNotFoundError,
} from '../src/identity/domain/identity.errors';

const MIGRATION_NAME = '20260906062900_identity_foundation';

/**
 * Identity persistence integration tests. Require the local PostgreSQL stack and
 * run only under `npm run test:integration:db`. They exercise the real Prisma
 * repositories, the database uniqueness constraint, and concurrent linking.
 * A fresh random `subject` per test keeps runs independent; created users are
 * removed afterwards (the FK cascade removes their links).
 */
describe('identity persistence (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  const createdUserIds: string[] = [];

  const subject = (): string => `subj-${randomUUID()}`;
  const track = <T extends { id: string }>(user: T): T => {
    createdUserIds.push(user.id);
    return user;
  };

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
  });

  afterAll(async () => {
    if (prisma && createdUserIds.length > 0) {
      // platform_identities.user_id is now ON DELETE RESTRICT (DEC-0045), so the
      // links must be removed before their users.
      await prisma.platformIdentity
        .deleteMany({ where: { userId: { in: createdUserIds } } })
        .catch(() => undefined);
      await prisma.user
        .deleteMany({ where: { id: { in: createdUserIds } } })
        .catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the identity_foundation migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('creates a user with a native uuid (v7) id and timestamps', async () => {
    const user = track(await identity.createUser());

    expect(isUuidV7(user.id)).toBe(true);
    expect(user.createdAt).toBeInstanceOf(Date);
    expect(user.updatedAt).toBeInstanceOf(Date);

    // Stored as a real PostgreSQL uuid.
    const rows = await prisma.$queryRaw<Array<{ data_type: string }>>`
      SELECT data_type FROM information_schema.columns
      WHERE table_name = 'users' AND column_name = 'id'`;
    expect(rows[0]?.data_type).toBe('uuid');
  });

  it('finds a user by id (round-trip)', async () => {
    const user = track(await identity.createUser());
    const found = await identity.findUserById(user.id);
    expect(found?.id).toBe(user.id);
  });

  it('attaches a platform identity and finds the user by it', async () => {
    const user = track(await identity.createUser());
    const s = subject();

    const link = await identity.attachPlatformIdentity(user.id, Platform.TELEGRAM, s);
    expect(isUuidV7(link.id)).toBe(true);
    expect(link.userId).toBe(user.id);

    const found = await identity.findUserByPlatformIdentity(Platform.TELEGRAM, s);
    expect(found?.id).toBe(user.id);
  });

  it('allows the same subject on different platforms', async () => {
    const user = track(await identity.createUser());
    const s = subject();
    await identity.attachPlatformIdentity(user.id, Platform.TELEGRAM, s);
    await expect(
      identity.attachPlatformIdentity(user.id, Platform.BALE, s),
    ).resolves.toBeDefined();
  });

  it('enforces (platform, subject) uniqueness — one identity, one user', async () => {
    const a = track(await identity.createUser());
    const b = track(await identity.createUser());
    const s = subject();

    await identity.attachPlatformIdentity(a.id, Platform.TELEGRAM, s);
    await expect(
      identity.attachPlatformIdentity(b.id, Platform.TELEGRAM, s),
    ).rejects.toBeInstanceOf(PlatformIdentityAlreadyLinkedError);
  });

  it('handles CONCURRENT attaches of the same identity to different users', async () => {
    const a = track(await identity.createUser());
    const b = track(await identity.createUser());
    const s = subject();

    const results = await Promise.allSettled([
      identity.attachPlatformIdentity(a.id, Platform.TELEGRAM, s),
      identity.attachPlatformIdentity(b.id, Platform.TELEGRAM, s),
    ]);

    const fulfilled = results.filter((r) => r.status === 'fulfilled');
    const rejected = results.filter((r) => r.status === 'rejected');
    expect(fulfilled).toHaveLength(1);
    expect(rejected).toHaveLength(1);
    expect((rejected[0] as PromiseRejectedResult).reason).toBeInstanceOf(
      PlatformIdentityAlreadyLinkedError,
    );

    // Exactly one owner persisted.
    const owner = await identity.findUserByPlatformIdentity(Platform.TELEGRAM, s);
    expect([a.id, b.id]).toContain(owner?.id);
  });

  it('rejects attaching to a non-existent user (FK) with a domain error', async () => {
    await expect(
      identity.attachPlatformIdentity(newIdentityId(), Platform.TELEGRAM, subject()),
    ).rejects.toBeInstanceOf(UserNotFoundError);
  });
});
