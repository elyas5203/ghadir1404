import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { PrismaPg } from '@prisma/adapter-pg';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { DatabaseReadinessService } from '../src/infrastructure/database/database-readiness.service';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { DATABASE_PING } from '../src/infrastructure/database/database.tokens';
import type { DatabasePing } from '../src/infrastructure/database/database.tokens';
import { PrismaClient } from '../src/infrastructure/database/prisma/generated/client';

/**
 * Persistence integration tests.
 *
 * These REQUIRE a local PostgreSQL (the Docker Compose stack) and are run
 * explicitly via `npm run test:integration:db`, never as part of the portable
 * unit suite. They exercise the real Prisma client and driver adapter.
 */
describe('database integration (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let readiness: DatabaseReadinessService;

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule],
    }).compile();
    // Triggers PrismaService.onModuleInit ($connect).
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    readiness = moduleRef.get(DatabaseReadinessService);
  });

  afterAll(async () => {
    await moduleRef?.close();
  });

  it('connects and answers a real SELECT 1', async () => {
    const rows = await prisma.$queryRaw<Array<{ ok: number }>>`SELECT 1 AS ok`;
    expect(rows).toHaveLength(1);
    expect(Number(rows[0]?.ok)).toBe(1);
  });

  it('probes successfully within the timeout', async () => {
    await expect(prisma.pingDatabase(2_000)).resolves.toBeUndefined();
  });

  it('reports ready while PostgreSQL is running', async () => {
    const result = await readiness.getReadiness();
    expect(result.status).toBe('ready');
    expect(result.checks.database).toBe('up');
  });

  it('reports not_ready when the database is unreachable', async () => {
    // A real connection to a closed local port — not a mock. The ping honours a
    // short timeout so the case is deterministic and never hangs the suite.
    const unreachable = new PrismaClient({
      adapter: new PrismaPg({
        connectionString: 'postgresql://khatmsaz:wrong@127.0.0.1:5599/khatmsaz',
      }),
    });
    const ping: DatabasePing = {
      pingDatabase: async (timeoutMs: number) => {
        let timer: ReturnType<typeof setTimeout> | undefined;
        const timeout = new Promise<never>((_resolve, reject) => {
          timer = setTimeout(() => reject(new Error('probe timed out')), timeoutMs);
        });
        try {
          await Promise.race([unreachable.$queryRaw`SELECT 1`, timeout]);
        } finally {
          if (timer) clearTimeout(timer);
        }
      },
    };
    const downModule = await Test.createTestingModule({
      providers: [
        DatabaseReadinessService,
        { provide: DATABASE_PING, useValue: ping },
      ],
    }).compile();
    const downReadiness = downModule.get(DatabaseReadinessService);

    try {
      const result = await downReadiness.getReadiness();
      expect(result.status).toBe('not_ready');
      expect(result.checks.database).toBe('down');
    } finally {
      // Fire-and-forget: the pool never connected (the port is closed), so
      // awaiting $disconnect can block. --forceExit reaps any lingering handle.
      void unreachable.$disconnect().catch(() => undefined);
      await downModule.close();
    }
  }, 15_000);

  it('never exposes the connection string or credentials in the readiness body', async () => {
    const result = await readiness.getReadiness();
    const serialised = JSON.stringify(result);
    expect(serialised).not.toMatch(/postgres(ql)?:\/\//);
    expect(serialised).not.toContain('POSTGRES_PASSWORD');
    expect(serialised.toLowerCase()).not.toContain('password');
  });
});
