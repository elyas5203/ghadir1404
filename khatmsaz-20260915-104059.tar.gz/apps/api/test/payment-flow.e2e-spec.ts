import { Test } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { ZarinpalService } from '../src/payment/infrastructure/zarinpal.service';
import { WalletService } from '../src/payment/application/wallet.service';
import { IdentityService } from '../src/identity/application/identity.service';
import { AuthenticationService } from '../src/session/application/authentication.service';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';

/**
 * Payment flow smoke tests (requires local PostgreSQL, `npm run test:e2e`).
 *
 * ZarinpalService is replaced with a jest mock so no real network calls are made.
 * Tests cover: normal charge flow, replay protection (409 on second verify), and
 * IDOR protection (the stored userId — not the requester's session — is charged).
 */
describe('payment flow smoke (requires PostgreSQL)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let identity: IdentityService;
  let auth: AuthenticationService;
  let wallet: WalletService;

  const userIds: string[] = [];

  const mockZarinpal = {
    createPayment: jest.fn<
      Promise<{ paymentUrl: string; authority: string }>,
      [string, number, string, string]
    >(),
    verifyPayment: jest.fn<Promise<{ refId: string }>, [string, number]>(),
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(ZarinpalService)
      .useValue(mockZarinpal)
      .compile();

    app = moduleRef.createNestApplication();
    await app.init();

    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    auth = moduleRef.get(AuthenticationService);
    wallet = moduleRef.get(WalletService);
  });

  afterAll(async () => {
    if (prisma) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const wallets = await (prisma.wallet as any)
        .findMany({ where: { userId: { in: userIds } }, select: { id: true } })
        .catch(() => [] as { id: string }[]);
      const walletIds = (wallets as { id: string }[]).map((w) => w.id);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (prisma.walletTransaction as any)
        .deleteMany({ where: { walletId: { in: walletIds } } })
        .catch(() => undefined);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (prisma.wallet as any)
        .deleteMany({ where: { userId: { in: userIds } } })
        .catch(() => undefined);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (prisma.pendingPayment as any)
        .deleteMany({ where: { userId: { in: userIds } } })
        .catch(() => undefined);
      await prisma.session
        .deleteMany({ where: { userId: { in: userIds } } })
        .catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  const newUserWithToken = async (): Promise<{ userId: string; token: string }> => {
    const user = await identity.createUser();
    userIds.push(user.id);
    const { token } = await auth.createSession(user.id);
    return { userId: user.id, token };
  };

  describe('happy path', () => {
    it('creates a payment, verifies it, and credits the correct wallet', async () => {
      const { userId, token } = await newUserWithToken();
      const fakeAuthority = `HAPPY_${Date.now()}`;

      mockZarinpal.createPayment.mockResolvedValue({
        paymentUrl: `https://sandbox.zarinpal.com/pg/StartPay/${fakeAuthority}`,
        authority: fakeAuthority,
      });
      mockZarinpal.verifyPayment.mockResolvedValue({ refId: 'REF_HAPPY' });

      const createRes = await request(app.getHttpServer())
        .post('/payment/create')
        .set('Authorization', `Bearer ${token}`)
        .send({ amountToman: 10_000, description: 'تست پرداخت' })
        .expect(201);

      expect(createRes.body.authority).toBe(fakeAuthority);

      const verifyRes = await request(app.getHttpServer())
        .get(`/payment/verify?Authority=${fakeAuthority}&Status=OK`)
        .expect(200);

      expect(verifyRes.body).toMatchObject({ success: true, refId: 'REF_HAPPY' });

      const { balance } = await wallet.getBalance(userId);
      expect(balance).toBe(10_000);
    });
  });

  describe('replay protection', () => {
    it('returns 409 on a second verify with the same authority', async () => {
      const { token } = await newUserWithToken();
      const fakeAuthority = `REPLAY_${Date.now()}`;

      mockZarinpal.createPayment.mockResolvedValue({
        paymentUrl: `https://sandbox.zarinpal.com/pg/StartPay/${fakeAuthority}`,
        authority: fakeAuthority,
      });
      mockZarinpal.verifyPayment.mockResolvedValue({ refId: 'REF_REPLAY' });

      await request(app.getHttpServer())
        .post('/payment/create')
        .set('Authorization', `Bearer ${token}`)
        .send({ amountToman: 5_000, description: 'تست تکرار' })
        .expect(201);

      await request(app.getHttpServer())
        .get(`/payment/verify?Authority=${fakeAuthority}&Status=OK`)
        .expect(200);

      // Second verify of the same authority must be rejected
      await request(app.getHttpServer())
        .get(`/payment/verify?Authority=${fakeAuthority}&Status=OK`)
        .expect(409);
    });
  });

  describe('IDOR protection', () => {
    it('always credits the payment-creator wallet regardless of who calls verify', async () => {
      const userA = await newUserWithToken();
      const fakeAuthority = `IDOR_${Date.now()}`;

      mockZarinpal.createPayment.mockResolvedValue({
        paymentUrl: `https://sandbox.zarinpal.com/pg/StartPay/${fakeAuthority}`,
        authority: fakeAuthority,
      });
      mockZarinpal.verifyPayment.mockResolvedValue({ refId: 'REF_IDOR' });

      // User A creates the payment intent
      await request(app.getHttpServer())
        .post('/payment/create')
        .set('Authorization', `Bearer ${userA.token}`)
        .send({ amountToman: 7_000, description: 'تست IDOR' })
        .expect(201);

      const { balance: before } = await wallet.getBalance(userA.userId);

      // Verify without any session (simulates an attacker who obtained the authority URL)
      await request(app.getHttpServer())
        .get(`/payment/verify?Authority=${fakeAuthority}&Status=OK`)
        .expect(200);

      // The credit must go to User A — the payment creator stored in PendingPayment,
      // not to any session-less requester.
      const { balance: after } = await wallet.getBalance(userA.userId);
      expect(after - before).toBe(7_000);
    });
  });
});
