import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { txClient } from '../src/infrastructure/database/prisma/prisma-unit-of-work';
import { UNIT_OF_WORK } from '../src/infrastructure/database/database.tokens';
import type { UnitOfWork } from '../src/infrastructure/database/database.tokens';

/**
 * Transaction-boundary integration tests (DEC-0044). Require the local
 * PostgreSQL stack (`npm run test:integration:db`). They prove the Unit of Work
 * really commits and really rolls back against a real database — the seam Phase
 * 3B's account merge will run inside. No merge or other use-case logic exists yet.
 */
describe('UnitOfWork transaction boundary (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let uow: UnitOfWork;
  const createdUserIds: string[] = [];

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({ imports: [DatabaseModule] }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    uow = moduleRef.get(UNIT_OF_WORK);
  });

  afterAll(async () => {
    if (prisma && createdUserIds.length > 0) {
      await prisma.user
        .deleteMany({ where: { id: { in: createdUserIds } } })
        .catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('commits the whole unit of work and returns its result', async () => {
    const id = newUuidV7();
    const returned = await uow.run(async (tx) => {
      await txClient(tx).user.create({ data: { id } });
      return id;
    });
    createdUserIds.push(id);

    expect(returned).toBe(id);
    const found = await prisma.user.findUnique({ where: { id } });
    expect(found?.id).toBe(id);
  });

  it('rolls the whole unit of work back when the work throws', async () => {
    const id = newUuidV7();
    await expect(
      uow.run(async (tx) => {
        await txClient(tx).user.create({ data: { id } });
        throw new Error('boom');
      }),
    ).rejects.toThrow('boom');

    // The row created inside the failed transaction must not exist.
    const found = await prisma.user.findUnique({ where: { id } });
    expect(found).toBeNull();
  });

  it('rolls back a multi-write unit of work atomically (all or nothing)', async () => {
    const okId = newUuidV7();
    const failId = newUuidV7();
    await expect(
      uow.run(async (tx) => {
        await txClient(tx).user.create({ data: { id: okId } });
        await txClient(tx).user.create({ data: { id: failId } });
        // Force a failure AFTER two successful writes.
        throw new Error('rollback both');
      }),
    ).rejects.toThrow('rollback both');

    const rows = await prisma.user.findMany({ where: { id: { in: [okId, failId] } } });
    expect(rows).toHaveLength(0);
  });
});
