import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { InvitationService } from '../src/invitation/application/invitation.service';
import { TELEGRAM_CONFIG } from '../src/telegram/infrastructure/telegram-config.tokens';
import { TELEGRAM_SENDER } from '../src/telegram/domain/telegram-sender';
import type { TelegramReply } from '../src/telegram/domain/telegram-message';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';

class CapturingOtp implements OtpDelivery {
  private readonly m = new Map<string, string>();
  async deliver(r: OtpDeliveryRequest): Promise<void> { this.m.set(r.e164, r.code); }
  codeFor(e: string): string { const c = this.m.get(e); if (!c) throw new Error(`no otp ${e}`); return c; }
}

const SECRET = 'test-webhook-secret';

/** A capturing sender so replies can be asserted without a real Telegram network. */
class CapturingSender {
  readonly sent: Array<{ chatId: string; text: string }> = [];
  async send(chatId: string, reply: TelegramReply): Promise<void> {
    this.sent.push({ chatId, text: reply.text });
  }
  last(): string {
    return this.sent[this.sent.length - 1]?.text ?? '';
  }
}

/**
 * Telegram webhook integration (requires local PostgreSQL, `npm run
 * test:integration:db`). Drives the REAL inbound path — secret check, raw→neutral
 * mapping, dispatch through the existing gateway/command service — with a capturing
 * sender (no Telegram network). Asserts secret verification, identity resolution,
 * unknown/invalid updates, unauthorized creator actions, and duplicate Telegram users.
 */
describe('telegram webhook (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let app: INestApplication;
  let http: ReturnType<typeof request>;
  let prisma: PrismaService;
  let authz: AuthorizationService;
  let invService: InvitationService;
  const sender = new CapturingSender();
  const otp = new CapturingOtp();

  const fromIds: string[] = [];
  const post = (body: unknown, secret: string | null = SECRET) => {
    const req = http.post('/telegram/webhook');
    if (secret !== null) req.set('X-Telegram-Bot-Api-Secret-Token', secret);
    return req.send(body as object);
  };
  const update = (fromId: string, text: string) => ({
    update_id: Math.floor(Math.random() * 1e9),
    message: { chat: { id: fromId }, from: { id: fromId }, text },
  });

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(TELEGRAM_CONFIG)
      .useValue({ botToken: '', webhookSecret: SECRET, apiBaseUrl: 'https://api.telegram.org' })
      .overrideProvider(TELEGRAM_SENDER)
      .useValue(sender)
      .overrideProvider(OTP_DELIVERY)
      .useValue(otp)
      .compile();
    app = moduleRef.createNestApplication();
    await app.init();
    http = request(app.getHttpServer());
    prisma = moduleRef.get(PrismaService);
    authz = moduleRef.get(AuthorizationService);
    invService = moduleRef.get(InvitationService);
  });

  afterAll(async () => {
    if (prisma) {
      const links = await prisma.platformIdentity
        .findMany({ where: { platform: 'TELEGRAM', subject: { in: fromIds } }, select: { userId: true } })
        .catch(() => [] as { userId: string }[]);
      const userIds = links.map((l) => l.userId);
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { creatorUserId: { in: userIds } } }).catch(() => undefined);
      await prisma.platformIdentity.deleteMany({ where: { subject: { in: fromIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('rejects a request with no secret header (403)', async () => {
    await post(update('tg-nosecret', '/start'), null).expect(403);
  });

  it('rejects a request with the wrong secret (403)', async () => {
    await post(update('tg-badsecret', '/start'), 'wrong').expect(403);
  });

  it('ignores a malformed update but still answers 200 (no crash, no user)', async () => {
    await post({ update_id: 5, edited_message: { text: 'x' } }).expect(200).expect({ ok: true });
    const link = await prisma.platformIdentity.findFirst({ where: { subject: 'tg-nosecret' } });
    expect(link).toBeNull(); // the earlier rejected /start provisioned nothing either
  });

  it('answers an unknown command with a calm reply (200)', async () => {
    const from = `tg-${Date.now()}-unknown`;
    fromIds.push(from);
    await post(update(from, '/wat')).expect(200);
    expect(sender.last()).toContain('شناخته نشد');
  });

  it('resolves identity: /start provisions exactly one user + platform identity, idempotently', async () => {
    const from = `tg-${Date.now()}-start`;
    fromIds.push(from);
    await post(update(from, '/start')).expect(200);
    expect(sender.last()).toContain('خوش آمدید');

    // A duplicate /start must NOT create a second user or platform identity.
    await post(update(from, '/start')).expect(200);
    const links = await prisma.platformIdentity.findMany({ where: { platform: 'TELEGRAM', subject: from } });
    expect(links).toHaveLength(1);
  });

  it('rejects an unauthorized creator action (no CREATOR) with a calm reply', async () => {
    const from = `tg-${Date.now()}-noncreator`;
    fromIds.push(from);
    await post(update(from, '/start')).expect(200);
    await post(update(from, '/create_khatm QURAN_FULL ختم')).expect(200);
    expect(sender.last()).toContain('اجازه');
    const link = await prisma.platformIdentity.findFirst({ where: { subject: from } });
    const khatms = await prisma.khatm.findMany({ where: { creatorUserId: link?.userId } });
    expect(khatms).toHaveLength(0);
  });

  it('lets a granted CREATOR create a khatm through the webhook', async () => {
    const from = `tg-${Date.now()}-creator`;
    fromIds.push(from);
    await post(update(from, '/start')).expect(200);
    const link = await prisma.platformIdentity.findFirst({ where: { subject: from } });
    await authz.grantCapability(link?.userId as string, CapabilityType.CREATOR);

    await post(update(from, '/create_khatm QURAN_FULL ختم قرآن')).expect(200);
    expect(sender.last()).toContain('شناسه');
    const khatms = await prisma.khatm.findMany({ where: { creatorUserId: link?.userId } });
    expect(khatms).toHaveLength(1);
    expect(khatms[0]?.status).toBe('DRAFT');
  });

  it('/join: a Telegram user accepts an invitation and joins the khatm', async () => {
    // Create a web user who owns an active khatm.
    const phone = `+98912${Math.floor(1_000_000 + Math.random() * 8_999_999)}`;
    await http.post('/api/auth/phone/request').send({ phone }).expect(201);
    const loginRes = await http.post('/api/auth/phone/verify').send({ phone, code: otp.codeFor(phone) }).expect(201);
    const ownerUserId = loginRes.body.userId as string;
    const setCookie = loginRes.headers['set-cookie'] as unknown as string[];
    const ownerCookie = (setCookie.find((c: string) => c.startsWith('khatmsaz_session=')) as string).split(';')[0] as string;

    await authz.grantCapability(ownerUserId, CapabilityType.CREATOR);
    const khatmRes = await http.post('/api/khatms').set('Cookie', ownerCookie)
      .send({ title: 'ختم تلگرامی', templateType: 'SALAWAT', khatmType: 'OPEN' }).expect(201);
    const khatmId = khatmRes.body.id as string;
    await http.post(`/api/khatms/${khatmId}/activate`).set('Cookie', ownerCookie).expect(204);

    // Owner creates an invitation.
    const invRes = await invService.createInvitation(khatmId, ownerUserId);
    const token = invRes.token;

    // A Telegram user starts and then joins via the token.
    const from = `tg-${Date.now()}-joiner`;
    fromIds.push(from);
    await post(update(from, '/start')).expect(200);
    await post(update(from, `/join ${token}`)).expect(200);
    expect(sender.last()).toContain(khatmId);

    // Cleanup extras.
    const link = await prisma.platformIdentity.findFirst({ where: { subject: from } });
    if (link) {
      await prisma.participation.deleteMany({ where: { userId: link.userId } }).catch(() => undefined);
      await prisma.khatmInvitation.deleteMany({ where: { khatmId } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: khatmId } }).catch(() => undefined);
      await prisma.userCapability.deleteMany({ where: { userId: ownerUserId } }).catch(() => undefined);
      await prisma.session.deleteMany({ where: { userId: ownerUserId } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: ownerUserId } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { e164: phone } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: ownerUserId } }).catch(() => undefined);
    }
  });
});
