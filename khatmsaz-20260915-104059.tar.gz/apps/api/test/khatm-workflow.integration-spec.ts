import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { KhatmModule } from '../src/khatm/khatm.module';
import { AllocationModule } from '../src/allocation/allocation.module';
import { KhatmWorkflowModule } from '../src/khatm-workflow/khatm-workflow.module';
import { KhatmWorkflowService } from '../src/khatm-workflow/application/khatm-workflow.service';
import { AuthorizationModule } from '../src/authorization/authorization.module';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { KhatmStatus } from '../src/khatm/domain/khatm-status';
import { KhatmTemplateType } from '../src/khatm/domain/khatm-template';
import { PortionUnitKind } from '../src/allocation/domain/portion-unit-kind';
import { PortionStatus } from '../src/allocation/domain/portion-status';
import { DuplicateParticipationError } from '../src/khatm/domain/khatm.errors';
import { PortionNotHeldByParticipationError } from '../src/allocation/domain/allocation.errors';
import {
  InactiveCreatorError,
  InactiveParticipantError,
  KhatmNotCompletableError,
  KhatmNotConfiguredError,
} from '../src/khatm-workflow/application/khatm-workflow.errors';

/**
 * Khatm workflow orchestration integration tests (require local PostgreSQL,
 * `npm run test:integration:db`). They drive the end-to-end journey through the
 * real capabilities and assert the resulting database state, the cross-capability
 * preconditions, and the DB constraints. Teardown is child-first; merged-user
 * self-FKs are cleared before deleting.
 */
describe('khatm workflow orchestration (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let workflow: KhatmWorkflowService;
  let authorization: AuthorizationService;

  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const newUser = async (): Promise<string> => {
    const u = await identity.createUser();
    userIds.push(u.id);
    return u.id;
  };
  /** A user granted the CREATOR capability (the explicit internal grant, DEC-0062). */
  const newCreator = async (): Promise<string> => {
    const id = await newUser();
    await authorization.grantCapability(id, CapabilityType.CREATOR);
    return id;
  };

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [
        DatabaseModule,
        IdentityModule,
        KhatmModule,
        AllocationModule,
        AuthorizationModule,
        KhatmWorkflowModule,
      ],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    workflow = moduleRef.get(KhatmWorkflowService);
    authorization = moduleRef.get(AuthorizationService);
  });

  afterAll(async () => {
    if (prisma) {
      // Break any merged-user self-FK so user deletion order is unconstrained.
      await prisma.user
        .updateMany({ where: { id: { in: userIds } }, data: { mergedIntoId: null } })
        .catch(() => undefined);
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.participation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('runs the full journey: create → generate → activate → join → allocate → complete', async () => {
    const creator = await newCreator();

    // 1. Create (DRAFT).
    const khatm = await workflow.createKhatm({
      creatorUserId: creator,
      title: 'ختم قرآن خانوادگی',
      templateType: KhatmTemplateType.QURAN_FULL,
    });
    khatmIds.push(khatm.id);
    expect(khatm.status).toBe(KhatmStatus.DRAFT);
    expect(khatm.creatorUserId).toBe(creator);

    // 2. Activation is blocked until a plan is configured.
    await expect(workflow.activateKhatm(khatm.id, creator)).rejects.toBeInstanceOf(KhatmNotConfiguredError);

    // 3. Generate the allocation plan (30 Juz), then activate.
    const plan = await workflow.generateAllocationPlan(khatm.id, creator, {
      kind: PortionUnitKind.POSITIONAL,
      from: 1,
      to: 30,
    });
    expect(plan.totalPortions).toBe(30);
    await workflow.activateKhatm(khatm.id, creator);
    expect((await prisma.khatm.findUnique({ where: { id: khatm.id } }))?.status).toBe(KhatmStatus.ACTIVE);

    // 4. Join and allocate all 30 portions to the participant.
    const joiner = await newUser();
    const participation = await workflow.joinKhatm(khatm.id, joiner);
    const assigned = await workflow.allocatePortions(khatm.id, creator, participation.id, 30);
    expect(assigned).toHaveLength(30);
    expect(await workflow.progress(khatm.id)).toEqual({ total: 30, open: 0, assigned: 30, completed: 0 });

    // 5. Completion is blocked until every portion is completed.
    await expect(workflow.completeKhatm(khatm.id, creator)).rejects.toBeInstanceOf(KhatmNotCompletableError);

    // 6. The holder completes each portion (a non-holder is rejected).
    const portionIds = (
      await prisma.khatmPortion.findMany({ where: { khatmId: khatm.id }, select: { id: true } })
    ).map((r) => r.id);
    const stranger = await workflow.joinKhatm(khatm.id, await newUser());
    await expect(
      workflow.completePortion(portionIds[0] as string, stranger.id),
    ).rejects.toBeInstanceOf(PortionNotHeldByParticipationError);
    for (const portionId of portionIds) {
      await workflow.completePortion(portionId, participation.id);
    }
    expect(await workflow.progress(khatm.id)).toEqual({ total: 30, open: 0, assigned: 0, completed: 30 });

    // 7. Now the khatm can be completed.
    await workflow.completeKhatm(khatm.id, creator);
    expect((await prisma.khatm.findUnique({ where: { id: khatm.id } }))?.status).toBe(KhatmStatus.COMPLETED);
    const rows = await prisma.khatmPortion.findMany({ where: { khatmId: khatm.id } });
    expect(rows.every((r) => r.status === PortionStatus.COMPLETED)).toBe(true);
  });

  it('serialises concurrent activation via the guarded transition (exactly one wins)', async () => {
    const creator = await newCreator();
    const khatm = await workflow.createKhatm({
      creatorUserId: creator,
      title: 'ختم همزمان',
      templateType: KhatmTemplateType.SALAWAT,
    });
    khatmIds.push(khatm.id);
    await workflow.generateAllocationPlan(khatm.id, creator, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 5 });

    // Two concurrent activations: the guarded DRAFT→ACTIVE transition lets one win.
    const results = await Promise.allSettled([
      workflow.activateKhatm(khatm.id, creator),
      workflow.activateKhatm(khatm.id, creator),
    ]);
    const fulfilled = results.filter((r) => r.status === 'fulfilled');
    expect(fulfilled).toHaveLength(1);
    expect((await prisma.khatm.findUnique({ where: { id: khatm.id } }))?.status).toBe(KhatmStatus.ACTIVE);
  });

  it('rejects a duplicate active participation via the DB constraint', async () => {
    const creator = await newCreator();
    const joiner = await newUser();
    const khatm = await workflow.createKhatm({
      creatorUserId: creator,
      title: 'ختم',
      templateType: KhatmTemplateType.SALAWAT,
    });
    khatmIds.push(khatm.id);
    await workflow.generateAllocationPlan(khatm.id, creator, { kind: PortionUnitKind.QUANTITY, total: 100, chunk: 10 });
    await workflow.activateKhatm(khatm.id, creator);

    await workflow.joinKhatm(khatm.id, joiner);
    await expect(workflow.joinKhatm(khatm.id, joiner)).rejects.toBeInstanceOf(DuplicateParticipationError);
  });

  it('rejects a merged (inactive) user as creator and as joiner', async () => {
    const winner = await newUser();
    const loser = await newUser();
    // Tombstone the loser directly (as a completed merge would).
    await prisma.user.update({
      where: { id: loser },
      data: { status: 'MERGED', mergedIntoId: winner },
    });

    await expect(
      workflow.createKhatm({ creatorUserId: loser, title: 'ختم', templateType: KhatmTemplateType.DUA }),
    ).rejects.toBeInstanceOf(InactiveCreatorError);

    // A live khatm to attempt joining (winner is a granted creator).
    await authorization.grantCapability(winner, CapabilityType.CREATOR);
    const khatm = await workflow.createKhatm({
      creatorUserId: winner,
      title: 'ختم',
      templateType: KhatmTemplateType.DUA,
    });
    khatmIds.push(khatm.id);
    await workflow.generateAllocationPlan(khatm.id, winner, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 5 });
    await workflow.activateKhatm(khatm.id, winner);
    await expect(workflow.joinKhatm(khatm.id, loser)).rejects.toBeInstanceOf(InactiveParticipantError);
  });
});
