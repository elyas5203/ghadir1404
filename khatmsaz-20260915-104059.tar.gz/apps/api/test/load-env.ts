// Integration-test setup: load the repository-root .env so the persistence
// integration suite can reach the local Docker PostgreSQL. This file is used
// ONLY by the integration jest config, never by the portable unit suite.
import { resolve } from 'node:path';
import { config as loadEnv } from 'dotenv';

loadEnv({ path: resolve(__dirname, '../../../.env') });
