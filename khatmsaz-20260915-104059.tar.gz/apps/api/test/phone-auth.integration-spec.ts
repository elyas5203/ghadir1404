import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { SessionModule } from '../src/session/session.module';
import { PhoneAuthService } from '../src/session/application/phone-auth.service';
import { AuthenticationService } from '../src/session/application/authentication.service';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';
import {
  InvalidOtpCodeError,
  NoActiveOtpChallengeError,
} from '../src/phone/domain/phone.errors';

/** Capturing delivery so the test can read the login code, as an SMS recipient would. */
class CapturingDelivery implements OtpDelivery {
  private readonly byE164 = new Map<string, string>();
  async deliver(req: OtpDeliveryRequest): Promise<void> {
    this.byE164.set(req.e164, req.code);
  }
  codeFor(e164: string): string {
    const c = this.byE164.get(e164);
    if (!c) throw new Error(`no code delivered for ${e164}`);
    return c;
  }
}

/**
 * Phone-first authentication integration (requires local PostgreSQL,
 * `npm run test:integration:db`). Proves the user-less login flow end to end
 * (DEC-0066): new-user creation, existing-user login, invalid/absent OTP, and that
 * the minted session actually authenticates.
 */
describe('phone-first authentication (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let phoneAuth: PhoneAuthService;
  let auth: AuthenticationService;
  const delivery = new CapturingDelivery();

  const e164s: string[] = [];
  const userIds: string[] = [];
  const rand = () => `+98912${Math.floor(1_000_000 + Math.random() * 8_999_999)}`;
  const newPhone = () => {
    const p = rand();
    e164s.push(p);
    return p;
  };

  beforeAll(async () => {
    // Disable the resend cooldown so the test can request a fresh code per login.
    process.env.OTP_RESEND_COOLDOWN_SECONDS = '0';
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, SessionModule],
    })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    phoneAuth = moduleRef.get(PhoneAuthService);
    auth = moduleRef.get(AuthenticationService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { e164: { in: e164s } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('creates a new user on first login and mints a working session', async () => {
    const phone = newPhone();
    await phoneAuth.requestLogin(phone);
    const result = await phoneAuth.completeLogin(phone, delivery.codeFor(phone));
    userIds.push(result.userId);

    expect(result.isNewUser).toBe(true);
    expect(result.token).toEqual(expect.any(String));

    // The number is now this user's VERIFIED claim.
    const claim = await prisma.phoneClaim.findFirst({ where: { userId: result.userId, e164: phone } });
    expect(claim?.status).toBe('VERIFIED');

    // The minted session authenticates back to the same user.
    const principal = await auth.authenticate(result.token);
    expect(principal.userId).toBe(result.userId);
    expect(principal.sessionId).toBe(result.sessionId);
  });

  it('resolves the SAME user on a later login (no duplicate account)', async () => {
    const phone = newPhone();
    await phoneAuth.requestLogin(phone);
    const first = await phoneAuth.completeLogin(phone, delivery.codeFor(phone));
    userIds.push(first.userId);
    expect(first.isNewUser).toBe(true);

    await phoneAuth.requestLogin(phone);
    const second = await phoneAuth.completeLogin(phone, delivery.codeFor(phone));
    expect(second.isNewUser).toBe(false);
    expect(second.userId).toBe(first.userId);

    const users = await prisma.phoneClaim.count({ where: { e164: phone, status: 'VERIFIED' } });
    expect(users).toBe(1); // still exactly one verified owner
  });

  it('rejects an invalid OTP code', async () => {
    const phone = newPhone();
    await phoneAuth.requestLogin(phone);
    const real = delivery.codeFor(phone);
    const wrong = (real[0] === '9' ? '0' : '9') + real.slice(1); // guaranteed different
    await expect(phoneAuth.completeLogin(phone, wrong)).rejects.toBeInstanceOf(InvalidOtpCodeError);
  });

  it('rejects a verify with no active challenge (never requested)', async () => {
    const phone = newPhone();
    await expect(phoneAuth.completeLogin(phone, '123456')).rejects.toBeInstanceOf(
      NoActiveOtpChallengeError,
    );
  });
});
