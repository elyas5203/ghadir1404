import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { KhatmModule } from '../src/khatm/khatm.module';
import { KhatmService } from '../src/khatm/application/khatm.service';
import { KhatmTemplateType } from '../src/khatm/domain/khatm-template';
import { AllocationModule } from '../src/allocation/allocation.module';
import { AllocationService } from '../src/allocation/application/allocation.service';
import { PortionUnitKind } from '../src/allocation/domain/portion-unit-kind';
import { PortionStatus } from '../src/allocation/domain/portion-status';
import {
  AllocationPlanAlreadyExistsError,
  KhatmNotAllocatableError,
} from '../src/allocation/domain/allocation.errors';

const MIGRATION_NAME = '20260907004303_khatm_allocation_engine';

/**
 * Khatm allocation-engine persistence integration tests. Require the local
 * PostgreSQL stack (`npm run test:integration:db`). They exercise real plan
 * generation (transaction), allocation/reallocation, the non-overlap partial unique
 * index, the derived progress query, and FK RESTRICT. Teardown is child-first.
 */
describe('khatm allocation engine persistence (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let khatm: KhatmService;
  let allocation: AllocationService;

  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const newUser = async (): Promise<string> => {
    const u = await identity.createUser();
    userIds.push(u.id);
    return u.id;
  };

  /** A fresh ACTIVE khatm with one ACTIVE participation; returns both ids. */
  const setup = async (): Promise<{ khatmId: string; participationId: string }> => {
    const creator = await newUser();
    const joiner = await newUser();
    const k = await khatm.createKhatm({
      creatorUserId: creator,
      title: 'ختم قرآن',
      templateType: KhatmTemplateType.QURAN_FULL,
    });
    khatmIds.push(k.id);
    await khatm.activateKhatm(k.id);
    const p = await khatm.join(k.id, joiner);
    return { khatmId: k.id, participationId: p.id };
  };

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule, KhatmModule, AllocationModule],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    khatm = moduleRef.get(KhatmService);
    allocation = moduleRef.get(AllocationService);
  });

  afterAll(async () => {
    if (prisma) {
      // Child-first (all RESTRICT): portions → plans → participations → khatms → users.
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.participation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the khatm_allocation_engine migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('generates a positional plan of 30 atomic, non-overlapping portions', async () => {
    const { khatmId } = await setup();
    const plan = await allocation.generatePlan(khatmId, {
      kind: PortionUnitKind.POSITIONAL,
      from: 1,
      to: 30,
    });
    expect(plan.totalPortions).toBe(30);

    const rows = await prisma.khatmPortion.findMany({
      where: { khatmId },
      orderBy: { sequence: 'asc' },
    });
    expect(rows).toHaveLength(30);
    expect(rows.every((r) => r.status === PortionStatus.OPEN)).toBe(true);
    expect(rows.map((r) => r.unitStart)).toEqual(Array.from({ length: 30 }, (_, i) => i + 1));
    expect(new Set(rows.map((r) => r.unitStart)).size).toBe(30);
  });

  it('generates a quantity plan whose chunks sum to the total', async () => {
    const { khatmId } = await setup();
    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.QUANTITY, total: 1000, chunk: 100 });
    const rows = await prisma.khatmPortion.findMany({ where: { khatmId } });
    expect(rows).toHaveLength(10);
    expect(rows.reduce((s, r) => s + (r.quantity ?? 0), 0)).toBe(1000);
    expect(rows.every((r) => r.unitStart === null)).toBe(true);
  });

  it('refuses a second plan for the same khatm (unique khatm_id)', async () => {
    const { khatmId } = await setup();
    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 5 });
    await expect(
      allocation.generatePlan(khatmId, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 5 }),
    ).rejects.toBeInstanceOf(AllocationPlanAlreadyExistsError);
  });

  it('enforces non-overlap at the DB: a duplicate positional unit in a plan is rejected', async () => {
    const { khatmId } = await setup();
    const plan = await allocation.generatePlan(khatmId, {
      kind: PortionUnitKind.POSITIONAL,
      from: 1,
      to: 3,
    });
    await expect(
      prisma.khatmPortion.create({
        data: {
          id: newUuidV7(),
          planId: plan.id,
          khatmId,
          sequence: 99,
          unitKind: PortionUnitKind.POSITIONAL,
          unitStart: 1, // duplicates unit 1 → violates the partial unique index
          unitEnd: 1,
        },
      }),
    ).rejects.toBeDefined();
  });

  it('allocates, completes, and derives progress against real PostgreSQL', async () => {
    const { khatmId, participationId } = await setup();
    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.POSITIONAL, from: 1, to: 30 });

    const assigned = await allocation.allocateOpenPortions(khatmId, participationId, 10);
    expect(assigned).toHaveLength(10);
    expect(await allocation.progress(khatmId)).toEqual({ total: 30, open: 20, assigned: 10, completed: 0 });

    const firstId = assigned[0]?.id as string;
    await allocation.completePortion(firstId);
    expect(await allocation.progress(khatmId)).toEqual({ total: 30, open: 20, assigned: 9, completed: 1 });

    const row = await prisma.khatmPortion.findUnique({ where: { id: firstId } });
    expect(row?.status).toBe(PortionStatus.COMPLETED);
    expect(row?.completedAt).toBeInstanceOf(Date);
  });

  it('reallocates a leaving participant\'s portions to another (transaction-safe)', async () => {
    const { khatmId, participationId } = await setup();
    // A second active participant on the same khatm.
    const otherUser = await newUser();
    const other = await khatm.join(khatmId, otherUser);

    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.POSITIONAL, from: 1, to: 10 });
    await allocation.allocateOpenPortions(khatmId, participationId, 10);
    expect(await allocation.progress(khatmId)).toMatchObject({ assigned: 10, open: 0 });

    const released = await allocation.releaseParticipation(khatmId, participationId);
    expect(released).toBe(10);
    expect(await allocation.progress(khatmId)).toMatchObject({ open: 10, assigned: 0 });

    const reAssigned = await allocation.allocateOpenPortions(khatmId, other.id, 10);
    expect(reAssigned).toHaveLength(10);
    const holders = await prisma.khatmPortion.findMany({ where: { khatmId }, select: { participationId: true } });
    expect(holders.every((h) => h.participationId === other.id)).toBe(true);
  });

  it('refuses allocation once the khatm is no longer ACTIVE', async () => {
    const { khatmId, participationId } = await setup();
    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.QUANTITY, total: 100, chunk: 10 });
    await khatm.completeKhatm(khatmId);
    await expect(
      allocation.allocateOpenPortions(khatmId, participationId, 1),
    ).rejects.toBeInstanceOf(KhatmNotAllocatableError);
  });

  it('RESTRICT forbids hard-deleting a khatm that has a plan', async () => {
    const { khatmId } = await setup();
    await allocation.generatePlan(khatmId, { kind: PortionUnitKind.QUANTITY, total: 10, chunk: 10 });
    await expect(prisma.khatm.delete({ where: { id: khatmId } })).rejects.toBeDefined();
  });
});
