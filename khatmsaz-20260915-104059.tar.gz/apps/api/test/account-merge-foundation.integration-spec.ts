import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { Platform } from '../src/identity/domain/platform';
import { UserStatus } from '../src/identity/domain/user-status';
import { ACCOUNT_MERGE_REPOSITORY } from '../src/identity/domain/account-merge.repository';
import type { AccountMergeRepository } from '../src/identity/domain/account-merge.repository';

const MIGRATION_NAME = '20260906120252_account_merge_foundation';

/**
 * Phase 3B foundation integration tests (schema + persistence only — NO merge
 * use-case). They prove, against real PostgreSQL: the User lifecycle columns, the
 * tombstone/alias self-FK, the one-verified-phone-per-user partial index
 * (DEC-0046), the FK RESTRICT/CASCADE strategy (DEC-0045), and the append-only
 * merge audit repository (DEC-0043). Requires the local stack
 * (`npm run test:integration:db`).
 */
describe('account-merge foundation (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let merges: AccountMergeRepository;
  const createdUserIds: string[] = [];

  const track = (id: string): string => {
    createdUserIds.push(id);
    return id;
  };
  const newUser = async (): Promise<string> => track((await identity.createUser()).id);
  const subject = (): string => `subj-${newUuidV7()}`;
  const nationalToE164 = (): string => `+9891${Math.floor(10_000_000 + Math.random() * 89_999_999)}`;

  const insertVerifiedClaim = (userId: string, e164: string): Promise<unknown> =>
    prisma.phoneClaim.create({
      data: { id: newUuidV7(), userId, e164, status: 'VERIFIED', verifiedAt: new Date() },
    });

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    merges = moduleRef.get(ACCOUNT_MERGE_REPOSITORY);
  });

  afterAll(async () => {
    if (prisma && createdUserIds.length > 0) {
      const where = { userId: { in: createdUserIds } };
      // Order matters under the new RESTRICT FKs: audit + children first, unlink
      // tombstone pointers, then users (otp_challenges cascade with their user).
      await prisma.accountMerge
        .deleteMany({
          where: {
            OR: [{ winnerUserId: { in: createdUserIds } }, { loserUserId: { in: createdUserIds } }],
          },
        })
        .catch(() => undefined);
      await prisma.platformIdentity.deleteMany({ where }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where }).catch(() => undefined);
      await prisma.user
        .updateMany({ where: { id: { in: createdUserIds } }, data: { status: 'ACTIVE', mergedIntoId: null } })
        .catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: createdUserIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the account_merge_foundation migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('creates a user ACTIVE with no tombstone pointer, and round-trips the lifecycle', async () => {
    const id = await newUser();
    const user = await identity.findUserById(id);
    expect(user?.status).toBe(UserStatus.ACTIVE);
    expect(user?.isActive).toBe(true);
    expect(user?.mergedIntoId).toBeNull();
  });

  it('supports a MERGED tombstone pointing at a canonical winner (DEC-0041)', async () => {
    const winner = await newUser();
    const loser = await newUser();
    await prisma.user.update({
      where: { id: loser },
      data: { status: 'MERGED', mergedIntoId: winner },
    });

    const restored = await identity.findUserById(loser);
    expect(restored?.isMerged).toBe(true);
    expect(restored?.mergedIntoId).toBe(winner);
  });

  it('rejects a tombstone pointer to a non-existent winner (self-FK)', async () => {
    const loser = await newUser();
    await expect(
      prisma.user.update({
        where: { id: loser },
        data: { status: 'MERGED', mergedIntoId: newUuidV7() },
      }),
    ).rejects.toBeDefined();
  });

  it('enforces at most one VERIFIED phone per user, across numbers (DEC-0046)', async () => {
    const userId = await newUser();
    await insertVerifiedClaim(userId, nationalToE164());
    // A second VERIFIED claim for the SAME user (different number) is rejected.
    await expect(insertVerifiedClaim(userId, nationalToE164())).rejects.toBeDefined();
  });

  it('still allows different users to each hold one verified number', async () => {
    const a = await newUser();
    const b = await newUser();
    await expect(insertVerifiedClaim(a, nationalToE164())).resolves.toBeDefined();
    await expect(insertVerifiedClaim(b, nationalToE164())).resolves.toBeDefined();
  });

  it('RESTRICTs deleting a user with a platform identity or a phone claim (DEC-0045)', async () => {
    const withPlatform = await newUser();
    await identity.attachPlatformIdentity(withPlatform, Platform.TELEGRAM, subject());
    await expect(prisma.user.delete({ where: { id: withPlatform } })).rejects.toBeDefined();

    const withPhone = await newUser();
    await insertVerifiedClaim(withPhone, nationalToE164());
    await expect(prisma.user.delete({ where: { id: withPhone } })).rejects.toBeDefined();
  });

  it('still CASCADEs otp_challenges when their user is deleted (DEC-0045)', async () => {
    const id = (await identity.createUser()).id; // not tracked: deleted within the test
    await prisma.otpChallenge.create({
      data: {
        id: newUuidV7(),
        userId: id,
        e164: nationalToE164(),
        purpose: 'PHONE_VERIFICATION',
        codeHash: 'x'.repeat(64),
        maxAttempts: 5,
        expiresAt: new Date(Date.now() + 300_000),
      },
    });
    await expect(prisma.user.delete({ where: { id } })).resolves.toBeDefined();
    const remaining = await prisma.otpChallenge.count({ where: { userId: id } });
    expect(remaining).toBe(0);
  });

  it('appends and reads back an immutable merge audit record (DEC-0043)', async () => {
    const winner = await newUser();
    const loser = await newUser();
    const e164 = nationalToE164();
    const record = await merges.append({
      id: newUuidV7(),
      winnerUserId: winner,
      loserUserId: loser,
      verifiedE164: e164,
      initiatingChallengeId: newUuidV7(),
      movedPlatformIdentities: 3,
      movedPhoneClaims: 1,
      context: 'PHONE_VERIFICATION',
    });

    const found = await merges.findById(record.id);
    expect(found?.winnerUserId).toBe(winner);
    expect(found?.loserUserId).toBe(loser);
    expect(found?.verifiedE164).toBe(e164);
    expect(found?.movedPlatformIdentities).toBe(3);
  });

  it('RESTRICTs an audit record referencing a non-existent account (FK)', async () => {
    const winner = await newUser();
    await expect(
      merges.append({
        id: newUuidV7(),
        winnerUserId: winner,
        loserUserId: newUuidV7(), // no such user
        verifiedE164: nationalToE164(),
      }),
    ).rejects.toBeDefined();
  });
});
