import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { PhoneModule } from '../src/phone/phone.module';
import { PhoneVerificationService } from '../src/phone/application/phone-verification.service';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';
import { isUuidV7 } from '@khatmsaz/kernel';

const MIGRATION_NAME = '20260906070332_phone_verification_foundation';

/**
 * A capturing delivery adapter so the test can read the plaintext code exactly
 * as an SMS recipient would (the code is never returned by the service, logged,
 * or stored in plaintext). Replaces the no-op production adapter for the test.
 */
class CapturingDelivery implements OtpDelivery {
  readonly sent: OtpDeliveryRequest[] = [];
  async deliver(request: OtpDeliveryRequest): Promise<void> {
    this.sent.push(request);
  }
  codeFor(e164: string): string {
    const match = [...this.sent].reverse().find((r) => r.e164 === e164);
    if (!match) throw new Error(`no code delivered for ${e164}`);
    return match.code;
  }
}

/**
 * Phone-verification persistence integration tests. Require the local PostgreSQL
 * stack and run only under `npm run test:integration:db`. They exercise the real
 * Prisma repositories, the hand-written partial unique indexes, and concurrent
 * verification. A fresh random national number per test keeps runs independent;
 * created users are removed afterwards (FK cascade removes claims and challenges).
 */
describe('phone verification persistence (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let phone: PhoneVerificationService;
  let delivery: CapturingDelivery;
  const createdUserIds: string[] = [];

  // A random, valid-looking Iranian mobile (0912 + 7 digits) per call.
  const nationalNumber = (): string =>
    `0912${Math.floor(1_000_000 + Math.random() * 8_999_999).toString().slice(0, 7)}`;

  const newUser = async (): Promise<string> => {
    const user = await identity.createUser();
    createdUserIds.push(user.id);
    return user.id;
  };

  beforeAll(async () => {
    delivery = new CapturingDelivery();
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule, PhoneModule],
    })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    phone = moduleRef.get(PhoneVerificationService);
  });

  afterAll(async () => {
    if (prisma && createdUserIds.length > 0) {
      // phone_claims.user_id is now ON DELETE RESTRICT (DEC-0045), so claims must
      // be removed before their users; otp_challenges still cascade on user delete.
      await prisma.phoneClaim
        .deleteMany({ where: { userId: { in: createdUserIds } } })
        .catch(() => undefined);
      await prisma.user
        .deleteMany({ where: { id: { in: createdUserIds } } })
        .catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the phone_verification_foundation migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('stores a claim with a native uuid id, canonical E.164, and UNVERIFIED status', async () => {
    const userId = await newUser();
    const claim = await phone.claimPhone(userId, nationalNumber());
    expect(isUuidV7(claim.id)).toBe(true);
    expect(claim.e164.startsWith('+98')).toBe(true);
    expect(claim.isUnverified).toBe(true);

    const rows = await prisma.$queryRaw<Array<{ data_type: string }>>`
      SELECT data_type FROM information_schema.columns
      WHERE table_name = 'phone_claims' AND column_name = 'id'`;
    expect(rows[0]?.data_type).toBe('uuid');
  });

  it('allows the SAME unverified number to be claimed by DIFFERENT users (contact data)', async () => {
    const national = nationalNumber();
    const a = await newUser();
    const b = await newUser();
    await expect(phone.claimPhone(a, national)).resolves.toBeDefined();
    await expect(phone.claimPhone(b, national)).resolves.toBeDefined();
  });

  it('never persists the plaintext code (only a keyed HMAC)', async () => {
    const userId = await newUser();
    const national = nationalNumber();
    const { e164 } = await phone.requestPhoneVerification(userId, national);
    const code = delivery.codeFor(e164);

    const rows = await prisma.$queryRaw<Array<{ code_hash: string }>>`
      SELECT code_hash FROM otp_challenges WHERE e164 = ${e164}`;
    expect(rows.length).toBeGreaterThan(0);
    for (const row of rows) {
      expect(row.code_hash).not.toContain(code);
      expect(row.code_hash).toMatch(/^[0-9a-f]{64}$/);
    }
  });

  it('verifies a correct code and marks the claim VERIFIED', async () => {
    const userId = await newUser();
    const national = nationalNumber();
    const { e164 } = await phone.requestPhoneVerification(userId, national);
    const result = await phone.verifyPhone(userId, national, delivery.codeFor(e164));
    expect(result.outcome).toBe('VERIFIED');
  });

  it('change phone via OTP: verifying a new number revokes the previous verified one (DEC-0046)', async () => {
    const userId = await newUser();
    const first = nationalNumber();
    const second = nationalNumber();

    const r1 = await phone.requestPhoneVerification(userId, first);
    await phone.verifyPhone(userId, first, delivery.codeFor(r1.e164));

    const r2 = await phone.requestPhoneVerification(userId, second);
    const result = await phone.verifyPhone(userId, second, delivery.codeFor(r2.e164));

    expect(result.outcome).toBe('VERIFIED');
    if (result.outcome === 'VERIFIED') expect(result.replacedE164).toBe(r1.e164);

    // The DB per-user partial index holds: exactly one VERIFIED claim, the new one.
    const verified = await prisma.phoneClaim.findMany({
      where: { userId, status: 'VERIFIED' },
    });
    expect(verified).toHaveLength(1);
    expect(verified[0]?.e164).toBe(r2.e164);

    // The previous number is retained as REVOKED history, never deleted.
    const old = await prisma.phoneClaim.findFirst({ where: { userId, e164: r1.e164 } });
    expect(old?.status).toBe('REVOKED');
    expect(old?.revokedAt).not.toBeNull();
  });

  it('enforces one active VERIFIED owner per number, globally (partial unique index)', async () => {
    const national = nationalNumber();
    const a = await newUser();
    const b = await newUser();

    const ra = await phone.requestPhoneVerification(a, national);
    await phone.verifyPhone(a, national, delivery.codeFor(ra.e164));

    // B claims the same number (allowed, unverified) and verifies with a real code.
    const rb = await phone.requestPhoneVerification(b, national);
    const result = await phone.verifyPhone(b, national, delivery.codeFor(rb.e164));
    expect(result.outcome).toBe('MERGE_REQUIRED');

    // Exactly one verified owner exists in the database.
    const rows = await prisma.$queryRaw<Array<{ count: bigint }>>`
      SELECT COUNT(*)::bigint AS count FROM phone_claims
      WHERE e164 = ${ra.e164} AND status = 'VERIFIED'`;
    expect(Number(rows[0]?.count)).toBe(1);
  });

  it('handles CONCURRENT verification of the same number by two users — exactly one wins', async () => {
    const national = nationalNumber();
    const a = await newUser();
    const b = await newUser();

    // Capture each user's own code right after issuing it (same canonical e164).
    const ra = await phone.requestPhoneVerification(a, national);
    const codeA = delivery.codeFor(ra.e164);
    await phone.requestPhoneVerification(b, national);
    const codeB = delivery.codeFor(ra.e164);

    const [resA, resB] = await Promise.all([
      phone.verifyPhone(a, national, codeA),
      phone.verifyPhone(b, national, codeB),
    ]);

    const outcomes = [resA.outcome, resB.outcome].sort();
    expect(outcomes).toEqual(['MERGE_REQUIRED', 'VERIFIED']);

    const rows = await prisma.$queryRaw<Array<{ count: bigint }>>`
      SELECT COUNT(*)::bigint AS count FROM phone_claims
      WHERE e164 = ${ra.e164} AND status = 'VERIFIED'`;
    expect(Number(rows[0]?.count)).toBe(1);
  });

  it('preserves historical claims: a revoked claim is retained alongside a new one', async () => {
    const userId = await newUser();
    const national = nationalNumber();
    const claim = await phone.claimPhone(userId, national);

    // Simulate an ended claim by revoking it directly (revocation flow is a later
    // phase); the row must remain and not block a fresh claim of the same number.
    await prisma.phoneClaim.update({
      where: { id: claim.id },
      data: { status: 'REVOKED', revokedAt: new Date() },
    });
    const fresh = await phone.claimPhone(userId, national);
    expect(fresh.id).not.toBe(claim.id);

    const rows = await prisma.$queryRaw<Array<{ count: bigint }>>`
      SELECT COUNT(*)::bigint AS count FROM phone_claims WHERE user_id = ${userId}::uuid`;
    expect(Number(rows[0]?.count)).toBe(2); // history preserved
  });

  it('rejects a wrong code, counts the attempt, and single-uses a consumed challenge', async () => {
    const userId = await newUser();
    const national = nationalNumber();
    const { e164 } = await phone.requestPhoneVerification(userId, national);
    const code = delivery.codeFor(e164);

    await expect(phone.verifyPhone(userId, national, '000000')).rejects.toBeDefined();
    const afterWrong = await prisma.$queryRaw<Array<{ attempts: number }>>`
      SELECT attempts FROM otp_challenges WHERE e164 = ${e164} ORDER BY created_at DESC LIMIT 1`;
    expect(afterWrong[0]?.attempts).toBe(1);

    // Correct code verifies and consumes.
    const ok = await phone.verifyPhone(userId, national, code);
    expect(ok.outcome).toBe('VERIFIED');
    const consumed = await prisma.$queryRaw<Array<{ consumed_at: Date | null }>>`
      SELECT consumed_at FROM otp_challenges WHERE e164 = ${e164} ORDER BY created_at DESC LIMIT 1`;
    expect(consumed[0]?.consumed_at).not.toBeNull();
  });

  it('surfaces the ownership conflict as a domain error at the repository boundary', async () => {
    // Two users, both with an UNVERIFIED claim on the same number.
    const national = nationalNumber();
    const a = await newUser();
    const b = await newUser();
    await phone.claimPhone(a, national);
    const claimB = await phone.claimPhone(b, national);

    // Verify A through the public flow.
    const ra = await phone.requestPhoneVerification(a, national);
    await phone.verifyPhone(a, national, delivery.codeFor(ra.e164));

    // Directly forcing B's claim to VERIFIED must hit the partial unique index
    // (this bypasses the service to prove the guarantee is in the DATABASE).
    await expect(
      prisma.phoneClaim.update({
        where: { id: claimB.id },
        data: { status: 'VERIFIED', verifiedAt: new Date() },
      }),
    ).rejects.toBeDefined();

    // A's claim is the sole verified owner; B's is still unverified.
    const bRow = await prisma.phoneClaim.findUnique({ where: { id: claimB.id } });
    expect(bRow?.status).toBe('UNVERIFIED');
  });
});
