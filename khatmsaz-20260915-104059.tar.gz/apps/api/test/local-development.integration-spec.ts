import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Test } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { seedLocalUser, bindLocalTelegram } from '../src/local-development/infrastructure/fixture';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import { LocalOtpDeliveryAdapter } from '../src/phone/infrastructure/local-otp-delivery.adapter';
import { NoopOtpDeliveryAdapter } from '../src/phone/infrastructure/noop-otp-delivery.adapter';
import * as paths from '../src/phone/infrastructure/local-otp-socket';
import { TelegramCommandService } from '../src/telegram/application/telegram-command.service';

describe('local fixtures and real authentication flow (PostgreSQL)', () => {
  const originalEnv = { ...process.env };
  let app: INestApplication;
  let prisma: PrismaService;
  let directory: string;
  const ids: string[] = [];
  const base = Math.floor(1000000 + Math.random() * 7000000);
  const creatorPhone = `+98912${base}`;
  const participantPhone = `+98912${base + 1}`;
  const subject = String(Date.now());
  let creatorId: string;
  let participantId: string;

  beforeAll(async () => {
    process.env.NODE_ENV = 'development';
    process.env.KHATMSAZ_DEV_OTP = '1';
    process.env.TELEGRAM_BOT_TOKEN = '';
    process.env.OTP_RESEND_COOLDOWN_SECONDS = '0';
    process.env.OTP_HMAC_SECRET = 'local-integration-test-only-not-a-real-secret';
    directory = await mkdtemp(join(tmpdir(), 'khatmsaz-local-integration-'));
    jest.spyOn(paths, 'localOtpDirectory').mockReturnValue(directory);
    jest.spyOn(paths, 'localOtpSocket').mockReturnValue(join(directory, 'delivery.sock'));
    const mod = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = mod.createNestApplication();
    await app.init();
    prisma = app.get(PrismaService);
  });
  afterAll(async () => {
    if (prisma) {
      const khatms = await prisma.khatm.findMany({
        where: { creatorUserId: { in: ids } },
        select: { id: true },
      });
      const khatmIds = khatms.map((k) => k.id);
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } });
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } });
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } });
      await prisma.session.deleteMany({ where: { userId: { in: ids } } });
      await prisma.otpChallenge.deleteMany({
        where: { e164: { in: [creatorPhone, participantPhone] } },
      });
      await prisma.userCapability.deleteMany({ where: { userId: { in: ids } } });
      await prisma.platformIdentity.deleteMany({ where: { userId: { in: ids } } });
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: ids } } });
      await prisma.user.deleteMany({ where: { id: { in: ids } } });
    }
    await app?.close();
    if (directory) await rm(directory, { recursive: true, force: true });
    jest.restoreAllMocks();
    process.env = { ...originalEnv };
  });

  it('seeds one user, verified claim and creator grant across repeated/concurrent calls', async () => {
    creatorId = await seedLocalUser(prisma, creatorPhone, true);
    ids.push(creatorId);
    const repeated = await Promise.all([
      seedLocalUser(prisma, creatorPhone, true),
      seedLocalUser(prisma, creatorPhone, true),
    ]);
    expect(repeated).toEqual([creatorId, creatorId]);
    expect(
      await prisma.phoneClaim.count({ where: { e164: creatorPhone, status: 'VERIFIED' } }),
    ).toBe(1);
    expect(
      await prisma.userCapability.count({
        where: { userId: creatorId, type: 'CREATOR', revokedAt: null },
      }),
    ).toBe(1);
    participantId = await seedLocalUser(prisma, participantPhone, false);
    ids.push(participantId);
    expect(await prisma.userCapability.count({ where: { userId: participantId } })).toBe(0);
  });

  it('binds a numeric Telegram identity idempotently and refuses reassignment or usernames', async () => {
    expect(await bindLocalTelegram(prisma, creatorPhone, subject)).toBe(creatorId);
    expect(await bindLocalTelegram(prisma, creatorPhone, subject)).toBe(creatorId);
    expect(await prisma.platformIdentity.count({ where: { platform: 'TELEGRAM', subject } })).toBe(
      1,
    );
    await expect(bindLocalTelegram(prisma, participantPhone, subject)).rejects.toThrow(
      'another account',
    );
    await expect(bindLocalTelegram(prisma, creatorPhone, '@username')).rejects.toThrow('numeric');
  });

  it('uses the normal login, HMAC challenge, httpOnly session and creator authorization', async () => {
    const http = request(app.getHttpServer());
    expect(app.get(OTP_DELIVERY)).toBeInstanceOf(LocalOtpDeliveryAdapter);
    await http.post('/api/auth/phone/request').send({ phone: creatorPhone }).expect(201);
    const code = app.get<LocalOtpDeliveryAdapter>(OTP_DELIVERY).takeLatest(creatorPhone);
    expect(code).not.toBeNull();
    const challenge = await prisma.otpChallenge.findFirstOrThrow({
      where: { e164: creatorPhone },
      orderBy: { createdAt: 'desc' },
    });
    expect(challenge.codeHash).not.toBe(code);
    expect(challenge.codeHash.length).toBeGreaterThan(6);
    const login = await http
      .post('/api/auth/phone/verify')
      .send({ phone: creatorPhone, code })
      .expect(201);
    expect(login.body.userId).toBe(creatorId);
    expect(login.body.token).toBeUndefined();
    const raw = (login.headers['set-cookie'] as unknown as string[])[0]!;
    expect(raw).toContain('HttpOnly');
    const cookie = raw.split(';')[0]!;
    const me = await http.get('/api/me').set('Cookie', cookie).expect(200);
    expect(me.body.isCreator).toBe(true);
    await http
      .post('/api/khatms')
      .set('Cookie', cookie)
      .send({ title: 'Local fixture test', templateType: 'DUA' })
      .expect(201);
    await http.post('/api/auth/phone/verify').send({ phone: creatorPhone, code }).expect(400);
    await http.post('/api/auth/logout').set('Cookie', cookie).expect(204);
    await http.get('/api/me').set('Cookie', cookie).expect(401);
    await http.get('/api/dev/otp/latest').expect(404);
  });

  it('keeps non-creators unauthorized over HTTP and Telegram', async () => {
    const http = request(app.getHttpServer());
    await http.post('/api/auth/phone/request').send({ phone: participantPhone }).expect(201);
    const code = app.get<LocalOtpDeliveryAdapter>(OTP_DELIVERY).takeLatest(participantPhone);
    const login = await http
      .post('/api/auth/phone/verify')
      .send({ phone: participantPhone, code })
      .expect(201);
    const cookie = (login.headers['set-cookie'] as unknown as string[])[0]!.split(';')[0]!;
    await http
      .post('/api/khatms')
      .set('Cookie', cookie)
      .send({ title: 'Denied', templateType: 'DUA' })
      .expect(403);
    const otherSubject = String(Number(subject) + 1);
    await bindLocalTelegram(prisma, participantPhone, otherSubject);
    const telegram = app.get(TelegramCommandService);
    const reply = await telegram.handle({
      fromId: otherSubject,
      chatId: otherSubject,
      text: '/create_khatm DUA Denied',
    });
    expect(reply.text).toContain('اجازه');
    expect(await prisma.khatm.count({ where: { creatorUserId: participantId } })).toBe(0);
  });

  it('Telegram /start reuses the seed and create/list/progress run the existing workflow', async () => {
    const telegram = app.get(TelegramCommandService);
    const send = (text: string) => telegram.handle({ fromId: subject, chatId: subject, text });
    await send('/start');
    await send('/start');
    const link = await prisma.platformIdentity.findUniqueOrThrow({
      where: { platform_subject: { platform: 'TELEGRAM', subject } },
    });
    expect(link.userId).toBe(creatorId);
    await send('/create_khatm DUA Telegram-local');
    const khatm = await prisma.khatm.findFirstOrThrow({
      where: { creatorUserId: creatorId, title: 'Telegram-local' },
    });
    expect((await send('/my_khatms')).text).toContain(khatm.id);
    expect((await send(`/progress ${khatm.id}`)).text).toContain('مجموع');
  });

  it.each(['production', 'test', 'staging'])(
    'refuses fixtures and uses no-op delivery in %s even with opt-in',
    async (mode) => {
      process.env.NODE_ENV = mode;
      try {
        await expect(seedLocalUser(prisma, creatorPhone, true)).rejects.toThrow('development');
        await expect(bindLocalTelegram(prisma, creatorPhone, subject)).rejects.toThrow(
          'development',
        );
        const mod = await Test.createTestingModule({ imports: [AppModule] }).compile();
        expect(mod.get(OTP_DELIVERY)).toBeInstanceOf(NoopOtpDeliveryAdapter);
        const other = mod.createNestApplication();
        await other.init();
        try {
          await request(other.getHttpServer()).get('/api/dev/otp/latest').expect(404);
        } finally {
          await other.close();
        }
      } finally {
        process.env.NODE_ENV = 'development';
      }
    },
  );
});
