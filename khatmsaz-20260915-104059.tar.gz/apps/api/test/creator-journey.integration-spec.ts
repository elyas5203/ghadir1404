import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';

class CapturingDelivery implements OtpDelivery {
  private readonly m = new Map<string, string>();
  async deliver(r: OtpDeliveryRequest): Promise<void> {
    this.m.set(r.e164, r.code);
  }
  codeFor(e: string): string {
    const c = this.m.get(e);
    if (!c) throw new Error(`no code ${e}`);
    return c;
  }
}

/**
 * The end-to-end CREATOR journey over the real phone-first cookie auth (Phase 10):
 * authenticate → (grant CREATOR internally) → create → activate → generate
 * allocation → manage progress; plus non-creator rejection (403) and ownership
 * protection (403). Requires local PostgreSQL.
 */
describe('creator journey over phone-first cookie auth (requires local PostgreSQL)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let authz: AuthorizationService;
  const delivery = new CapturingDelivery();

  const e164s: string[] = [];
  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const login = async (): Promise<{ cookie: string; userId: string }> => {
    const http = request(app.getHttpServer());
    const phone = `+98912${Math.floor(1_000_000 + Math.random() * 8_999_999)}`;
    e164s.push(phone);
    await http.post('/api/auth/phone/request').send({ phone }).expect(201);
    const res = await http.post('/api/auth/phone/verify').send({ phone, code: delivery.codeFor(phone) }).expect(201);
    userIds.push(res.body.userId);
    const setCookie = res.headers['set-cookie'] as unknown as string[];
    const cookie = (setCookie.find((c) => c.startsWith('khatmsaz_session=')) as string).split(';')[0] as string;
    return { cookie, userId: res.body.userId };
  };

  beforeAll(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    app = moduleRef.createNestApplication();
    await app.init();
    prisma = app.get(PrismaService);
    authz = app.get(AuthorizationService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { e164: { in: e164s } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('a non-creator is rejected (403) and a granted creator completes the journey', async () => {
    const http = request(app.getHttpServer());
    const creator = await login();

    // Non-creator cannot create.
    await http
      .post('/api/khatms')
      .set('Cookie', creator.cookie)
      .send({ title: 'ختم', templateType: 'QURAN_FULL' })
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('CapabilityRequiredError'));

    // Grant CREATOR (explicit internal mechanism, DEC-0062), then the journey works.
    await authz.grantCapability(creator.userId, CapabilityType.CREATOR);

    const created = await http
      .post('/api/khatms')
      .set('Cookie', creator.cookie)
      .send({ title: 'ختم قرآن', templateType: 'QURAN_FULL' })
      .expect(201);
    khatmIds.push(created.body.id);
    const khatmId = created.body.id as string;

    await http
      .post(`/api/khatms/${khatmId}/plan`)
      .set('Cookie', creator.cookie)
      .send({ spec: { kind: 'POSITIONAL', from: 1, to: 5 } })
      .expect(201);
    await http.post(`/api/khatms/${khatmId}/activate`).set('Cookie', creator.cookie).expect(204);
    await http
      .get(`/api/khatms/${khatmId}/progress`)
      .set('Cookie', creator.cookie)
      .expect(200)
      .expect((r) => expect(r.body).toMatchObject({ total: 5, open: 5 }));

    // Ownership protection: another authenticated creator cannot manage this khatm.
    const intruder = await login();
    await authz.grantCapability(intruder.userId, CapabilityType.CREATOR);
    await http
      .post(`/api/khatms/${khatmId}/activate`)
      .set('Cookie', intruder.cookie)
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('ResourceOwnershipError'));
  });
});
