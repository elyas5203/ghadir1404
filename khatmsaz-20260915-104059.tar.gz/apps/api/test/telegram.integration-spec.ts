import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { KhatmModule } from '../src/khatm/khatm.module';
import { AllocationModule } from '../src/allocation/allocation.module';
import { KhatmWorkflowModule } from '../src/khatm-workflow/khatm-workflow.module';
import { KhatmWorkflowService } from '../src/khatm-workflow/application/khatm-workflow.service';
import { AuthorizationModule } from '../src/authorization/authorization.module';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { TelegramModule } from '../src/telegram/telegram.module';
import { TelegramCommandService } from '../src/telegram/application/telegram-command.service';
import { PortionUnitKind } from '../src/allocation/domain/portion-unit-kind';

/**
 * Telegram transport integration (requires local PostgreSQL,
 * `npm run test:integration:db`). Drives commands through the real identity and
 * workflow capabilities and asserts the resulting database state — no Telegram
 * network is involved (the sender is a no-op). Teardown is child-first.
 */
describe('telegram transport (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let telegram: TelegramCommandService;
  let workflow: KhatmWorkflowService;
  let authz: AuthorizationService;

  const fromIds: string[] = [];
  const khatmIds: string[] = [];
  const send = (fromId: string, text: string) =>
    telegram.handle({ chatId: fromId, fromId, text });

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [
        DatabaseModule,
        IdentityModule,
        KhatmModule,
        AllocationModule,
        AuthorizationModule,
        KhatmWorkflowModule,
        TelegramModule,
      ],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    telegram = moduleRef.get(TelegramCommandService);
    workflow = moduleRef.get(KhatmWorkflowService);
    authz = moduleRef.get(AuthorizationService);
  });

  afterAll(async () => {
    if (prisma) {
      const links = await prisma.platformIdentity
        .findMany({ where: { platform: 'TELEGRAM', subject: { in: fromIds } }, select: { userId: true } })
        .catch(() => [] as { userId: string }[]);
      const userIds = links.map((l) => l.userId);
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.participation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.platformIdentity.deleteMany({ where: { subject: { in: fromIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('resolves Telegram identity to a User and drives the khatm workflow', async () => {
    const creatorFrom = `tg-${Date.now()}-a`;
    fromIds.push(creatorFrom);

    // /start provisions a User + a TELEGRAM platform identity.
    const started = await send(creatorFrom, '/start');
    expect(started.text).toContain('خوش آمدید');
    const link = await prisma.platformIdentity.findFirst({
      where: { platform: 'TELEGRAM', subject: creatorFrom },
    });
    expect(link).not.toBeNull();
    const creatorUserId = link?.userId as string;
    const creator = await prisma.user.findUnique({ where: { id: creatorUserId } });
    expect(creator?.status).toBe('ACTIVE');

    // Grant the resolved user the CREATOR capability (explicit internal grant,
    // DEC-0062) — creating a khatm now requires it (DEC-0063).
    await authz.grantCapability(creatorUserId, CapabilityType.CREATOR);

    // /create_khatm creates a DRAFT khatm owned by the resolved user.
    const created = await send(creatorFrom, '/create_khatm QURAN_FULL ختم قرآن');
    expect(created.text).toContain('شناسه');
    const khatms = await prisma.khatm.findMany({ where: { creatorUserId } });
    expect(khatms).toHaveLength(1);
    const khatmId = khatms[0]?.id as string;
    khatmIds.push(khatmId);
    expect(khatms[0]?.status).toBe('DRAFT');
    expect(khatms[0]?.title).toBe('ختم قرآن');

    // /my_khatms lists it.
    const listed = await send(creatorFrom, '/my_khatms');
    expect(listed.text).toContain(khatmId);

    // Prepare the khatm for joining (plan + activate) via the workflow directly,
    // acting as the owner.
    await workflow.generateAllocationPlan(khatmId, creatorUserId, {
      kind: PortionUnitKind.POSITIONAL,
      from: 1,
      to: 10,
    });
    await workflow.activateKhatm(khatmId, creatorUserId);

    // A second Telegram user starts; joining is done via the workflow (raw /join was
    // retired in Phase 10.4 — invitations replace it in Phase 11).
    const joinerFrom = `tg-${Date.now()}-b`;
    fromIds.push(joinerFrom);
    await send(joinerFrom, '/start');
    const joinerLink = await prisma.platformIdentity.findFirst({
      where: { platform: 'TELEGRAM', subject: joinerFrom },
    });
    await workflow.joinKhatm(khatmId, joinerLink?.userId as string);
    const participation = await prisma.participation.findFirst({
      where: { khatmId, userId: joinerLink?.userId },
    });
    expect(participation?.status).toBe('ACTIVE');

    // /progress reports the plan's totals.
    const progress = await send(joinerFrom, `/progress ${khatmId}`);
    expect(progress.text).toContain('10');
  });

  it('treats the retired /join command as unknown (superseded by invitations)', async () => {
    const from = `tg-${Date.now()}-c`;
    fromIds.push(from);
    await send(from, '/start');
    const reply = await send(from, `/join ${newUuidV7()}`);
    expect(reply.text).toContain('شناخته نشد');
  });

  it('asks an unknown user to /start before creating a khatm', async () => {
    const reply = await send(`tg-${Date.now()}-never`, '/create_khatm DUA x');
    expect(reply.text).toContain('/start');
  });
});
