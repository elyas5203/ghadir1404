import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { KhatmModule } from '../src/khatm/khatm.module';
import { KhatmService } from '../src/khatm/application/khatm.service';
import { KhatmStatus } from '../src/khatm/domain/khatm-status';
import { KhatmTemplateType } from '../src/khatm/domain/khatm-template';
import { ParticipationStatus } from '../src/khatm/domain/participation-status';
import { AssignmentStatus } from '../src/khatm/domain/assignment-status';
import { AssignmentUnitKind } from '../src/khatm/domain/portion';
import { Portion } from '../src/khatm/domain/portion';
import {
  DuplicateParticipationError,
  KhatmCreatorNotFoundError,
} from '../src/khatm/domain/khatm.errors';

const MIGRATION_NAME = '20260906195317_khatm_engine_foundation';

/**
 * Khatm-engine persistence integration tests. Require the local PostgreSQL stack
 * and run only under `npm run test:integration:db`. They exercise the real Prisma
 * repositories, the participation partial unique index, portion persistence, the
 * derived progress query, and the FK RESTRICT strategy (DEC-0045/0051). Everything
 * created is torn down child-first afterwards (RESTRICT forbids deleting a parent
 * with children).
 */
describe('khatm engine persistence (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let khatm: KhatmService;

  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const newUser = async (): Promise<string> => {
    const u = await identity.createUser();
    userIds.push(u.id);
    return u.id;
  };
  const newActiveKhatm = async (
    creatorUserId: string,
    templateType: KhatmTemplateType = KhatmTemplateType.QURAN_FULL,
  ): Promise<string> => {
    const k = await khatm.createKhatm({ creatorUserId, title: 'ختم', templateType });
    khatmIds.push(k.id);
    await khatm.activateKhatm(k.id);
    return k.id;
  };

  beforeAll(async () => {
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule, KhatmModule],
    }).compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    khatm = moduleRef.get(KhatmService);
  });

  afterAll(async () => {
    if (prisma) {
      // Child-first: assignments → participations → khatms → users (all RESTRICT).
      await prisma.assignment
        .deleteMany({ where: { khatmId: { in: khatmIds } } })
        .catch(() => undefined);
      await prisma.participation
        .deleteMany({ where: { khatmId: { in: khatmIds } } })
        .catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the khatm_engine_foundation migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('creates a DRAFT khatm and round-trips it with its template and creator', async () => {
    const creator = await newUser();
    const created = await khatm.createKhatm({
      creatorUserId: creator,
      title: '  ختم قرآن خانوادگی  ',
      description: '  به نیت سلامتی  ',
      templateType: KhatmTemplateType.QURAN_FULL,
    });
    khatmIds.push(created.id);

    const found = await khatm.findKhatmById(created.id);
    expect(found).not.toBeNull();
    expect(found?.status).toBe(KhatmStatus.DRAFT);
    expect(found?.creatorUserId).toBe(creator);
    expect(found?.title).toBe('ختم قرآن خانوادگی');
    expect(found?.description).toBe('به نیت سلامتی');
    expect(found?.templateType).toBe(KhatmTemplateType.QURAN_FULL);
  });

  it('rejects creating a khatm for a non-existent creator (FK)', async () => {
    await expect(
      khatm.createKhatm({
        creatorUserId: '018f9a2b-0000-7000-8000-0000000000fe',
        title: 'ختم',
        templateType: KhatmTemplateType.DUA,
      }),
    ).rejects.toBeInstanceOf(KhatmCreatorNotFoundError);
  });

  it('persists the full lifecycle DRAFT → ACTIVE → COMPLETED', async () => {
    const creator = await newUser();
    const id = await newActiveKhatm(creator);
    expect((await khatm.findKhatmById(id))?.status).toBe(KhatmStatus.ACTIVE);
    await khatm.completeKhatm(id);
    expect((await khatm.findKhatmById(id))?.status).toBe(KhatmStatus.COMPLETED);
  });

  it('enforces one ACTIVE participation per (khatm, user) but retains history on rejoin', async () => {
    const creator = await newUser();
    const joiner = await newUser();
    const id = await newActiveKhatm(creator);

    const first = await khatm.join(id, joiner);
    await expect(khatm.join(id, joiner)).rejects.toBeInstanceOf(DuplicateParticipationError);

    await khatm.leaveParticipation(first.id);
    const second = await khatm.join(id, joiner);
    expect(second.id).not.toBe(first.id);

    // History preserved: the old row is LEFT, the new row is ACTIVE.
    const rows = await prisma.participation.findMany({
      where: { khatmId: id, userId: joiner },
      orderBy: { joinedAt: 'asc' },
    });
    expect(rows.map((r) => r.status)).toEqual([
      ParticipationStatus.LEFT,
      ParticipationStatus.ACTIVE,
    ]);
  });

  it('persists positional and quantity portions and derives progress', async () => {
    const creator = await newUser();
    const joiner = await newUser();
    const id = await newActiveKhatm(creator);
    const p = await khatm.join(id, joiner);

    const positional = await khatm.assignPortion(p.id, Portion.positional(1, 15));
    const quantity = await khatm.assignPortion(p.id, Portion.quantity(500));

    const posRow = await prisma.assignment.findUnique({ where: { id: positional.id } });
    expect(posRow?.unitKind).toBe(AssignmentUnitKind.POSITIONAL);
    expect(posRow?.unitStart).toBe(1);
    expect(posRow?.unitEnd).toBe(15);
    expect(posRow?.quantity).toBeNull();

    const qtyRow = await prisma.assignment.findUnique({ where: { id: quantity.id } });
    expect(qtyRow?.unitKind).toBe(AssignmentUnitKind.QUANTITY);
    expect(qtyRow?.quantity).toBe(500);
    expect(qtyRow?.unitStart).toBeNull();

    expect(await khatm.khatmProgress(id)).toEqual({ total: 2, completed: 0 });
    await khatm.completeAssignment(positional.id);
    expect(await khatm.khatmProgress(id)).toEqual({ total: 2, completed: 1 });

    const completedRow = await prisma.assignment.findUnique({ where: { id: positional.id } });
    expect(completedRow?.status).toBe(AssignmentStatus.COMPLETED);
    expect(completedRow?.completedAt).toBeInstanceOf(Date);
  });

  it('rejects new assignments once the khatm is COMPLETED', async () => {
    const creator = await newUser();
    const joiner = await newUser();
    const id = await newActiveKhatm(creator);
    const p = await khatm.join(id, joiner);
    await khatm.completeKhatm(id);
    await expect(khatm.assignPortion(p.id, Portion.quantity(10))).rejects.toThrow();
  });

  it('RESTRICT forbids hard-deleting a user who created a khatm', async () => {
    const creator = await newUser();
    const id = await newActiveKhatm(creator);
    void id;
    await expect(prisma.user.delete({ where: { id: creator } })).rejects.toBeDefined();
  });
});
