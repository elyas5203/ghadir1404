import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { AuthorizationService } from '../src/authorization/application/authorization.service';
import { CapabilityType } from '../src/authorization/domain/capability-type';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';

class CapturingDelivery implements OtpDelivery {
  private readonly m = new Map<string, string>();
  async deliver(r: OtpDeliveryRequest): Promise<void> {
    this.m.set(r.e164, r.code);
  }
  codeFor(e: string): string {
    const c = this.m.get(e);
    if (!c) throw new Error(`no code ${e}`);
    return c;
  }
}

/**
 * Invitation + participant experience integration (requires local PostgreSQL,
 * DEC-0068). Covers create/accept/expired/unauthorized, plus the participant reads
 * (joined khatms, my portions) over the real phone-first cookie auth.
 */
describe('invitations & participant experience (requires local PostgreSQL)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let authz: AuthorizationService;
  const delivery = new CapturingDelivery();
  const e164s: string[] = [];
  const userIds: string[] = [];
  const khatmIds: string[] = [];

  const login = async (): Promise<{ cookie: string; userId: string }> => {
    const http = request(app.getHttpServer());
    const phone = `+98912${Math.floor(1_000_000 + Math.random() * 8_999_999)}`;
    e164s.push(phone);
    await http.post('/api/auth/phone/request').send({ phone }).expect(201);
    const res = await http.post('/api/auth/phone/verify').send({ phone, code: delivery.codeFor(phone) }).expect(201);
    userIds.push(res.body.userId);
    const setCookie = res.headers['set-cookie'] as unknown as string[];
    const cookie = (setCookie.find((c) => c.startsWith('khatmsaz_session=')) as string).split(';')[0] as string;
    return { cookie, userId: res.body.userId };
  };

  const makeActiveKhatm = async (cookie: string): Promise<string> => {
    const http = request(app.getHttpServer());
    const created = await http.post('/api/khatms').set('Cookie', cookie).send({ title: 'ختم', templateType: 'QURAN_FULL' }).expect(201);
    const id = created.body.id as string;
    khatmIds.push(id);
    await http.post(`/api/khatms/${id}/plan`).set('Cookie', cookie).send({ spec: { kind: 'POSITIONAL', from: 1, to: 3 } }).expect(201);
    await http.post(`/api/khatms/${id}/activate`).set('Cookie', cookie).expect(204);
    return id;
  };

  beforeAll(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    app = moduleRef.createNestApplication();
    await app.init();
    prisma = app.get(PrismaService);
    authz = app.get(AuthorizationService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.khatmInvitation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmPortion.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatmAllocationPlan.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.participation.deleteMany({ where: { khatmId: { in: khatmIds } } }).catch(() => undefined);
      await prisma.khatm.deleteMany({ where: { id: { in: khatmIds } } }).catch(() => undefined);
      await prisma.userCapability.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { e164: { in: e164s } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('owner creates an invitation; a participant accepts, joins, and sees it', async () => {
    const http = request(app.getHttpServer());
    const owner = await login();
    await authz.grantCapability(owner.userId, CapabilityType.CREATOR);
    const khatmId = await makeActiveKhatm(owner.cookie);

    // Owner issues an invitation.
    const inv = await http.post(`/api/khatms/${khatmId}/invitations`).set('Cookie', owner.cookie).expect(201);
    const token = inv.body.token as string;
    expect(token).toEqual(expect.any(String));

    // A non-owner cannot issue one.
    const stranger = await login();
    await http
      .post(`/api/khatms/${khatmId}/invitations`)
      .set('Cookie', stranger.cookie)
      .expect(403)
      .expect((r) => expect(r.body.error.code).toBe('ResourceOwnershipError'));

    // A participant accepts and joins.
    const participant = await login();
    const accepted = await http.post('/api/invitations/accept').set('Cookie', participant.cookie).send({ token }).expect(201);
    expect(accepted.body.khatmId).toBe(khatmId);

    // The participant now sees the khatm among their joined khatms.
    const mine = await http.get('/api/me/khatms').set('Cookie', participant.cookie).expect(200);
    expect((mine.body.khatms as Array<{ id: string }>).some((k) => k.id === khatmId)).toBe(true);

    // The owner allocates a portion to the participant, who then sees it.
    const parts = await http.get(`/api/khatms/${khatmId}/participants`).set('Cookie', owner.cookie).expect(200);
    const participationId = (parts.body.participants as Array<{ participationId: string; userId: string }>).find(
      (p) => p.userId === participant.userId,
    )?.participationId;
    await http.post(`/api/khatms/${khatmId}/allocate`).set('Cookie', owner.cookie).send({ participationId, count: 2 }).expect(201);
    const myPortions = await http.get(`/api/khatms/${khatmId}/my-portions`).set('Cookie', participant.cookie).expect(200);
    expect(myPortions.body.portions).toHaveLength(2);
    expect(myPortions.body.portions[0].status).toBe('ASSIGNED');
  });

  it('rejects accepting an expired invitation, and an unauthenticated accept (401)', async () => {
    const http = request(app.getHttpServer());
    const owner = await login();
    await authz.grantCapability(owner.userId, CapabilityType.CREATOR);
    const khatmId = await makeActiveKhatm(owner.cookie);
    const inv = await http.post(`/api/khatms/${khatmId}/invitations`).set('Cookie', owner.cookie).expect(201);
    const token = inv.body.token as string;

    // Force the invitation to be expired.
    await prisma.khatmInvitation.update({
      where: { id: inv.body.invitationId },
      data: { expiresAt: new Date(Date.now() - 1000) },
    });

    const participant = await login();
    await http
      .post('/api/invitations/accept')
      .set('Cookie', participant.cookie)
      .send({ token })
      .expect(409)
      .expect((r) => expect(r.body.error.code).toBe('InvitationNotAcceptableError'));

    // Unauthenticated accept is rejected before anything else.
    await http.post('/api/invitations/accept').send({ token }).expect(401);
  });
});
