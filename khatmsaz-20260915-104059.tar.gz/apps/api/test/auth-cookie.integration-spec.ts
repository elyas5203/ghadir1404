import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';

class CapturingDelivery implements OtpDelivery {
  private readonly byE164 = new Map<string, string>();
  async deliver(req: OtpDeliveryRequest): Promise<void> {
    this.byE164.set(req.e164, req.code);
  }
  codeFor(e164: string): string {
    const c = this.byE164.get(e164);
    if (!c) throw new Error(`no code for ${e164}`);
    return c;
  }
}

/**
 * Browser session (httpOnly cookie) integration (requires local PostgreSQL,
 * `npm run test:integration:db`, DEC-0067). Proves: phone-first verify sets an
 * httpOnly session cookie (and no token in the body), the cookie authenticates a
 * request, and logout invalidates the server session so the cookie is then rejected.
 */
describe('browser cookie sessions (requires local PostgreSQL)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  const delivery = new CapturingDelivery();

  const e164s: string[] = [];
  const userIds: string[] = [];
  const phone = `+98912${Math.floor(1_000_000 + Math.random() * 8_999_999)}`;
  e164s.push(phone);

  const cookieName = 'khatmsaz_session';
  const sessionCookie = (setCookie: string[] | undefined): string => {
    const raw = (setCookie ?? []).find((c) => c.startsWith(`${cookieName}=`));
    if (!raw) throw new Error('no session cookie set');
    return raw.split(';')[0] as string;
  };

  beforeAll(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    app = moduleRef.createNestApplication();
    await app.init();
    prisma = app.get(PrismaService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { e164: { in: e164s } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('phone verify sets an httpOnly cookie and does NOT return the token', async () => {
    const http = request(app.getHttpServer());
    await http.post('/api/auth/phone/request').send({ phone }).expect(201);

    const verify = await http
      .post('/api/auth/phone/verify')
      .send({ phone, code: delivery.codeFor(phone) })
      .expect(201);

    userIds.push(verify.body.userId);
    expect(verify.body.token).toBeUndefined(); // token never in the body
    expect(verify.body.isNewUser).toBe(true);

    const setCookie = verify.headers['set-cookie'] as unknown as string[];
    const raw = (setCookie ?? []).find((c) => c.startsWith(`${cookieName}=`)) ?? '';
    expect(raw).toContain('HttpOnly');
    expect(raw.toLowerCase()).toContain('samesite=lax');

    // The cookie authenticates a request.
    const cookie = sessionCookie(setCookie);
    const me = await http.get('/api/me').set('Cookie', cookie).expect(200);
    expect(me.body.userId).toBe(verify.body.userId);
    expect(me.body.isCreator).toBe(false);

    // Logout invalidates the server session; the same cookie is then rejected.
    await http.post('/api/auth/logout').set('Cookie', cookie).expect(204);
    await http.get('/api/me').set('Cookie', cookie).expect(401);
  });

  it('rejects a request with no cookie and no bearer token (401)', async () => {
    await request(app.getHttpServer()).get('/api/me').expect(401);
  });
});
