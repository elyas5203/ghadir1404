import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7 } from '@khatmsaz/kernel';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { Platform } from '../src/identity/domain/platform';
import { PhoneModule } from '../src/phone/phone.module';
import { PhoneVerificationService } from '../src/phone/application/phone-verification.service';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';
import { AccountMergeModule } from '../src/account-merge/account-merge.module';
import { AccountMergeService } from '../src/account-merge/application/account-merge.service';
import { InvalidAccountMergeError } from '../src/identity/domain/identity.errors';

class CapturingDelivery implements OtpDelivery {
  readonly sent: OtpDeliveryRequest[] = [];
  async deliver(request: OtpDeliveryRequest): Promise<void> {
    this.sent.push(request);
  }
  codeFor(e164: string): string {
    const match = [...this.sent].reverse().find((r) => r.e164 === e164);
    if (!match) throw new Error(`no code delivered for ${e164}`);
    return match.code;
  }
}

/**
 * Account-merge use-case integration tests (Phase 3B, real PostgreSQL). Intra-
 * product only (DEC-0047). They exercise the full merge through the real
 * repositories and UnitOfWork: data moves to the winner, the loser is tombstoned
 * and retained, history is preserved, and an audit row is written — all atomically.
 */
describe('account merge use-case (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let phone: PhoneVerificationService;
  let merge: AccountMergeService;
  let delivery: CapturingDelivery;
  const createdUserIds: string[] = [];

  const track = (id: string): string => {
    createdUserIds.push(id);
    return id;
  };
  const newUser = async (): Promise<string> => track((await identity.createUser()).id);
  const subject = (): string => `subj-${newUuidV7()}`;
  const nationalNumber = (): string =>
    `0912${Math.floor(1_000_000 + Math.random() * 8_999_999).toString().slice(0, 7)}`;

  const verify = async (userId: string, national: string): Promise<string> => {
    const { e164 } = await phone.requestPhoneVerification(userId, national);
    await phone.verifyPhone(userId, national, delivery.codeFor(e164));
    return e164;
  };

  beforeAll(async () => {
    delivery = new CapturingDelivery();
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule, PhoneModule, AccountMergeModule],
    })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    phone = moduleRef.get(PhoneVerificationService);
    merge = moduleRef.get(AccountMergeService);
  });

  afterAll(async () => {
    if (prisma && createdUserIds.length > 0) {
      const where = { userId: { in: createdUserIds } };
      await prisma.accountMerge
        .deleteMany({
          where: {
            OR: [{ winnerUserId: { in: createdUserIds } }, { loserUserId: { in: createdUserIds } }],
          },
        })
        .catch(() => undefined);
      await prisma.platformIdentity.deleteMany({ where }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where }).catch(() => undefined);
      await prisma.user
        .updateMany({ where: { id: { in: createdUserIds } }, data: { status: 'ACTIVE', mergedIntoId: null } })
        .catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: createdUserIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('resolves a MERGE_REQUIRED conflict: moves data, tombstones the loser, writes an audit', async () => {
    // Winner A verifies the number; loser B (with a channel login) collides on it.
    const a = await newUser();
    const b = await newUser();
    const p = nationalNumber();
    const pE164 = await verify(a, p);
    await identity.attachPlatformIdentity(b, Platform.TELEGRAM, subject());

    const rB = await phone.requestPhoneVerification(b, p);
    const conflict = await phone.verifyPhone(b, p, delivery.codeFor(rB.e164));
    expect(conflict.outcome).toBe('MERGE_REQUIRED');

    const audit = await merge.mergeAccounts({
      winnerUserId: a,
      loserUserId: b,
      verifiedE164: pE164,
      initiatingChallengeId: rB.challengeId,
      context: 'PHONE_VERIFICATION',
    });

    // Audit persisted with the winner canonical.
    expect(audit.winnerUserId).toBe(a);
    expect(audit.loserUserId).toBe(b);
    expect(audit.movedPlatformIdentities).toBe(1);
    const storedAudit = await prisma.accountMerge.findUnique({ where: { id: audit.id } });
    expect(storedAudit).not.toBeNull();

    // Loser tombstoned, retained (not deleted), pointing at the winner.
    const bRow = await prisma.user.findUnique({ where: { id: b } });
    expect(bRow?.status).toBe('MERGED');
    expect(bRow?.mergedIntoId).toBe(a);

    // Channel login moved to the winner.
    expect(await prisma.platformIdentity.count({ where: { userId: b } })).toBe(0);
    expect(await prisma.platformIdentity.count({ where: { userId: a } })).toBe(1);

    // Winner still owns the number, and holds exactly one verified phone.
    const aVerified = await prisma.phoneClaim.findMany({ where: { userId: a, status: 'VERIFIED' } });
    expect(aVerified).toHaveLength(1);
    expect(aVerified[0]?.e164).toBe(pE164);

    // Loser has no active claims left (moved/revoked); history retained under winner.
    expect(await prisma.phoneClaim.count({ where: { userId: b, status: { not: 'REVOKED' } } })).toBe(0);
  });

  it('revokes the loser\'s OWN different verified number during the merge (DEC-0046)', async () => {
    const a = await newUser();
    const b = await newUser();
    const shared = nationalNumber();
    const bOwn = nationalNumber();

    const sharedE164 = await verify(a, shared); // A owns the shared number
    const bOwnE164 = await verify(b, bOwn); // B has its own different verified number

    // B collides on the shared number → MERGE_REQUIRED.
    const rB = await phone.requestPhoneVerification(b, shared);
    expect((await phone.verifyPhone(b, shared, delivery.codeFor(rB.e164))).outcome).toBe(
      'MERGE_REQUIRED',
    );

    await merge.mergeAccounts({ winnerUserId: a, loserUserId: b, verifiedE164: sharedE164 });

    // The winner keeps exactly one verified phone: the shared number.
    const aVerified = await prisma.phoneClaim.findMany({ where: { userId: a, status: 'VERIFIED' } });
    expect(aVerified).toHaveLength(1);
    expect(aVerified[0]?.e164).toBe(sharedE164);

    // B's own number is retained as REVOKED history (moved to the winner).
    const bOwnRow = await prisma.phoneClaim.findFirst({ where: { e164: bOwnE164 } });
    expect(bOwnRow?.status).toBe('REVOKED');
    expect(bOwnRow?.userId).toBe(a);
  });

  it('rejects merging an already-merged (inactive) account', async () => {
    const a = await newUser();
    const b = await newUser();
    await merge.mergeAccounts({ winnerUserId: a, loserUserId: b, verifiedE164: nationalNumber() });
    // Second merge of the same loser must be rejected.
    await expect(
      merge.mergeAccounts({ winnerUserId: a, loserUserId: b, verifiedE164: nationalNumber() }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);
  });

  it('rolls back and changes nothing when the winner does not exist (atomicity)', async () => {
    const b = await newUser();
    await identity.attachPlatformIdentity(b, Platform.TELEGRAM, subject());

    await expect(
      merge.mergeAccounts({
        winnerUserId: newUuidV7(), // no such user
        loserUserId: b,
        verifiedE164: nationalNumber(),
      }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);

    // The loser is untouched: still ACTIVE, still owns its platform identity.
    const bRow = await prisma.user.findUnique({ where: { id: b } });
    expect(bRow?.status).toBe('ACTIVE');
    expect(await prisma.platformIdentity.count({ where: { userId: b } })).toBe(1);
  });
});
