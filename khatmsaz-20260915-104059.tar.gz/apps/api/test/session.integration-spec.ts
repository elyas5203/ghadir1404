import { createHash } from 'node:crypto';
import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseModule } from '../src/infrastructure/database/database.module';
import { PrismaService } from '../src/infrastructure/database/prisma/prisma.service';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/application/identity.service';
import { PhoneModule } from '../src/phone/phone.module';
import { PhoneVerificationService } from '../src/phone/application/phone-verification.service';
import { OTP_DELIVERY } from '../src/phone/domain/otp-delivery';
import type { OtpDelivery, OtpDeliveryRequest } from '../src/phone/domain/otp-delivery';
import { SessionModule } from '../src/session/session.module';
import { AuthenticationService } from '../src/session/application/authentication.service';
import { PhoneOtpLoginService } from '../src/session/application/phone-otp-login.service';
import {
  InvalidSessionTokenError,
  SessionExpiredError,
  SessionRevokedError,
} from '../src/session/domain/session.errors';

const MIGRATION_NAME = '20260907071058_session_foundation';

/** Capturing OTP delivery so the phone-login bridge test can read the real code. */
class CapturingDelivery implements OtpDelivery {
  readonly sent: OtpDeliveryRequest[] = [];
  async deliver(request: OtpDeliveryRequest): Promise<void> {
    this.sent.push(request);
  }
  codeFor(e164: string): string {
    const match = [...this.sent].reverse().find((r) => r.e164 === e164);
    if (!match) throw new Error(`no code delivered for ${e164}`);
    return match.code;
  }
}

/**
 * Session / authentication persistence integration (requires local PostgreSQL,
 * `npm run test:integration:db`). Exercises the real Prisma session repository,
 * token hashing, lifecycle, and the phone-OTP login bridge. Teardown removes
 * sessions before users (FK cascade would also cover it).
 */
describe('session & authentication persistence (requires local PostgreSQL)', () => {
  let moduleRef: TestingModule;
  let prisma: PrismaService;
  let identity: IdentityService;
  let phone: PhoneVerificationService;
  let auth: AuthenticationService;
  let login: PhoneOtpLoginService;
  let delivery: CapturingDelivery;

  const userIds: string[] = [];
  const nationalNumber = (): string =>
    `0912${Math.floor(1_000_000 + Math.random() * 8_999_999).toString().slice(0, 7)}`;

  const newUser = async (): Promise<string> => {
    const user = await identity.createUser();
    userIds.push(user.id);
    return user.id;
  };

  beforeAll(async () => {
    delivery = new CapturingDelivery();
    moduleRef = await Test.createTestingModule({
      imports: [DatabaseModule, IdentityModule, PhoneModule, SessionModule],
    })
      .overrideProvider(OTP_DELIVERY)
      .useValue(delivery)
      .compile();
    await moduleRef.init();
    prisma = moduleRef.get(PrismaService);
    identity = moduleRef.get(IdentityService);
    phone = moduleRef.get(PhoneVerificationService);
    auth = moduleRef.get(AuthenticationService);
    login = moduleRef.get(PhoneOtpLoginService);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.session.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.otpChallenge.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.phoneClaim.deleteMany({ where: { userId: { in: userIds } } }).catch(() => undefined);
      await prisma.user.deleteMany({ where: { id: { in: userIds } } }).catch(() => undefined);
    }
    await moduleRef?.close();
  });

  it('records the session_foundation migration as applied', async () => {
    const rows = await prisma.$queryRaw<Array<{ migration_name: string }>>`
      SELECT migration_name FROM _prisma_migrations
      WHERE migration_name = ${MIGRATION_NAME} AND finished_at IS NOT NULL`;
    expect(rows).toHaveLength(1);
  });

  it('creates a session, authenticates its token, and stores only the hash', async () => {
    const userId = await newUser();
    const { token, session } = await auth.createSession(userId);

    const principal = await auth.authenticate(token);
    expect(principal).toEqual({ userId, sessionId: session.id });

    // The DB row holds the SHA-256 hash, never the raw token.
    const rows = await prisma.$queryRaw<Array<{ token_hash: string }>>`
      SELECT token_hash FROM sessions WHERE id = ${session.id}::uuid`;
    expect(rows[0]?.token_hash).toBe(createHash('sha256').update(token).digest('hex'));
    expect(rows[0]?.token_hash).not.toContain(token);
  });

  it('rejects a revoked session', async () => {
    const userId = await newUser();
    const { token, session } = await auth.createSession(userId);
    await auth.revokeSession(session.id);
    await expect(auth.authenticate(token)).rejects.toBeInstanceOf(SessionRevokedError);
  });

  it('rejects an expired session', async () => {
    const userId = await newUser();
    const { token, session } = await auth.createSession(userId);
    // Force expiry in the past directly in the DB.
    await prisma.session.update({
      where: { id: session.id },
      data: { expiresAt: new Date(Date.now() - 1000) },
    });
    await expect(auth.authenticate(token)).rejects.toBeInstanceOf(SessionExpiredError);
  });

  it('rejects an unknown token', async () => {
    await expect(auth.authenticate('definitely-not-a-real-token')).rejects.toBeInstanceOf(
      InvalidSessionTokenError,
    );
  });

  it('bridges phone verification to a session (phone OTP → session)', async () => {
    const userId = await newUser();
    const national = nationalNumber();
    const requested = await phone.requestPhoneVerification(userId, national);
    const code = delivery.codeFor(requested.e164);

    const result = await login.loginByPhoneOtp(userId, national, code);
    expect(result.outcome).toBe('VERIFIED');
    if (result.outcome === 'MERGE_REQUIRED') throw new Error('unexpected');

    // The issued token authenticates.
    const principal = await auth.authenticate(result.token);
    expect(principal.userId).toBe(userId);
    expect(principal.sessionId).toBe(result.session.id);
  });
});
