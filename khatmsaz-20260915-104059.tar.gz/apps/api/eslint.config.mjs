// @ts-check
import tseslint from 'typescript-eslint';

export default tseslint.config(
  {
    ignores: [
      'dist/**',
      'node_modules/**',
      'coverage/**',
      // Generated Prisma client — not authored here, regenerated on demand.
      'src/infrastructure/database/prisma/generated/**',
    ],
  },
  ...tseslint.configs.recommended,
  {
    languageOptions: {
      parserOptions: { sourceType: 'module' },
    },
    rules: {
      '@typescript-eslint/explicit-function-return-type': 'off',
      '@typescript-eslint/no-explicit-any': 'error',
      // `consistent-type-imports` is intentionally NOT enabled here. NestJS
      // dependency injection relies on `emitDecoratorMetadata`, which requires
      // classes used only as constructor-parameter types (e.g. an injected
      // service) to remain VALUE imports. The rule would rewrite them to
      // `import type` and break runtime DI. See .claude/rules/backend.md.
    },
  },
);
