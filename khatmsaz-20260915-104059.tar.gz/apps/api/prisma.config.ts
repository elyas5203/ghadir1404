// Prisma 7 configuration for the KhatmSaz API (persistence layer).
//
// Prisma tooling is confined to this API workspace. The schema and migrations
// are API-owned and live under ./prisma. See docs/ai/DATABASE.md.
//
// This file is deliberately self-contained (no @khatmsaz/config import) so that
// `prisma generate` never depends on the workspace build order. The runtime
// application uses the validated, fail-fast `databaseUrl()` helper in
// @khatmsaz/config; the small derivation below only feeds Migrate tooling.

import { resolve } from 'node:path';
import { config as loadEnv } from 'dotenv';
import { defineConfig, env } from 'prisma/config';

// Load the repository-root .env for local development. Prisma commands run with
// the working directory set to this workspace (apps/api); the shared .env lives
// two levels up. Missing files are ignored, so this is a no-op in CI where the
// environment is provided directly.
loadEnv({ path: resolve(process.cwd(), '../../.env') });
loadEnv({ path: resolve(process.cwd(), '.env') });

// Local convenience: when DATABASE_URL is not set explicitly, derive it from the
// discrete POSTGRES_* values that also drive the Docker Compose stack, so the
// credential is not duplicated. Non-throwing: `prisma generate` needs no live
// database and must keep working when the environment is empty.
if (!process.env.DATABASE_URL) {
  const host = process.env.POSTGRES_HOST?.trim();
  const db = process.env.POSTGRES_DB?.trim();
  const user = process.env.POSTGRES_USER?.trim();
  const password = process.env.POSTGRES_PASSWORD;
  const port = process.env.POSTGRES_PORT?.trim();
  if (host && db && user && password) {
    const portSegment = port ? `:${port}` : '';
    const enc = encodeURIComponent;
    process.env.DATABASE_URL =
      `postgresql://${enc(user)}:${enc(password)}@${host}${portSegment}` +
      `/${enc(db)}?schema=public`;
  }
}

export default defineConfig({
  schema: 'prisma/schema.prisma',
  migrations: {
    path: 'prisma/migrations',
  },
  datasource: {
    url: env('DATABASE_URL'),
  },
});
