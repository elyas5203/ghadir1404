export interface SmsProvider {
  send(mobile: string, message: string): Promise<{ messageId: string }>;
}

export const SMS_PROVIDER = Symbol('SMS_PROVIDER');
