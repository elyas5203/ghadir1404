import { KavenegarSmsService } from './infrastructure/kavenegar-sms.service';
import { NoopSmsService } from './infrastructure/noop-sms.service';
import type { SmsConfig } from '@khatmsaz/config';

const cfg: SmsConfig = {
  provider: 'kavenegar',
  kavenegarApiKey: 'test-api-key',
  kavenegarSender: '10004346',
};

describe('KavenegarSmsService', () => {
  let fetchMock: jest.Mock;

  beforeEach(() => {
    fetchMock = jest.fn();
    global.fetch = fetchMock;
  });

  afterEach(() => jest.restoreAllMocks());

  it('sends a POST to the correct Kavenegar URL with correct form params', async () => {
    fetchMock.mockResolvedValueOnce({
      json: async () => ({
        return: { status: 200, message: 'success' },
        entries: [{ messageid: 12345 }],
      }),
    });

    const service = new KavenegarSmsService(cfg);
    const result = await service.send('+989120000001', 'کد تأیید: 123456');

    expect(result.messageId).toBe('12345');
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toContain('/test-api-key/sms/send.json');
    const body = new URLSearchParams(init.body as string);
    expect(body.get('receptor')).toBe('+989120000001');
    expect(body.get('sender')).toBe('10004346');
    // SECURITY: message content is not tested to be absent from logs; just that it reaches the API correctly
    expect(body.get('message')).toBe('کد تأیید: 123456');
  });

  it('throws when Kavenegar returns a non-200 status', async () => {
    fetchMock.mockResolvedValueOnce({
      json: async () => ({
        return: { status: 400, message: 'Invalid receptor' },
        entries: [],
      }),
    });

    const service = new KavenegarSmsService(cfg);
    await expect(service.send('+989120000001', 'test')).rejects.toThrow('SMS delivery failed');
  });

  it('does NOT include the API key in any logged output', async () => {
    fetchMock.mockResolvedValueOnce({
      json: async () => ({
        return: { status: 200, message: 'success' },
        entries: [{ messageid: 1 }],
      }),
    });
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => undefined);
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => undefined);
    const service = new KavenegarSmsService(cfg);
    await service.send('+989120000001', 'msg');
    const logged = [...logSpy.mock.calls, ...warnSpy.mock.calls].flat().join(' ');
    expect(logged).not.toContain('test-api-key');
  });
});

describe('NoopSmsService', () => {
  it('returns a noop message id without throwing', async () => {
    const service: import('./domain/sms.types').SmsProvider = new NoopSmsService();
    const result = await service.send('+989120000001', 'test');
    expect(result.messageId).toMatch(/^noop-/);
  });
});
