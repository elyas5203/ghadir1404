import { Injectable, Logger } from '@nestjs/common';
import type { SmsProvider } from '../domain/sms.types';

/** No-op SmsProvider for test/dev environments without a real SMS gateway. */
@Injectable()
export class NoopSmsService implements SmsProvider {
  private readonly logger = new Logger('SmsProvider');

  async send(): Promise<{ messageId: string }> {
    this.logger.debug('SMS send requested (no provider configured; not sent).');
    return { messageId: `noop-${Date.now()}` };
  }
}
