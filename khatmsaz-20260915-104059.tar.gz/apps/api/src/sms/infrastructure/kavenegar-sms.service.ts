import { Injectable, Logger } from '@nestjs/common';
import type { SmsConfig } from '@khatmsaz/config';
import type { SmsProvider } from '../domain/sms.types';

/**
 * Kavenegar SMS adapter (Phase 08).
 * SECURITY: API key is read from config and NEVER logged.
 */
@Injectable()
export class KavenegarSmsService implements SmsProvider {
  private readonly logger = new Logger('SmsProvider');

  constructor(private readonly config: SmsConfig) {}

  async send(mobile: string, message: string): Promise<{ messageId: string }> {
    const url = `https://api.kavenegar.com/v1/${this.config.kavenegarApiKey}/sms/send.json`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        receptor: mobile,
        message,
        sender: this.config.kavenegarSender,
      }).toString(),
    });
    const data = (await res.json()) as {
      return: { status: number; message: string };
      entries: Array<{ messageid: number }>;
    };
    if (data.return.status !== 200) {
      this.logger.warn(`Kavenegar send failed (status=${data.return.status}).`);
      throw new Error(`SMS delivery failed: ${data.return.message}`);
    }
    return { messageId: String(data.entries[0]?.messageid ?? 'unknown') };
  }
}
