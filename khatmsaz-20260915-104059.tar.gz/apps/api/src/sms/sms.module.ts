import { Module } from '@nestjs/common';
import { smsConfig } from '@khatmsaz/config';
import { SMS_PROVIDER } from './domain/sms.types';
import { KavenegarSmsService } from './infrastructure/kavenegar-sms.service';
import { NoopSmsService } from './infrastructure/noop-sms.service';

/**
 * SMS capability module (Phase 08).
 * Provider is config-gated: SMS_PROVIDER=kavenegar → KavenegarSmsService;
 * any other value (or empty) → NoopSmsService so the app starts without credentials.
 */
@Module({
  providers: [
    {
      provide: SMS_PROVIDER,
      useFactory: () => {
        const cfg = smsConfig();
        if (cfg.provider === 'kavenegar' && cfg.kavenegarApiKey.length > 0) {
          return new KavenegarSmsService(cfg);
        }
        return new NoopSmsService();
      },
    },
  ],
  exports: [SMS_PROVIDER],
})
export class SmsModule {}
