import 'reflect-metadata';
import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { Logger as PinoLogger } from 'nestjs-pino';
import { readInt, readList, readString, isProduction, localOtpEnabled } from '@khatmsaz/config';
import { AppModule } from './app.module';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  app.useLogger(app.get(PinoLogger));
  // Close the private OTP socket on normal local shutdown/restart.
  if (localOtpEnabled()) app.enableShutdownHooks();

  // CORS is an explicit allow-list. It is never "*".
  // Local defaults cover the web app and the admin app only.
  const allowedOrigins = readList('API_CORS_ORIGINS', [
    'http://localhost:3000',
    'http://localhost:3002',
  ]);
  app.enableCors({
    origin: allowedOrigins,
    credentials: true,
  });

  // Bind to loopback by default so a development machine does not expose the
  // API to the local network. Override deliberately via API_HOST.
  const host = readString('API_HOST', '127.0.0.1');
  const port = readInt('API_PORT', 3001);

  await app.listen(port, host);

  const logger = new Logger('Bootstrap');
  logger.log(`KhatmSaz API listening on http://${host}:${port}`);
  if (!isProduction()) {
    logger.log(`Health endpoint: http://${host}:${port}/health`);
  }
}

void bootstrap();
