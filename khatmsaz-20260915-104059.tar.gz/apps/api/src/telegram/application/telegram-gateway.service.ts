import { Inject, Injectable } from '@nestjs/common';
import { TelegramCommandService } from './telegram-command.service';
import { TELEGRAM_SENDER } from '../domain/telegram-sender';
import type { TelegramSender } from '../domain/telegram-sender';
import type { TelegramCallbackQuery, TelegramReply, TelegramUpdate } from '../domain/telegram-message';

/**
 * The inbound entry point of the Telegram transport (DEC-0058): it takes a
 * vendor-neutral {@link TelegramUpdate}, asks the command service for a reply, and
 * delivers it through the outbound {@link TelegramSender} port. A future webhook or
 * long-poll infrastructure adapter maps real Bot API updates into `dispatch` and
 * binds a real sender; nothing here touches a Telegram SDK or the network.
 *
 * Phase 19 adds {@link dispatchCallback} for inline-keyboard button presses.
 */
@Injectable()
export class TelegramGateway {
  constructor(
    private readonly commands: TelegramCommandService,
    @Inject(TELEGRAM_SENDER) private readonly sender: TelegramSender,
  ) {}

  /** Handle one text-command update end-to-end: produce the reply and send it. */
  async dispatch(update: TelegramUpdate): Promise<TelegramReply> {
    const reply = await this.commands.handle(update);
    await this.sender.send(update.chatId, reply);
    return reply;
  }

  /**
   * Handle a button callback end-to-end (Phase 19): answer the query (clears the
   * loading state) then optionally send a follow-up text to the same chat.
   */
  async dispatchCallback(query: TelegramCallbackQuery): Promise<void> {
    const reply = await this.commands.handleCallback(query);
    await this.sender.answerCallbackQuery(query.callbackQueryId, reply.toast);
    if (reply.text) {
      await this.sender.send(query.chatId, {
        text: reply.text,
        inlineKeyboard: reply.inlineKeyboard,
        replyKeyboard: reply.replyKeyboard,
      });
    }
  }
}
