import type { KhatmTemplateType } from '../../khatm/domain/khatm-template';

export interface WizardDraft {
  templateType: KhatmTemplateType;
  title: string;
  editionId?: string;
  surahNumber?: number;
  repetitionTarget?: number;
  quantity?: number;
  niyyat?: string | null;
}

export type SessionState =
  | { step: 'create:template' }
  | { step: 'create:title'; template: KhatmTemplateType }
  | { step: 'create:edition'; title: string }
  | { step: 'create:surah_num'; title: string }
  | { step: 'create:repetition'; title: string; surahNumber: number }
  | { step: 'create:quantity'; title: string; template: KhatmTemplateType }
  | { step: 'create:niyyat'; draft: WizardDraft }
  | { step: 'settings:reminder_hour' }
  /** Account-linking wizard: ask for mobile phone number. */
  | { step: 'link:phone' }
  /** Account-linking wizard: ask for OTP. `failCount` resets to link:phone at 3. */
  | { step: 'link:otp'; mobile: string; failCount: number }
  /** Join-khatm wizard: user enters an invitation token. */
  | { step: 'join:token' };
