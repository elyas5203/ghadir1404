import type { SessionState } from './wizard-state.types';

/**
 * Per-chat wizard conversation state (Sprint 5 / Phase persistent-wizard).
 *
 * Abstracted so TelegramModule and BaleModule can each provide a Redis-backed
 * store in production and the in-memory fallback in tests and no-Redis envs.
 * Keys are always scoped by a namespace string (e.g. "telegram", "bale") to
 * prevent state collisions when two adapters run in the same Redis.
 */
export interface WizardStateStore {
  get(chatId: string): Promise<SessionState | undefined>;
  set(chatId: string, state: SessionState, ttlSeconds?: number): Promise<void>;
  delete(chatId: string): Promise<void>;
}

export const WIZARD_STATE = Symbol('WIZARD_STATE');

/** In-process fallback — safe for tests and single-process deploys. */
export class InMemoryWizardStateStore implements WizardStateStore {
  private readonly map = new Map<string, SessionState>();

  async get(chatId: string): Promise<SessionState | undefined> {
    return this.map.get(chatId);
  }

  async set(chatId: string, state: SessionState): Promise<void> {
    this.map.set(chatId, state);
  }

  async delete(chatId: string): Promise<void> {
    this.map.delete(chatId);
  }
}

/**
 * Redis-backed store with TTL expiry.
 * Uses ioredis directly to avoid coupling to BullMQ's connection pool.
 */
export class RedisWizardStateStore implements WizardStateStore {
  private readonly client: import('ioredis').Redis;
  private readonly ns: string;

  constructor(namespace: string, redisUrl: string) {
    // Dynamic import avoids a hard ioredis dependency in test environments that
    // never instantiate this class.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { Redis } = require('ioredis') as typeof import('ioredis');
    this.client = new Redis(redisUrl, { lazyConnect: true, maxRetriesPerRequest: 2 });
    this.ns = namespace;
  }

  private key(chatId: string): string {
    return `wizard:${this.ns}:${chatId}`;
  }

  async get(chatId: string): Promise<SessionState | undefined> {
    try {
      const val = await this.client.get(this.key(chatId));
      return val ? (JSON.parse(val) as SessionState) : undefined;
    } catch {
      return undefined;
    }
  }

  async set(chatId: string, state: SessionState, ttlSeconds = 1800): Promise<void> {
    try {
      await this.client.set(this.key(chatId), JSON.stringify(state), 'EX', ttlSeconds);
    } catch {
      // best-effort — if Redis is unavailable the wizard simply won't persist
    }
  }

  async delete(chatId: string): Promise<void> {
    try {
      await this.client.del(this.key(chatId));
    } catch {
      // best-effort
    }
  }

  async onModuleDestroy(): Promise<void> {
    try {
      await this.client.quit();
    } catch {
      // already closed
    }
  }
}
