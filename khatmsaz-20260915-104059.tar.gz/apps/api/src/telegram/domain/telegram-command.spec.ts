import { parseCommand, isKnownCommand, TelegramCommandName } from './telegram-command';

describe('parseCommand', () => {
  it('returns null for non-command text', () => {
    expect(parseCommand('hello there')).toBeNull();
    expect(parseCommand('')).toBeNull();
    expect(parseCommand('   ')).toBeNull();
  });

  it('parses a bare command', () => {
    expect(parseCommand('/start')).toEqual({ name: 'start', args: [], rest: '' });
  });

  it('lower-cases the name and strips a @botname suffix', () => {
    expect(parseCommand('/START@KhatmSazBot')?.name).toBe('start');
  });

  it('splits arguments and preserves the free-text rest', () => {
    const parsed = parseCommand('/create_khatm QURAN_FULL ختم خانوادگی');
    expect(parsed?.name).toBe('create_khatm');
    expect(parsed?.args).toEqual(['QURAN_FULL', 'ختم', 'خانوادگی']);
    expect(parsed?.rest).toBe('QURAN_FULL ختم خانوادگی');
  });

  it('tolerates leading/inner extra whitespace', () => {
    expect(parseCommand('   /join    abc  ')).toEqual({ name: 'join', args: ['abc'], rest: 'abc' });
  });

  it('recognises the known command set', () => {
    expect(isKnownCommand('start')).toBe(true);
    expect(isKnownCommand(TelegramCommandName.PROGRESS)).toBe(true);
    expect(isKnownCommand('nope')).toBe(false);
  });
});
