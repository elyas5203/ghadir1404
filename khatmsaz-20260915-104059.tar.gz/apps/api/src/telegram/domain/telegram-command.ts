/**
 * Pure parsing of a Telegram message into a command — no I/O, no framework. A
 * command is a `/name` at the start of the text, optionally suffixed with
 * `@botname` (stripped), followed by whitespace-separated arguments. Anything that
 * does not start with `/` is not a command.
 *
 * Also exports the persistent keyboard button labels and a map from label text
 * to the virtual command name, so the gateway can route ReplyKeyboard button
 * presses (which arrive as plain text, not `/commands`) correctly.
 */

/** The commands this foundation understands. */
export const TelegramCommandName = {
  START: 'start',
  MENU: 'menu',
  CREATE_KHATM: 'create_khatm',
  MY_KHATMS: 'my_khatms',
  JOIN: 'join',
  LEAVE: 'leave',
  PROGRESS: 'progress',
  PORTIONS: 'portions',
  WALLET: 'wallet',
  HELP: 'help',
  SETTINGS: 'settings',
  SUPPORT: 'support',
} as const;

export type TelegramCommandName =
  (typeof TelegramCommandName)[keyof typeof TelegramCommandName];

export interface ParsedCommand {
  /** The command name without its leading slash, lower-cased. */
  readonly name: string;
  /** Whitespace-separated arguments after the command. */
  readonly args: readonly string[];
  /** The argument text joined back together (for free-text like a title). */
  readonly rest: string;
}

/** Parse message text into a {@link ParsedCommand}, or `null` when it is not a command. */
export function parseCommand(text: string): ParsedCommand | null {
  if (typeof text !== 'string') return null;
  const trimmed = text.trim();
  if (!trimmed.startsWith('/')) return null;

  const tokens = trimmed.slice(1).split(/\s+/).filter((t) => t.length > 0);
  if (tokens.length === 0) return null;

  const rawName = tokens[0] as string;
  const name = rawName.split('@')[0]?.toLowerCase() ?? '';
  if (name.length === 0) return null;

  const args = tokens.slice(1);
  return { name, args, rest: args.join(' ') };
}

export function isKnownCommand(name: string): name is TelegramCommandName {
  return (Object.values(TelegramCommandName) as string[]).includes(name);
}

/** Persistent ReplyKeyboard button labels — what Telegram sends back as plain text. */
export const BUTTON_LABELS = {
  MY_KHATMS: '📖 ختم‌های من',
  CREATE: '➕ ساخت ختم',
  PROGRESS: '📊 پیشرفت',
  WALLET: '💰 کیف‌پول',
  SETTINGS: '⚙️ تنظیمات',
  HELP: '❓ راهنما',
  CANCEL: '🚫 لغو',
  NO_NIYYAT: 'بدون نیت',
} as const;

export type ButtonLabel = (typeof BUTTON_LABELS)[keyof typeof BUTTON_LABELS];

/**
 * Maps each ReplyKeyboard button label to a virtual command name.
 * The service checks this map when `parseCommand` returns null, so button presses
 * are routed to the same handlers as the equivalent slash-commands.
 */
export const BUTTON_TO_COMMAND: Readonly<Record<string, string>> = {
  [BUTTON_LABELS.MY_KHATMS]: TelegramCommandName.MY_KHATMS,
  [BUTTON_LABELS.CREATE]: 'create_wizard',
  [BUTTON_LABELS.PROGRESS]: TelegramCommandName.PROGRESS,
  [BUTTON_LABELS.WALLET]: TelegramCommandName.WALLET,
  [BUTTON_LABELS.SETTINGS]: TelegramCommandName.SETTINGS,
  [BUTTON_LABELS.HELP]: TelegramCommandName.HELP,
};
