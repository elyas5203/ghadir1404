/**
 * TelegramSender — the OUTBOUND adapter port (DEC-0058). The application asks it to
 * deliver a reply to a chat; the implementation is an infrastructure adapter. The
 * default binding is a NO-OP (no bot token, no network) — the same seam pattern as
 * the OTP `OtpDelivery` port (DEC-0036). A real Bot API adapter implements this
 * interface later without touching the command layer.
 *
 * Phase 19 adds {@link answerCallbackQuery} so the gateway can acknowledge a
 * button-press and clear Telegram's loading indicator.
 */

import type { TelegramReply } from './telegram-message';

/** DI token for {@link TelegramSender}. */
export const TELEGRAM_SENDER = Symbol('TELEGRAM_SENDER');

export interface TelegramSender {
  /** Deliver a reply to a chat. Never throws for a "no provider configured" case. */
  send(chatId: string, reply: TelegramReply): Promise<void>;

  /**
   * Acknowledge a callback query so Telegram clears the button's loading state.
   * `text` is shown as a brief toast to the user (optional, max 200 chars).
   * Phase 19.
   */
  answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void>;
}
