/**
 * Vendor-neutral Telegram message shapes — the ADAPTER BOUNDARY of the Telegram
 * transport (DEC-0058). The command layer speaks only in these shapes; a future
 * infrastructure adapter maps a real Bot API update to a {@link TelegramUpdate} and
 * a {@link TelegramReply} back to a `sendMessage` call. No Telegram SDK type ever
 * reaches the application/domain layers — the same rule as every other adapter.
 *
 * Phase 19 adds inline-keyboard support ({@link InlineKeyboardButton}) and a
 * discriminated callback-query type ({@link TelegramCallbackQuery}) so the gateway
 * can route button-press events separately from text commands.
 */

/** A single button in an inline keyboard row. */
export interface InlineKeyboardButton {
  readonly text: string;
  readonly callbackData: string;
}

/** An inbound text message reduced to what the command layer needs. */
export interface TelegramUpdate {
  /** The chat to reply into (an opaque platform id). */
  readonly chatId: string;
  /**
   * The sender's immutable Telegram user id — used as the platform-identity
   * `subject` (never a username, which is not stable identity — DEC-0032).
   */
  readonly fromId: string;
  /** The raw message text. */
  readonly text: string;
}

/**
 * An inbound inline-keyboard callback (Phase 19).
 * Produced when the user taps a button attached to a previous bot message.
 */
export interface TelegramCallbackQuery {
  /** Telegram callback query id — must be answered to clear the loading indicator. */
  readonly callbackQueryId: string;
  /** The chat the original message was in. */
  readonly chatId: string;
  /** The tapper's immutable Telegram user id. */
  readonly fromId: string;
  /** The `callback_data` string set on the button. */
  readonly data: string;
}

/** A single button in a persistent reply keyboard row. */
export interface ReplyKeyboardButton {
  readonly text: string;
}

/** An outbound reply. Plain text by default; optional inline keyboard for Phase 19. */
export interface TelegramReply {
  readonly text: string;
  /** Rows of button columns shown below the message as an inline keyboard. */
  readonly inlineKeyboard?: ReadonlyArray<ReadonlyArray<InlineKeyboardButton>>;
  /**
   * A persistent reply keyboard shown below the input field.
   * Pass an empty array to remove the keyboard.
   */
  readonly replyKeyboard?: ReadonlyArray<ReadonlyArray<ReplyKeyboardButton>>;
  /** When true, removes the currently-shown reply keyboard. */
  readonly removeKeyboard?: boolean;
}

/**
 * The result of handling a callback query (Phase 19).
 * `toast` is shown as a brief pop-up by Telegram (max 200 chars, optional).
 * `text` is sent as a follow-up message in the chat (optional).
 * `inlineKeyboard` and `replyKeyboard` are forwarded to the follow-up message.
 */
export interface CallbackReply {
  readonly toast?: string;
  readonly text?: string;
  readonly inlineKeyboard?: ReadonlyArray<ReadonlyArray<InlineKeyboardButton>>;
  readonly replyKeyboard?: ReadonlyArray<ReadonlyArray<ReplyKeyboardButton>>;
}
