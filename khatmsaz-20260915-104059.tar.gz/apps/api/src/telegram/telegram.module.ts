import { Module } from '@nestjs/common';
import { telegramConfig, telegramOutboundEnabled, redisConfig, redisEnabled } from '@khatmsaz/config';
import { IdentityModule } from '../identity/identity.module';
import { KhatmModule } from '../khatm/khatm.module';
import { KhatmWorkflowModule } from '../khatm-workflow/khatm-workflow.module';
import { InvitationModule } from '../invitation/invitation.module';
import { PaymentModule } from '../payment/payment.module';
import { UserSettingsModule } from '../user-settings/user-settings.module';
import { NotificationModule } from '../notification/notification.module';
import { BotSharedModule } from '../bot-shared/bot-shared.module';
import { TelegramCommandService } from './application/telegram-command.service';
import { TelegramGateway } from './application/telegram-gateway.service';
import { TELEGRAM_SENDER } from './domain/telegram-sender';
import { NoopTelegramSender } from './infrastructure/noop-telegram-sender';
import { BotApiTelegramSender } from './infrastructure/bot-api-telegram-sender';
import { TelegramWebhookController } from './infrastructure/telegram-webhook.controller';
import { TELEGRAM_CONFIG } from './infrastructure/telegram-config.tokens';
import { WIZARD_STATE, InMemoryWizardStateStore, RedisWizardStateStore } from './application/wizard-state.service';

/**
 * Telegram channel adapter module (Phase 5 DEC-0058; Phase 9 DEC-0065). It routes
 * Telegram commands into the khatm workflows and resolves the caller's platform
 * identity through the identity capability — with NO business logic in the transport.
 *
 * Phase 9 connects the boundary to the real Bot API, entirely in infrastructure:
 * the inbound {@link TelegramWebhookController} (secret-verified, maps a raw update to
 * the vendor-neutral shape and dispatches through the existing gateway) and the
 * outbound {@link TELEGRAM_SENDER}, which is the real {@link BotApiTelegramSender}
 * when a bot token is configured and the {@link NoopTelegramSender} otherwise — so the
 * app builds and runs with an empty environment and the webhook stays disabled until a
 * secret is set. The Bot API is reached with plain `fetch`; no SDK is imported.
 */
@Module({
  imports: [IdentityModule, KhatmModule, KhatmWorkflowModule, InvitationModule, PaymentModule, UserSettingsModule, NotificationModule, BotSharedModule],
  controllers: [TelegramWebhookController],
  providers: [
    TelegramCommandService,
    TelegramGateway,
    { provide: TELEGRAM_CONFIG, useFactory: telegramConfig },
    {
      provide: TELEGRAM_SENDER,
      inject: [TELEGRAM_CONFIG],
      useFactory: (config: ReturnType<typeof telegramConfig>) =>
        telegramOutboundEnabled(config)
          ? new BotApiTelegramSender(config)
          : new NoopTelegramSender(),
    },
    {
      provide: WIZARD_STATE,
      useFactory: () => {
        const cfg = redisConfig();
        return redisEnabled(cfg)
          ? new RedisWizardStateStore('telegram', cfg.url)
          : new InMemoryWizardStateStore();
      },
    },
  ],
  exports: [TelegramCommandService, TelegramGateway],
})
export class TelegramModule {}
