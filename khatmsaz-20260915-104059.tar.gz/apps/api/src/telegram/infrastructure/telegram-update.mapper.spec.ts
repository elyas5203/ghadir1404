import { toTelegramUpdate } from './telegram-update.mapper';

describe('toTelegramUpdate (raw Bot API → neutral shape)', () => {
  it('maps a text message, stringifying numeric ids', () => {
    const update = toTelegramUpdate({
      update_id: 1,
      message: { chat: { id: 42 }, from: { id: 99 }, text: '/start' },
    });
    expect(update).toEqual({ chatId: '42', fromId: '99', text: '/start' });
  });

  it('accepts already-string ids', () => {
    const update = toTelegramUpdate({
      message: { chat: { id: '42' }, from: { id: '99' }, text: 'hi' },
    });
    expect(update).toEqual({ chatId: '42', fromId: '99', text: 'hi' });
  });

  it.each([
    ['not an object', 'nope'],
    ['null', null],
    ['no message', { update_id: 1 }],
    ['no text', { message: { chat: { id: 1 }, from: { id: 2 } } }],
    ['non-string text', { message: { chat: { id: 1 }, from: { id: 2 }, text: 123 } }],
    ['no sender', { message: { chat: { id: 1 }, text: 'hi' } }],
    ['no chat', { message: { from: { id: 2 }, text: 'hi' } }],
  ])('returns null for an unsupported update: %s', (_label, raw) => {
    expect(toTelegramUpdate(raw)).toBeNull();
  });
});
