import { Injectable, Logger } from '@nestjs/common';
import type { TelegramSender } from '../domain/telegram-sender';

/**
 * No-op {@link TelegramSender} — the default outbound adapter while no Bot API token
 * is configured and no real Telegram network is integrated (DEC-0058, mirroring the
 * no-op OTP delivery adapter, DEC-0036). It logs that a reply would be sent (never
 * the chat id or message body, to avoid logging user content) and returns. A real
 * Bot API adapter implements the same port later without touching the command layer.
 */
@Injectable()
export class NoopTelegramSender implements TelegramSender {
  private readonly logger = new Logger('TelegramSender');

  async send(): Promise<void> {
    this.logger.debug('Telegram reply prepared (no provider configured; not sent).');
  }

  async answerCallbackQuery(): Promise<void> {
    this.logger.debug('Telegram callback acknowledged (no provider configured; not sent).');
  }
}
