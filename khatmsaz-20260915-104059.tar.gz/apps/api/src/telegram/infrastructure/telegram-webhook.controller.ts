import {
  Body,
  Controller,
  ForbiddenException,
  Headers,
  HttpCode,
  Inject,
  Logger,
  Post,
} from '@nestjs/common';
import { timingSafeEqual } from 'node:crypto';
import { TelegramGateway } from '../application/telegram-gateway.service';
import { toTelegramUpdate, isCallbackQuery } from './telegram-update.mapper';
import { TELEGRAM_CONFIG } from './telegram-config.tokens';
import type { TelegramConfig } from './telegram-config.tokens';

/** Telegram's secret header (lower-cased by the HTTP layer). */
const SECRET_HEADER = 'x-telegram-bot-api-secret-token';

/**
 * Inbound Telegram webhook (DEC-0065): Telegram POSTs raw updates here. It verifies
 * the shared secret (constant-time), maps the raw Bot API payload to a vendor-neutral
 * shape and dispatches it through the EXISTING gateway/command service — no business
 * logic lives here. When no webhook secret is configured the endpoint is DISABLED and
 * rejects everything, so an unconfigured deployment exposes no open command surface.
 *
 * Phase 19: routes callback_query updates to {@link TelegramGateway.dispatchCallback}
 * and text messages to {@link TelegramGateway.dispatch}.
 *
 * It always answers 200 for a verified request (even for ignored/unprocessable
 * updates) so Telegram does not retry; only a failed secret check is a 403.
 */
@Controller('telegram')
export class TelegramWebhookController {
  private readonly logger = new Logger('TelegramWebhook');

  constructor(
    private readonly gateway: TelegramGateway,
    @Inject(TELEGRAM_CONFIG) private readonly config: TelegramConfig,
  ) {}

  @Post('webhook')
  @HttpCode(200)
  async receive(
    @Headers(SECRET_HEADER) presentedSecret: string | undefined,
    @Body() body: unknown,
  ): Promise<{ ok: true }> {
    this.assertSecret(presentedSecret);

    const update = toTelegramUpdate(body);
    if (update === null) return { ok: true }; // unsupported/malformed update — ignore

    try {
      if (isCallbackQuery(update)) {
        await this.gateway.dispatchCallback(update);
      } else {
        await this.gateway.dispatch(update);
      }
    } catch {
      // Never surface internals to Telegram; a 200 avoids a retry storm.
      this.logger.warn('Failed to process a Telegram update.');
    }
    return { ok: true };
  }

  /** Constant-time check of the configured secret; a missing config disables the webhook. */
  private assertSecret(presented: string | undefined): void {
    const expected = this.config.webhookSecret;
    if (expected.length === 0 || typeof presented !== 'string') {
      throw new ForbiddenException('Telegram webhook is not available.');
    }
    const a = Buffer.from(presented);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      throw new ForbiddenException('Telegram webhook is not available.');
    }
  }
}
