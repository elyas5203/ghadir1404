/**
 * DI token for the non-injectable {@link TelegramConfig} value, resolved from
 * `@khatmsaz/config.telegramConfig()` and bound in the module. Kept out of the
 * application/domain layers so nothing there depends on configuration or secrets.
 */

import type { TelegramConfig } from '@khatmsaz/config';

export const TELEGRAM_CONFIG = Symbol('TELEGRAM_CONFIG');
export type { TelegramConfig };
