/**
 * Map a RAW Telegram Bot API update into the vendor-neutral shapes the application
 * speaks (DEC-0058, DEC-0065). This is the ONE place a real Bot API payload is
 * understood; it lives in infrastructure so no Telegram-shaped object reaches the
 * application/domain. Pure and defensive — a malformed or unsupported update (edited
 * message, non-text, missing sender) yields `null` and is ignored.
 *
 * Phase 19 adds callback_query mapping → {@link TelegramCallbackQuery}.
 */

import type { TelegramCallbackQuery, TelegramUpdate } from '../domain/telegram-message';

/** The slice of a Bot API update we consume. Everything is treated as untrusted. */
interface RawTelegramUpdate {
  readonly message?: {
    readonly text?: unknown;
    readonly chat?: { readonly id?: unknown };
    readonly from?: { readonly id?: unknown };
  };
  readonly callback_query?: {
    readonly id?: unknown;
    readonly data?: unknown;
    readonly message?: { readonly chat?: { readonly id?: unknown } };
    readonly from?: { readonly id?: unknown };
  };
}

function asId(value: unknown): string | null {
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  if (typeof value === 'string' && value.trim().length > 0) return value.trim();
  return null;
}

export type MappedTelegramUpdate = TelegramUpdate | TelegramCallbackQuery;

export function toTelegramUpdate(raw: unknown): MappedTelegramUpdate | null {
  if (typeof raw !== 'object' || raw === null) return null;
  const payload = raw as RawTelegramUpdate;

  // --- callback_query (button press) ---
  if (payload.callback_query) {
    const cq = payload.callback_query;
    const callbackQueryId = asId(cq.id);
    const fromId = asId(cq.from?.id);
    const chatId = asId(cq.message?.chat?.id);
    const data = typeof cq.data === 'string' && cq.data.length > 0 ? cq.data : null;
    if (callbackQueryId && fromId && chatId && data) {
      return { callbackQueryId, chatId, fromId, data } satisfies TelegramCallbackQuery;
    }
    return null;
  }

  // --- text message ---
  const message = payload.message;
  if (!message || typeof message.text !== 'string') return null;

  const chatId = asId(message.chat?.id);
  const fromId = asId(message.from?.id);
  if (chatId === null || fromId === null) return null;

  return { chatId, fromId, text: message.text } satisfies TelegramUpdate;
}

export function isCallbackQuery(u: MappedTelegramUpdate): u is TelegramCallbackQuery {
  return 'callbackQueryId' in u;
}
