import { Injectable, Logger } from '@nestjs/common';
import type { TelegramConfig } from '@khatmsaz/config';
import type { TelegramSender } from '../domain/telegram-sender';
import type { TelegramReply } from '../domain/telegram-message';

/**
 * Real outbound {@link TelegramSender} over the Telegram Bot API (DEC-0065). It is
 * deliberately implemented with plain `fetch` — no third-party SDK — so the vendor
 * surface is a single, replaceable HTTP call confined to infrastructure; a full SDK
 * (e.g. grammy) could later implement the same port without touching the command
 * layer. The bot token is held here and NEVER logged (the URL that embeds it is not
 * logged either); only a coarse success/failure is recorded.
 *
 * Phase 19 adds inline-keyboard support (`reply_markup`) and `answerCallbackQuery`.
 *
 * Bound only when a token is configured (see the module factory); otherwise the
 * no-op sender is used and the channel stays dark.
 */
@Injectable()
export class BotApiTelegramSender implements TelegramSender {
  private readonly logger = new Logger('TelegramSender');

  constructor(private readonly config: TelegramConfig) {}

  async send(chatId: string, reply: TelegramReply): Promise<void> {
    const url = `${this.config.apiBaseUrl}/bot${this.config.botToken}/sendMessage`;
    const body: Record<string, unknown> = {
      chat_id: chatId,
      text: reply.text,
      parse_mode: 'HTML',
    };
    if (reply.removeKeyboard) {
      body['reply_markup'] = { remove_keyboard: true };
    } else if (reply.replyKeyboard && reply.replyKeyboard.length > 0) {
      body['reply_markup'] = {
        keyboard: reply.replyKeyboard.map((row) => row.map((btn) => ({ text: btn.text }))),
        resize_keyboard: true,
        one_time_keyboard: false,
        is_persistent: true,
      };
    } else if (reply.inlineKeyboard && reply.inlineKeyboard.length > 0) {
      body['reply_markup'] = {
        inline_keyboard: reply.inlineKeyboard.map((row) =>
          row.map((btn) => ({ text: btn.text, callback_data: btn.callbackData })),
        ),
      };
    }
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!response.ok) {
        this.logger.warn(`Telegram sendMessage failed with status ${response.status}.`);
      }
    } catch {
      this.logger.warn('Telegram sendMessage request failed (network error).');
    }
  }

  async answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
    const url = `${this.config.apiBaseUrl}/bot${this.config.botToken}/answerCallbackQuery`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callback_query_id: callbackQueryId,
          ...(text ? { text } : {}),
        }),
      });
      if (!response.ok) {
        this.logger.warn(`Telegram answerCallbackQuery failed with status ${response.status}.`);
      }
    } catch {
      this.logger.warn('Telegram answerCallbackQuery request failed (network error).');
    }
  }
}
