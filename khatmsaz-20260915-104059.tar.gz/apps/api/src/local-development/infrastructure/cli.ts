import 'reflect-metadata';
import { resolve } from 'node:path';
import { request } from 'node:http';
import { config } from 'dotenv';
import { PrismaPg } from '@prisma/adapter-pg';
import { assertLocalDevelopment, databaseUrl, localOtpEnabled } from '@khatmsaz/config';
import { PrismaClient } from '../../infrastructure/database/prisma/generated/client';
import { localOtpSocket } from '../../phone/infrastructure/local-otp-socket';
import { LibphonenumberPhoneNormalizer } from '../../phone/infrastructure/libphonenumber-phone-normalizer';
import { bindLocalTelegram, seedLocalUser } from './fixture';

config({ path: resolve(__dirname, '../../../../../.env'), quiet: true });

async function main(): Promise<void> {
  assertLocalDevelopment();
  const [command, phone, option, extra] = process.argv.slice(2);
  if (!phone || extra || !['seed', 'bind-telegram', 'otp'].includes(command ?? '')) {
    throw new Error(
      'Usage: dev:local seed <phone> [creator] | bind-telegram <phone> <numeric-id> | otp <phone>',
    );
  }
  if (command === 'otp') {
    if (option || !localOtpEnabled()) throw new Error('OTP retrieval requires KHATMSAZ_DEV_OTP=1.');
    // Interactive delivery only: never pipe credentials into log collectors/files.
    if (!process.stdout.isTTY)
      throw new Error('OTP retrieval requires an interactive terminal (no redirection).');
    const e164 = new LibphonenumberPhoneNormalizer().normalize(phone).e164;
    const code = await new Promise<string>((resolveCode, reject) => {
      const req = request(
        {
          socketPath: localOtpSocket(),
          path: `/latest?e164=${encodeURIComponent(e164)}`,
          method: 'GET',
        },
        (res) => {
          let body = '';
          res.setEncoding('utf8');
          res.on('data', (chunk: string) => {
            body += chunk;
            if (body.length > 256) req.destroy();
          });
          res.on('end', () => {
            try {
              const value = JSON.parse(body) as { code?: unknown };
              if (
                res.statusCode !== 200 ||
                typeof value.code !== 'string' ||
                !/^\d{6}$/.test(value.code)
              )
                throw new Error();
              resolveCode(value.code);
            } catch {
              reject(new Error('No unread login OTP. Request a fresh code in the web app.'));
            }
          });
        },
      );
      req.setTimeout(3000, () => req.destroy());
      req.on('error', () =>
        reject(new Error('Local OTP delivery unavailable. Start the opted-in development API.')),
      );
      req.end();
    });
    process.stdout.write(`${code}\n`);
    return;
  }
  if (command === 'seed' && option !== undefined && option !== 'creator')
    throw new Error('Only the existing creator capability is supported.');
  if (command === 'bind-telegram' && !option)
    throw new Error('Supply the numeric Telegram user ID.');
  const client = new PrismaClient({ adapter: new PrismaPg({ connectionString: databaseUrl() }) });
  try {
    const id =
      command === 'seed'
        ? await seedLocalUser(client, phone, option === 'creator')
        : await bindLocalTelegram(client, phone, option!);
    process.stdout.write(`Local ${command} complete. User ID: ${id}\n`);
  } finally {
    await client.$disconnect();
  }
}

void main().catch(() => {
  // Database/library exceptions can contain credentials or phone numbers.
  process.stderr.write(
    'Local command failed. Check development mode, local database, arguments and identity conflicts. See docs/ai/LOCAL_DEVELOPMENT.md.\n',
  );
  process.exitCode = 1;
});
