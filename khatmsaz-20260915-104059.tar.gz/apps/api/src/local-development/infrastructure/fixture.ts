import { assertLocalDevelopment } from '@khatmsaz/config';
import { newUuidV7 } from '@khatmsaz/kernel';
import type { PrismaClient } from '../../infrastructure/database/prisma/generated/client';
import { LibphonenumberPhoneNormalizer } from '../../phone/infrastructure/libphonenumber-phone-normalizer';

/** CLI-only fixture. Never imported by an application module or controller. */
export async function seedLocalUser(
  client: PrismaClient,
  rawPhone: string,
  creator: boolean,
): Promise<string> {
  assertLocalDevelopment();
  const phone = new LibphonenumberPhoneNormalizer().normalize(rawPhone);
  return client.$transaction(async (tx) => {
    // Serialize this local tool, including concurrent repeated invocations.
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(1263752275)`;
    const claim = await tx.phoneClaim.findFirst({
      where: { e164: phone.e164, status: 'VERIFIED' },
    });
    const user = claim
      ? await tx.user.findUniqueOrThrow({ where: { id: claim.userId } })
      : await tx.user.create({ data: { id: newUuidV7() } });
    if (user.status !== 'ACTIVE') throw new Error('Fixture requires an active account.');
    if (!claim) {
      await tx.phoneClaim.create({
        data: {
          id: newUuidV7(),
          userId: user.id,
          e164: phone.e164,
          region: phone.region,
          status: 'VERIFIED',
          verifiedAt: new Date(),
        },
      });
    }
    if (
      creator &&
      !(await tx.userCapability.findFirst({
        where: { userId: user.id, type: 'CREATOR', revokedAt: null },
      }))
    ) {
      await tx.userCapability.create({
        data: { id: newUuidV7(), userId: user.id, type: 'CREATOR' },
      });
    }
    return user.id;
  });
}

export async function bindLocalTelegram(
  client: PrismaClient,
  rawPhone: string,
  subject: string,
): Promise<string> {
  assertLocalDevelopment();
  if (!/^[1-9][0-9]{0,15}$/.test(subject) || !Number.isSafeInteger(Number(subject))) {
    throw new Error('Supply a positive, safe numeric Telegram user ID, never a username.');
  }
  const phone = new LibphonenumberPhoneNormalizer().normalize(rawPhone);
  return client.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(1263752275)`;
    const claim = await tx.phoneClaim.findFirst({
      where: { e164: phone.e164, status: 'VERIFIED' },
    });
    if (!claim) throw new Error('Seed the local phone first.');
    const user = await tx.user.findUniqueOrThrow({ where: { id: claim.userId } });
    if (user.status !== 'ACTIVE') throw new Error('Fixture requires an active account.');
    const link = await tx.platformIdentity.findUnique({
      where: { platform_subject: { platform: 'TELEGRAM', subject } },
    });
    if (link && link.userId !== user.id) {
      throw new Error(
        'Telegram identity already belongs to another account; no reassignment performed.',
      );
    }
    if (!link)
      await tx.platformIdentity.create({
        data: { id: newUuidV7(), userId: user.id, platform: 'TELEGRAM', subject },
      });
    return user.id;
  });
}
