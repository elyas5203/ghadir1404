import { Module } from '@nestjs/common';
import { IdentityModule } from '../identity/identity.module';
import { PhoneModule } from '../phone/phone.module';
import { AccountMergeService } from './application/account-merge.service';

/**
 * Account-merge capability module (Phase 3B).
 *
 * A cross-capability ORCHESTRATION module: it composes the identity and phone
 * capabilities' domain-owned repository ports (exported by their modules) to
 * resolve a verified-ownership conflict. It imports IdentityModule and PhoneModule
 * for those port bindings and the global DatabaseModule supplies `UNIT_OF_WORK`.
 *
 * Scope (DEC-0047): KhatmSaz identity only — intra-product unification across this
 * product's own channels. No cross-product identity, no auth/session/creator work.
 * There is no HTTP controller or bot handler yet; the use-case is wired and testable.
 */
@Module({
  imports: [IdentityModule, PhoneModule],
  providers: [AccountMergeService],
  exports: [AccountMergeService],
})
export class AccountMergeModule {}
