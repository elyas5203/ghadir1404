import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { newUuidV7, UNIT_OF_WORK } from '@khatmsaz/kernel';
import type { TransactionContext, UnitOfWork } from '@khatmsaz/kernel';
import { AccountMergeService } from './account-merge.service';
import { USER_REPOSITORY } from '../../identity/domain/user.repository';
import type { UserRepository } from '../../identity/domain/user.repository';
import { PLATFORM_IDENTITY_REPOSITORY } from '../../identity/domain/platform-identity.repository';
import type { PlatformIdentityRepository } from '../../identity/domain/platform-identity.repository';
import { ACCOUNT_MERGE_REPOSITORY } from '../../identity/domain/account-merge.repository';
import type {
  AccountMergeRepository,
  AppendAccountMergeInput,
} from '../../identity/domain/account-merge.repository';
import { PHONE_CLAIM_REPOSITORY } from '../../phone/domain/phone-claim.repository';
import type { PhoneClaimRepository } from '../../phone/domain/phone-claim.repository';
import { User } from '../../identity/domain/user';
import { UserStatus } from '../../identity/domain/user-status';
import { AccountMerge } from '../../identity/domain/account-merge';
import { InvalidAccountMergeError } from '../../identity/domain/identity.errors';

class FakeUnitOfWork implements UnitOfWork {
  run<T>(work: (tx: TransactionContext) => Promise<T>): Promise<T> {
    return work({} as TransactionContext);
  }
}

interface UserRow {
  id: string;
  status: UserStatus;
  mergedIntoId: string | null;
}

class FakeUserRepository implements UserRepository {
  readonly rows = new Map<string, UserRow>();
  add(status: UserStatus = UserStatus.ACTIVE): string {
    const id = newUuidV7();
    // A MERGED user always carries a tombstone pointer (User invariant).
    this.rows.set(id, {
      id,
      status,
      mergedIntoId: status === UserStatus.MERGED ? newUuidV7() : null,
    });
    return id;
  }
  async create(): Promise<User> {
    throw new Error('unused');
  }
  async findById(id: string): Promise<User | null> {
    const r = this.rows.get(id);
    if (!r) return null;
    const now = new Date();
    return User.restore({
      id: r.id,
      status: r.status,
      mergedIntoId: r.mergedIntoId,
      createdAt: now,
      updatedAt: now,
    });
  }
  async tombstone(userId: string, mergedIntoId: string): Promise<void> {
    const r = this.rows.get(userId);
    if (!r || r.status !== UserStatus.ACTIVE) {
      throw new InvalidAccountMergeError('the account is no longer active');
    }
    r.status = UserStatus.MERGED;
    r.mergedIntoId = mergedIntoId;
  }
  async updateDisplayName(): Promise<User> {
    throw new Error('not implemented in this fake');
  }
  async listAll(): Promise<User[]> { return []; }
  async countAll(): Promise<number> { return 0; }
  async search(): Promise<User[]> { return []; }
  async updateStatus(): Promise<User> { throw new Error('not implemented in this fake'); }
  async updateRole(): Promise<User> { throw new Error('not implemented in this fake'); }
}

class FakePlatformIdentityRepository implements PlatformIdentityRepository {
  readonly owners: string[] = []; // one entry per link = its userId
  async findByPlatformSubject(): Promise<null> {
    return null;
  }
  async attach(): Promise<never> {
    throw new Error('unused');
  }
  async reassignOwner(fromUserId: string, toUserId: string): Promise<number> {
    let count = 0;
    for (let i = 0; i < this.owners.length; i += 1) {
      if (this.owners[i] === fromUserId) {
        this.owners[i] = toUserId;
        count += 1;
      }
    }
    return count;
  }
}

interface ClaimRow {
  userId: string;
  revoked: boolean;
}

class FakePhoneClaimRepository implements PhoneClaimRepository {
  readonly rows: ClaimRow[] = [];
  async findActiveByUserAndPhone(): Promise<null> {
    return null;
  }
  async createUnverified(): Promise<never> {
    throw new Error('unused');
  }
  async markVerified(): Promise<never> {
    throw new Error('unused');
  }
  async findVerifiedByUser(): Promise<null> {
    return null;
  }
  async findVerifiedOwnerId(): Promise<null> {
    return null;
  }
  async revoke(): Promise<never> {
    throw new Error('unused');
  }
  async revokeAllActiveByUser(userId: string): Promise<number> {
    let count = 0;
    for (const r of this.rows) {
      if (r.userId === userId && !r.revoked) {
        r.revoked = true;
        count += 1;
      }
    }
    return count;
  }
  async reassignOwner(fromUserId: string, toUserId: string): Promise<number> {
    let count = 0;
    for (const r of this.rows) {
      if (r.userId === fromUserId) {
        r.userId = toUserId;
        count += 1;
      }
    }
    return count;
  }
}

class FakeAccountMergeRepository implements AccountMergeRepository {
  readonly appended: AppendAccountMergeInput[] = [];
  async append(input: AppendAccountMergeInput): Promise<AccountMerge> {
    this.appended.push(input);
    return AccountMerge.restore({
      id: input.id,
      winnerUserId: input.winnerUserId,
      loserUserId: input.loserUserId,
      verifiedE164: input.verifiedE164,
      initiatingChallengeId: input.initiatingChallengeId ?? null,
      movedPlatformIdentities: input.movedPlatformIdentities ?? 0,
      movedPhoneClaims: input.movedPhoneClaims ?? 0,
      context: input.context ?? null,
      createdAt: new Date(),
    });
  }
  async findById(): Promise<null> {
    return null;
  }
}

describe('AccountMergeService', () => {
  let service: AccountMergeService;
  let users: FakeUserRepository;
  let platformIdentities: FakePlatformIdentityRepository;
  let phoneClaims: FakePhoneClaimRepository;
  let merges: FakeAccountMergeRepository;

  beforeEach(async () => {
    users = new FakeUserRepository();
    platformIdentities = new FakePlatformIdentityRepository();
    phoneClaims = new FakePhoneClaimRepository();
    merges = new FakeAccountMergeRepository();
    const moduleRef: TestingModule = await Test.createTestingModule({
      providers: [
        AccountMergeService,
        { provide: USER_REPOSITORY, useValue: users },
        { provide: PLATFORM_IDENTITY_REPOSITORY, useValue: platformIdentities },
        { provide: PHONE_CLAIM_REPOSITORY, useValue: phoneClaims },
        { provide: ACCOUNT_MERGE_REPOSITORY, useValue: merges },
        { provide: UNIT_OF_WORK, useValue: new FakeUnitOfWork() },
      ],
    }).compile();
    service = moduleRef.get(AccountMergeService);
  });

  it('moves data to the winner, tombstones the loser, and appends an audit record', async () => {
    const winner = users.add();
    const loser = users.add();
    platformIdentities.owners.push(loser, loser); // two channel logins on the loser
    phoneClaims.rows.push({ userId: loser, revoked: false }); // one active claim
    phoneClaims.rows.push({ userId: loser, revoked: true }); // one historical claim

    const record = await service.mergeAccounts({
      winnerUserId: winner,
      loserUserId: loser,
      verifiedE164: '+989123456789',
      initiatingChallengeId: newUuidV7(),
      context: 'PHONE_VERIFICATION',
    });

    // Audit counts.
    expect(record.winnerUserId).toBe(winner);
    expect(record.loserUserId).toBe(loser);
    expect(record.movedPlatformIdentities).toBe(2);
    expect(record.movedPhoneClaims).toBe(2);
    expect(merges.appended).toHaveLength(1);

    // Data moved to the winner (never deleted).
    expect(platformIdentities.owners.every((o) => o === winner)).toBe(true);
    expect(phoneClaims.rows.every((r) => r.userId === winner)).toBe(true);
    // The loser's active claim was revoked (history retained).
    expect(phoneClaims.rows.every((r) => r.revoked)).toBe(true);

    // Loser tombstoned pointing at the winner; winner still active.
    expect(users.rows.get(loser)?.status).toBe(UserStatus.MERGED);
    expect(users.rows.get(loser)?.mergedIntoId).toBe(winner);
    expect(users.rows.get(winner)?.status).toBe(UserStatus.ACTIVE);
  });

  it('rejects winner === loser', async () => {
    const id = users.add();
    await expect(
      service.mergeAccounts({ winnerUserId: id, loserUserId: id, verifiedE164: '+989123456789' }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);
  });

  it('rejects a missing verified phone', async () => {
    const winner = users.add();
    const loser = users.add();
    await expect(
      service.mergeAccounts({ winnerUserId: winner, loserUserId: loser, verifiedE164: '  ' }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);
  });

  it('rejects when an account is missing or not active', async () => {
    const winner = users.add();
    const loser = users.add(UserStatus.MERGED); // already merged → not active
    await expect(
      service.mergeAccounts({ winnerUserId: winner, loserUserId: loser, verifiedE164: '+989123456789' }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);

    await expect(
      service.mergeAccounts({
        winnerUserId: winner,
        loserUserId: newUuidV7(), // no such user
        verifiedE164: '+989123456789',
      }),
    ).rejects.toBeInstanceOf(InvalidAccountMergeError);
  });
});
