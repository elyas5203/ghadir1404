import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, assertUuidV7, UNIT_OF_WORK } from '@khatmsaz/kernel';
import type { UnitOfWork } from '@khatmsaz/kernel';
import { USER_REPOSITORY } from '../../identity/domain/user.repository';
import type { UserRepository } from '../../identity/domain/user.repository';
import { PLATFORM_IDENTITY_REPOSITORY } from '../../identity/domain/platform-identity.repository';
import type { PlatformIdentityRepository } from '../../identity/domain/platform-identity.repository';
import { ACCOUNT_MERGE_REPOSITORY } from '../../identity/domain/account-merge.repository';
import type { AccountMergeRepository } from '../../identity/domain/account-merge.repository';
import type { AccountMerge } from '../../identity/domain/account-merge';
import { InvalidAccountMergeError } from '../../identity/domain/identity.errors';
import { PHONE_CLAIM_REPOSITORY } from '../../phone/domain/phone-claim.repository';
import type { PhoneClaimRepository } from '../../phone/domain/phone-claim.repository';

/** Inputs for merging two KhatmSaz accounts (DEC-0042/0046). */
export interface MergeAccountsInput {
  /** The canonical account that survives — the pre-existing verified owner. */
  readonly winnerUserId: string;
  /** The account merged into the winner and tombstoned. */
  readonly loserUserId: string;
  /** The verified phone that triggered the merge (recorded in the audit). */
  readonly verifiedE164: string;
  /** The OTP challenge that proved the phone, if known. */
  readonly initiatingChallengeId?: string | null;
  /** Optional non-secret context/reason code. */
  readonly context?: string | null;
}

/**
 * The intra-product account-merge use-case (DEC-0042, DEC-0046, DEC-0047).
 *
 * KhatmSaz identity only: winner and loser are both KhatmSaz `User`s arriving via
 * this one product's channels (Telegram/Bale/Web). This is NOT cross-product.
 *
 * The merge is explicit and audited, and runs entirely inside a single
 * transaction (DEC-0044). It **moves** data and **never deletes** history:
 *   - platform identities (channel logins) are reassigned to the winner;
 *   - the loser's active phone claims are revoked, then all of the loser's claims
 *     are reassigned to the winner as retained history — the winner keeps its own
 *     verified number, so one-verified-phone-per-user (DEC-0046) still holds;
 *   - the loser is tombstoned (status MERGED, `mergedIntoId` = winner), retained;
 *   - an immutable audit record is appended.
 * Everything is an UPDATE, never a delete, so the FK RESTRICT strategy (DEC-0045)
 * is respected. It performs NO cross-product work and adds no auth/session/creator
 * behaviour.
 */
@Injectable()
export class AccountMergeService {
  constructor(
    @Inject(USER_REPOSITORY) private readonly users: UserRepository,
    @Inject(PLATFORM_IDENTITY_REPOSITORY)
    private readonly platformIdentities: PlatformIdentityRepository,
    @Inject(PHONE_CLAIM_REPOSITORY) private readonly phoneClaims: PhoneClaimRepository,
    @Inject(ACCOUNT_MERGE_REPOSITORY) private readonly merges: AccountMergeRepository,
    @Inject(UNIT_OF_WORK) private readonly uow: UnitOfWork,
  ) {}

  async mergeAccounts(input: MergeAccountsInput): Promise<AccountMerge> {
    assertUuidV7(input.winnerUserId, 'winnerUserId');
    assertUuidV7(input.loserUserId, 'loserUserId');
    if (input.winnerUserId === input.loserUserId) {
      throw new InvalidAccountMergeError('winner and loser must be different accounts');
    }
    if (typeof input.verifiedE164 !== 'string' || input.verifiedE164.trim().length === 0) {
      throw new InvalidAccountMergeError('verifiedE164 is required');
    }

    const now = new Date();

    return this.uow.run(async (tx) => {
      // Validate both accounts inside the transaction.
      const winner = await this.users.findById(input.winnerUserId, tx);
      const loser = await this.users.findById(input.loserUserId, tx);
      if (!winner) throw new InvalidAccountMergeError('winner account not found');
      if (!loser) throw new InvalidAccountMergeError('loser account not found');
      if (!winner.isActive) throw new InvalidAccountMergeError('winner account is not active');
      if (!loser.isActive) throw new InvalidAccountMergeError('loser account is not active');

      // 1. Move channel logins to the canonical winner.
      const movedPlatformIdentities = await this.platformIdentities.reassignOwner(
        input.loserUserId,
        input.winnerUserId,
        tx,
      );

      // 2. Revoke the loser's active phone claims, then move all of them to the
      //    winner as history (all REVOKED now, so no partial index can be violated).
      await this.phoneClaims.revokeAllActiveByUser(input.loserUserId, now, tx);
      const movedPhoneClaims = await this.phoneClaims.reassignOwner(
        input.loserUserId,
        input.winnerUserId,
        tx,
      );

      // 3. Tombstone the loser (retained, never deleted), pointing at the winner.
      await this.users.tombstone(input.loserUserId, input.winnerUserId, tx);

      // 4. Append the immutable audit record.
      return this.merges.append(
        {
          id: newUuidV7(),
          winnerUserId: input.winnerUserId,
          loserUserId: input.loserUserId,
          verifiedE164: input.verifiedE164,
          initiatingChallengeId: input.initiatingChallengeId ?? null,
          movedPlatformIdentities,
          movedPhoneClaims,
          context: input.context ?? null,
        },
        tx,
      );
    });
  }
}
