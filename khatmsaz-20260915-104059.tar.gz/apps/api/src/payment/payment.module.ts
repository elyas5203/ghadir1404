import { Module } from '@nestjs/common';
import { zarinpalConfig } from '@khatmsaz/config';
import { WalletService } from './application/wallet.service';
import { PlanService } from './application/plan.service';
import { WALLET_REPOSITORY } from './domain/wallet.repository';
import { PAYMENT_INTENT_REPOSITORY } from './domain/payment-intent.repository';
import { PrismaWalletRepository } from './infrastructure/prisma-wallet.repository';
import { PrismaPaymentIntentRepository } from './infrastructure/prisma-payment-intent.repository';
import { ZarinpalService } from './infrastructure/zarinpal.service';
import { ZARINPAL_CONFIG } from './infrastructure/zarinpal.tokens';

@Module({
  providers: [
    WalletService,
    PlanService,
    { provide: WALLET_REPOSITORY, useClass: PrismaWalletRepository },
    { provide: PAYMENT_INTENT_REPOSITORY, useClass: PrismaPaymentIntentRepository },
    { provide: ZARINPAL_CONFIG, useFactory: zarinpalConfig },
    {
      provide: ZarinpalService,
      inject: [ZARINPAL_CONFIG],
      useFactory: (cfg: ReturnType<typeof zarinpalConfig>) => new ZarinpalService(cfg),
    },
  ],
  exports: [WalletService, ZarinpalService, PlanService, PAYMENT_INTENT_REPOSITORY],
})
export class PaymentModule {}
