import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7 } from '@khatmsaz/kernel';
import {
  WALLET_REPOSITORY,
  type WalletRepository,
  type WalletRow,
} from '../domain/wallet.repository';
import { InsufficientBalanceError } from '../domain/payment.errors';

/**
 * Wallet use-cases (Sprint Phase 03).
 *
 * The wallet is created lazily on first charge — not every user will use
 * the payment system. The repository performs balance adjustments atomically.
 */
@Injectable()
export class WalletService {
  constructor(@Inject(WALLET_REPOSITORY) private readonly wallets: WalletRepository) {}

  async getOrCreateWallet(userId: string): Promise<WalletRow> {
    const existing = await this.wallets.findByUserId(userId);
    if (existing) return existing;
    return this.wallets.create(newUuidV7(), userId);
  }

  async getBalance(userId: string): Promise<{ balance: number; credit: number }> {
    const wallet = await this.wallets.findByUserId(userId);
    return { balance: wallet?.balanceToman ?? 0, credit: wallet?.creditToman ?? 0 };
  }

  async charge(userId: string, amountToman: number, ref: string): Promise<void> {
    const wallet = await this.getOrCreateWallet(userId);
    await this.wallets.adjustBalance(wallet.id, amountToman);
    await this.wallets.addTransaction({
      id: newUuidV7(),
      walletId: wallet.id,
      amount: amountToman,
      type: 'CHARGE',
      ref,
      description: null,
      createdAt: new Date(),
    });
  }

  async spend(userId: string, amountToman: number, description: string): Promise<void> {
    const wallet = await this.wallets.findByUserId(userId);
    const balance = wallet?.balanceToman ?? 0;
    if (balance < amountToman) throw new InsufficientBalanceError();
    await this.wallets.adjustBalance(wallet!.id, -amountToman);
    await this.wallets.addTransaction({
      id: newUuidV7(),
      walletId: wallet!.id,
      amount: -amountToman,
      type: 'SPEND',
      ref: null,
      description,
      createdAt: new Date(),
    });
  }

  async addCredit(userId: string, amountToman: number): Promise<void> {
    const wallet = await this.getOrCreateWallet(userId);
    await this.wallets.adjustCredit(wallet.id, amountToman);
    await this.wallets.addTransaction({
      id: newUuidV7(),
      walletId: wallet.id,
      amount: amountToman,
      type: 'CREDIT',
      ref: null,
      description: 'تبلیغات — عضو جدید',
      createdAt: new Date(),
    });
  }
}
