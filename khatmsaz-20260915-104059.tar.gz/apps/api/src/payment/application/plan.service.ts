import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';

export type PlanTier = 'FREE' | 'BASIC' | 'PRO';

/**
 * Manages user plan tier assignment (Sprint 3, DEC-0085).
 * Relies on direct Prisma access (infrastructure concern confined to this service).
 */
@Injectable()
export class PlanService {
  constructor(private readonly prisma: PrismaService) {}

  async assignPlan(userId: string, plan: PlanTier): Promise<void> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (this.prisma.userPlan as any).upsert({
      where: { userId },
      create: { userId, plan },
      update: { plan, startsAt: new Date() },
    });
  }

  async getPlan(userId: string): Promise<PlanTier> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row = await (this.prisma.userPlan as any).findUnique({
      where: { userId },
      select: { plan: true },
    });
    return (row?.plan as PlanTier | undefined) ?? 'FREE';
  }
}
