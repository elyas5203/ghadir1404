export interface WalletRow {
  readonly id: string;
  readonly userId: string;
  readonly balanceToman: number;
  readonly creditToman: number;
}

export interface WalletTransactionRow {
  readonly id: string;
  readonly walletId: string;
  readonly amount: number;
  readonly type: 'CHARGE' | 'SPEND' | 'REFUND' | 'CREDIT';
  readonly ref: string | null;
  readonly description: string | null;
  readonly createdAt: Date;
}

export interface WalletRepository {
  findByUserId(userId: string): Promise<WalletRow | null>;
  create(walletId: string, userId: string): Promise<WalletRow>;
  /** Atomically adjusts balanceToman by `delta` (positive or negative). */
  adjustBalance(walletId: string, delta: number): Promise<WalletRow>;
  adjustCredit(walletId: string, delta: number): Promise<WalletRow>;
  addTransaction(tx: WalletTransactionRow): Promise<void>;
}

export const WALLET_REPOSITORY = Symbol('WalletRepository');
