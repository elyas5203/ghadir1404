export class InsufficientBalanceError extends Error {
  constructor() {
    super('Insufficient wallet balance.');
    this.name = 'InsufficientBalanceError';
  }
}

export class PaymentVerificationFailedError extends Error {
  constructor(reason: string) {
    super(`Payment verification failed: ${reason}`);
    this.name = 'PaymentVerificationFailedError';
  }
}

export class WalletNotFoundError extends Error {
  constructor() {
    super('Wallet not found.');
    this.name = 'WalletNotFoundError';
  }
}
