export interface CreatePaymentIntentInput {
  readonly id: string;
  readonly userId: string;
  readonly authority: string;
  readonly amountToman: number;
  readonly description: string;
  readonly expiresAt: Date;
}

export interface PaymentIntentRecord {
  readonly id: string;
  readonly userId: string;
  readonly authority: string;
  readonly amountToman: number;
  readonly used: boolean;
  readonly expiresAt: Date;
}

export interface PaymentIntentRepository {
  create(input: CreatePaymentIntentInput): Promise<void>;
  findByAuthority(authority: string): Promise<PaymentIntentRecord | null>;
  /** Marks used=true only if currently used=false. Returns true if the CAS succeeded. */
  markUsed(authority: string): Promise<boolean>;
}

export const PAYMENT_INTENT_REPOSITORY = Symbol('PAYMENT_INTENT_REPOSITORY');
