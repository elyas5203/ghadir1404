import {
  BadRequestException,
  ConflictException,
  Controller,
  Get,
  GoneException,
  Inject,
  NotFoundException,
  Post,
  Body,
  Query,
  UseGuards,
} from '@nestjs/common';
import { SkipThrottle, Throttle } from '@nestjs/throttler';
import { newUuidV7 } from '@khatmsaz/kernel';
import { SessionAuthGuard } from '../../http-api/auth/session-auth.guard';
import { Principal } from '../../http-api/auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../../session/domain/authenticated-principal';
import { WalletService } from '../application/wallet.service';
import { ZarinpalService } from './zarinpal.service';
import { zarinpalConfig } from '@khatmsaz/config';
import {
  PAYMENT_INTENT_REPOSITORY,
  type PaymentIntentRepository,
} from '../domain/payment-intent.repository';

/**
 * Payment REST endpoints (Sprint Phase 03).
 *
 * Security (Sprint 3 — DEC-0083):
 *  - IDOR fix: on createPayment the server persists {authority → userId, amountToman}.
 *    verifyPayment looks up the stored record; principal.userId is NOT used for
 *    charging. An attacker with a different session cannot credit their own wallet
 *    using someone else's authority.
 *  - Replay fix: markUsed() is an atomic CAS (UPDATE WHERE used=false). Only the
 *    first verify succeeds; a repeated call with the same authority is rejected.
 *    ZarinPal code 101 ("already verified") is treated as a failure here — the wallet
 *    has already been charged if code 100 succeeded on the first call.
 */
@Controller('payment')
export class PaymentController {
  constructor(
    private readonly wallet: WalletService,
    private readonly zarinpal: ZarinpalService,
    @Inject(PAYMENT_INTENT_REPOSITORY)
    private readonly intents: PaymentIntentRepository,
  ) {}

  @Get('wallet')
  @UseGuards(SessionAuthGuard)
  async getWallet(@Principal() principal: AuthenticatedPrincipal) {
    return this.wallet.getBalance(principal.userId);
  }

  @Throttle({ short: { ttl: 60_000, limit: 5 } })
  @Post('create')
  @UseGuards(SessionAuthGuard)
  async createPayment(
    @Principal() principal: AuthenticatedPrincipal,
    @Body() body: { amountToman: number; description: string },
  ) {
    const cfg = zarinpalConfig();
    const callbackUrl = `${cfg.callbackBaseUrl}/payment/verify`;
    const { paymentUrl, authority } = await this.zarinpal.createPayment(
      principal.userId,
      body.amountToman,
      body.description,
      callbackUrl,
    );

    await this.intents.create({
      id: newUuidV7(),
      userId: principal.userId,
      authority,
      amountToman: body.amountToman,
      description: body.description ?? '',
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    });

    return { paymentUrl, authority };
  }

  @SkipThrottle()
  @Get('verify')
  async verifyPayment(
    @Query('Authority') authority: string,
    @Query('Status') status: string,
  ) {
    if (status !== 'OK') {
      throw new BadRequestException('پرداخت لغو شد.');
    }

    const intent = await this.intents.findByAuthority(authority);
    if (!intent) throw new NotFoundException('تراکنش یافت نشد.');
    if (intent.used) throw new ConflictException('این تراکنش قبلاً ثبت شده.');
    if (intent.expiresAt < new Date()) throw new GoneException('مهلت پرداخت گذشته.');

    // Only code 100 is accepted — code 101 ("already verified") is treated as a
    // duplicate because the DB would already be marked used from the first call.
    const { refId } = await this.zarinpal.verifyPayment(authority, intent.amountToman);

    // Atomic CAS: mark used only if still false (replay guard).
    const claimed = await this.intents.markUsed(authority);
    if (!claimed) throw new ConflictException('این تراکنش قبلاً ثبت شده.');

    await this.wallet.charge(intent.userId, intent.amountToman, refId);
    return { success: true, refId };
  }
}
