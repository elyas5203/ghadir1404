export const ZARINPAL_CONFIG = Symbol('ZARINPAL_CONFIG');
