import { Injectable, Logger } from '@nestjs/common';
import type { ZarinpalConfig } from '@khatmsaz/config';
import { PaymentVerificationFailedError } from '../domain/payment.errors';

/**
 * ZarinPal payment gateway adapter (Sprint Phase 03).
 * Uses ZarinPal REST v4 API. Sandbox / production selected by config.
 * SECURITY: merchantId is read from config and NEVER logged.
 */
@Injectable()
export class ZarinpalService {
  private readonly logger = new Logger('ZarinpalService');
  private readonly baseUrl: string;

  constructor(private readonly config: ZarinpalConfig) {
    this.baseUrl = config.sandbox
      ? 'https://sandbox.zarinpal.com/pg/v4/payment'
      : 'https://api.zarinpal.com/pg/v4/payment';
  }

  /** Creates a payment request and returns the redirect URL. */
  async createPayment(
    userId: string,
    amountToman: number,
    description: string,
    callbackUrl: string,
  ): Promise<{ paymentUrl: string; authority: string }> {
    const body = {
      merchant_id: this.config.merchantId,
      amount: amountToman * 10, // ZarinPal accepts Rials
      description,
      callback_url: callbackUrl,
      metadata: { user_id: userId },
    };
    const res = await fetch(`${this.baseUrl}/request.json`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
    });
    const json = (await res.json()) as { data?: { authority?: string; code?: number }; errors?: unknown };
    const authority = json.data?.authority;
    if (!authority || json.data?.code !== 100) {
      this.logger.warn('ZarinPal createPayment failed.');
      throw new PaymentVerificationFailedError('Could not initiate payment.');
    }
    const gatewayBase = this.config.sandbox
      ? 'https://sandbox.zarinpal.com/pg/StartPay'
      : 'https://www.zarinpal.com/pg/StartPay';
    return { paymentUrl: `${gatewayBase}/${authority}`, authority };
  }

  /** Verifies a payment after redirect and returns the refId. */
  async verifyPayment(
    authority: string,
    amountToman: number,
  ): Promise<{ refId: string }> {
    const body = {
      merchant_id: this.config.merchantId,
      amount: amountToman * 10,
      authority,
    };
    const res = await fetch(`${this.baseUrl}/verify.json`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
    });
    const json = (await res.json()) as { data?: { ref_id?: string; code?: number }; errors?: unknown };
    const code = json.data?.code;
    const refId = json.data?.ref_id;
    // Only accept code 100. Code 101 ("already verified") is intentionally rejected
    // here; the caller's DB-level replay guard (used=true CAS) catches duplicates
    // before this point, so 101 reaching here means the ZarinPal state is ahead of
    // our DB — treat as a conflict rather than silently charging twice (Sprint 3).
    if (code !== 100 || !refId) {
      throw new PaymentVerificationFailedError('Payment verification rejected by ZarinPal.');
    }
    return { refId: String(refId) };
  }
}
