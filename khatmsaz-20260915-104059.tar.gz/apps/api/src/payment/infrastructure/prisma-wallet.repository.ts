import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { WalletRepository, WalletRow, WalletTransactionRow } from '../domain/wallet.repository';

@Injectable()
export class PrismaWalletRepository implements WalletRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findByUserId(userId: string): Promise<WalletRow | null> {
    const row = await this.prisma.wallet.findUnique({ where: { userId } });
    return row ? this.toWalletRow(row) : null;
  }

  async create(walletId: string, userId: string): Promise<WalletRow> {
    const row = await this.prisma.wallet.create({
      data: { id: walletId, userId },
    });
    return this.toWalletRow(row);
  }

  async adjustBalance(walletId: string, delta: number): Promise<WalletRow> {
    const row = await this.prisma.wallet.update({
      where: { id: walletId },
      data: { balanceToman: { increment: delta } },
    });
    return this.toWalletRow(row);
  }

  async adjustCredit(walletId: string, delta: number): Promise<WalletRow> {
    const row = await this.prisma.wallet.update({
      where: { id: walletId },
      data: { creditToman: { increment: delta } },
    });
    return this.toWalletRow(row);
  }

  async addTransaction(tx: WalletTransactionRow): Promise<void> {
    await this.prisma.walletTransaction.create({
      data: {
        id: tx.id,
        walletId: tx.walletId,
        amount: tx.amount,
        type: tx.type,
        ref: tx.ref ?? null,
        description: tx.description ?? null,
      },
    });
  }

  private toWalletRow(row: { id: string; userId: string; balanceToman: number; creditToman: number }): WalletRow {
    return {
      id: row.id,
      userId: row.userId,
      balanceToman: row.balanceToman,
      creditToman: row.creditToman,
    };
  }
}
