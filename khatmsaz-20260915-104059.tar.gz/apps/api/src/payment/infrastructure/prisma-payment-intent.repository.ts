import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type {
  CreatePaymentIntentInput,
  PaymentIntentRecord,
  PaymentIntentRepository,
} from '../domain/payment-intent.repository';

@Injectable()
export class PrismaPaymentIntentRepository implements PaymentIntentRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreatePaymentIntentInput): Promise<void> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (this.prisma.pendingPayment as any).create({
      data: {
        id: input.id,
        userId: input.userId,
        authority: input.authority,
        amountToman: input.amountToman,
        description: input.description,
        expiresAt: input.expiresAt,
      },
    });
  }

  async findByAuthority(authority: string): Promise<PaymentIntentRecord | null> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row = await (this.prisma.pendingPayment as any).findUnique({
      where: { authority },
      select: { id: true, userId: true, authority: true, amountToman: true, used: true, expiresAt: true },
    });
    return row as PaymentIntentRecord | null;
  }

  async markUsed(authority: string): Promise<boolean> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const result = await (this.prisma.pendingPayment as any).updateMany({
      where: { authority, used: false },
      data: { used: true },
    });
    return result.count > 0;
  }
}
