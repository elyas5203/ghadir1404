import { newUuidV7 } from '@khatmsaz/kernel';
import { AuthorizationService } from './authorization.service';
import { Capability } from '../domain/capability';
import { CapabilityType } from '../domain/capability-type';
import { CapabilityRequiredError } from '../domain/authorization.errors';
import type { CapabilityRepository } from '../domain/capability.repository';
import type { CapabilityType as CapType } from '../domain/capability-type';

/** In-memory capability store enforcing one active grant per (user, type). */
class FakeCapabilityRepository implements CapabilityRepository {
  readonly rows: Capability[] = [];
  async findActive(userId: string, type: CapType): Promise<Capability | null> {
    return this.rows.find((c) => c.userId === userId && c.type === type && c.isActive) ?? null;
  }
  async create(capability: Capability): Promise<Capability> {
    this.rows.push(capability);
    return capability;
  }
  async revokeActive(userId: string, type: CapType, revokedAt: Date): Promise<number> {
    let n = 0;
    for (let i = 0; i < this.rows.length; i += 1) {
      const c = this.rows[i]!;
      if (c.userId === userId && c.type === type && c.isActive) {
        this.rows[i] = Capability.restore({
          id: c.id,
          userId: c.userId,
          type: c.type,
          grantedAt: c.grantedAt,
          revokedAt,
        });
        n += 1;
      }
    }
    return n;
  }
}

describe('AuthorizationService', () => {
  let repo: FakeCapabilityRepository;
  let service: AuthorizationService;
  const user = newUuidV7();

  beforeEach(() => {
    repo = new FakeCapabilityRepository();
    service = new AuthorizationService(repo);
  });

  it('reports no capability before any grant', async () => {
    expect(await service.hasCapability(user, CapabilityType.CREATOR)).toBe(false);
  });

  it('grants and then reports the capability', async () => {
    await service.grantCapability(user, CapabilityType.CREATOR);
    expect(await service.hasCapability(user, CapabilityType.CREATOR)).toBe(true);
  });

  it('is idempotent — granting twice keeps a single active grant', async () => {
    const first = await service.grantCapability(user, CapabilityType.CREATOR);
    const second = await service.grantCapability(user, CapabilityType.CREATOR);
    expect(second.id).toBe(first.id);
    expect(repo.rows.filter((c) => c.isActive)).toHaveLength(1);
  });

  it('requireCapability throws when absent and passes when present', async () => {
    await expect(service.requireCapability(user, CapabilityType.CREATOR)).rejects.toBeInstanceOf(
      CapabilityRequiredError,
    );
    await service.grantCapability(user, CapabilityType.CREATOR);
    await expect(service.requireCapability(user, CapabilityType.CREATOR)).resolves.toBeUndefined();
  });

  it('revoke removes access but keeps history', async () => {
    await service.grantCapability(user, CapabilityType.CREATOR);
    const revoked = await service.revokeCapability(user, CapabilityType.CREATOR);
    expect(revoked).toBe(1);
    expect(await service.hasCapability(user, CapabilityType.CREATOR)).toBe(false);
    expect(repo.rows).toHaveLength(1); // the row is retained, not deleted
    expect(repo.rows[0]!.isActive).toBe(false);
  });

  it('revoke is idempotent (0 when nothing active)', async () => {
    expect(await service.revokeCapability(user, CapabilityType.CREATOR)).toBe(0);
  });

  it('a re-grant after revoke creates a new active grant (history grows)', async () => {
    await service.grantCapability(user, CapabilityType.CREATOR);
    await service.revokeCapability(user, CapabilityType.CREATOR);
    const regranted = await service.grantCapability(user, CapabilityType.CREATOR);
    expect(regranted.isActive).toBe(true);
    expect(repo.rows).toHaveLength(2);
    expect(await service.hasCapability(user, CapabilityType.CREATOR)).toBe(true);
  });
});
