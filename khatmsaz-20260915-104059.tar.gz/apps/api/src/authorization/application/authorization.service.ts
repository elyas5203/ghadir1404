import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, isUuidV7, assertUuidV7 } from '@khatmsaz/kernel';
import { Capability } from '../domain/capability';
import { CapabilityType, isCapabilityType } from '../domain/capability-type';
import {
  CapabilityRequiredError,
  InvalidCapabilityError,
  UnknownCapabilityTypeError,
} from '../domain/authorization.errors';
import { CAPABILITY_REPOSITORY } from '../domain/capability.repository';
import type { CapabilityRepository } from '../domain/capability.repository';

/**
 * AuthorizationService — answers ONE question: **"is this user allowed?"** (DEC-0061).
 *
 * It is Prisma-free and has NO knowledge of sessions, tokens, or HTTP. It never
 * decides whether an action is *valid* (that is the business domains' job) — only
 * whether the user *may*. Granting is an explicit internal mechanism (DEC-0062): how
 * a user earns a capability is a product rule not decided here.
 */
@Injectable()
export class AuthorizationService {
  constructor(
    @Inject(CAPABILITY_REPOSITORY) private readonly capabilities: CapabilityRepository,
  ) {}

  /** Whether `userId` holds an active grant of `type`. A bad id yields `false`. */
  async hasCapability(userId: string, type: CapabilityType): Promise<boolean> {
    if (!isUuidV7(userId) || !isCapabilityType(type)) return false;
    return (await this.capabilities.findActive(userId, type)) !== null;
  }

  /** Throw {@link CapabilityRequiredError} (→ 403) when the user lacks `type`. */
  async requireCapability(userId: string, type: CapabilityType): Promise<void> {
    if (!(await this.hasCapability(userId, type))) {
      throw new CapabilityRequiredError();
    }
  }

  /**
   * Grant `type` to `userId`, idempotently: an existing active grant is returned
   * unchanged (and a concurrent double-grant loses the partial unique and resolves
   * to the existing grant). This is the internal grant mechanism — there is no
   * public onboarding endpoint (DEC-0062).
   */
  async grantCapability(userId: string, type: CapabilityType): Promise<Capability> {
    assertUuidV7(userId, 'userId');
    if (!isCapabilityType(type)) throw new UnknownCapabilityTypeError();

    const existing = await this.capabilities.findActive(userId, type);
    if (existing) return existing;
    try {
      return await this.capabilities.create(Capability.grant({ id: newUuidV7(), userId, type }));
    } catch (error) {
      if (error instanceof InvalidCapabilityError) {
        const raced = await this.capabilities.findActive(userId, type);
        if (raced) return raced;
      }
      throw error;
    }
  }

  /** Revoke the user's active grant of `type` (history retained). Returns count revoked. */
  async revokeCapability(userId: string, type: CapabilityType): Promise<number> {
    assertUuidV7(userId, 'userId');
    if (!isCapabilityType(type)) throw new UnknownCapabilityTypeError();
    return this.capabilities.revokeActive(userId, type, new Date());
  }
}
