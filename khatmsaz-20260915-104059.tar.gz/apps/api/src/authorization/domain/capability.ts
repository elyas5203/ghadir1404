/**
 * Capability — the DOMAIN entity for an authorization grant (DEC-0062): a user holds
 * a named capability, with grant/revoke history. It is **active** while `revokedAt`
 * is null; revoking stamps `revokedAt` (the row is retained, never deleted), and a
 * re-grant is a new entity. Plain domain object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { CapabilityType, isCapabilityType } from './capability-type';
import { InvalidCapabilityError, UnknownCapabilityTypeError } from './authorization.errors';

export interface CapabilityProps {
  readonly id: string;
  readonly userId: string;
  readonly type: CapabilityType;
  readonly grantedAt: Date;
  readonly revokedAt: Date | null;
}

export interface NewCapabilityProps {
  readonly id: string;
  readonly userId: string;
  readonly type: CapabilityType;
}

export class Capability {
  readonly id: string;
  readonly userId: string;
  readonly type: CapabilityType;
  readonly grantedAt: Date;
  readonly revokedAt: Date | null;

  private constructor(props: CapabilityProps) {
    this.id = props.id;
    this.userId = props.userId;
    this.type = props.type;
    this.grantedAt = props.grantedAt;
    this.revokedAt = props.revokedAt;
  }

  /** True while the grant has not been revoked. */
  get isActive(): boolean {
    return this.revokedAt === null;
  }

  static grant(props: NewCapabilityProps): Capability {
    assertUuidV7(props.id, 'Capability.id');
    assertUuidV7(props.userId, 'Capability.userId');
    if (!isCapabilityType(props.type)) {
      throw new UnknownCapabilityTypeError();
    }
    return new Capability({ ...props, grantedAt: new Date(), revokedAt: null });
  }

  static restore(props: CapabilityProps): Capability {
    assertUuidV7(props.id, 'Capability.id');
    assertUuidV7(props.userId, 'Capability.userId');
    if (!isCapabilityType(props.type)) {
      throw new UnknownCapabilityTypeError();
    }
    if (props.revokedAt !== null && props.revokedAt.getTime() < props.grantedAt.getTime()) {
      throw new InvalidCapabilityError('revokedAt cannot precede grantedAt');
    }
    return new Capability(props);
  }
}
