/**
 * CapabilityRepository — a persistence port OWNED BY THE DOMAIN. Its Prisma-backed
 * implementation lives in infrastructure (DEC-0031). The "one active grant per
 * (user, type)" invariant is enforced by a partial unique index in the database,
 * not by a racy pre-check (DEC-0062).
 */

import type { CapabilityType } from './capability-type';
import type { Capability } from './capability';

export const CAPABILITY_REPOSITORY = Symbol('CAPABILITY_REPOSITORY');

export interface CapabilityRepository {
  /** The user's active (non-revoked) grant of `type`, or `null`. */
  findActive(userId: string, type: CapabilityType): Promise<Capability | null>;
  /**
   * Persist a new active grant. A concurrent/duplicate active grant fails on the
   * partial unique index and is surfaced as
   * {@link import('./authorization.errors').InvalidCapabilityError} so the caller can
   * fall back to the existing active grant.
   */
  create(capability: Capability): Promise<Capability>;
  /**
   * Revoke the user's active grant of `type` (stamps `revoked_at`). Returns the
   * number revoked (0 when the user had no active grant — revoke is idempotent).
   */
  revokeActive(userId: string, type: CapabilityType, revokedAt: Date): Promise<number>;
}
