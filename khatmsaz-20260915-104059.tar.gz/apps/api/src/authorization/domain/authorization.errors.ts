/**
 * Authorization domain errors (Phase 7). Framework- and Prisma-free.
 *
 * The two DENIAL errors ({@link CapabilityRequiredError}, {@link
 * ResourceOwnershipError}) are the "not allowed" outcomes — distinct from an
 * authentication failure (a 401 raised earlier by the session guard). Their messages
 * are deliberately GENERIC: they never name which capability the user lacks in a way
 * that enables enumeration, and never disclose a resource's owner.
 */

export class AuthorizationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A capability grant's fields were internally inconsistent on construction. */
export class InvalidCapabilityError extends AuthorizationError {
  constructor(reason: string) {
    super(`Invalid capability: ${reason}.`);
  }
}

/** An unknown capability type was supplied. */
export class UnknownCapabilityTypeError extends AuthorizationError {
  constructor() {
    super('Invalid capability: unknown type.');
  }
}

/** Base for "you are not allowed" outcomes — maps to HTTP 403 at the transport. */
export class ForbiddenError extends AuthorizationError {}

/** The user does not hold a capability required for the action. */
export class CapabilityRequiredError extends ForbiddenError {
  constructor() {
    super('You do not have permission to perform this action.');
  }
}

/** The user is not the owner of the resource they attempted to manage. */
export class ResourceOwnershipError extends ForbiddenError {
  constructor() {
    super('You do not have permission to manage this resource.');
  }
}
