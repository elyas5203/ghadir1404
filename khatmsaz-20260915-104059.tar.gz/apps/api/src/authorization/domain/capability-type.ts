/**
 * The kinds of capability a user can be granted (DEC-0062). A capability is an
 * authorization grant — a coarse "this user may do X" — NOT a role hierarchy and
 * NOT identity. Only CREATOR exists this phase; Admin is deliberately not modelled.
 * The string values match the persistence enum `capability_type`.
 */

export const CapabilityType = {
  /** May create and manage their own Khatms. */
  CREATOR: 'CREATOR',
} as const;

export type CapabilityType = (typeof CapabilityType)[keyof typeof CapabilityType];

export const ALL_CAPABILITY_TYPES: readonly CapabilityType[] = Object.values(CapabilityType);

export function isCapabilityType(value: unknown): value is CapabilityType {
  return typeof value === 'string' && (ALL_CAPABILITY_TYPES as readonly string[]).includes(value);
}
