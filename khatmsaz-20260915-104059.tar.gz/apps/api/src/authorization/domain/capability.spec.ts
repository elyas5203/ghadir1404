import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { Capability } from './capability';
import { CapabilityType } from './capability-type';
import { InvalidCapabilityError, UnknownCapabilityTypeError } from './authorization.errors';

describe('Capability (domain)', () => {
  it('is granted active with no revocation', () => {
    const c = Capability.grant({ id: newUuidV7(), userId: newUuidV7(), type: CapabilityType.CREATOR });
    expect(c.isActive).toBe(true);
    expect(c.revokedAt).toBeNull();
    expect(c.type).toBe(CapabilityType.CREATOR);
  });

  it('restores as inactive when revoked', () => {
    const granted = new Date(1_000);
    const c = Capability.restore({
      id: newUuidV7(),
      userId: newUuidV7(),
      type: CapabilityType.CREATOR,
      grantedAt: granted,
      revokedAt: new Date(2_000),
    });
    expect(c.isActive).toBe(false);
  });

  it('rejects a non-UUIDv7 id/userId', () => {
    expect(() => Capability.grant({ id: 'x', userId: newUuidV7(), type: CapabilityType.CREATOR })).toThrow(
      InvalidUuidV7Error,
    );
  });

  it('rejects an unknown capability type', () => {
    expect(() =>
      Capability.grant({ id: newUuidV7(), userId: newUuidV7(), type: 'ADMIN' as CapabilityType }),
    ).toThrow(UnknownCapabilityTypeError);
  });

  it('rejects revokedAt before grantedAt on restore', () => {
    expect(() =>
      Capability.restore({
        id: newUuidV7(),
        userId: newUuidV7(),
        type: CapabilityType.CREATOR,
        grantedAt: new Date(5_000),
        revokedAt: new Date(1_000),
      }),
    ).toThrow(InvalidCapabilityError);
  });
});
