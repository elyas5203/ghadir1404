import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { CapabilityType } from '../domain/capability-type';
import type { Capability } from '../domain/capability';
import type { CapabilityRepository } from '../domain/capability.repository';
import { InvalidCapabilityError } from '../domain/authorization.errors';
import { toCapability } from './capability.mapper';
import { PRISMA_UNIQUE_VIOLATION, prismaErrorCode } from './prisma-error';

/**
 * Prisma-backed {@link CapabilityRepository} — the only capability persistence that
 * sees Prisma; returns domain objects, never Prisma rows. "One active grant per
 * (user, type)" is enforced by the partial unique index; a violation is translated
 * to {@link InvalidCapabilityError} so the service can fall back to the existing grant.
 */
@Injectable()
export class PrismaCapabilityRepository implements CapabilityRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findActive(userId: string, type: CapabilityType): Promise<Capability | null> {
    const row = await this.prisma.userCapability.findFirst({
      where: { userId, type, revokedAt: null },
    });
    return row ? toCapability(row) : null;
  }

  async create(capability: Capability): Promise<Capability> {
    try {
      const row = await this.prisma.userCapability.create({
        data: {
          id: capability.id,
          userId: capability.userId,
          type: capability.type,
          grantedAt: capability.grantedAt,
          revokedAt: capability.revokedAt,
        },
      });
      return toCapability(row);
    } catch (error) {
      if (prismaErrorCode(error) === PRISMA_UNIQUE_VIOLATION) {
        throw new InvalidCapabilityError('an active grant of this type already exists');
      }
      throw error;
    }
  }

  async revokeActive(userId: string, type: CapabilityType, revokedAt: Date): Promise<number> {
    const result = await this.prisma.userCapability.updateMany({
      where: { userId, type, revokedAt: null },
      data: { revokedAt },
    });
    return result.count;
  }
}
