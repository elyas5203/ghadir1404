/**
 * Inspect Prisma request errors by their stable public error codes
 * (https://pris.ly/d/error-reference), duck-typing `code` to avoid depending on a
 * specific error-class identity. Confined to infrastructure.
 */

export const PRISMA_UNIQUE_VIOLATION = 'P2002';
export const PRISMA_FOREIGN_KEY_VIOLATION = 'P2003';

export function prismaErrorCode(error: unknown): string | undefined {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code;
    return typeof code === 'string' ? code : undefined;
  }
  return undefined;
}
