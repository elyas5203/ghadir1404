/**
 * Map `user_capabilities` rows to the domain {@link Capability}. Lives in
 * infrastructure so the Prisma row shape is converted to a Prisma-free domain object
 * here and nowhere else (DEC-0031); `Capability.restore` re-validates invariants.
 */

import { Capability } from '../domain/capability';
import type { CapabilityType } from '../domain/capability-type';

export interface CapabilityRow {
  id: string;
  userId: string;
  type: string;
  grantedAt: Date;
  revokedAt: Date | null;
}

export function toCapability(row: CapabilityRow): Capability {
  return Capability.restore({
    id: row.id,
    userId: row.userId,
    type: row.type as CapabilityType,
    grantedAt: row.grantedAt,
    revokedAt: row.revokedAt,
  });
}
