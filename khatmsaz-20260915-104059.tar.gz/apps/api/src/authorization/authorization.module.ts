import { Module } from '@nestjs/common';
import { AuthorizationService } from './application/authorization.service';
import { CAPABILITY_REPOSITORY } from './domain/capability.repository';
import { PrismaCapabilityRepository } from './infrastructure/prisma-capability.repository';

/**
 * Authorization capability (Phase 7, DEC-0061/0062). Owns the capability model and
 * the `AuthorizationService` that answers "is this user allowed?". It binds the
 * domain-owned repository port to its Prisma implementation and exports the service
 * for the orchestration layer to compose. No transport surface (there is no public
 * grant endpoint — granting is an explicit internal mechanism).
 */
@Module({
  providers: [
    AuthorizationService,
    { provide: CAPABILITY_REPOSITORY, useClass: PrismaCapabilityRepository },
  ],
  exports: [AuthorizationService],
})
export class AuthorizationModule {}
