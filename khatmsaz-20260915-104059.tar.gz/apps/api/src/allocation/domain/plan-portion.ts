/**
 * PlanPortion — the DOMAIN entity for one allocatable portion of a khatm's plan
 * (DEC-0052): a "slot" that a participant can be given, complete, or have returned
 * to the pool for reallocation.
 *
 *   OPEN ── assignTo(p) ──▶ ASSIGNED(holder=p) ── complete ──▶ COMPLETED (terminal)
 *    ▲                          │
 *    └──────── release ─────────┘
 *
 * Invariants the entity guarantees: an ASSIGNED portion has a holder
 * (`participationId`); OPEN and COMPLETED... an OPEN portion has no holder; a
 * COMPLETED portion carries `completedAt`. Non-overlap between portions is a plan
 * property (atomic positional units + a DB partial unique index, DEC-0053), not an
 * entity concern. Transitions return a NEW PlanPortion (immutable). Plain domain
 * object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { PortionSpec } from './portion-spec';
import { PortionStatus, isPortionStatus } from './portion-status';
import {
  InvalidPortionError,
  InvalidPortionTransitionError,
  UnknownPortionStatusError,
} from './allocation.errors';

export interface PlanPortionProps {
  readonly id: string;
  readonly planId: string;
  readonly khatmId: string;
  readonly sequence: number;
  readonly spec: PortionSpec;
  readonly status: PortionStatus;
  readonly participationId: string | null;
  readonly completedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface NewPlanPortionProps {
  readonly id: string;
  readonly planId: string;
  readonly khatmId: string;
  readonly sequence: number;
  readonly spec: PortionSpec;
}

export class PlanPortion {
  readonly id: string;
  readonly planId: string;
  readonly khatmId: string;
  readonly sequence: number;
  readonly spec: PortionSpec;
  readonly status: PortionStatus;
  readonly participationId: string | null;
  readonly completedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: PlanPortionProps) {
    this.id = props.id;
    this.planId = props.planId;
    this.khatmId = props.khatmId;
    this.sequence = props.sequence;
    this.spec = props.spec;
    this.status = props.status;
    this.participationId = props.participationId;
    this.completedAt = props.completedAt;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  get isOpen(): boolean {
    return this.status === PortionStatus.OPEN;
  }
  get isAssigned(): boolean {
    return this.status === PortionStatus.ASSIGNED;
  }
  get isCompleted(): boolean {
    return this.status === PortionStatus.COMPLETED;
  }

  /** OPEN → ASSIGNED, taking a holder. */
  assignTo(participationId: string): PlanPortion {
    assertUuidV7(participationId, 'participationId');
    if (this.status !== PortionStatus.OPEN) {
      throw new InvalidPortionTransitionError('only an open portion can be assigned');
    }
    return new PlanPortion({ ...this, status: PortionStatus.ASSIGNED, participationId });
  }

  /** ASSIGNED → OPEN, returning the portion to the pool (reallocation). */
  release(): PlanPortion {
    if (this.status !== PortionStatus.ASSIGNED) {
      throw new InvalidPortionTransitionError('only an assigned portion can be released');
    }
    return new PlanPortion({ ...this, status: PortionStatus.OPEN, participationId: null });
  }

  /** ASSIGNED → ASSIGNED with a new holder (reassignment). */
  reassignTo(participationId: string): PlanPortion {
    assertUuidV7(participationId, 'participationId');
    if (this.status !== PortionStatus.ASSIGNED) {
      throw new InvalidPortionTransitionError('only an assigned portion can be reassigned');
    }
    return new PlanPortion({ ...this, participationId });
  }

  /** ASSIGNED → COMPLETED, stamped with the completion time. */
  complete(completedAt: Date): PlanPortion {
    if (this.status !== PortionStatus.ASSIGNED) {
      throw new InvalidPortionTransitionError('only an assigned portion can be completed');
    }
    return new PlanPortion({ ...this, status: PortionStatus.COMPLETED, completedAt });
  }

  /** Create a brand-new OPEN portion. */
  static create(props: NewPlanPortionProps): PlanPortion {
    assertUuidV7(props.id, 'PlanPortion.id');
    assertUuidV7(props.planId, 'PlanPortion.planId');
    assertUuidV7(props.khatmId, 'PlanPortion.khatmId');
    if (!Number.isInteger(props.sequence) || props.sequence < 1) {
      throw new InvalidPortionError('a portion needs a positive integer sequence');
    }
    const now = new Date();
    return new PlanPortion({
      ...props,
      status: PortionStatus.OPEN,
      participationId: null,
      completedAt: null,
      createdAt: now,
      updatedAt: now,
    });
  }

  /** Reconstitute a persisted portion, enforcing its status/holder invariants. */
  static restore(props: PlanPortionProps): PlanPortion {
    assertUuidV7(props.id, 'PlanPortion.id');
    assertUuidV7(props.planId, 'PlanPortion.planId');
    assertUuidV7(props.khatmId, 'PlanPortion.khatmId');
    if (!isPortionStatus(props.status)) {
      throw new UnknownPortionStatusError();
    }
    if (props.status === PortionStatus.OPEN && props.participationId !== null) {
      throw new InvalidPortionError('an open portion must not have a holder');
    }
    if (props.status === PortionStatus.ASSIGNED && !props.participationId) {
      throw new InvalidPortionError('an assigned portion requires a holder');
    }
    if (props.status === PortionStatus.COMPLETED && !props.completedAt) {
      throw new InvalidPortionError('a completed portion requires completedAt');
    }
    if (props.participationId !== null) {
      assertUuidV7(props.participationId, 'PlanPortion.participationId');
    }
    return new PlanPortion(props);
  }
}
