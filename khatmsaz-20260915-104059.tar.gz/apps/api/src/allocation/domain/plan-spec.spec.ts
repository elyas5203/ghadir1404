import { generatePortions, MAX_PORTIONS_PER_PLAN } from './plan-spec';
import { PortionUnitKind } from './portion-unit-kind';
import { InvalidPlanSpecError } from './allocation.errors';

describe('generatePortions (template → portion generation)', () => {
  describe('POSITIONAL (e.g. a full Qur\'an by Juz 1..30)', () => {
    it('produces one atomic unit per position, tiling the range', () => {
      const portions = generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 1, to: 30 });
      expect(portions).toHaveLength(30);
      expect(portions.map((p) => p.unitStart)).toEqual(
        Array.from({ length: 30 }, (_, i) => i + 1),
      );
      expect(portions.every((p) => p.kind === PortionUnitKind.POSITIONAL)).toBe(true);
      expect(portions.every((p) => p.unitStart === p.unitEnd)).toBe(true);
    });

    it('is NON-OVERLAPPING and gap-free: units are exactly from..to, each once', () => {
      const portions = generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 5, to: 12 });
      const units = portions.map((p) => p.unitStart);
      expect(units).toEqual([5, 6, 7, 8, 9, 10, 11, 12]);
      expect(new Set(units).size).toBe(units.length); // no duplicates → no overlap
    });

    it('supports a single unit (from === to)', () => {
      expect(generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 7, to: 7 })).toHaveLength(1);
    });

    it('rejects from > to and non-positive bounds', () => {
      expect(() => generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 5, to: 1 })).toThrow(
        InvalidPlanSpecError,
      );
      expect(() => generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 0, to: 3 })).toThrow(
        InvalidPlanSpecError,
      );
    });
  });

  describe('QUANTITY (e.g. 1000 Salawat in 100s)', () => {
    it('splits into equal chunks that sum to the total', () => {
      const portions = generatePortions({ kind: PortionUnitKind.QUANTITY, total: 1000, chunk: 100 });
      expect(portions).toHaveLength(10);
      expect(portions.every((p) => p.quantity === 100)).toBe(true);
      expect(portions.reduce((s, p) => s + (p.quantity as number), 0)).toBe(1000);
    });

    it('puts the remainder in a smaller final chunk', () => {
      const portions = generatePortions({ kind: PortionUnitKind.QUANTITY, total: 250, chunk: 100 });
      expect(portions.map((p) => p.quantity)).toEqual([100, 100, 50]);
      expect(portions.reduce((s, p) => s + (p.quantity as number), 0)).toBe(250);
    });

    it('handles a total smaller than the chunk (one chunk = total)', () => {
      expect(generatePortions({ kind: PortionUnitKind.QUANTITY, total: 40, chunk: 100 })).toEqual([
        expect.objectContaining({ quantity: 40 }),
      ]);
    });

    it('rejects non-positive total or chunk', () => {
      expect(() => generatePortions({ kind: PortionUnitKind.QUANTITY, total: 0, chunk: 10 })).toThrow(
        InvalidPlanSpecError,
      );
      expect(() => generatePortions({ kind: PortionUnitKind.QUANTITY, total: 10, chunk: 0 })).toThrow(
        InvalidPlanSpecError,
      );
    });
  });

  it('rejects a plan that would exceed the portion cap', () => {
    expect(() =>
      generatePortions({ kind: PortionUnitKind.POSITIONAL, from: 1, to: MAX_PORTIONS_PER_PLAN + 1 }),
    ).toThrow(InvalidPlanSpecError);
  });
});
