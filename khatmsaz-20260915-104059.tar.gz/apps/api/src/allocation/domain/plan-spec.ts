/**
 * PlanSpec + the portion GENERATOR — the "template to portion generation" core of
 * the allocation engine (DEC-0052).
 *
 * A khatm's content target is expressed as a PlanSpec, and `generatePortions`
 * turns it into an ordered, NON-OVERLAPPING set of {@link PortionSpec}s (the plan).
 * The generator is generic and template-DRIVEN by configuration (DEC-0019): the
 * caller supplies the numbers (which units, how large a chunk), so no per-template
 * count or granularity is hard-coded into the engine (DEC-0052). The template type
 * on the khatm informs which family the caller chooses; the engine only validates
 * internal coherence.
 *
 *   - POSITIONAL `{ from, to }`  → atomic units `from, from+1, …, to`
 *     (e.g. a full Qur'an by Juz is `{ from: 1, to: 30 }`). The units tile the
 *     range with no gaps or overlaps — the non-overlap guarantee by construction.
 *   - QUANTITY `{ total, chunk }` → `ceil(total / chunk)` chunks that sum to
 *     `total` (e.g. 1000 Salawat in 100s → ten chunks; a remainder forms a smaller
 *     final chunk).
 *
 * Pure domain function; no Prisma or framework dependency.
 */

import { PortionSpec } from './portion-spec';
import { PortionUnitKind } from './portion-unit-kind';
import { InvalidPlanSpecError } from './allocation.errors';

export interface PositionalPlanSpec {
  readonly kind: typeof PortionUnitKind.POSITIONAL;
  readonly from: number;
  readonly to: number;
}

export interface QuantityPlanSpec {
  readonly kind: typeof PortionUnitKind.QUANTITY;
  readonly total: number;
  readonly chunk: number;
}

export type PlanSpec = PositionalPlanSpec | QuantityPlanSpec;

/** A safety bound: a single generated plan may not exceed this many portions. */
export const MAX_PORTIONS_PER_PLAN = 10_000;

function isPositiveInt(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 1;
}

/**
 * Generate the ordered, non-overlapping portions for a plan spec. Throws
 * {@link InvalidPlanSpecError} for an incoherent spec or one that would exceed
 * {@link MAX_PORTIONS_PER_PLAN}. The result is never empty.
 */
export function generatePortions(spec: PlanSpec): PortionSpec[] {
  if (spec.kind === PortionUnitKind.POSITIONAL) {
    if (!isPositiveInt(spec.from) || !isPositiveInt(spec.to)) {
      throw new InvalidPlanSpecError('positional bounds must be positive integers');
    }
    if (spec.from > spec.to) {
      throw new InvalidPlanSpecError('positional `from` must be <= `to`');
    }
    const count = spec.to - spec.from + 1;
    guardCount(count);
    const portions: PortionSpec[] = [];
    for (let unit = spec.from; unit <= spec.to; unit += 1) {
      portions.push(PortionSpec.positionalUnit(unit));
    }
    return portions;
  }

  if (!isPositiveInt(spec.total) || !isPositiveInt(spec.chunk)) {
    throw new InvalidPlanSpecError('quantity `total` and `chunk` must be positive integers');
  }
  const fullChunks = Math.floor(spec.total / spec.chunk);
  const remainder = spec.total % spec.chunk;
  const count = fullChunks + (remainder > 0 ? 1 : 0);
  guardCount(count);
  const portions: PortionSpec[] = [];
  for (let i = 0; i < fullChunks; i += 1) {
    portions.push(PortionSpec.quantityChunk(spec.chunk));
  }
  if (remainder > 0) {
    portions.push(PortionSpec.quantityChunk(remainder));
  }
  return portions;
}

function guardCount(count: number): void {
  if (count > MAX_PORTIONS_PER_PLAN) {
    throw new InvalidPlanSpecError(
      `a plan may not exceed ${MAX_PORTIONS_PER_PLAN} portions (asked for ${count})`,
    );
  }
}
