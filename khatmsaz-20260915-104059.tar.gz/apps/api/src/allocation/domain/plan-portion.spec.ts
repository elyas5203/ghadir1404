import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { PlanPortion } from './plan-portion';
import { PortionSpec } from './portion-spec';
import { PortionStatus } from './portion-status';
import { InvalidPortionError, InvalidPortionTransitionError } from './allocation.errors';

const newOpen = () =>
  PlanPortion.create({
    id: newUuidV7(),
    planId: newUuidV7(),
    khatmId: newUuidV7(),
    sequence: 1,
    spec: PortionSpec.positionalUnit(1),
  });

describe('PlanPortion (domain)', () => {
  it('is born OPEN with no holder and no completedAt', () => {
    const p = newOpen();
    expect(p.status).toBe(PortionStatus.OPEN);
    expect(p.isOpen).toBe(true);
    expect(p.participationId).toBeNull();
    expect(p.completedAt).toBeNull();
  });

  it('rejects a non-positive sequence', () => {
    expect(() =>
      PlanPortion.create({
        id: newUuidV7(),
        planId: newUuidV7(),
        khatmId: newUuidV7(),
        sequence: 0,
        spec: PortionSpec.quantityChunk(10),
      }),
    ).toThrow(InvalidPortionError);
  });

  describe('lifecycle', () => {
    const holder = newUuidV7();

    it('OPEN → ASSIGNED via assignTo (takes a holder)', () => {
      const a = newOpen().assignTo(holder);
      expect(a.status).toBe(PortionStatus.ASSIGNED);
      expect(a.participationId).toBe(holder);
    });

    it('ASSIGNED → OPEN via release (clears holder) — reallocation', () => {
      const released = newOpen().assignTo(holder).release();
      expect(released.status).toBe(PortionStatus.OPEN);
      expect(released.participationId).toBeNull();
    });

    it('ASSIGNED → ASSIGNED via reassignTo (new holder)', () => {
      const other = newUuidV7();
      const moved = newOpen().assignTo(holder).reassignTo(other);
      expect(moved.status).toBe(PortionStatus.ASSIGNED);
      expect(moved.participationId).toBe(other);
    });

    it('ASSIGNED → COMPLETED via complete (stamps completedAt)', () => {
      const at = new Date();
      const done = newOpen().assignTo(holder).complete(at);
      expect(done.status).toBe(PortionStatus.COMPLETED);
      expect(done.completedAt).toBe(at);
    });

    it('is immutable across transitions', () => {
      const open = newOpen();
      open.assignTo(holder);
      expect(open.status).toBe(PortionStatus.OPEN);
    });

    it('rejects an invalid holder id on assign', () => {
      expect(() => newOpen().assignTo('nope')).toThrow(InvalidUuidV7Error);
    });
  });

  describe('invalid transitions', () => {
    const holder = newUuidV7();
    it('cannot assign a non-open portion', () => {
      expect(() => newOpen().assignTo(holder).assignTo(holder)).toThrow(
        InvalidPortionTransitionError,
      );
    });
    it('cannot release an open portion', () => {
      expect(() => newOpen().release()).toThrow(InvalidPortionTransitionError);
    });
    it('cannot complete an open portion', () => {
      expect(() => newOpen().complete(new Date())).toThrow(InvalidPortionTransitionError);
    });
    it('cannot transition out of COMPLETED', () => {
      const done = newOpen().assignTo(holder).complete(new Date());
      expect(() => done.release()).toThrow(InvalidPortionTransitionError);
      expect(() => done.reassignTo(holder)).toThrow(InvalidPortionTransitionError);
    });
  });

  describe('restore invariants', () => {
    const base = {
      id: newUuidV7(),
      planId: newUuidV7(),
      khatmId: newUuidV7(),
      sequence: 1,
      spec: PortionSpec.positionalUnit(1),
      completedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    it('rejects an OPEN portion with a holder', () => {
      expect(() =>
        PlanPortion.restore({ ...base, status: PortionStatus.OPEN, participationId: newUuidV7() }),
      ).toThrow(InvalidPortionError);
    });
    it('rejects an ASSIGNED portion with no holder', () => {
      expect(() =>
        PlanPortion.restore({ ...base, status: PortionStatus.ASSIGNED, participationId: null }),
      ).toThrow(InvalidPortionError);
    });
    it('rejects a COMPLETED portion with no completedAt', () => {
      expect(() =>
        PlanPortion.restore({
          ...base,
          status: PortionStatus.COMPLETED,
          participationId: newUuidV7(),
          completedAt: null,
        }),
      ).toThrow(InvalidPortionError);
    });
  });
});
