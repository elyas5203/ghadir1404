import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { AllocationPlan } from './allocation-plan';
import { PortionUnitKind } from './portion-unit-kind';
import { InvalidPortionError, UnknownPortionUnitKindError } from './allocation.errors';

describe('AllocationPlan (domain)', () => {
  it('creates a plan with a positive portion count', () => {
    const plan = AllocationPlan.create({
      id: newUuidV7(),
      khatmId: newUuidV7(),
      unitKind: PortionUnitKind.POSITIONAL,
      totalPortions: 30,
    });
    expect(plan.totalPortions).toBe(30);
    expect(plan.unitKind).toBe(PortionUnitKind.POSITIONAL);
  });

  it('rejects a non-UUIDv7 id/khatmId', () => {
    expect(() =>
      AllocationPlan.create({ id: 'x', khatmId: newUuidV7(), unitKind: PortionUnitKind.QUANTITY, totalPortions: 1 }),
    ).toThrow(InvalidUuidV7Error);
  });

  it('rejects an empty plan (zero portions)', () => {
    expect(() =>
      AllocationPlan.create({ id: newUuidV7(), khatmId: newUuidV7(), unitKind: PortionUnitKind.QUANTITY, totalPortions: 0 }),
    ).toThrow(InvalidPortionError);
  });

  it('rejects an unknown unit kind', () => {
    expect(() =>
      AllocationPlan.create({ id: newUuidV7(), khatmId: newUuidV7(), unitKind: 'X' as PortionUnitKind, totalPortions: 1 }),
    ).toThrow(UnknownPortionUnitKindError);
  });
});
