/**
 * AllocationPlan — the DOMAIN entity for a khatm's content target: the set of
 * portions that make up the khatm, produced once by the generator (DEC-0052).
 *
 * There is at most ONE plan per khatm (enforced by a unique index on `khatmId`),
 * so generating a plan is idempotent-guarded and race-safe. The plan records the
 * portion family and how many portions it produced; the portions themselves are
 * {@link import('./plan-portion').PlanPortion}s. Plain domain object; no Prisma or
 * framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { PortionUnitKind, isPortionUnitKind } from './portion-unit-kind';
import { InvalidPortionError, UnknownPortionUnitKindError } from './allocation.errors';

export interface AllocationPlanProps {
  readonly id: string;
  readonly khatmId: string;
  readonly unitKind: PortionUnitKind;
  readonly totalPortions: number;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface NewAllocationPlanProps {
  readonly id: string;
  readonly khatmId: string;
  readonly unitKind: PortionUnitKind;
  readonly totalPortions: number;
}

export class AllocationPlan {
  readonly id: string;
  readonly khatmId: string;
  readonly unitKind: PortionUnitKind;
  readonly totalPortions: number;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: AllocationPlanProps) {
    this.id = props.id;
    this.khatmId = props.khatmId;
    this.unitKind = props.unitKind;
    this.totalPortions = props.totalPortions;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  static create(props: NewAllocationPlanProps): AllocationPlan {
    assertUuidV7(props.id, 'AllocationPlan.id');
    assertUuidV7(props.khatmId, 'AllocationPlan.khatmId');
    if (!isPortionUnitKind(props.unitKind)) {
      throw new UnknownPortionUnitKindError();
    }
    if (!Number.isInteger(props.totalPortions) || props.totalPortions < 1) {
      throw new InvalidPortionError('a plan must contain at least one portion');
    }
    const now = new Date();
    return new AllocationPlan({ ...props, createdAt: now, updatedAt: now });
  }

  static restore(props: AllocationPlanProps): AllocationPlan {
    assertUuidV7(props.id, 'AllocationPlan.id');
    assertUuidV7(props.khatmId, 'AllocationPlan.khatmId');
    if (!isPortionUnitKind(props.unitKind)) {
      throw new UnknownPortionUnitKindError();
    }
    return new AllocationPlan(props);
  }

  static unitKindOf(spec: { kind: PortionUnitKind }): PortionUnitKind {
    return spec.kind === PortionUnitKind.POSITIONAL
      ? PortionUnitKind.POSITIONAL
      : PortionUnitKind.QUANTITY;
  }
}
