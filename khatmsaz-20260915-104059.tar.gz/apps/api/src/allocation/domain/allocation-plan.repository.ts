/**
 * AllocationPlanRepository — a persistence port OWNED BY THE DOMAIN. Its
 * Prisma-backed implementation lives in infrastructure (DEC-0031). Only the
 * operations this phase needs are declared.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { AllocationPlan } from './allocation-plan';

export const ALLOCATION_PLAN_REPOSITORY = Symbol('ALLOCATION_PLAN_REPOSITORY');

export interface AllocationPlanRepository {
  /**
   * Persist a new plan. The `khatmId` unique index makes a second plan for the
   * same khatm fail with
   * {@link import('./allocation.errors').AllocationPlanAlreadyExistsError}; a
   * missing khatm fails with
   * {@link import('./allocation.errors').KhatmNotPlannableError}.
   */
  create(plan: AllocationPlan, tx?: TransactionContext): Promise<AllocationPlan>;
  /** Find the khatm's plan, or `null` when it has none. */
  findByKhatmId(khatmId: string, tx?: TransactionContext): Promise<AllocationPlan | null>;
}
