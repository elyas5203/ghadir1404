/**
 * PortionSpec — the SHAPE of one allocatable portion, as a DOMAIN value object of
 * the allocation engine (DEC-0052). It describes WHAT a portion covers, independent
 * of who holds it or whether it is done (that is {@link
 * import('./plan-portion').PlanPortion}).
 *
 *   - POSITIONAL — an ATOMIC unit at `unitStart === unitEnd` (e.g. Qur'an Juz 7).
 *     Engine portions are atomic so non-overlap is a plain uniqueness rule
 *     (DEC-0053); the `unitEnd` column is retained equal to `unitStart` to mirror
 *     the persistence shape and leave room for future grouping.
 *   - QUANTITY — a count (`quantity`), e.g. a 100-Salawat chunk.
 *
 * Exactly one shape is populated. Plain domain object; no Prisma or framework.
 */

import { PortionUnitKind, isPortionUnitKind } from './portion-unit-kind';
import { InvalidPortionError, UnknownPortionUnitKindError } from './allocation.errors';

export interface PortionSpecProps {
  readonly kind: PortionUnitKind;
  readonly unitStart: number | null;
  readonly unitEnd: number | null;
  readonly quantity: number | null;
}

function isPositiveInt(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 1;
}

export class PortionSpec {
  readonly kind: PortionUnitKind;
  readonly unitStart: number | null;
  readonly unitEnd: number | null;
  readonly quantity: number | null;

  private constructor(props: PortionSpecProps) {
    this.kind = props.kind;
    this.unitStart = props.unitStart;
    this.unitEnd = props.unitEnd;
    this.quantity = props.quantity;
  }

  get isPositional(): boolean {
    return this.kind === PortionUnitKind.POSITIONAL;
  }

  /** How much the portion covers: 1 for an atomic positional unit, the count for QUANTITY. */
  get size(): number {
    return this.kind === PortionUnitKind.POSITIONAL ? 1 : (this.quantity as number);
  }

  /** An atomic positional unit at `index` (e.g. Juz 7 → `positionalUnit(7)`). */
  static positionalUnit(index: number): PortionSpec {
    if (!isPositiveInt(index)) {
      throw new InvalidPortionError('a positional unit needs a positive integer index');
    }
    return new PortionSpec({
      kind: PortionUnitKind.POSITIONAL,
      unitStart: index,
      unitEnd: index,
      quantity: null,
    });
  }

  /** A count-based chunk (e.g. 100 Salawat → `quantityChunk(100)`). */
  static quantityChunk(amount: number): PortionSpec {
    if (!isPositiveInt(amount)) {
      throw new InvalidPortionError('a quantity chunk needs a positive integer amount');
    }
    return new PortionSpec({
      kind: PortionUnitKind.QUANTITY,
      unitStart: null,
      unitEnd: null,
      quantity: amount,
    });
  }

  /** Reconstruct from flattened persistence columns, enforcing shape consistency. */
  static restore(props: PortionSpecProps): PortionSpec {
    if (!isPortionUnitKind(props.kind)) {
      throw new UnknownPortionUnitKindError();
    }
    if (props.kind === PortionUnitKind.POSITIONAL) {
      if (props.quantity !== null) {
        throw new InvalidPortionError('a positional portion must not carry a quantity');
      }
      if (props.unitStart === null || props.unitStart !== props.unitEnd) {
        throw new InvalidPortionError('an engine positional portion must be a single atomic unit');
      }
      return PortionSpec.positionalUnit(props.unitStart);
    }
    if (props.unitStart !== null || props.unitEnd !== null) {
      throw new InvalidPortionError('a quantity portion must not carry positional bounds');
    }
    return PortionSpec.quantityChunk(props.quantity as number);
  }
}
