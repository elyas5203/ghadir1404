import { PortionSpec } from './portion-spec';
import { PortionUnitKind } from './portion-unit-kind';
import { InvalidPortionError, UnknownPortionUnitKindError } from './allocation.errors';

describe('PortionSpec (domain)', () => {
  it('builds an atomic positional unit', () => {
    const p = PortionSpec.positionalUnit(7);
    expect(p.kind).toBe(PortionUnitKind.POSITIONAL);
    expect(p.unitStart).toBe(7);
    expect(p.unitEnd).toBe(7);
    expect(p.quantity).toBeNull();
    expect(p.size).toBe(1);
    expect(p.isPositional).toBe(true);
  });

  it('builds a quantity chunk', () => {
    const p = PortionSpec.quantityChunk(100);
    expect(p.kind).toBe(PortionUnitKind.QUANTITY);
    expect(p.quantity).toBe(100);
    expect(p.unitStart).toBeNull();
    expect(p.size).toBe(100);
  });

  it('rejects non-positive or non-integer values', () => {
    expect(() => PortionSpec.positionalUnit(0)).toThrow(InvalidPortionError);
    expect(() => PortionSpec.quantityChunk(1.5)).toThrow(InvalidPortionError);
  });

  describe('restore', () => {
    it('round-trips a positional unit', () => {
      const p = PortionSpec.restore({ kind: PortionUnitKind.POSITIONAL, unitStart: 3, unitEnd: 3, quantity: null });
      expect(p.unitStart).toBe(3);
    });

    it('round-trips a quantity chunk', () => {
      const p = PortionSpec.restore({ kind: PortionUnitKind.QUANTITY, unitStart: null, unitEnd: null, quantity: 50 });
      expect(p.quantity).toBe(50);
    });

    it('rejects a non-atomic positional portion (start !== end)', () => {
      expect(() =>
        PortionSpec.restore({ kind: PortionUnitKind.POSITIONAL, unitStart: 1, unitEnd: 5, quantity: null }),
      ).toThrow(InvalidPortionError);
    });

    it('rejects mixed columns and unknown kinds', () => {
      expect(() =>
        PortionSpec.restore({ kind: PortionUnitKind.POSITIONAL, unitStart: 1, unitEnd: 1, quantity: 9 }),
      ).toThrow(InvalidPortionError);
      expect(() =>
        PortionSpec.restore({ kind: 'X' as PortionUnitKind, unitStart: null, unitEnd: null, quantity: 1 }),
      ).toThrow(UnknownPortionUnitKindError);
    });
  });
});
