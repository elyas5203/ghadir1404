/**
 * Domain errors for the Khatm allocation engine (Phase 4.1).
 *
 * Framework- and Prisma-independent. Infrastructure repositories translate
 * persistence failures (unique / foreign-key violations, guarded updates that match
 * no row) into these so nothing outside infrastructure sees a Prisma error type.
 */

export class AllocationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A plan-generation spec was internally inconsistent (bad bounds, non-positive chunk, …). */
export class InvalidPlanSpecError extends AllocationError {
  constructor(reason: string) {
    super(`Invalid allocation plan spec: ${reason}.`);
  }
}

/** A portion's fields were internally inconsistent. */
export class InvalidPortionError extends AllocationError {
  constructor(reason: string) {
    super(`Invalid portion: ${reason}.`);
  }
}

/** An unknown portion unit kind was supplied. */
export class UnknownPortionUnitKindError extends AllocationError {
  constructor() {
    super('Invalid portion: unknown unit kind.');
  }
}

/** An unknown portion status was supplied. */
export class UnknownPortionStatusError extends AllocationError {
  constructor() {
    super('Invalid portion: unknown status.');
  }
}

/** An illegal portion lifecycle transition was attempted. */
export class InvalidPortionTransitionError extends AllocationError {
  constructor(reason: string) {
    super(`Invalid portion transition: ${reason}.`);
  }
}

/** The khatm cannot have a plan generated (it does not exist or is terminal). */
export class KhatmNotPlannableError extends AllocationError {
  constructor() {
    super('The khatm cannot have an allocation plan generated (missing or terminal).');
  }
}

/** The khatm is not ACTIVE, so portions cannot be allocated. */
export class KhatmNotAllocatableError extends AllocationError {
  constructor() {
    super('The khatm is not active and cannot allocate portions.');
  }
}

/** The referenced participation is not an active participant of the khatm. */
export class ParticipationNotAllocatableError extends AllocationError {
  constructor() {
    super('The referenced participation is not an active participant of this khatm.');
  }
}

/** A khatm already has an allocation plan (one plan per khatm). */
export class AllocationPlanAlreadyExistsError extends AllocationError {
  constructor() {
    super('This khatm already has an allocation plan.');
  }
}

/** The referenced allocation plan or portion does not exist. */
export class PortionNotFoundError extends AllocationError {
  constructor() {
    super('The referenced portion does not exist.');
  }
}

/** A portion was completed by someone other than its assigned holder. */
export class PortionNotHeldByParticipationError extends AllocationError {
  constructor() {
    super('Only the assigned holder can complete this portion.');
  }
}

/**
 * A guarded portion update matched no row: the portion was not in the expected
 * status (it was changed concurrently, or does not exist).
 */
export class PortionNotInExpectedStateError extends AllocationError {
  constructor() {
    super('The portion is not in the expected state.');
  }
}
