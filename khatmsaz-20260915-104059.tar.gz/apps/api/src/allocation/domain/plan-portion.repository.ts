/**
 * PlanPortionRepository — a persistence port OWNED BY THE DOMAIN. Its Prisma-backed
 * implementation lives in infrastructure (DEC-0031). Lifecycle transitions are
 * guarded on the expected prior status so concurrent changes cannot both win.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { PlanPortion } from './plan-portion';

export const PLAN_PORTION_REPOSITORY = Symbol('PLAN_PORTION_REPOSITORY');

/** A khatm's allocation progress, counted over its plan portions. */
export interface PortionProgress {
  readonly total: number;
  readonly open: number;
  readonly assigned: number;
  readonly completed: number;
}

export interface PlanPortionRepository {
  /** Bulk-insert the generated portions of a plan; returns the number written. */
  createMany(portions: readonly PlanPortion[], tx?: TransactionContext): Promise<number>;
  /** Find a portion by id, or `null` when none exists. */
  findById(id: string, tx?: TransactionContext): Promise<PlanPortion | null>;
  /** The khatm's OPEN portions in `sequence` order, up to `limit`. */
  findOpenByKhatm(
    khatmId: string,
    limit: number,
    tx?: TransactionContext,
  ): Promise<PlanPortion[]>;
  /** Portions currently held by a participation, in `sequence` order (empty when none). */
  findByParticipation(participationId: string): Promise<PlanPortion[]>;
  /**
   * OPEN → ASSIGNED, guarded on OPEN. Throws
   * {@link import('./allocation.errors').PortionNotInExpectedStateError} when no
   * row matches, or
   * {@link import('./allocation.errors').ParticipationNotAllocatableError} when the
   * holder FK is unknown.
   */
  assign(portionId: string, participationId: string, tx?: TransactionContext): Promise<void>;
  /** ASSIGNED → ASSIGNED with a new holder, guarded on ASSIGNED. */
  reassign(portionId: string, participationId: string, tx?: TransactionContext): Promise<void>;
  /** ASSIGNED → OPEN (clears holder), guarded on ASSIGNED. */
  release(portionId: string, tx?: TransactionContext): Promise<void>;
  /**
   * Release every ASSIGNED portion held by a participation in a khatm back to OPEN
   * (reallocation when a participant leaves). Returns the number released.
   */
  releaseAllAssignedByParticipation(
    khatmId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<number>;
  /** ASSIGNED → COMPLETED (stamps `completedAt`), guarded on ASSIGNED. */
  complete(portionId: string, completedAt: Date, tx?: TransactionContext): Promise<void>;
  /** Count a khatm's portions by status, for progress. */
  progressByKhatm(khatmId: string, tx?: TransactionContext): Promise<PortionProgress>;
}
