/**
 * How an allocation portion is expressed — a DOMAIN-owned concept of the Khatm
 * ALLOCATION ENGINE (Phase 4.1, DEC-0052).
 *
 * Deliberately independent of the Phase-4 `AssignmentUnitKind`: capabilities never
 * import each other's domain (DEC-0039). The two families:
 *   - POSITIONAL — an identifiable unit within a fixed structure (e.g. a Qur'an
 *     Juz). Engine plan portions are ATOMIC positional units (one unit each), which
 *     is what lets non-overlap be enforced by a plain partial unique index rather
 *     than a range-exclusion constraint (DEC-0053).
 *   - QUANTITY — a bare count of repetitions (e.g. a chunk of Salawat). Counts do
 *     not "overlap", so the non-overlap rule is meaningful only for POSITIONAL.
 *
 * The string values match the persistence enum `portion_unit_kind`; nothing outside
 * infrastructure depends on the Prisma-generated enum.
 */

export const PortionUnitKind = {
  POSITIONAL: 'POSITIONAL',
  QUANTITY: 'QUANTITY',
} as const;

export type PortionUnitKind = (typeof PortionUnitKind)[keyof typeof PortionUnitKind];

export const ALL_PORTION_UNIT_KINDS: readonly PortionUnitKind[] =
  Object.values(PortionUnitKind);

export function isPortionUnitKind(value: unknown): value is PortionUnitKind {
  return typeof value === 'string' && (ALL_PORTION_UNIT_KINDS as readonly string[]).includes(value);
}
