/**
 * The lifecycle of a {@link import('./plan-portion').PlanPortion} — a DOMAIN-owned
 * concept of the allocation engine (DEC-0052).
 *
 *   OPEN ── assign ──▶ ASSIGNED ── complete ──▶ COMPLETED (terminal)
 *    ▲                    │
 *    └──── release ───────┘   (reallocation: a held portion returns to the pool)
 *
 * OPEN is an unallocated portion in the pool; ASSIGNED is held by exactly one
 * participation; COMPLETED is fulfilled and terminal. A held portion can be
 * RELEASED back to OPEN (the basis of reallocation when a participant leaves). The
 * string values match the persistence enum `khatm_portion_status`.
 */

export const PortionStatus = {
  OPEN: 'OPEN',
  ASSIGNED: 'ASSIGNED',
  COMPLETED: 'COMPLETED',
} as const;

export type PortionStatus = (typeof PortionStatus)[keyof typeof PortionStatus];

export const ALL_PORTION_STATUSES: readonly PortionStatus[] = Object.values(PortionStatus);

export function isPortionStatus(value: unknown): value is PortionStatus {
  return typeof value === 'string' && (ALL_PORTION_STATUSES as readonly string[]).includes(value);
}
