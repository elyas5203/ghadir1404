/**
 * KhatmStateReader — a READ port OWNED BY THE ALLOCATION DOMAIN.
 *
 * The allocation engine must know a little about the Phase-4 khatm/participation
 * state (is the khatm plannable? active? is this an active participant?) WITHOUT
 * importing the khatm capability's domain (DEC-0039). This port expresses exactly
 * those questions as booleans; its infrastructure implementation answers them by
 * reading the khatm tables via Prisma — no Phase-4 domain type crosses the
 * boundary, and Phase 4 is left unmodified (DEC-0052). It is transaction-aware so
 * the checks run inside the same transaction as the writes they guard.
 */

import type { TransactionContext } from '@khatmsaz/kernel';

export const KHATM_STATE_READER = Symbol('KHATM_STATE_READER');

export interface KhatmStateReader {
  /** True when the khatm exists and is not terminal (a plan may be generated). */
  canPlan(khatmId: string, tx?: TransactionContext): Promise<boolean>;
  /** True when the khatm exists and is ACTIVE (portions may be allocated). */
  isActive(khatmId: string, tx?: TransactionContext): Promise<boolean>;
  /** True when the participation exists, is ACTIVE, and belongs to the khatm. */
  hasActiveParticipation(
    khatmId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<boolean>;
}
