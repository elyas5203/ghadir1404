import { Module } from '@nestjs/common';
import { AllocationService } from './application/allocation.service';
import { ALLOCATION_PLAN_REPOSITORY } from './domain/allocation-plan.repository';
import { PLAN_PORTION_REPOSITORY } from './domain/plan-portion.repository';
import { KHATM_STATE_READER } from './domain/khatm-state.reader';
import { PrismaAllocationPlanRepository } from './infrastructure/prisma-allocation-plan.repository';
import { PrismaPlanPortionRepository } from './infrastructure/prisma-plan-portion.repository';
import { PrismaKhatmStateReader } from './infrastructure/prisma-khatm-state.reader';

/**
 * Khatm allocation engine module (Phase 4.1, DEC-0052).
 *
 * The generic, template-driven engine that turns a plan spec into non-overlapping
 * portions and allocates them to participants, with reallocation, progress, and
 * transaction safety. It is SELF-CONTAINED: it binds its own domain-owned ports to
 * Prisma implementations, reads Phase-4 khatm/participation state through its own
 * {@link KhatmStateReader} port, and imports no Phase-4 domain — so Phase 4 stays
 * unmodified. The `@Global` DatabaseModule provides `PrismaService` and
 * `UNIT_OF_WORK`.
 *
 * No HTTP controller or bot surface — no transport this phase.
 */
@Module({
  providers: [
    AllocationService,
    { provide: ALLOCATION_PLAN_REPOSITORY, useClass: PrismaAllocationPlanRepository },
    { provide: PLAN_PORTION_REPOSITORY, useClass: PrismaPlanPortionRepository },
    { provide: KHATM_STATE_READER, useClass: PrismaKhatmStateReader },
  ],
  exports: [AllocationService],
})
export class AllocationModule {}
