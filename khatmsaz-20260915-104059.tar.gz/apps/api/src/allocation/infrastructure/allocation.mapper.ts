/**
 * Mapping between persistence rows and allocation-engine domain entities. Lives in
 * infrastructure so Prisma-shaped rows become Prisma-free domain objects here and
 * nowhere else (DEC-0031). The domain factories re-validate every invariant.
 */

import { AllocationPlan } from '../domain/allocation-plan';
import type { PortionUnitKind } from '../domain/portion-unit-kind';
import { PlanPortion } from '../domain/plan-portion';
import { PortionSpec } from '../domain/portion-spec';
import type { PortionStatus } from '../domain/portion-status';

export interface AllocationPlanRow {
  id: string;
  khatmId: string;
  unitKind: string;
  totalPortions: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface PlanPortionRow {
  id: string;
  planId: string;
  khatmId: string;
  sequence: number;
  unitKind: string;
  unitStart: number | null;
  unitEnd: number | null;
  quantity: number | null;
  status: string;
  participationId: string | null;
  completedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export function toAllocationPlan(row: AllocationPlanRow): AllocationPlan {
  return AllocationPlan.restore({
    id: row.id,
    khatmId: row.khatmId,
    unitKind: row.unitKind as PortionUnitKind,
    totalPortions: row.totalPortions,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}

export function toPlanPortion(row: PlanPortionRow): PlanPortion {
  return PlanPortion.restore({
    id: row.id,
    planId: row.planId,
    khatmId: row.khatmId,
    sequence: row.sequence,
    spec: PortionSpec.restore({
      kind: row.unitKind as PortionUnitKind,
      unitStart: row.unitStart,
      unitEnd: row.unitEnd,
      quantity: row.quantity,
    }),
    status: row.status as PortionStatus,
    participationId: row.participationId,
    completedAt: row.completedAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}
