/**
 * Minimal, resilient inspection of Prisma request errors by their stable public
 * error codes (https://pris.ly/d/error-reference). Duck-typing the `code` avoids
 * depending on a specific error-class identity while staying inside infrastructure.
 */

export const PRISMA_UNIQUE_VIOLATION = 'P2002';
export const PRISMA_FOREIGN_KEY_VIOLATION = 'P2003';

export function prismaErrorCode(error: unknown): string | undefined {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code;
    return typeof code === 'string' ? code : undefined;
  }
  return undefined;
}
