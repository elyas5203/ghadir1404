import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import type { AllocationPlan } from '../domain/allocation-plan';
import type { AllocationPlanRepository } from '../domain/allocation-plan.repository';
import {
  AllocationPlanAlreadyExistsError,
  KhatmNotPlannableError,
} from '../domain/allocation.errors';
import { toAllocationPlan } from './allocation.mapper';
import {
  PRISMA_FOREIGN_KEY_VIOLATION,
  PRISMA_UNIQUE_VIOLATION,
  prismaErrorCode,
} from './prisma-error';

/**
 * Prisma-backed {@link AllocationPlanRepository}. The only plan persistence that
 * sees Prisma; returns domain objects, never Prisma rows. The `khatm_id` unique
 * index makes one-plan-per-khatm race-safe (a concurrent second generate loses).
 */
@Injectable()
export class PrismaAllocationPlanRepository implements AllocationPlanRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(plan: AllocationPlan, tx?: TransactionContext): Promise<AllocationPlan> {
    try {
      const row = await dbClient(this.prisma, tx).khatmAllocationPlan.create({
        data: {
          id: plan.id,
          khatmId: plan.khatmId,
          unitKind: plan.unitKind,
          totalPortions: plan.totalPortions,
        },
      });
      return toAllocationPlan(row);
    } catch (error) {
      const code = prismaErrorCode(error);
      if (code === PRISMA_UNIQUE_VIOLATION) {
        throw new AllocationPlanAlreadyExistsError();
      }
      if (code === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new KhatmNotPlannableError();
      }
      throw error;
    }
  }

  async findByKhatmId(khatmId: string, tx?: TransactionContext): Promise<AllocationPlan | null> {
    const row = await dbClient(this.prisma, tx).khatmAllocationPlan.findUnique({
      where: { khatmId },
    });
    return row ? toAllocationPlan(row) : null;
  }
}
