import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import type { KhatmStateReader } from '../domain/khatm-state.reader';

/**
 * Prisma-backed {@link KhatmStateReader}. Answers the allocation engine's
 * questions about Phase-4 khatm/participation state by reading those tables
 * directly — the ONLY coupling to Phase 4, kept in infrastructure and read-only, so
 * no Phase-4 domain type is imported (DEC-0039/0052) and Phase 4 is unmodified. The
 * status literals below match the `khatm_status` / `participation_status` DB enums;
 * they are infra-level SQL constants, not a domain dependency.
 */
@Injectable()
export class PrismaKhatmStateReader implements KhatmStateReader {
  constructor(private readonly prisma: PrismaService) {}

  async canPlan(khatmId: string, tx?: TransactionContext): Promise<boolean> {
    const count = await dbClient(this.prisma, tx).khatm.count({
      where: { id: khatmId, status: { in: ['DRAFT', 'ACTIVE'] } },
    });
    return count > 0;
  }

  async isActive(khatmId: string, tx?: TransactionContext): Promise<boolean> {
    const count = await dbClient(this.prisma, tx).khatm.count({
      where: { id: khatmId, status: 'ACTIVE' },
    });
    return count > 0;
  }

  async hasActiveParticipation(
    khatmId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<boolean> {
    const count = await dbClient(this.prisma, tx).participation.count({
      where: { id: participationId, khatmId, status: 'ACTIVE' },
    });
    return count > 0;
  }
}
