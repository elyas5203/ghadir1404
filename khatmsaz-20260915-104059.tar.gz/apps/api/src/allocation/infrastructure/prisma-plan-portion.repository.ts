import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import { PortionStatus } from '../domain/portion-status';
import type { PlanPortion } from '../domain/plan-portion';
import type {
  PlanPortionRepository,
  PortionProgress,
} from '../domain/plan-portion.repository';
import {
  ParticipationNotAllocatableError,
  PortionNotInExpectedStateError,
} from '../domain/allocation.errors';
import { toPlanPortion } from './allocation.mapper';
import { PRISMA_FOREIGN_KEY_VIOLATION, prismaErrorCode } from './prisma-error';

/**
 * Prisma-backed {@link PlanPortionRepository}. The only portion persistence that
 * sees Prisma; returns domain objects, never Prisma rows. Every lifecycle change is
 * a guarded `updateMany` keyed on the expected prior status, so a concurrent change
 * updates 0 rows and is rejected rather than silently lost.
 */
@Injectable()
export class PrismaPlanPortionRepository implements PlanPortionRepository {
  constructor(private readonly prisma: PrismaService) {}

  async createMany(
    portions: readonly PlanPortion[],
    tx?: TransactionContext,
  ): Promise<number> {
    const result = await dbClient(this.prisma, tx).khatmPortion.createMany({
      data: portions.map((p) => ({
        id: p.id,
        planId: p.planId,
        khatmId: p.khatmId,
        sequence: p.sequence,
        unitKind: p.spec.kind,
        unitStart: p.spec.unitStart,
        unitEnd: p.spec.unitEnd,
        quantity: p.spec.quantity,
      })),
    });
    return result.count;
  }

  async findById(id: string, tx?: TransactionContext): Promise<PlanPortion | null> {
    const row = await dbClient(this.prisma, tx).khatmPortion.findUnique({ where: { id } });
    return row ? toPlanPortion(row) : null;
  }

  async findByParticipation(participationId: string): Promise<PlanPortion[]> {
    const rows = await this.prisma.khatmPortion.findMany({
      where: { participationId },
      orderBy: { sequence: 'asc' },
    });
    return rows.map(toPlanPortion);
  }

  async findOpenByKhatm(
    khatmId: string,
    limit: number,
    tx?: TransactionContext,
  ): Promise<PlanPortion[]> {
    const rows = await dbClient(this.prisma, tx).khatmPortion.findMany({
      where: { khatmId, status: PortionStatus.OPEN },
      orderBy: { sequence: 'asc' },
      take: limit,
    });
    return rows.map(toPlanPortion);
  }

  async assign(
    portionId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<void> {
    try {
      const result = await dbClient(this.prisma, tx).khatmPortion.updateMany({
        where: { id: portionId, status: PortionStatus.OPEN },
        data: { status: PortionStatus.ASSIGNED, participationId },
      });
      if (result.count === 0) {
        throw new PortionNotInExpectedStateError();
      }
    } catch (error) {
      if (prismaErrorCode(error) === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new ParticipationNotAllocatableError();
      }
      throw error;
    }
  }

  async reassign(
    portionId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<void> {
    try {
      const result = await dbClient(this.prisma, tx).khatmPortion.updateMany({
        where: { id: portionId, status: PortionStatus.ASSIGNED },
        data: { participationId },
      });
      if (result.count === 0) {
        throw new PortionNotInExpectedStateError();
      }
    } catch (error) {
      if (prismaErrorCode(error) === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new ParticipationNotAllocatableError();
      }
      throw error;
    }
  }

  async release(portionId: string, tx?: TransactionContext): Promise<void> {
    const result = await dbClient(this.prisma, tx).khatmPortion.updateMany({
      where: { id: portionId, status: PortionStatus.ASSIGNED },
      data: { status: PortionStatus.OPEN, participationId: null },
    });
    if (result.count === 0) {
      throw new PortionNotInExpectedStateError();
    }
  }

  async releaseAllAssignedByParticipation(
    khatmId: string,
    participationId: string,
    tx?: TransactionContext,
  ): Promise<number> {
    const result = await dbClient(this.prisma, tx).khatmPortion.updateMany({
      where: { khatmId, participationId, status: PortionStatus.ASSIGNED },
      data: { status: PortionStatus.OPEN, participationId: null },
    });
    return result.count;
  }

  async complete(
    portionId: string,
    completedAt: Date,
    tx?: TransactionContext,
  ): Promise<void> {
    const result = await dbClient(this.prisma, tx).khatmPortion.updateMany({
      where: { id: portionId, status: PortionStatus.ASSIGNED },
      data: { status: PortionStatus.COMPLETED, completedAt },
    });
    if (result.count === 0) {
      throw new PortionNotInExpectedStateError();
    }
  }

  async progressByKhatm(khatmId: string, tx?: TransactionContext): Promise<PortionProgress> {
    const grouped = await dbClient(this.prisma, tx).khatmPortion.groupBy({
      by: ['status'],
      where: { khatmId },
      _count: { _all: true },
    });
    const counts: Record<string, number> = {};
    for (const g of grouped) {
      counts[g.status] = g._count._all;
    }
    const open = counts[PortionStatus.OPEN] ?? 0;
    const assigned = counts[PortionStatus.ASSIGNED] ?? 0;
    const completed = counts[PortionStatus.COMPLETED] ?? 0;
    return { total: open + assigned + completed, open, assigned, completed };
  }
}
