import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { UNIT_OF_WORK } from '@khatmsaz/kernel';
import type { TransactionContext, UnitOfWork } from '@khatmsaz/kernel';
import { AllocationService } from './allocation.service';
import { AllocationPlan } from '../domain/allocation-plan';
import { PlanPortion } from '../domain/plan-portion';
import { PortionUnitKind } from '../domain/portion-unit-kind';
import { PortionStatus } from '../domain/portion-status';
import {
  KhatmNotAllocatableError,
  KhatmNotPlannableError,
  ParticipationNotAllocatableError,
  AllocationPlanAlreadyExistsError,
  PortionNotInExpectedStateError,
  PortionNotHeldByParticipationError,
} from '../domain/allocation.errors';
import { ALLOCATION_PLAN_REPOSITORY } from '../domain/allocation-plan.repository';
import type { AllocationPlanRepository } from '../domain/allocation-plan.repository';
import { PLAN_PORTION_REPOSITORY } from '../domain/plan-portion.repository';
import type {
  PlanPortionRepository,
  PortionProgress,
} from '../domain/plan-portion.repository';
import { KHATM_STATE_READER } from '../domain/khatm-state.reader';
import type { KhatmStateReader } from '../domain/khatm-state.reader';

/** A Unit of Work that simply runs the callback with a dummy transaction. */
class FakeUnitOfWork implements UnitOfWork {
  run<T>(work: (tx: TransactionContext) => Promise<T>): Promise<T> {
    return work({} as TransactionContext);
  }
}

class FakePlanRepository implements AllocationPlanRepository {
  readonly plans: AllocationPlan[] = [];
  async create(plan: AllocationPlan): Promise<AllocationPlan> {
    if (this.plans.some((p) => p.khatmId === plan.khatmId)) {
      throw new AllocationPlanAlreadyExistsError();
    }
    this.plans.push(plan);
    return plan;
  }
  async findByKhatmId(khatmId: string): Promise<AllocationPlan | null> {
    return this.plans.find((p) => p.khatmId === khatmId) ?? null;
  }
}

class FakePortionRepository implements PlanPortionRepository {
  rows: PlanPortion[] = [];
  async createMany(portions: readonly PlanPortion[]): Promise<number> {
    this.rows.push(...portions);
    return portions.length;
  }
  async findById(id: string): Promise<PlanPortion | null> {
    return this.rows.find((p) => p.id === id) ?? null;
  }
  async findByParticipation(participationId: string): Promise<PlanPortion[]> {
    return this.rows.filter((p) => p.participationId === participationId);
  }
  async findOpenByKhatm(khatmId: string, limit: number): Promise<PlanPortion[]> {
    return this.rows
      .filter((p) => p.khatmId === khatmId && p.isOpen)
      .sort((a, b) => a.sequence - b.sequence)
      .slice(0, limit);
  }
  private replace(id: string, next: PlanPortion): void {
    this.rows = this.rows.map((p) => (p.id === id ? next : p));
  }
  async assign(portionId: string, participationId: string): Promise<void> {
    const p = await this.findById(portionId);
    if (!p || !p.isOpen) throw new PortionNotInExpectedStateError();
    this.replace(portionId, p.assignTo(participationId));
  }
  async reassign(portionId: string, participationId: string): Promise<void> {
    const p = await this.findById(portionId);
    if (!p || !p.isAssigned) throw new PortionNotInExpectedStateError();
    this.replace(portionId, p.reassignTo(participationId));
  }
  async release(portionId: string): Promise<void> {
    const p = await this.findById(portionId);
    if (!p || !p.isAssigned) throw new PortionNotInExpectedStateError();
    this.replace(portionId, p.release());
  }
  async releaseAllAssignedByParticipation(
    khatmId: string,
    participationId: string,
  ): Promise<number> {
    let count = 0;
    this.rows = this.rows.map((p) => {
      if (p.khatmId === khatmId && p.participationId === participationId && p.isAssigned) {
        count += 1;
        return p.release();
      }
      return p;
    });
    return count;
  }
  async complete(portionId: string, completedAt: Date): Promise<void> {
    const p = await this.findById(portionId);
    if (!p || !p.isAssigned) throw new PortionNotInExpectedStateError();
    this.replace(portionId, p.complete(completedAt));
  }
  async progressByKhatm(khatmId: string): Promise<PortionProgress> {
    const scoped = this.rows.filter((p) => p.khatmId === khatmId);
    return {
      total: scoped.length,
      open: scoped.filter((p) => p.status === PortionStatus.OPEN).length,
      assigned: scoped.filter((p) => p.status === PortionStatus.ASSIGNED).length,
      completed: scoped.filter((p) => p.status === PortionStatus.COMPLETED).length,
    };
  }
}

class FakeStateReader implements KhatmStateReader {
  plannable = true;
  active = true;
  activeParticipations = new Set<string>();
  async canPlan(): Promise<boolean> {
    return this.plannable;
  }
  async isActive(): Promise<boolean> {
    return this.active;
  }
  async hasActiveParticipation(_khatmId: string, participationId: string): Promise<boolean> {
    return this.activeParticipations.size === 0 || this.activeParticipations.has(participationId);
  }
}

describe('AllocationService', () => {
  let service: AllocationService;
  let portions: FakePortionRepository;
  let state: FakeStateReader;
  const khatmId = '018f9a2b-0000-7000-8000-0000000000a1';
  const p1 = '018f9a2b-0000-7000-8000-0000000000b1';
  const p2 = '018f9a2b-0000-7000-8000-0000000000b2';

  beforeEach(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      providers: [
        AllocationService,
        { provide: ALLOCATION_PLAN_REPOSITORY, useClass: FakePlanRepository },
        { provide: PLAN_PORTION_REPOSITORY, useClass: FakePortionRepository },
        { provide: KHATM_STATE_READER, useClass: FakeStateReader },
        { provide: UNIT_OF_WORK, useClass: FakeUnitOfWork },
      ],
    }).compile();
    service = moduleRef.get(AllocationService);
    portions = moduleRef.get(PLAN_PORTION_REPOSITORY);
    state = moduleRef.get(KHATM_STATE_READER);
  });

  const generateQuran = () =>
    service.generatePlan(khatmId, { kind: PortionUnitKind.POSITIONAL, from: 1, to: 30 });

  it('generates a plan of non-overlapping portions and reports progress', async () => {
    const plan = await generateQuran();
    expect(plan.totalPortions).toBe(30);
    expect(plan.unitKind).toBe(PortionUnitKind.POSITIONAL);
    const units = portions.rows.map((p) => p.spec.unitStart);
    expect(new Set(units).size).toBe(30); // all distinct → non-overlapping
    expect(await service.progress(khatmId)).toEqual({ total: 30, open: 30, assigned: 0, completed: 0 });
  });

  it('refuses a second plan for the same khatm', async () => {
    await generateQuran();
    await expect(generateQuran()).rejects.toBeInstanceOf(AllocationPlanAlreadyExistsError);
  });

  it('refuses to generate a plan for a non-plannable khatm', async () => {
    state.plannable = false;
    await expect(generateQuran()).rejects.toBeInstanceOf(KhatmNotPlannableError);
  });

  it('allocates open portions to a participant and tracks progress', async () => {
    await generateQuran();
    const assigned = await service.allocateOpenPortions(khatmId, p1, 5);
    expect(assigned).toHaveLength(5);
    expect(assigned.map((p) => p.sequence)).toEqual([1, 2, 3, 4, 5]);
    expect(await service.progress(khatmId)).toEqual({ total: 30, open: 25, assigned: 5, completed: 0 });
  });

  it('never allocates the same portion twice (non-overlap under allocation)', async () => {
    await generateQuran();
    const first = await service.allocateOpenPortions(khatmId, p1, 10);
    const second = await service.allocateOpenPortions(khatmId, p2, 10);
    const firstIds = new Set(first.map((p) => p.id));
    expect(second.some((p) => firstIds.has(p.id))).toBe(false);
    expect(await service.progress(khatmId)).toEqual({ total: 30, open: 10, assigned: 20, completed: 0 });
  });

  it('refuses allocation when the khatm is not active or the participation is inactive', async () => {
    await generateQuran();
    state.active = false;
    await expect(service.allocateOpenPortions(khatmId, p1, 1)).rejects.toBeInstanceOf(
      KhatmNotAllocatableError,
    );
    state.active = true;
    state.activeParticipations = new Set([p1]);
    await expect(service.allocateOpenPortions(khatmId, p2, 1)).rejects.toBeInstanceOf(
      ParticipationNotAllocatableError,
    );
  });

  it('reallocates: releasing a participant returns their portions to the pool for others', async () => {
    await generateQuran();
    const assigned = await service.allocateOpenPortions(khatmId, p1, 6);
    const released = await service.releaseParticipation(khatmId, p1);
    expect(released).toBe(6);
    expect(await service.progress(khatmId)).toEqual({ total: 30, open: 30, assigned: 0, completed: 0 });

    // The released portions can now go to another participant.
    const reAssigned = await service.allocateOpenPortions(khatmId, p2, 6);
    expect(reAssigned).toHaveLength(6);
    const firstId = assigned[0]?.id;
    expect(reAssigned.some((p) => p.id === firstId)).toBe(true);
  });

  it('completes an assigned portion and reflects it in progress', async () => {
    await generateQuran();
    const [portion] = await service.allocateOpenPortions(khatmId, p1, 1);
    await service.completePortion(portion?.id as string);
    expect(await service.progress(khatmId)).toEqual({ total: 30, open: 29, assigned: 0, completed: 1 });
  });

  it('reassigns an assigned portion to another participant', async () => {
    await generateQuran();
    const [portion] = await service.allocateOpenPortions(khatmId, p1, 1);
    await service.reassignPortion(portion?.id as string, p2);
    const after = await portions.findById(portion?.id as string);
    expect(after?.participationId).toBe(p2);
  });

  describe('completeHeldPortion (holder-checked)', () => {
    it('lets the assigned holder complete their portion', async () => {
      await generateQuran();
      const [portion] = await service.allocateOpenPortions(khatmId, p1, 1);
      await service.completeHeldPortion(portion?.id as string, p1);
      const after = await portions.findById(portion?.id as string);
      expect(after?.isCompleted).toBe(true);
    });

    it('rejects completion by anyone other than the holder', async () => {
      await generateQuran();
      const [portion] = await service.allocateOpenPortions(khatmId, p1, 1);
      await expect(service.completeHeldPortion(portion?.id as string, p2)).rejects.toBeInstanceOf(
        PortionNotHeldByParticipationError,
      );
      const after = await portions.findById(portion?.id as string);
      expect(after?.isAssigned).toBe(true); // untouched
    });

    it('cannot complete the same portion twice', async () => {
      await generateQuran();
      const [portion] = await service.allocateOpenPortions(khatmId, p1, 1);
      await service.completeHeldPortion(portion?.id as string, p1);
      await expect(service.completeHeldPortion(portion?.id as string, p1)).rejects.toBeInstanceOf(
        PortionNotInExpectedStateError,
      );
    });
  });
});
