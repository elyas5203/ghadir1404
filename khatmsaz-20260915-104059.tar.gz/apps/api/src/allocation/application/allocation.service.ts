import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, isUuidV7, assertUuidV7, UNIT_OF_WORK } from '@khatmsaz/kernel';
import type { UnitOfWork, TransactionContext } from '@khatmsaz/kernel';
import { AllocationPlan } from '../domain/allocation-plan';
import { PlanPortion } from '../domain/plan-portion';
import { generatePortions } from '../domain/plan-spec';
import type { PlanSpec } from '../domain/plan-spec';
import {
  KhatmNotAllocatableError,
  KhatmNotPlannableError,
  ParticipationNotAllocatableError,
  PortionNotFoundError,
  PortionNotHeldByParticipationError,
} from '../domain/allocation.errors';
import { ALLOCATION_PLAN_REPOSITORY } from '../domain/allocation-plan.repository';
import type { AllocationPlanRepository } from '../domain/allocation-plan.repository';
import { PLAN_PORTION_REPOSITORY } from '../domain/plan-portion.repository';
import type { PlanPortionRepository, PortionProgress } from '../domain/plan-portion.repository';
import { KHATM_STATE_READER } from '../domain/khatm-state.reader';
import type { KhatmStateReader } from '../domain/khatm-state.reader';

/**
 * The Khatm ALLOCATION ENGINE use-cases (Phase 4.1, DEC-0052). Application code:
 * it orchestrates the generic portion generator, the domain lifecycle rules, and
 * the persistence ports, and is entirely Prisma-free (DEC-0031).
 *
 * Multi-row operations — generating a whole plan, allocating a batch of portions,
 * releasing a participant's portions — run inside {@link UnitOfWork} so they commit
 * or roll back together (DEC-0044); the guarding state checks read through the same
 * transaction. It leaves Phase 4 unmodified and reaches khatm/participation state
 * only through the {@link KhatmStateReader} read port.
 */
@Injectable()
export class AllocationService {
  constructor(
    @Inject(ALLOCATION_PLAN_REPOSITORY) private readonly plans: AllocationPlanRepository,
    @Inject(PLAN_PORTION_REPOSITORY) private readonly portions: PlanPortionRepository,
    @Inject(KHATM_STATE_READER) private readonly khatmState: KhatmStateReader,
    @Inject(UNIT_OF_WORK) private readonly uow: UnitOfWork,
  ) {}

  /**
   * Generate the khatm's allocation plan from a spec: create the plan and all its
   * (non-overlapping) OPEN portions atomically. Rejects a terminal/missing khatm
   * and a second plan for the same khatm.
   */
  async generatePlan(khatmId: string, spec: PlanSpec): Promise<AllocationPlan> {
    assertUuidV7(khatmId, 'khatmId');
    const specs = generatePortions(spec); // validates the spec; throws on incoherence
    const unitKind = AllocationPlan.unitKindOf(spec);

    return this.uow.run(async (tx) => {
      if (!(await this.khatmState.canPlan(khatmId, tx))) {
        throw new KhatmNotPlannableError();
      }
      const plan = await this.plans.create(
        AllocationPlan.create({
          id: newUuidV7(),
          khatmId,
          unitKind,
          totalPortions: specs.length,
        }),
        tx,
      );
      const portions = specs.map((portionSpec, index) =>
        PlanPortion.create({
          id: newUuidV7(),
          planId: plan.id,
          khatmId,
          sequence: index + 1,
          spec: portionSpec,
        }),
      );
      await this.portions.createMany(portions, tx);
      return plan;
    });
  }

  /** The khatm's allocation plan, or `null` when none has been generated. */
  async findPlan(khatmId: string): Promise<AllocationPlan | null> {
    if (!isUuidV7(khatmId)) return null;
    return this.plans.findByKhatmId(khatmId);
  }

  /**
   * Allocate up to `count` OPEN portions of a khatm to an active participation, in
   * `sequence` order, atomically. Returns the portions actually assigned (possibly
   * fewer than requested when the pool runs out). Non-overlap holds because each
   * portion is assigned at most once.
   */
  async allocateOpenPortions(
    khatmId: string,
    participationId: string,
    count: number,
  ): Promise<PlanPortion[]> {
    assertUuidV7(khatmId, 'khatmId');
    assertUuidV7(participationId, 'participationId');
    if (!Number.isInteger(count) || count < 1) return [];

    return this.uow.run(async (tx) => {
      await this.assertAllocatable(khatmId, participationId, tx);
      const open = await this.portions.findOpenByKhatm(khatmId, count, tx);
      const assigned: PlanPortion[] = [];
      for (const portion of open) {
        await this.portions.assign(portion.id, participationId, tx);
        assigned.push(portion.assignTo(participationId));
      }
      return assigned;
    });
  }

  /** Allocate one specific OPEN portion to an active participation. */
  async allocatePortion(portionId: string, participationId: string): Promise<void> {
    assertUuidV7(portionId, 'portionId');
    assertUuidV7(participationId, 'participationId');
    await this.uow.run(async (tx) => {
      const portion = await this.requirePortion(portionId, tx);
      await this.assertAllocatable(portion.khatmId, participationId, tx);
      await this.portions.assign(portionId, participationId, tx);
    });
  }

  /**
   * Reallocation: return every ASSIGNED portion a participation holds in a khatm to
   * the OPEN pool, atomically. Returns the number released. Called when a
   * participant leaves/is removed; COMPLETED portions are untouched.
   */
  async releaseParticipation(khatmId: string, participationId: string): Promise<number> {
    assertUuidV7(khatmId, 'khatmId');
    assertUuidV7(participationId, 'participationId');
    return this.uow.run((tx) =>
      this.portions.releaseAllAssignedByParticipation(khatmId, participationId, tx),
    );
  }

  /** Move one ASSIGNED portion to a different active participation. */
  async reassignPortion(portionId: string, toParticipationId: string): Promise<void> {
    assertUuidV7(portionId, 'portionId');
    assertUuidV7(toParticipationId, 'toParticipationId');
    await this.uow.run(async (tx) => {
      const portion = await this.requirePortion(portionId, tx);
      await this.assertAllocatable(portion.khatmId, toParticipationId, tx);
      await this.portions.reassign(portionId, toParticipationId, tx);
    });
  }

  /** Mark an ASSIGNED portion COMPLETED, stamped now. */
  async completePortion(portionId: string): Promise<void> {
    assertUuidV7(portionId, 'portionId');
    await this.portions.complete(portionId, new Date());
  }

  /**
   * Mark a portion COMPLETED, but only when `participationId` is its assigned
   * holder — the actor completing their own assigned portion. Throws
   * {@link PortionNotHeldByParticipationError} for anyone else, and (via the guarded
   * complete) {@link import('../domain/allocation.errors').PortionNotInExpectedStateError}
   * if it is not ASSIGNED (e.g. already completed — it cannot be completed twice).
   */
  async completeHeldPortion(portionId: string, participationId: string): Promise<void> {
    assertUuidV7(portionId, 'portionId');
    assertUuidV7(participationId, 'participationId');
    await this.uow.run(async (tx) => {
      const portion = await this.requirePortion(portionId, tx);
      if (portion.participationId !== participationId) {
        throw new PortionNotHeldByParticipationError();
      }
      await this.portions.complete(portionId, new Date(), tx);
    });
  }

  /** Derive the khatm's allocation progress (counts by portion status). */
  async progress(khatmId: string): Promise<PortionProgress> {
    assertUuidV7(khatmId, 'khatmId');
    return this.portions.progressByKhatm(khatmId);
  }

  /** The portions currently held by a participation (a participant's assigned work). */
  async listPortionsForParticipation(participationId: string): Promise<PlanPortion[]> {
    assertUuidV7(participationId, 'participationId');
    return this.portions.findByParticipation(participationId);
  }

  private async assertAllocatable(
    khatmId: string,
    participationId: string,
    tx: TransactionContext,
  ): Promise<void> {
    if (!(await this.khatmState.isActive(khatmId, tx))) {
      throw new KhatmNotAllocatableError();
    }
    if (!(await this.khatmState.hasActiveParticipation(khatmId, participationId, tx))) {
      throw new ParticipationNotAllocatableError();
    }
  }

  private async requirePortion(portionId: string, tx: TransactionContext): Promise<PlanPortion> {
    const portion = await this.portions.findById(portionId, tx);
    if (!portion) throw new PortionNotFoundError();
    return portion;
  }
}
