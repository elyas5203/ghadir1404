import { BaleCommandService } from './bale-command.service';
import type { IdentityService } from '../../identity/application/identity.service';
import type { KhatmWorkflowService } from '../../khatm-workflow/application/khatm-workflow.service';
import type { KhatmService } from '../../khatm/application/khatm.service';
import type { InvitationService } from '../../invitation/application/invitation.service';
import type { WalletService } from '../../payment/application/wallet.service';
import type { UserSettingsService } from '../../user-settings/application/user-settings.service';
import type { PhoneAuthService } from '../../session/application/phone-auth.service';
import type { BotUserResolverService } from '../../bot-shared/bot-user-resolver.service';
import type { TelegramUpdate } from '../../telegram/domain/telegram-message';

const FROM = '998877';
const update = (text: string): TelegramUpdate => ({ chatId: 'c2', fromId: FROM, text });

function make(overrides: {
  identity?: Partial<IdentityService>;
  workflow?: Partial<KhatmWorkflowService>;
  khatms?: Partial<KhatmService>;
  invitations?: Partial<InvitationService>;
  wallet?: Partial<WalletService>;
  settings?: Partial<UserSettingsService>;
  phoneAuth?: Partial<PhoneAuthService>;
  botResolver?: Partial<BotUserResolverService>;
}): { service: BaleCommandService; calls: Record<string, unknown[]> } {
  const calls: Record<string, unknown[]> = {};
  const record = (name: string, value?: unknown) => {
    calls[name] = (calls[name] ?? []).concat([value]);
  };

  const identity = {
    findUserByPlatformIdentity: async () => ({ id: 'u1', isActive: true }),
    createUser: async () => {
      record('createUser');
      return { id: 'u-new', isActive: true };
    },
    attachPlatformIdentity: async (userId: unknown, platform: unknown, subject: unknown) =>
      record('attach', { userId, platform, subject }),
    ...overrides.identity,
  } as unknown as IdentityService;

  const workflow = {
    createKhatm: async (input: unknown) => {
      record('createKhatm', input);
      return { id: 'k1', title: (input as { title: string }).title, khatmType: 'COMMITMENT' } as never;
    },
    generateAllocationPlan: async () => ({} as never),
    activateKhatm: async () => undefined,
    progress: async () => ({ total: 30, open: 20, assigned: 5, completed: 5 }),
    listMyKhatms: async () => [],
    listMyPortions: async () => [],
    leaveKhatm: async () => undefined,
    completeAllMyPortions: async () => 0,
    allocatePortions: async () => [],
    ...overrides.workflow,
  } as unknown as KhatmWorkflowService;

  const khatms = {
    listKhatmsByCreator: async () => [],
    findKhatmById: async () => ({ id: 'k1', khatmType: 'COMMITMENT', creatorUserId: 'u1' } as never),
    ...overrides.khatms,
  } as unknown as KhatmService;

  const invitations = {
    acceptInvitation: async (token: unknown, userId: unknown) => {
      record('acceptInvitation', { token, userId });
      return { khatmId: 'k1', participationId: 'p1' };
    },
    createInvitation: async () => ({ invitation: {} as never, token: 'invite-tok' }),
    ...overrides.invitations,
  } as unknown as InvitationService;

  const wallet = {
    getBalance: async () => ({ userId: 'u1', balance: 0, credit: 0, currency: 'IRR' }),
    ...overrides.wallet,
  } as unknown as WalletService;

  const settings = {
    getSettings: async () => ({
      userId: 'u1',
      reminderHour: 9,
      reminderMinute: 0,
      timezone: 'Asia/Tehran',
      fontSize: 'NORMAL',
      preferredReciter: null,
      smsEnabled: false,
      city: null,
      province: null,
      gender: null,
      language: 'fa',
    }),
    updateSettings: async () => ({} as never),
    ...overrides.settings,
  } as unknown as UserSettingsService;

  const phoneAuth = overrides.phoneAuth
    ? ({
        requestLogin: async (phone: string) => { record('requestLogin', phone); return { e164: phone }; },
        linkByPhoneOtp: async (phone: string, code: string) => { record('linkByPhoneOtp', { phone, code }); return 'u-linked'; },
        ...overrides.phoneAuth,
      } as unknown as PhoneAuthService)
    : undefined;

  const botResolver = overrides.botResolver
    ? ({
        linkUser: async (userId: string, platform: unknown, chatId: unknown) => { record('linkUser', { userId, platform, chatId }); },
        ...overrides.botResolver,
      } as unknown as BotUserResolverService)
    : undefined;

  return {
    service: new BaleCommandService(
      identity, workflow, khatms, invitations, wallet, settings,
      undefined, undefined, undefined, undefined,
      phoneAuth, botResolver,
    ),
    calls,
  };
}

describe('BaleCommandService — OTP account linking', () => {
  const unlinked = { identity: { findUserByPlatformIdentity: async () => null } };

  it('returns main menu when user is already linked (no OTP wizard)', async () => {
    const { service } = make({ phoneAuth: {} });
    const r = await service.handle(update('/start'));
    expect(r.text).toContain('خوش آمدید');
    expect(r.replyKeyboard).toBeDefined();
  });

  it('prompts for phone when not linked and phoneAuth is wired', async () => {
    const { service } = make({ ...unlinked, phoneAuth: {}, botResolver: {} });
    const r = await service.handle(update('/start'));
    expect(r.text).toContain('موبایل');
  });

  it('rejects an invalid phone format at link:phone step', async () => {
    const { service, calls } = make({ ...unlinked, phoneAuth: {}, botResolver: {} });
    await service.handle(update('/start'));
    const r = await service.handle(update('09000'));
    expect(r.text).toContain('معتبر');
    expect(calls['requestLogin']).toBeUndefined();
  });

  it('calls requestLogin and advances to link:otp on valid phone', async () => {
    const { service, calls } = make({ ...unlinked, phoneAuth: {}, botResolver: {} });
    await service.handle(update('/start'));
    const r = await service.handle(update('09123456789'));
    expect(calls['requestLogin']).toHaveLength(1);
    expect(calls['requestLogin']![0]).toBe('09123456789');
    expect(r.text).toContain('کد');
  });

  it('links user and returns main menu on valid OTP (uses Platform.BALE)', async () => {
    const { service, calls } = make({ ...unlinked, phoneAuth: {}, botResolver: {} });
    await service.handle(update('/start'));
    await service.handle(update('09123456789'));
    const r = await service.handle(update('123456'));
    expect(calls['linkByPhoneOtp']![0]).toMatchObject({ phone: '09123456789', code: '123456' });
    expect(calls['linkUser']![0]).toMatchObject({ userId: 'u-linked', platform: 'BALE', chatId: FROM });
    expect(r.text).toContain('متصل شد');
    expect(r.replyKeyboard).toBeDefined();
  });

  it('rejects non-digit text at link:otp step', async () => {
    const { service, calls } = make({ ...unlinked, phoneAuth: {}, botResolver: {} });
    await service.handle(update('/start'));
    await service.handle(update('09123456789'));
    const r = await service.handle(update('abcde'));
    expect(r.text).toContain('رقم');
    expect(calls['linkByPhoneOtp']).toBeUndefined();
  });

  it('increments failCount on wrong OTP and stays link:otp', async () => {
    const { service } = make({
      ...unlinked,
      phoneAuth: {
        linkByPhoneOtp: async () => { const e = Object.assign(new Error(), { name: 'InvalidOtpError' }); throw e; },
      },
      botResolver: {},
    });
    await service.handle(update('/start'));
    await service.handle(update('09123456789'));
    const r = await service.handle(update('000000'));
    expect(r.text).toContain('باقی‌مانده');
  });

  it('clears state and requests restart after 3 wrong OTP attempts', async () => {
    const { service } = make({
      ...unlinked,
      phoneAuth: {
        linkByPhoneOtp: async () => { const e = Object.assign(new Error(), { name: 'InvalidOtpError' }); throw e; },
      },
      botResolver: {},
    });
    await service.handle(update('/start'));
    await service.handle(update('09123456789'));
    await service.handle(update('000000')); // fail 1
    await service.handle(update('000000')); // fail 2
    const r = await service.handle(update('000000')); // fail 3 → clear
    expect(r.text).toContain('/start');
  });

  it('accepts invitation token at join:token step', async () => {
    const { service, calls } = make({});
    await service.handle(update('/join'));
    const r = await service.handle(update('tok-abc'));
    expect(calls['acceptInvitation']![0]).toMatchObject({ token: 'tok-abc', userId: 'u1' });
    expect(r.text).toContain('k1');
  });

  it('returns pleaseStart for /join when user is not linked', async () => {
    const { service } = make({ ...unlinked });
    const r = await service.handle(update('/join tok'));
    expect(r.text).toContain('/start');
  });
});
