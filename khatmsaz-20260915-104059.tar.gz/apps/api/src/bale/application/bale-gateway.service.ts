import { Inject, Injectable } from '@nestjs/common';
import { BaleCommandService } from './bale-command.service';
import { BALE_SENDER } from '../domain/bale-sender';
import type { BaleSender } from '../domain/bale-sender';
import type { TelegramCallbackQuery, TelegramReply, TelegramUpdate } from '../../telegram/domain/telegram-message';

/**
 * Bale channel gateway (Sprint Phase 04).
 * Mirrors TelegramGateway: dispatches commands and delivers replies via BaleSender.
 */
@Injectable()
export class BaleGateway {
  constructor(
    private readonly commands: BaleCommandService,
    @Inject(BALE_SENDER) private readonly sender: BaleSender,
  ) {}

  async dispatch(update: TelegramUpdate): Promise<TelegramReply> {
    const reply = await this.commands.handle(update);
    await this.sender.send(update.chatId, reply);
    return reply;
  }

  async dispatchCallback(query: TelegramCallbackQuery): Promise<void> {
    const reply = await this.commands.handleCallback(query);
    await this.sender.answerCallbackQuery(query.callbackQueryId, reply.toast);
    if (reply.text) {
      await this.sender.send(query.chatId, {
        text: reply.text,
        inlineKeyboard: reply.inlineKeyboard,
        replyKeyboard: reply.replyKeyboard,
      });
    }
  }
}
