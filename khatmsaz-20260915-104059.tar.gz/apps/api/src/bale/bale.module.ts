import { Module } from '@nestjs/common';
import { baleConfig, baleOutboundEnabled, redisConfig, redisEnabled } from '@khatmsaz/config';
import { IdentityModule } from '../identity/identity.module';
import { KhatmModule } from '../khatm/khatm.module';
import { KhatmWorkflowModule } from '../khatm-workflow/khatm-workflow.module';
import { InvitationModule } from '../invitation/invitation.module';
import { PaymentModule } from '../payment/payment.module';
import { UserSettingsModule } from '../user-settings/user-settings.module';
import { NotificationModule } from '../notification/notification.module';
import { BotSharedModule } from '../bot-shared/bot-shared.module';
import { BaleCommandService } from './application/bale-command.service';
import { BaleGateway } from './application/bale-gateway.service';
import { WIZARD_STATE, InMemoryWizardStateStore, RedisWizardStateStore } from '../telegram/application/wizard-state.service';
import { BALE_SENDER } from './domain/bale-sender';
import { NoopBaleSender } from './infrastructure/noop-bale-sender';
import { BotApiBaleSender } from './infrastructure/bot-api-bale-sender';
import { BaleWebhookController } from './infrastructure/bale-webhook.controller';
import { BALE_CONFIG } from './infrastructure/bale-config.tokens';

/**
 * Bale channel adapter module (Sprint Phase 04).
 * Mirrors TelegramModule: config-gated real sender / no-op fallback.
 * Webhook disabled unless BALE_WEBHOOK_SECRET is set.
 */
@Module({
  imports: [IdentityModule, KhatmModule, KhatmWorkflowModule, InvitationModule, PaymentModule, UserSettingsModule, NotificationModule, BotSharedModule],
  controllers: [BaleWebhookController],
  providers: [
    BaleCommandService,
    BaleGateway,
    { provide: BALE_CONFIG, useFactory: baleConfig },
    {
      provide: BALE_SENDER,
      inject: [BALE_CONFIG],
      useFactory: (config: ReturnType<typeof baleConfig>) =>
        baleOutboundEnabled(config) ? new BotApiBaleSender(config) : new NoopBaleSender(),
    },
    {
      provide: WIZARD_STATE,
      useFactory: () => {
        const cfg = redisConfig();
        return redisEnabled(cfg)
          ? new RedisWizardStateStore('bale', cfg.url)
          : new InMemoryWizardStateStore();
      },
    },
  ],
  exports: [BaleCommandService, BaleGateway],
})
export class BaleModule {}
