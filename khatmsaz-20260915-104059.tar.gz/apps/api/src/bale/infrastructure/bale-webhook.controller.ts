import {
  Body,
  Controller,
  ForbiddenException,
  Headers,
  HttpCode,
  Inject,
  Logger,
  Post,
} from '@nestjs/common';
import { timingSafeEqual } from 'node:crypto';
import { BaleGateway } from '../application/bale-gateway.service';
import { toTelegramUpdate, isCallbackQuery } from '../../telegram/infrastructure/telegram-update.mapper';
import { BALE_CONFIG } from './bale-config.tokens';
import type { BaleConfig } from '@khatmsaz/config';

const SECRET_HEADER = 'x-bale-bot-api-secret-token';

/**
 * Inbound Bale webhook (Sprint Phase 04). Mirrors TelegramWebhookController.
 * Bale Bot API sends updates in the same shape as Telegram.
 */
@Controller('bale')
export class BaleWebhookController {
  private readonly logger = new Logger('BaleWebhook');

  constructor(
    private readonly gateway: BaleGateway,
    @Inject(BALE_CONFIG) private readonly config: BaleConfig,
  ) {}

  @Post('webhook')
  @HttpCode(200)
  async receive(
    @Headers(SECRET_HEADER) presentedSecret: string | undefined,
    @Body() body: unknown,
  ): Promise<{ ok: true }> {
    this.assertSecret(presentedSecret);

    const update = toTelegramUpdate(body);
    if (update === null) return { ok: true };

    try {
      if (isCallbackQuery(update)) {
        await this.gateway.dispatchCallback(update);
      } else {
        await this.gateway.dispatch(update);
      }
    } catch {
      this.logger.warn('Failed to process a Bale update.');
    }
    return { ok: true };
  }

  private assertSecret(presented: string | undefined): void {
    const expected = this.config.webhookSecret;
    if (expected.length === 0 || typeof presented !== 'string') {
      throw new ForbiddenException('Bale webhook is not available.');
    }
    const a = Buffer.from(presented);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      throw new ForbiddenException('Bale webhook is not available.');
    }
  }
}
