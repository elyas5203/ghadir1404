export const BALE_CONFIG = Symbol('BALE_CONFIG');
