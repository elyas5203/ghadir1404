import { Injectable, Logger } from '@nestjs/common';
import type { BaleConfig } from '@khatmsaz/config';
import type { BaleSender } from '../domain/bale-sender';
import type { TelegramReply } from '../../telegram/domain/telegram-message';

/**
 * Real outbound BaleSender over the Bale Bot API (Sprint Phase 04).
 * Bale Bot API is structurally identical to Telegram's; only the base URL differs.
 * No SDK — plain fetch, token never logged.
 */
@Injectable()
export class BotApiBaleSender implements BaleSender {
  private readonly logger = new Logger('BaleSender');

  constructor(private readonly config: BaleConfig) {}

  async send(chatId: string, reply: TelegramReply): Promise<void> {
    const url = `${this.config.apiBaseUrl}/bot${this.config.botToken}/sendMessage`;
    const body: Record<string, unknown> = { chat_id: chatId, text: reply.text };
    if (reply.removeKeyboard) {
      body['reply_markup'] = { remove_keyboard: true };
    } else if (reply.replyKeyboard?.length) {
      body['reply_markup'] = {
        keyboard: reply.replyKeyboard.map((row) => row.map((btn) => ({ text: btn.text }))),
        resize_keyboard: true,
        one_time_keyboard: false,
        is_persistent: true,
      };
    } else if (reply.inlineKeyboard?.length) {
      body['reply_markup'] = {
        inline_keyboard: reply.inlineKeyboard.map((row) =>
          row.map((btn) => ({ text: btn.text, callback_data: btn.callbackData })),
        ),
      };
    }
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) this.logger.warn(`Bale sendMessage failed: ${res.status}`);
    } catch {
      this.logger.warn('Bale sendMessage network error.');
    }
  }

  async answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
    const url = `${this.config.apiBaseUrl}/bot${this.config.botToken}/answerCallbackQuery`;
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callback_query_id: callbackQueryId, ...(text ? { text } : {}) }),
      });
      if (!res.ok) this.logger.warn(`Bale answerCallbackQuery failed: ${res.status}`);
    } catch {
      this.logger.warn('Bale answerCallbackQuery network error.');
    }
  }
}
