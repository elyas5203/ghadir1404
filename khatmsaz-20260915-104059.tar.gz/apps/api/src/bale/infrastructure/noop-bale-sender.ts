import { Injectable, Logger } from '@nestjs/common';
import type { BaleSender } from '../domain/bale-sender';

/** No-op BaleSender when BALE_BOT_TOKEN is not configured. Mirrors NoopTelegramSender. */
@Injectable()
export class NoopBaleSender implements BaleSender {
  private readonly logger = new Logger('BaleSender');

  async send(): Promise<void> {
    this.logger.debug('Bale reply prepared (no provider configured; not sent).');
  }

  async answerCallbackQuery(): Promise<void> {
    this.logger.debug('Bale callback acknowledged (no provider configured; not sent).');
  }
}
