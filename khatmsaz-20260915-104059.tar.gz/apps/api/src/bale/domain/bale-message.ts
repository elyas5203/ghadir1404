/**
 * Vendor-neutral Bale message shapes (Sprint Phase 04).
 * Bale Bot API is structurally identical to Telegram Bot API,
 * so we reuse the same shapes.
 */
export type {
  TelegramUpdate as BaleUpdate,
  TelegramCallbackQuery as BaleCallbackQuery,
  TelegramReply as BaleReply,
  CallbackReply as BaleCallbackReply,
  InlineKeyboardButton,
} from '../../telegram/domain/telegram-message';
