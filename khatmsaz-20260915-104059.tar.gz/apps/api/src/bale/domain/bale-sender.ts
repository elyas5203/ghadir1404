/**
 * BaleSender — outbound adapter port for the Bale channel (Sprint Phase 04).
 * Mirrors TelegramSender; same interface, different platform.
 */

import type { TelegramReply } from '../../telegram/domain/telegram-message';

export const BALE_SENDER = Symbol('BALE_SENDER');

export interface BaleSender {
  send(chatId: string, reply: TelegramReply): Promise<void>;
  answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void>;
}
