import { Inject, Injectable } from '@nestjs/common';
import { newIdentityId, isUuidV7, assertUuidV7 } from '../domain/identity-id';
import { isPlatform } from '../domain/platform';
import type { Platform } from '../domain/platform';
import { requireSubject } from '../domain/platform-identity';
import type { PlatformIdentity } from '../domain/platform-identity';
import type { User, UserRole } from '../domain/user';
import type { UserStatus } from '../domain/user-status';
import { UnknownPlatformError } from '../domain/identity.errors';
import { USER_REPOSITORY } from '../domain/user.repository';
import type { UserRepository } from '../domain/user.repository';
import { PLATFORM_IDENTITY_REPOSITORY } from '../domain/platform-identity.repository';
import type { PlatformIdentityRepository } from '../domain/platform-identity.repository';

/**
 * Identity use-cases. This is application code: it orchestrates domain rules and
 * the persistence ports, and is entirely Prisma-free. Only the operations this
 * phase requires exist here.
 *
 * Lookups are lenient (invalid input → `null`); commands are strict (invalid
 * input throws a domain error). Uniqueness of a platform identity is guaranteed
 * by the database constraint, surfaced as a domain error — never by a pre-check
 * alone.
 */
@Injectable()
export class IdentityService {
  constructor(
    @Inject(USER_REPOSITORY) private readonly users: UserRepository,
    @Inject(PLATFORM_IDENTITY_REPOSITORY)
    private readonly platformIdentities: PlatformIdentityRepository,
  ) {}

  /** Create a new canonical user with an application-generated UUIDv7 id. */
  async createUser(): Promise<User> {
    return this.users.create(newIdentityId());
  }

  /** Find a user by canonical id. An id that is not a UUIDv7 yields `null`. */
  async findUserById(id: string): Promise<User | null> {
    if (!isUuidV7(id)) return null;
    return this.users.findById(id);
  }

  /**
   * Find the user that owns a given external platform identity. Unknown platform
   * or empty subject yields `null` rather than throwing — this is a lookup.
   */
  async findUserByPlatformIdentity(platform: Platform, subject: string): Promise<User | null> {
    if (!isPlatform(platform)) return null;
    const cleaned = typeof subject === 'string' ? subject.trim() : '';
    if (cleaned.length === 0) return null;

    const link = await this.platformIdentities.findByPlatformSubject(platform, cleaned);
    if (!link) return null;
    return this.users.findById(link.userId);
  }

  /**
   * Set or clear the user's display name. The trimmed value is stored; an empty
   * or absent value stores null. Validates the userId is a valid UUIDv7.
   */
  async setDisplayName(userId: string, displayName: string | null): Promise<User> {
    assertUuidV7(userId, 'userId');
    const trimmed = displayName?.trim() ?? null;
    return this.users.updateDisplayName(userId, trimmed && trimmed.length > 0 ? trimmed : null);
  }

  /**
   * Attach an external platform identity to a user. Validates inputs, then
   * inserts; the database's (platform, subject) unique constraint and the user
   * foreign key make concurrent/duplicate attaches fail with a domain error.
   */
  async attachPlatformIdentity(
    userId: string,
    platform: Platform,
    subject: string,
  ): Promise<PlatformIdentity> {
    assertUuidV7(userId, 'userId');
    if (!isPlatform(platform)) throw new UnknownPlatformError();
    const cleanedSubject = requireSubject(subject);

    return this.platformIdentities.attach({
      id: newIdentityId(),
      userId,
      platform,
      subject: cleanedSubject,
    });
  }

  /** List all users (admin use only). */
  async listAllUsers(limit = 50, offset = 0): Promise<User[]> {
    return this.users.listAll(limit, offset);
  }

  /** Total user count (admin use only). */
  async countAllUsers(): Promise<number> {
    return this.users.countAll();
  }

  /** Search users by display name or partial id (admin use only). */
  async searchUsers(query: string, limit = 50, offset = 0): Promise<User[]> {
    if (!query.trim()) return this.users.listAll(limit, offset);
    return this.users.search(query.trim(), limit, offset);
  }

  /** Update a user's moderation status (admin use only). */
  async updateUserStatus(userId: string, status: UserStatus): Promise<User> {
    assertUuidV7(userId, 'userId');
    return this.users.updateStatus(userId, status);
  }

  /** Update a user's platform role (admin use only). */
  async updateUserRole(userId: string, role: UserRole): Promise<User> {
    assertUuidV7(userId, 'userId');
    return this.users.updateRole(userId, role);
  }
}
