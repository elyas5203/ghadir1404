import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { IdentityService } from './identity.service';
import { isUuidV7 } from '../domain/identity-id';
import { Platform } from '../domain/platform';
import { User } from '../domain/user';
import { PlatformIdentity } from '../domain/platform-identity';
import {
  InvalidIdentityIdError,
  InvalidPlatformSubjectError,
  PlatformIdentityAlreadyLinkedError,
  UnknownPlatformError,
} from '../domain/identity.errors';
import { USER_REPOSITORY } from '../domain/user.repository';
import type { UserRepository } from '../domain/user.repository';
import { PLATFORM_IDENTITY_REPOSITORY } from '../domain/platform-identity.repository';
import type {
  AttachPlatformIdentityInput,
  PlatformIdentityRepository,
} from '../domain/platform-identity.repository';

/** In-memory UserRepository. */
class FakeUserRepository implements UserRepository {
  readonly users = new Map<string, User>();
  async create(id: string): Promise<User> {
    const now = new Date();
    const user = User.restore({ id, createdAt: now, updatedAt: now });
    this.users.set(id, user);
    return user;
  }
  async findById(id: string): Promise<User | null> {
    return this.users.get(id) ?? null;
  }
  async tombstone(): Promise<void> {
    throw new Error('not implemented in this fake');
  }
  async updateDisplayName(userId: string, displayName: string | null): Promise<User> {
    const existing = this.users.get(userId);
    if (!existing) throw new Error('user not found');
    const updated = User.restore({ ...existing, displayName });
    this.users.set(userId, updated);
    return updated;
  }
  async listAll(limit: number, offset: number): Promise<User[]> {
    return [...this.users.values()].slice(offset, offset + limit);
  }
  async countAll(): Promise<number> { return this.users.size; }
  async search(): Promise<User[]> { return []; }
  async updateStatus(): Promise<User> { throw new Error('not implemented in this fake'); }
  async updateRole(): Promise<User> { throw new Error('not implemented in this fake'); }
}

/** In-memory PlatformIdentityRepository that emulates the (platform, subject) unique constraint. */
class FakePlatformIdentityRepository implements PlatformIdentityRepository {
  readonly links: PlatformIdentity[] = [];
  async findByPlatformSubject(
    platform: Platform,
    subject: string,
  ): Promise<PlatformIdentity | null> {
    return (
      this.links.find((l) => l.platform === platform && l.subject === subject) ?? null
    );
  }
  async attach(input: AttachPlatformIdentityInput): Promise<PlatformIdentity> {
    if (this.links.some((l) => l.platform === input.platform && l.subject === input.subject)) {
      throw new PlatformIdentityAlreadyLinkedError(input.platform);
    }
    const now = new Date();
    const link = PlatformIdentity.restore({ ...input, createdAt: now, updatedAt: now });
    this.links.push(link);
    return link;
  }
  async reassignOwner(): Promise<number> {
    // Not exercised by IdentityService tests (merge lives in its own capability).
    throw new Error('not implemented in this fake');
  }
}

describe('IdentityService', () => {
  let service: IdentityService;
  let users: FakeUserRepository;
  let platformIdentities: FakePlatformIdentityRepository;

  beforeEach(async () => {
    users = new FakeUserRepository();
    platformIdentities = new FakePlatformIdentityRepository();
    const moduleRef: TestingModule = await Test.createTestingModule({
      providers: [
        IdentityService,
        { provide: USER_REPOSITORY, useValue: users },
        { provide: PLATFORM_IDENTITY_REPOSITORY, useValue: platformIdentities },
      ],
    }).compile();
    service = moduleRef.get(IdentityService);
  });

  describe('createUser', () => {
    it('creates a user with an application-generated UUIDv7 id', async () => {
      const user = await service.createUser();
      expect(isUuidV7(user.id)).toBe(true);
      expect(await users.findById(user.id)).not.toBeNull();
    });
  });

  describe('findUserById', () => {
    it('returns the user when it exists', async () => {
      const created = await service.createUser();
      expect((await service.findUserById(created.id))?.id).toBe(created.id);
    });
    it('returns null for a non-UUIDv7 id without hitting the repository', async () => {
      expect(await service.findUserById('not-a-uuid')).toBeNull();
    });
    it('returns null for an unknown user', async () => {
      const other = await service.createUser();
      users.users.delete(other.id);
      expect(await service.findUserById(other.id)).toBeNull();
    });
  });

  describe('attachPlatformIdentity', () => {
    it('attaches a link and finds the user by platform identity', async () => {
      const user = await service.createUser();
      const link = await service.attachPlatformIdentity(user.id, Platform.TELEGRAM, ' 987654321 ');

      expect(isUuidV7(link.id)).toBe(true);
      expect(link.subject).toBe('987654321'); // trimmed
      const found = await service.findUserByPlatformIdentity(Platform.TELEGRAM, '987654321');
      expect(found?.id).toBe(user.id);
    });

    it('rejects a duplicate (platform, subject) with a domain error', async () => {
      const a = await service.createUser();
      const b = await service.createUser();
      await service.attachPlatformIdentity(a.id, Platform.TELEGRAM, '555');
      await expect(
        service.attachPlatformIdentity(b.id, Platform.TELEGRAM, '555'),
      ).rejects.toBeInstanceOf(PlatformIdentityAlreadyLinkedError);
    });

    it('allows the same subject on different platforms', async () => {
      const user = await service.createUser();
      await service.attachPlatformIdentity(user.id, Platform.TELEGRAM, '555');
      await expect(
        service.attachPlatformIdentity(user.id, Platform.BALE, '555'),
      ).resolves.toBeDefined();
    });

    it('validates inputs', async () => {
      const user = await service.createUser();
      await expect(
        service.attachPlatformIdentity('not-a-uuid', Platform.TELEGRAM, '1'),
      ).rejects.toBeInstanceOf(InvalidIdentityIdError);
      await expect(
        service.attachPlatformIdentity(user.id, 'X' as Platform, '1'),
      ).rejects.toBeInstanceOf(UnknownPlatformError);
      await expect(
        service.attachPlatformIdentity(user.id, Platform.TELEGRAM, '   '),
      ).rejects.toBeInstanceOf(InvalidPlatformSubjectError);
    });
  });

  describe('findUserByPlatformIdentity', () => {
    it('returns null for unknown platform or blank subject (lenient lookup)', async () => {
      expect(await service.findUserByPlatformIdentity('X' as Platform, '1')).toBeNull();
      expect(await service.findUserByPlatformIdentity(Platform.TELEGRAM, '  ')).toBeNull();
    });
    it('returns null when no link matches', async () => {
      expect(await service.findUserByPlatformIdentity(Platform.BALE, 'missing')).toBeNull();
    });
  });
});
