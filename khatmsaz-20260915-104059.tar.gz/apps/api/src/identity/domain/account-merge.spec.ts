import { newIdentityId } from './identity-id';
import { AccountMerge } from './account-merge';
import { InvalidAccountMergeError, InvalidIdentityIdError } from './identity.errors';

const base = () => ({
  id: newIdentityId(),
  winnerUserId: newIdentityId(),
  loserUserId: newIdentityId(),
  verifiedE164: '+989123456789',
  initiatingChallengeId: newIdentityId() as string | null,
  movedPlatformIdentities: 2,
  movedPhoneClaims: 1,
  context: 'PHONE_VERIFICATION' as string | null,
  createdAt: new Date(),
});

describe('AccountMerge (audit entity)', () => {
  it('restores a valid audit record', () => {
    const props = base();
    const merge = AccountMerge.restore(props);
    expect(merge.id).toBe(props.id);
    expect(merge.winnerUserId).toBe(props.winnerUserId);
    expect(merge.loserUserId).toBe(props.loserUserId);
    expect(merge.verifiedE164).toBe('+989123456789');
    expect(merge.movedPlatformIdentities).toBe(2);
  });

  it('allows a null initiating challenge and null context', () => {
    expect(() =>
      AccountMerge.restore({ ...base(), initiatingChallengeId: null, context: null }),
    ).not.toThrow();
  });

  it('rejects winner === loser (a merge is between two distinct accounts)', () => {
    const id = newIdentityId();
    expect(() =>
      AccountMerge.restore({ ...base(), winnerUserId: id, loserUserId: id }),
    ).toThrow(InvalidAccountMergeError);
  });

  it('rejects non-UUIDv7 ids', () => {
    expect(() => AccountMerge.restore({ ...base(), winnerUserId: 'nope' })).toThrow(
      InvalidIdentityIdError,
    );
    expect(() => AccountMerge.restore({ ...base(), initiatingChallengeId: 'nope' })).toThrow(
      InvalidIdentityIdError,
    );
  });

  it('rejects an empty verified phone and negative counts', () => {
    expect(() => AccountMerge.restore({ ...base(), verifiedE164: '   ' })).toThrow(
      InvalidAccountMergeError,
    );
    expect(() => AccountMerge.restore({ ...base(), movedPhoneClaims: -1 })).toThrow(
      InvalidAccountMergeError,
    );
  });
});
