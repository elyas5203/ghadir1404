/**
 * User account lifecycle status — a DOMAIN-owned concept (DEC-0040).
 *
 * ACTIVE is the normal state. MERGED marks a tombstoned account that was merged
 * into a canonical winner (DEC-0041); a MERGED user carries a `mergedIntoId`
 * pointing at that winner and is retained, never deleted. Further states
 * (moderation/erasure) are deliberately not added until a written requirement
 * exists. The string values mirror the persistence enum so mapping is a straight
 * pass-through, but nothing outside infrastructure depends on the Prisma enum.
 */

export const UserStatus = {
  ACTIVE: 'ACTIVE',
  MERGED: 'MERGED',
  WARNED: 'WARNED',
  SUSPENDED: 'SUSPENDED',
  BANNED: 'BANNED',
} as const;

export type UserStatus = (typeof UserStatus)[keyof typeof UserStatus];

export const ALL_USER_STATUSES: readonly UserStatus[] = Object.values(UserStatus);

/** Narrows an unknown value to a known {@link UserStatus}. */
export function isUserStatus(value: unknown): value is UserStatus {
  return typeof value === 'string' && (ALL_USER_STATUSES as readonly string[]).includes(value);
}
