/**
 * AccountMergeRepository — a persistence PORT OWNED BY THE DOMAIN for the
 * append-only merge audit (DEC-0043).
 *
 * Only the operations the audit needs exist: append a record and read one back.
 * There is deliberately NO update or delete — the ledger is immutable. The
 * Prisma-backed implementation lives in infrastructure (DEC-0031). The record is
 * written by the merge use-case in a LATER Phase 3B step; this phase provides only
 * the model and its persistence seam.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { AccountMerge } from './account-merge';

/** DI token for {@link AccountMergeRepository}. */
export const ACCOUNT_MERGE_REPOSITORY = Symbol('ACCOUNT_MERGE_REPOSITORY');

/** Validated inputs for appending a merge audit record. */
export interface AppendAccountMergeInput {
  readonly id: string;
  readonly winnerUserId: string;
  readonly loserUserId: string;
  readonly verifiedE164: string;
  readonly initiatingChallengeId?: string | null;
  readonly movedPlatformIdentities?: number;
  readonly movedPhoneClaims?: number;
  readonly context?: string | null;
}

export interface AccountMergeRepository {
  /** Append a new immutable audit record (within a transaction when given). */
  append(input: AppendAccountMergeInput, tx?: TransactionContext): Promise<AccountMerge>;
  /** Read one audit record by id, or `null`. */
  findById(id: string): Promise<AccountMerge | null>;
}
