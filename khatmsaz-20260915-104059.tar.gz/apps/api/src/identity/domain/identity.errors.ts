/**
 * Domain errors for the identity capability.
 *
 * These are framework- and Prisma-independent. Infrastructure repositories
 * translate persistence failures (unique / foreign-key violations) into these
 * domain errors so nothing outside infrastructure sees a Prisma error type.
 *
 * Messages never include a platform `subject` value or any credential.
 */

import type { Platform } from './platform';

/**
 * The "id must be a UUIDv7" error is a KERNEL invariant (every aggregate id is a
 * UUIDv7), so it is owned by `@khatmsaz/kernel` (DEC-0039). It is re-exported here
 * under its historical name so identity callers/tests keep a stable import; the
 * thrown instance is the kernel's `InvalidUuidV7Error`.
 */
export { InvalidUuidV7Error as InvalidIdentityIdError } from '@khatmsaz/kernel';

/** Base class for all identity domain errors. */
export class IdentityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A platform subject (the external account id) was missing or blank. */
export class InvalidPlatformSubjectError extends IdentityError {
  constructor() {
    super('Invalid platform identity: subject (the external account id) is required.');
  }
}

/** An unknown platform was supplied. */
export class UnknownPlatformError extends IdentityError {
  constructor() {
    super('Invalid platform identity: unknown platform.');
  }
}

/** An unknown user lifecycle status was supplied. */
export class UnknownUserStatusError extends IdentityError {
  constructor() {
    super('Invalid user: unknown status.');
  }
}

/** A User's lifecycle fields were inconsistent (e.g. MERGED without a target). */
export class InvalidUserError extends IdentityError {
  constructor(reason: string) {
    super(`Invalid user: ${reason}.`);
  }
}

/** An account-merge audit record was inconsistent (e.g. winner === loser). */
export class InvalidAccountMergeError extends IdentityError {
  constructor(reason: string) {
    super(`Invalid account merge: ${reason}.`);
  }
}

/** Attaching a link failed because the referenced user does not exist. */
export class UserNotFoundError extends IdentityError {
  constructor() {
    super('Cannot attach platform identity: the referenced user does not exist.');
  }
}

/**
 * The (platform, subject) pair is already linked to a user. Raised when a
 * concurrent or repeated attach hits the database uniqueness constraint — one
 * external platform identity can belong to at most one user.
 */
export class PlatformIdentityAlreadyLinkedError extends IdentityError {
  constructor(public readonly platform: Platform) {
    super('This platform identity is already linked to a user.');
  }
}
