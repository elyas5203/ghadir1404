/**
 * UserRepository — a persistence port OWNED BY THE DOMAIN.
 *
 * The interface is expressed in domain terms ({@link User}, string ids). Its
 * Prisma-backed implementation lives in infrastructure and is the only code that
 * sees Prisma types (DEC-0031). Only the operations this phase needs are
 * declared — no speculative methods.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { User } from './user';
import type { UserStatus } from './user-status';
import type { UserRole } from './user';

/** DI token for {@link UserRepository}. */
export const USER_REPOSITORY = Symbol('USER_REPOSITORY');

export interface UserRepository {
  /** Persist a new user with the given canonical id (a UUIDv7). */
  create(id: string): Promise<User>;
  /** Find a user by canonical id, or `null` when none exists. */
  findById(id: string, tx?: TransactionContext): Promise<User | null>;
  /**
   * Tombstone a user (DEC-0041): set status MERGED and `mergedIntoId` to the
   * canonical winner. Guarded on the user currently being ACTIVE — a losing
   * concurrent merge (the user is no longer ACTIVE) throws
   * {@link import('./identity.errors').InvalidAccountMergeError}. This is an
   * UPDATE, never a delete, so the account is retained (FK RESTRICT respected).
   */
  tombstone(userId: string, mergedIntoId: string, tx?: TransactionContext): Promise<void>;
  /** Set (or clear) the user's display name (Phase 14, DEC-0073). */
  updateDisplayName(userId: string, displayName: string | null): Promise<User>;
  /** List all users, newest first. Admin use only. */
  listAll(limit: number, offset: number): Promise<User[]>;
  /** Count all non-merged users. Admin use only. */
  countAll(): Promise<number>;
  /** Search users by display name or partial id. Admin use only. */
  search(query: string, limit: number, offset: number): Promise<User[]>;
  /** Update the lifecycle status of a user (admin moderation). */
  updateStatus(userId: string, status: UserStatus): Promise<User>;
  /** Update the platform role of a user. */
  updateRole(userId: string, role: UserRole): Promise<User>;
}
