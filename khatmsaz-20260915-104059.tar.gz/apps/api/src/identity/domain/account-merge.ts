/**
 * AccountMerge — the DOMAIN entity for one append-only account-merge audit record
 * (DEC-0043). It is written when a merge completes (a LATER Phase 3B step — NOT
 * built yet) and is immutable thereafter: no update, no delete, and therefore no
 * `updatedAt`.
 *
 * It records the canonical `winner`, the tombstoned `loser`, the `verifiedE164`
 * that triggered the merge, the OTP challenge that proved it, and a summary of
 * what moved. `verifiedE164` is PII and is stored as a plain string (no OTP code
 * or secret is ever recorded here). Plain domain object; no Prisma or framework
 * dependency, and — deliberately — no dependency on the phone capability (the
 * number is recorded data, not a phone-domain concern).
 */

import { assertUuidV7 } from './identity-id';
import { InvalidAccountMergeError } from './identity.errors';

export interface AccountMergeProps {
  readonly id: string;
  readonly winnerUserId: string;
  readonly loserUserId: string;
  readonly verifiedE164: string;
  readonly initiatingChallengeId: string | null;
  readonly movedPlatformIdentities: number;
  readonly movedPhoneClaims: number;
  readonly context: string | null;
  readonly createdAt: Date;
}

export class AccountMerge {
  readonly id: string;
  readonly winnerUserId: string;
  readonly loserUserId: string;
  readonly verifiedE164: string;
  readonly initiatingChallengeId: string | null;
  readonly movedPlatformIdentities: number;
  readonly movedPhoneClaims: number;
  readonly context: string | null;
  readonly createdAt: Date;

  private constructor(props: AccountMergeProps) {
    this.id = props.id;
    this.winnerUserId = props.winnerUserId;
    this.loserUserId = props.loserUserId;
    this.verifiedE164 = props.verifiedE164;
    this.initiatingChallengeId = props.initiatingChallengeId;
    this.movedPlatformIdentities = props.movedPlatformIdentities;
    this.movedPhoneClaims = props.movedPhoneClaims;
    this.context = props.context;
    this.createdAt = props.createdAt;
  }

  /**
   * Reconstitute an audit record, enforcing its invariants: ids are UUIDv7, the
   * winner and loser differ (a merge is between two distinct accounts), the moved
   * counts are non-negative integers, and the recorded phone is non-empty.
   */
  static restore(props: AccountMergeProps): AccountMerge {
    assertUuidV7(props.id, 'AccountMerge.id');
    assertUuidV7(props.winnerUserId, 'AccountMerge.winnerUserId');
    assertUuidV7(props.loserUserId, 'AccountMerge.loserUserId');
    if (props.winnerUserId === props.loserUserId) {
      throw new InvalidAccountMergeError('winner and loser must be different accounts');
    }
    if (props.initiatingChallengeId !== null) {
      assertUuidV7(props.initiatingChallengeId, 'AccountMerge.initiatingChallengeId');
    }
    if (typeof props.verifiedE164 !== 'string' || props.verifiedE164.trim().length === 0) {
      throw new InvalidAccountMergeError('verifiedE164 is required');
    }
    if (!isNonNegativeInt(props.movedPlatformIdentities) || !isNonNegativeInt(props.movedPhoneClaims)) {
      throw new InvalidAccountMergeError('moved counts must be non-negative integers');
    }
    return new AccountMerge(props);
  }
}

function isNonNegativeInt(value: number): boolean {
  return Number.isInteger(value) && value >= 0;
}
