/**
 * PlatformIdentityRepository — a persistence port OWNED BY THE DOMAIN.
 *
 * Expressed in domain terms; the Prisma-backed implementation lives in
 * infrastructure (DEC-0031). Only this phase's operations are declared.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { PlatformIdentity } from './platform-identity';
import type { Platform } from './platform';

/** DI token for {@link PlatformIdentityRepository}. */
export const PLATFORM_IDENTITY_REPOSITORY = Symbol('PLATFORM_IDENTITY_REPOSITORY');

/** Validated inputs for attaching a new platform identity link. */
export interface AttachPlatformIdentityInput {
  readonly id: string;
  readonly userId: string;
  readonly platform: Platform;
  readonly subject: string;
}

export interface PlatformIdentityRepository {
  /** Look up a link by its unique (platform, subject) pair, or `null`. */
  findByPlatformSubject(platform: Platform, subject: string): Promise<PlatformIdentity | null>;

  /**
   * Insert a new link. The (platform, subject) uniqueness is enforced by a
   * database constraint, so a concurrent or repeated attach for the same pair
   * throws {@link PlatformIdentityAlreadyLinkedError}; a missing user throws
   * {@link UserNotFoundError}. Implementations must NOT rely on a pre-read
   * instead of the constraint.
   */
  attach(input: AttachPlatformIdentityInput): Promise<PlatformIdentity>;

  /**
   * Reassign every platform identity of `fromUserId` to `toUserId` — an UPDATE of
   * `user_id`, never a delete, so the links survive and move to the canonical
   * account during a merge (DEC-0045 RESTRICT respected). `(platform, subject)`
   * stays globally unique, so no reassignment can collide. Returns the number moved.
   */
  reassignOwner(
    fromUserId: string,
    toUserId: string,
    tx?: TransactionContext,
  ): Promise<number>;
}
