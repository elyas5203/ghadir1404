import { assertUuidV7, isUuidV7, newIdentityId } from './identity-id';
import { InvalidIdentityIdError } from './identity.errors';

describe('identity id (UUIDv7)', () => {
  it('generates valid, unique UUIDv7 values', () => {
    const a = newIdentityId();
    const b = newIdentityId();

    expect(a).not.toBe(b);
    expect(isUuidV7(a)).toBe(true);
    // The version nibble of a UUIDv7 is "7".
    expect(a[14]).toBe('7');
    // Canonical 8-4-4-4-12 hyphenated form.
    expect(a).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$/);
  });

  it('generates roughly time-ordered ids (v7 is sortable)', () => {
    const first = newIdentityId();
    const second = newIdentityId();
    // v7 embeds a millisecond timestamp prefix; later ids sort >= earlier ones.
    expect([first, second].sort()).toEqual([first, second]);
  });

  it('rejects non-v7 uuids and non-uuids', () => {
    // A valid UUIDv4 must be rejected — only v7 is the canonical identity.
    expect(isUuidV7('9b2e4c1a-1f3d-4a2b-8c7e-1a2b3c4d5e6f')).toBe(false);
    expect(isUuidV7('not-a-uuid')).toBe(false);
    expect(isUuidV7('')).toBe(false);
  });

  it('assertUuidV7 throws InvalidIdentityIdError for bad ids', () => {
    expect(() => assertUuidV7('nope', 'User.id')).toThrow(InvalidIdentityIdError);
    expect(() => assertUuidV7(newIdentityId(), 'User.id')).not.toThrow();
  });
});
