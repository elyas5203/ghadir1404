/**
 * External platforms KhatmSaz can link identities from — a DOMAIN-owned concept.
 *
 * The domain never branches on a specific platform (DEC-0018); this type only
 * enumerates which external systems may own a linked account. The string values
 * intentionally match the persistence enum so mapping is a straight pass-through,
 * but nothing outside infrastructure depends on the Prisma-generated enum.
 */

export const Platform = {
  TELEGRAM: 'TELEGRAM',
  BALE: 'BALE',
} as const;

export type Platform = (typeof Platform)[keyof typeof Platform];

export const ALL_PLATFORMS: readonly Platform[] = Object.values(Platform);

/** Narrows an unknown value to a known {@link Platform}. */
export function isPlatform(value: unknown): value is Platform {
  return typeof value === 'string' && (ALL_PLATFORMS as readonly string[]).includes(value);
}
