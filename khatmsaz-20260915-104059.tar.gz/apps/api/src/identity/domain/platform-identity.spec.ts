import { newIdentityId } from './identity-id';
import {
  InvalidIdentityIdError,
  InvalidPlatformSubjectError,
  UnknownPlatformError,
} from './identity.errors';
import { Platform } from './platform';
import { PlatformIdentity, requireSubject } from './platform-identity';

describe('PlatformIdentity (domain entity)', () => {
  const base = () => ({
    id: newIdentityId(),
    userId: newIdentityId(),
    platform: Platform.TELEGRAM,
    subject: '123456789',
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  it('restores a valid link', () => {
    const props = base();
    const link = PlatformIdentity.restore(props);
    expect(link.platform).toBe('TELEGRAM');
    expect(link.subject).toBe('123456789');
    expect(link.userId).toBe(props.userId);
  });

  it('trims the subject and rejects a blank one', () => {
    expect(PlatformIdentity.restore({ ...base(), subject: '  42 ' }).subject).toBe('42');
    expect(() => PlatformIdentity.restore({ ...base(), subject: '   ' })).toThrow(
      InvalidPlatformSubjectError,
    );
  });

  it('requires id and userId to be UUIDv7', () => {
    expect(() => PlatformIdentity.restore({ ...base(), id: 'x' })).toThrow(InvalidIdentityIdError);
    expect(() => PlatformIdentity.restore({ ...base(), userId: 'x' })).toThrow(
      InvalidIdentityIdError,
    );
  });

  it('rejects an unknown platform', () => {
    expect(() =>
      PlatformIdentity.restore({ ...base(), platform: 'WHATSAPP' as Platform }),
    ).toThrow(UnknownPlatformError);
  });

  describe('requireSubject', () => {
    it('returns the trimmed subject', () => {
      expect(requireSubject('  abc ')).toBe('abc');
    });
    it('throws on empty/whitespace', () => {
      expect(() => requireSubject('')).toThrow(InvalidPlatformSubjectError);
      expect(() => requireSubject('   ')).toThrow(InvalidPlatformSubjectError);
    });
  });
});
