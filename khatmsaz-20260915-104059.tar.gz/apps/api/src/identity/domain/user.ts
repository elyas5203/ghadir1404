/**
 * The canonical User — the internal, immutable actor of KhatmSaz.
 *
 * A User is identified solely by its UUIDv7 `id` (DEC-0010, DEC-0032). Phase 3B
 * adds the account lifecycle (DEC-0040) and the tombstone/alias pointer
 * (DEC-0041): a MERGED user is a tombstone that carries `mergedIntoId` pointing at
 * the canonical winner it was merged into, and is retained rather than deleted.
 * An ACTIVE user never has a `mergedIntoId`. Profile data is still deferred. Plain
 * domain object with no Prisma or framework dependency.
 */

import { assertUuidV7 } from './identity-id';
import { UserStatus, isUserStatus } from './user-status';
import { InvalidUserError, UnknownUserStatusError } from './identity.errors';

export type UserRole = 'USER' | 'SUPER_ADMIN';

export interface UserProps {
  readonly id: string;
  readonly createdAt: Date;
  readonly updatedAt: Date;
  /** Lifecycle status; defaults to ACTIVE when omitted (DEC-0040). */
  readonly status?: UserStatus;
  /** The canonical winner this account was merged into; null unless MERGED (DEC-0041). */
  readonly mergedIntoId?: string | null;
  /** Optional human-readable name the user set themselves (Phase 14, DEC-0073). */
  readonly displayName?: string | null;
  /** Platform role; defaults to USER (Phase 06). */
  readonly role?: UserRole;
}

export class User {
  readonly id: string;
  readonly createdAt: Date;
  readonly updatedAt: Date;
  readonly status: UserStatus;
  readonly mergedIntoId: string | null;
  readonly displayName: string | null;
  readonly role: UserRole;

  private constructor(props: Required<UserProps>) {
    this.id = props.id;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
    this.status = props.status;
    this.mergedIntoId = props.mergedIntoId;
    this.displayName = props.displayName;
    this.role = props.role;
  }

  get isActive(): boolean {
    return this.status === UserStatus.ACTIVE;
  }

  /** True when this account is a tombstone merged into another (DEC-0041). */
  get isMerged(): boolean {
    return this.status === UserStatus.MERGED;
  }

  /**
   * Reconstitute a persisted User, enforcing the identity invariant that `id` is
   * a UUIDv7 and the lifecycle invariant that a MERGED user has a UUIDv7
   * `mergedIntoId` while an ACTIVE user has none. The domain never trusts stored
   * state blindly.
   */
  static restore(props: UserProps): User {
    assertUuidV7(props.id, 'User.id');

    const status = props.status ?? UserStatus.ACTIVE;
    if (!isUserStatus(status)) {
      throw new UnknownUserStatusError();
    }

    const mergedIntoId = props.mergedIntoId ?? null;
    if (status === UserStatus.MERGED) {
      if (!mergedIntoId) {
        throw new InvalidUserError('a MERGED user requires mergedIntoId');
      }
      assertUuidV7(mergedIntoId, 'User.mergedIntoId');
    } else if (mergedIntoId !== null) {
      throw new InvalidUserError('an ACTIVE user must not have mergedIntoId');
    }

    return new User({
      id: props.id,
      createdAt: props.createdAt,
      updatedAt: props.updatedAt,
      status,
      mergedIntoId,
      displayName: props.displayName ?? null,
      role: props.role ?? 'USER',
    });
  }
}
