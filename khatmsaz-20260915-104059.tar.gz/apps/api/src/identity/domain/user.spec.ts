import { newIdentityId } from './identity-id';
import { InvalidIdentityIdError, InvalidUserError, UnknownUserStatusError } from './identity.errors';
import { User } from './user';
import { UserStatus } from './user-status';

describe('User (domain entity)', () => {
  it('restores a user with a valid UUIDv7 id, defaulting to an ACTIVE lifecycle', () => {
    const id = newIdentityId();
    const now = new Date();
    const user = User.restore({ id, createdAt: now, updatedAt: now });

    expect(user.id).toBe(id);
    expect(user.createdAt).toBe(now);
    expect(user.updatedAt).toBe(now);
    expect(user.status).toBe(UserStatus.ACTIVE);
    expect(user.isActive).toBe(true);
    expect(user.isMerged).toBe(false);
    expect(user.mergedIntoId).toBeNull();
  });

  it('enforces the identity invariant: id must be a UUIDv7', () => {
    const now = new Date();
    expect(() =>
      User.restore({ id: 'not-a-uuid', createdAt: now, updatedAt: now }),
    ).toThrow(InvalidIdentityIdError);
    // A UUIDv4 is not a valid canonical identity either.
    expect(() =>
      User.restore({
        id: '9b2e4c1a-1f3d-4a2b-8c7e-1a2b3c4d5e6f',
        createdAt: now,
        updatedAt: now,
      }),
    ).toThrow(InvalidIdentityIdError);
  });

  describe('lifecycle (DEC-0040/0041)', () => {
    const base = () => ({ id: newIdentityId(), createdAt: new Date(), updatedAt: new Date() });

    it('restores a MERGED tombstone pointing at a canonical winner', () => {
      const winnerId = newIdentityId();
      const user = User.restore({ ...base(), status: UserStatus.MERGED, mergedIntoId: winnerId });
      expect(user.isMerged).toBe(true);
      expect(user.isActive).toBe(false);
      expect(user.mergedIntoId).toBe(winnerId);
    });

    it('rejects a MERGED user without a mergedIntoId', () => {
      expect(() => User.restore({ ...base(), status: UserStatus.MERGED })).toThrow(InvalidUserError);
    });

    it('rejects a MERGED user whose mergedIntoId is not a UUIDv7', () => {
      expect(() =>
        User.restore({ ...base(), status: UserStatus.MERGED, mergedIntoId: 'nope' }),
      ).toThrow(InvalidIdentityIdError);
    });

    it('rejects an ACTIVE user that carries a mergedIntoId', () => {
      expect(() =>
        User.restore({ ...base(), status: UserStatus.ACTIVE, mergedIntoId: newIdentityId() }),
      ).toThrow(InvalidUserError);
    });

    it('rejects an unknown status', () => {
      expect(() =>
        User.restore({ ...base(), status: 'DELETED' as UserStatus }),
      ).toThrow(UnknownUserStatusError);
    });
  });
});
