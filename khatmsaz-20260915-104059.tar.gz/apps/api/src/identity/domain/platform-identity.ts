/**
 * A PlatformIdentity links a canonical {@link User} to an account on an external
 * platform. It is only an external CLAIM/link, never a source of canonical
 * identity (DEC-0032). `subject` is the platform's IMMUTABLE account id (for
 * example a Telegram numeric user id) — never a username, which is not stable
 * identity. Plain domain object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from './identity-id';
import { InvalidPlatformSubjectError, UnknownPlatformError } from './identity.errors';
import { isPlatform } from './platform';
import type { Platform } from './platform';

export interface PlatformIdentityProps {
  readonly id: string;
  readonly userId: string;
  readonly platform: Platform;
  readonly subject: string;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * Normalise a raw subject: trim surrounding whitespace and reject an empty
 * value. Returns the cleaned subject or throws {@link InvalidPlatformSubjectError}.
 */
export function requireSubject(raw: string): string {
  const trimmed = raw?.trim() ?? '';
  if (trimmed.length === 0) {
    throw new InvalidPlatformSubjectError();
  }
  return trimmed;
}

export class PlatformIdentity {
  readonly id: string;
  readonly userId: string;
  readonly platform: Platform;
  readonly subject: string;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: PlatformIdentityProps) {
    this.id = props.id;
    this.userId = props.userId;
    this.platform = props.platform;
    this.subject = props.subject;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  /**
   * Reconstitute a persisted link, enforcing the identity invariants: `id` and
   * `userId` are UUIDv7, `platform` is known, and `subject` is non-empty.
   */
  static restore(props: PlatformIdentityProps): PlatformIdentity {
    assertUuidV7(props.id, 'PlatformIdentity.id');
    assertUuidV7(props.userId, 'PlatformIdentity.userId');
    if (!isPlatform(props.platform)) {
      throw new UnknownPlatformError();
    }
    return new PlatformIdentity({ ...props, subject: requireSubject(props.subject) });
  }
}
