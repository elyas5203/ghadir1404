/**
 * Identity id primitives.
 *
 * The canonical id generation/validation now lives in the shared kernel
 * (`@khatmsaz/kernel`, DEC-0039) because every aggregate id in KhatmSaz is a
 * UUIDv7 — it is not an identity-specific concern. This module re-exports the
 * kernel primitives under identity-friendly names so the identity capability's
 * internal imports stay stable, and so nothing here duplicates the kernel.
 */

export { isUuidV7, assertUuidV7, newUuidV7 as newIdentityId } from '@khatmsaz/kernel';
