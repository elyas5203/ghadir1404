import { Module } from '@nestjs/common';
import { IdentityService } from './application/identity.service';
import { USER_REPOSITORY } from './domain/user.repository';
import { PLATFORM_IDENTITY_REPOSITORY } from './domain/platform-identity.repository';
import { ACCOUNT_MERGE_REPOSITORY } from './domain/account-merge.repository';
import { PrismaUserRepository } from './infrastructure/prisma-user.repository';
import { PrismaPlatformIdentityRepository } from './infrastructure/prisma-platform-identity.repository';
import { PrismaAccountMergeRepository } from './infrastructure/prisma-account-merge.repository';

/**
 * Identity capability module.
 *
 * Binds the domain-owned persistence ports to their Prisma-backed
 * implementations. The rest of the application depends on {@link IdentityService}
 * and the domain ports; Prisma lives only behind these bindings (DEC-0031). The
 * `@Global` DatabaseModule (imported once in AppModule) provides `PrismaService`.
 *
 * This phase deliberately exposes no HTTP controller — there is no registration
 * or bot surface yet. The module exists so the identity use-cases are wired and
 * testable.
 */
@Module({
  providers: [
    IdentityService,
    { provide: USER_REPOSITORY, useClass: PrismaUserRepository },
    { provide: PLATFORM_IDENTITY_REPOSITORY, useClass: PrismaPlatformIdentityRepository },
    // Persistence seam for the append-only merge audit (DEC-0043). The merge
    // use-case that writes to it is a LATER Phase 3B step — not built yet.
    { provide: ACCOUNT_MERGE_REPOSITORY, useClass: PrismaAccountMergeRepository },
  ],
  // Export the domain-owned repository ports (interfaces, not Prisma) so the
  // account-merge orchestration module can compose them (DEC-0047, intra-product).
  exports: [
    IdentityService,
    USER_REPOSITORY,
    PLATFORM_IDENTITY_REPOSITORY,
    ACCOUNT_MERGE_REPOSITORY,
  ],
})
export class IdentityModule {}
