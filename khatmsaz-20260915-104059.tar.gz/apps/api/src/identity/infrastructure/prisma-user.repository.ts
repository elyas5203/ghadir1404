import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import { UserStatus } from '../domain/user-status';
import type { UserStatus as UserStatusType } from '../domain/user-status';
import type { User, UserRole } from '../domain/user';
import type { UserRepository } from '../domain/user.repository';
import { InvalidAccountMergeError } from '../domain/identity.errors';
import { toUser, type UserRow } from './identity.mapper';

/**
 * Prisma-backed {@link UserRepository}. The only User persistence code that sees
 * Prisma; it returns domain {@link User} objects, never Prisma rows.
 */
@Injectable()
export class PrismaUserRepository implements UserRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(id: string): Promise<User> {
    const row = await this.prisma.user.create({ data: { id } });
    return toUser(row);
  }

  async findById(id: string, tx?: TransactionContext): Promise<User | null> {
    const row = await dbClient(this.prisma, tx).user.findUnique({ where: { id } });
    return row ? toUser(row) : null;
  }

  async tombstone(
    userId: string,
    mergedIntoId: string,
    tx?: TransactionContext,
  ): Promise<void> {
    // Guarded on ACTIVE so two concurrent merges of the same loser cannot both
    // tombstone it — the loser of that race updates 0 rows and is rejected.
    // `updated_at` is maintained by Prisma (@updatedAt).
    const result = await dbClient(this.prisma, tx).user.updateMany({
      where: { id: userId, status: UserStatus.ACTIVE },
      data: { status: UserStatus.MERGED, mergedIntoId },
    });
    if (result.count === 0) {
      throw new InvalidAccountMergeError('the account is no longer active');
    }
  }

  async updateDisplayName(userId: string, displayName: string | null): Promise<User> {
    // Cast: Prisma client regenerates to include displayName after migration.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row = await (this.prisma.user as any).update({
      where: { id: userId },
      data: { displayName },
    }) as UserRow;
    return toUser(row);
  }

  async listAll(limit: number, offset: number): Promise<User[]> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rows = await (this.prisma.user as any).findMany({
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    }) as UserRow[];
    return rows.map(toUser);
  }

  async countAll(): Promise<number> {
    return this.prisma.user.count();
  }

  async search(query: string, limit: number, offset: number): Promise<User[]> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rows = await (this.prisma.user as any).findMany({
      where: {
        OR: [
          { displayName: { contains: query, mode: 'insensitive' } },
          { id: { startsWith: query } },
        ],
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    }) as UserRow[];
    return rows.map(toUser);
  }

  async updateStatus(userId: string, status: UserStatusType): Promise<User> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row = await (this.prisma.user as any).update({
      where: { id: userId },
      data: { status },
    }) as UserRow;
    return toUser(row);
  }

  async updateRole(userId: string, role: UserRole): Promise<User> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row = await (this.prisma.user as any).update({
      where: { id: userId },
      data: { role },
    }) as UserRow;
    return toUser(row);
  }
}
