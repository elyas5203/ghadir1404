import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import type { Platform } from '../domain/platform';
import type { PlatformIdentity } from '../domain/platform-identity';
import type {
  AttachPlatformIdentityInput,
  PlatformIdentityRepository,
} from '../domain/platform-identity.repository';
import {
  PlatformIdentityAlreadyLinkedError,
  UserNotFoundError,
} from '../domain/identity.errors';
import { toPlatformIdentity } from './identity.mapper';
import {
  PRISMA_FOREIGN_KEY_VIOLATION,
  PRISMA_UNIQUE_VIOLATION,
  prismaErrorCode,
} from './prisma-error';

/**
 * Prisma-backed {@link PlatformIdentityRepository}.
 *
 * `attach` inserts directly and lets the database's (platform, subject) unique
 * constraint decide the winner of any concurrent/duplicate attempt — it does not
 * pre-check existence to gate the write. Prisma's `PrismaClientKnownRequestError`
 * codes are translated into domain errors so no Prisma type escapes this layer.
 */
@Injectable()
export class PrismaPlatformIdentityRepository implements PlatformIdentityRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findByPlatformSubject(
    platform: Platform,
    subject: string,
  ): Promise<PlatformIdentity | null> {
    const row = await this.prisma.platformIdentity.findUnique({
      where: { platform_subject: { platform, subject } },
    });
    return row ? toPlatformIdentity(row) : null;
  }

  async attach(input: AttachPlatformIdentityInput): Promise<PlatformIdentity> {
    try {
      const row = await this.prisma.platformIdentity.create({
        data: {
          id: input.id,
          userId: input.userId,
          platform: input.platform,
          subject: input.subject,
        },
      });
      return toPlatformIdentity(row);
    } catch (error) {
      const code = prismaErrorCode(error);
      if (code === PRISMA_UNIQUE_VIOLATION) {
        throw new PlatformIdentityAlreadyLinkedError(input.platform);
      }
      if (code === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new UserNotFoundError();
      }
      throw error;
    }
  }

  async reassignOwner(
    fromUserId: string,
    toUserId: string,
    tx?: TransactionContext,
  ): Promise<number> {
    const result = await dbClient(this.prisma, tx).platformIdentity.updateMany({
      where: { userId: fromUserId },
      data: { userId: toUserId },
    });
    return result.count;
  }
}
