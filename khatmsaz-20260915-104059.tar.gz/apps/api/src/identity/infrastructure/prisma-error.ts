/**
 * Minimal, resilient inspection of Prisma request errors by their stable public
 * error codes (documented at https://pris.ly/d/error-reference). Duck-typing the
 * `code` avoids depending on a specific error-class identity across module copies
 * while staying entirely inside the infrastructure layer.
 */

/** Prisma "unique constraint failed". */
export const PRISMA_UNIQUE_VIOLATION = 'P2002';
/** Prisma "foreign key constraint failed". */
export const PRISMA_FOREIGN_KEY_VIOLATION = 'P2003';

/** Return the Prisma error code of `error`, if it carries one. */
export function prismaErrorCode(error: unknown): string | undefined {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code;
    return typeof code === 'string' ? code : undefined;
  }
  return undefined;
}
