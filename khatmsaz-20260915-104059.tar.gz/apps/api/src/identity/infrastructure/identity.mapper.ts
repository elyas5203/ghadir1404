/**
 * Mapping between persistence rows and domain entities. This file lives in
 * infrastructure precisely so that the Prisma-shaped rows are converted to
 * Prisma-free domain objects here and nowhere else (DEC-0031). The domain entity
 * factories re-validate every invariant, so a corrupt row cannot enter the
 * domain silently.
 */

import { User } from '../domain/user';
import type { UserRole } from '../domain/user';
import { PlatformIdentity } from '../domain/platform-identity';
import { AccountMerge } from '../domain/account-merge';
import type { Platform } from '../domain/platform';
import type { UserStatus } from '../domain/user-status';

/** Shape of a `users` row the mapper needs. */
export interface UserRow {
  id: string;
  status: string;
  role?: string | null;
  /** Populated after the 20260911200000 migration and prisma generate. */
  displayName?: string | null;
  mergedIntoId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

/** Shape of an `account_merges` row the mapper needs. */
export interface AccountMergeRow {
  id: string;
  winnerUserId: string;
  loserUserId: string;
  verifiedE164: string;
  initiatingChallengeId: string | null;
  movedPlatformIdentities: number;
  movedPhoneClaims: number;
  context: string | null;
  createdAt: Date;
}

/** Shape of a `platform_identities` row the mapper needs. */
export interface PlatformIdentityRow {
  id: string;
  userId: string;
  platform: string;
  subject: string;
  createdAt: Date;
  updatedAt: Date;
}

export function toUser(row: UserRow): User {
  return User.restore({
    id: row.id,
    status: row.status as UserStatus,
    role: (row.role ?? 'USER') as UserRole,
    displayName: row.displayName,
    mergedIntoId: row.mergedIntoId,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}

export function toAccountMerge(row: AccountMergeRow): AccountMerge {
  return AccountMerge.restore({
    id: row.id,
    winnerUserId: row.winnerUserId,
    loserUserId: row.loserUserId,
    verifiedE164: row.verifiedE164,
    initiatingChallengeId: row.initiatingChallengeId,
    movedPlatformIdentities: row.movedPlatformIdentities,
    movedPhoneClaims: row.movedPhoneClaims,
    context: row.context,
    createdAt: row.createdAt,
  });
}

export function toPlatformIdentity(row: PlatformIdentityRow): PlatformIdentity {
  return PlatformIdentity.restore({
    id: row.id,
    userId: row.userId,
    platform: row.platform as Platform,
    subject: row.subject,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}
