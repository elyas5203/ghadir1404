import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import type { AccountMerge } from '../domain/account-merge';
import type {
  AccountMergeRepository,
  AppendAccountMergeInput,
} from '../domain/account-merge.repository';
import { toAccountMerge } from './identity.mapper';

/**
 * Prisma-backed {@link AccountMergeRepository}. The only merge-audit persistence
 * code that sees Prisma; it returns domain {@link AccountMerge} objects, never
 * Prisma rows. Append-only: it exposes no update or delete.
 */
@Injectable()
export class PrismaAccountMergeRepository implements AccountMergeRepository {
  constructor(private readonly prisma: PrismaService) {}

  async append(input: AppendAccountMergeInput, tx?: TransactionContext): Promise<AccountMerge> {
    const row = await dbClient(this.prisma, tx).accountMerge.create({
      data: {
        id: input.id,
        winnerUserId: input.winnerUserId,
        loserUserId: input.loserUserId,
        verifiedE164: input.verifiedE164,
        initiatingChallengeId: input.initiatingChallengeId ?? null,
        movedPlatformIdentities: input.movedPlatformIdentities ?? 0,
        movedPhoneClaims: input.movedPhoneClaims ?? 0,
        context: input.context ?? null,
      },
    });
    return toAccountMerge(row);
  }

  async findById(id: string): Promise<AccountMerge | null> {
    const row = await this.prisma.accountMerge.findUnique({ where: { id } });
    return row ? toAccountMerge(row) : null;
  }
}
