import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, assertUuidV7 } from '@khatmsaz/kernel';
import { KhatmService } from '../../khatm/application/khatm.service';
import { KhatmNotFoundError, DuplicateParticipationError } from '../../khatm/domain/khatm.errors';
import { KhatmWorkflowService } from '../../khatm-workflow/application/khatm-workflow.service';
import { ResourceOwnershipError } from '../../authorization/domain/authorization.errors';
import { Invitation } from '../domain/invitation';
import {
  INVITATION_REPOSITORY,
  INVITATION_TOKEN,
} from '../domain/invitation.repository';
import type { InvitationRepository, InvitationToken } from '../domain/invitation.repository';
import {
  InvitationNotAcceptableError,
  InvitationNotFoundError,
} from '../domain/invitation.errors';

/**
 * Invitation lifetime — set to 100 years (effectively indefinite, DEC-0075).
 * Explicit cancellation/revocation still works; the expiresAt field is retained
 * in the schema for potential future downgrade use, but it plays no role for MVP.
 */
export const DEFAULT_INVITATION_TTL_SECONDS = 100 * 365 * 24 * 60 * 60;

export interface CreatedInvitation {
  readonly invitation: Invitation;
  /** Raw opaque invite token — returned once; forms the shareable invite link. */
  readonly token: string;
}

export interface AcceptedInvitation {
  readonly khatmId: string;
  readonly participationId: string | null;
}

/**
 * Invitation orchestration (Phase 11, DEC-0068). It composes the invitation store
 * with the khatm capability: only a khatm's OWNER may issue/cancel/list its invites
 * (ownership authorization, DEC-0063), and accepting joins the khatm through the
 * existing workflow (authorization/uniqueness never bypassed). Tokens are opaque and
 * stored hashed; history is preserved (accept/cancel stamp a time).
 */
@Injectable()
export class InvitationService {
  constructor(
    @Inject(INVITATION_REPOSITORY) private readonly invitations: InvitationRepository,
    @Inject(INVITATION_TOKEN) private readonly token: InvitationToken,
    private readonly khatms: KhatmService,
    private readonly workflow: KhatmWorkflowService,
  ) {}

  /** Issue an invitation for a khatm — owner only. Returns the raw token once. */
  async createInvitation(khatmId: string, actingUserId: string): Promise<CreatedInvitation> {
    await this.requireOwner(khatmId, actingUserId);
    const { token, tokenHash } = this.token.generate();
    const now = new Date();
    const invitation = await this.invitations.create(
      Invitation.create({
        id: newUuidV7(),
        khatmId,
        createdByUserId: actingUserId,
        tokenHash,
        createdAt: now,
        expiresAt: new Date(now.getTime() + DEFAULT_INVITATION_TTL_SECONDS * 1000),
      }),
    );
    return { invitation, token };
  }

  /** List a khatm's invitations — owner only. */
  async listInvitations(khatmId: string, actingUserId: string): Promise<Invitation[]> {
    await this.requireOwner(khatmId, actingUserId);
    return this.invitations.findByKhatm(khatmId);
  }

  /** Cancel an invitation — the issuer (khatm owner) only. */
  async cancelInvitation(invitationId: string, actingUserId: string): Promise<void> {
    assertUuidV7(invitationId, 'invitationId');
    const invitation = await this.invitations.findById(invitationId);
    if (!invitation) throw new InvitationNotFoundError();
    if (invitation.createdByUserId !== actingUserId) throw new ResourceOwnershipError();
    const cancelled = await this.invitations.markCancelled(invitationId, new Date());
    if (cancelled === 0) throw new InvitationNotAcceptableError();
  }

  /**
   * Accept an invitation (authenticated). Validates the invite is still open, joins
   * the khatm through the workflow (which enforces active user + active khatm + the
   * one-active-participation invariant), then marks the invite ACCEPTED. A user who
   * is already a participant accepts idempotently.
   */
  async acceptInvitation(rawToken: string, userId: string): Promise<AcceptedInvitation> {
    assertUuidV7(userId, 'userId');
    if (typeof rawToken !== 'string' || rawToken.length === 0) {
      throw new InvitationNotFoundError();
    }
    const invitation = await this.invitations.findByTokenHash(this.token.hash(rawToken));
    if (!invitation) throw new InvitationNotFoundError();
    if (!invitation.isAcceptableAt(new Date())) throw new InvitationNotAcceptableError();

    let participationId: string | null = null;
    try {
      const participation = await this.workflow.joinKhatm(invitation.khatmId, userId);
      participationId = participation.id;
    } catch (error) {
      if (!(error instanceof DuplicateParticipationError)) throw error;
    }
    await this.invitations.markAccepted(invitation.id, userId, new Date());
    return { khatmId: invitation.khatmId, participationId };
  }

  private async requireOwner(khatmId: string, actingUserId: string): Promise<void> {
    assertUuidV7(actingUserId, 'actingUserId');
    const khatm = await this.khatms.findKhatmById(khatmId);
    if (!khatm) throw new KhatmNotFoundError();
    if (khatm.creatorUserId !== actingUserId) throw new ResourceOwnershipError();
  }
}
