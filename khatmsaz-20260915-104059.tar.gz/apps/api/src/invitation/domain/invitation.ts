/**
 * Invitation — the DOMAIN entity for an owner-issued grant to join a khatm
 * (DEC-0068). It stores only the SHA-256 HASH of the opaque token (the raw token is
 * returned once, at creation). Status is DERIVED from timestamps. Plain domain
 * object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { InvitationStatus } from './invitation-status';
import { InvalidInvitationError } from './invitation.errors';

export interface InvitationProps {
  readonly id: string;
  readonly khatmId: string;
  readonly createdByUserId: string;
  /** SHA-256 hex of the raw token. NEVER the raw token. */
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly acceptedAt: Date | null;
  readonly acceptedByUserId: string | null;
  readonly cancelledAt: Date | null;
}

export interface NewInvitationProps {
  readonly id: string;
  readonly khatmId: string;
  readonly createdByUserId: string;
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
}

const SHA256_HEX = /^[0-9a-f]{64}$/;

export class Invitation {
  readonly id: string;
  readonly khatmId: string;
  readonly createdByUserId: string;
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly acceptedAt: Date | null;
  readonly acceptedByUserId: string | null;
  readonly cancelledAt: Date | null;

  private constructor(props: InvitationProps) {
    this.id = props.id;
    this.khatmId = props.khatmId;
    this.createdByUserId = props.createdByUserId;
    this.tokenHash = props.tokenHash;
    this.createdAt = props.createdAt;
    this.expiresAt = props.expiresAt;
    this.acceptedAt = props.acceptedAt;
    this.acceptedByUserId = props.acceptedByUserId;
    this.cancelledAt = props.cancelledAt;
  }

  /** Derive the status at `now`: cancelled > accepted > expired > created. */
  statusAt(now: Date): InvitationStatus {
    if (this.cancelledAt !== null) return InvitationStatus.CANCELLED;
    if (this.acceptedAt !== null) return InvitationStatus.ACCEPTED;
    if (this.expiresAt.getTime() <= now.getTime()) return InvitationStatus.EXPIRED;
    return InvitationStatus.CREATED;
  }

  /** True only when the invitation can be accepted at `now` (still CREATED). */
  isAcceptableAt(now: Date): boolean {
    return this.statusAt(now) === InvitationStatus.CREATED;
  }

  static create(props: NewInvitationProps): Invitation {
    assertUuidV7(props.id, 'Invitation.id');
    assertUuidV7(props.khatmId, 'Invitation.khatmId');
    assertUuidV7(props.createdByUserId, 'Invitation.createdByUserId');
    if (!SHA256_HEX.test(props.tokenHash)) {
      throw new InvalidInvitationError('tokenHash must be a SHA-256 hex digest');
    }
    if (props.expiresAt.getTime() <= props.createdAt.getTime()) {
      throw new InvalidInvitationError('expiresAt must be after createdAt');
    }
    return new Invitation({
      ...props,
      acceptedAt: null,
      acceptedByUserId: null,
      cancelledAt: null,
    });
  }

  static restore(props: InvitationProps): Invitation {
    assertUuidV7(props.id, 'Invitation.id');
    assertUuidV7(props.khatmId, 'Invitation.khatmId');
    assertUuidV7(props.createdByUserId, 'Invitation.createdByUserId');
    if (!SHA256_HEX.test(props.tokenHash)) {
      throw new InvalidInvitationError('tokenHash must be a SHA-256 hex digest');
    }
    if (props.acceptedByUserId !== null) {
      assertUuidV7(props.acceptedByUserId, 'Invitation.acceptedByUserId');
    }
    return new Invitation(props);
  }
}
