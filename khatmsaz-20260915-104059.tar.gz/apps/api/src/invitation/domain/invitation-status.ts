/**
 * The lifecycle status of an {@link import('./invitation').Invitation} (DEC-0068),
 * DERIVED from timestamps so it can never drift:
 *
 *   CANCELLED — `cancelledAt` set (owner revoked it). Terminal.
 *   ACCEPTED  — `acceptedAt` set (a user joined via it). Terminal.
 *   EXPIRED   — not cancelled/accepted, but `expiresAt` has passed. Terminal.
 *   CREATED   — none of the above; the only status that can be accepted.
 *
 * Cancellation wins over acceptance wins over expiry (a cancelled invite is
 * cancelled even if the clock also passed expiry).
 */
export const InvitationStatus = {
  CREATED: 'CREATED',
  ACCEPTED: 'ACCEPTED',
  EXPIRED: 'EXPIRED',
  CANCELLED: 'CANCELLED',
} as const;

export type InvitationStatus = (typeof InvitationStatus)[keyof typeof InvitationStatus];
