/**
 * Invitation domain errors (Phase 11). Framework- and Prisma-free. Messages are
 * generic and never contain a token.
 */

export class InvitationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

export class InvalidInvitationError extends InvitationError {
  constructor(reason: string) {
    super(`Invalid invitation: ${reason}.`);
  }
}

/** No invitation matches the presented token (unknown token). */
export class InvitationNotFoundError extends InvitationError {
  constructor() {
    super('The invitation is invalid.');
  }
}

/** The invitation cannot be accepted (expired, cancelled, or already accepted). */
export class InvitationNotAcceptableError extends InvitationError {
  constructor() {
    super('This invitation can no longer be accepted.');
  }
}
