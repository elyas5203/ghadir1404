/**
 * InvitationRepository + token ports — OWNED BY THE DOMAIN. Prisma-backed
 * implementations live in infrastructure (DEC-0031). Invitations are looked up by
 * token hash (never the raw token); accept/cancel are guarded UPDATEs (history kept).
 */

import type { Invitation } from './invitation';

export const INVITATION_REPOSITORY = Symbol('INVITATION_REPOSITORY');
export const INVITATION_TOKEN = Symbol('INVITATION_TOKEN');

export interface InvitationRepository {
  create(invitation: Invitation): Promise<Invitation>;
  findByTokenHash(tokenHash: string): Promise<Invitation | null>;
  findById(id: string): Promise<Invitation | null>;
  /** All invitations of a khatm, newest first. */
  findByKhatm(khatmId: string): Promise<Invitation[]>;
  /** Mark accepted, guarded on it still being open (not accepted/cancelled). Returns rows affected. */
  markAccepted(id: string, acceptedByUserId: string, acceptedAt: Date): Promise<number>;
  /** Mark cancelled, guarded on it not already being accepted/cancelled. Returns rows affected. */
  markCancelled(id: string, cancelledAt: Date): Promise<number>;
}

/** High-entropy opaque invite token generation + hashing (SHA-256, constant-time). */
export interface InvitationToken {
  generate(): { token: string; tokenHash: string };
  hash(token: string): string;
}
