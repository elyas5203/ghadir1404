import { Module } from '@nestjs/common';
import { KhatmModule } from '../khatm/khatm.module';
import { KhatmWorkflowModule } from '../khatm-workflow/khatm-workflow.module';
import { InvitationService } from './application/invitation.service';
import { INVITATION_REPOSITORY, INVITATION_TOKEN } from './domain/invitation.repository';
import { PrismaInvitationRepository } from './infrastructure/prisma-invitation.repository';
import { CryptoInvitationToken } from './infrastructure/crypto-invitation-token';

/**
 * Invitation capability (Phase 11, DEC-0068). Owns the invitation model and the
 * orchestration that issues/accepts/cancels invites. It composes the khatm capability
 * (ownership + join) and binds its domain ports to Prisma/crypto implementations.
 */
@Module({
  imports: [KhatmModule, KhatmWorkflowModule],
  providers: [
    InvitationService,
    { provide: INVITATION_REPOSITORY, useClass: PrismaInvitationRepository },
    { provide: INVITATION_TOKEN, useClass: CryptoInvitationToken },
  ],
  exports: [InvitationService],
})
export class InvitationModule {}
