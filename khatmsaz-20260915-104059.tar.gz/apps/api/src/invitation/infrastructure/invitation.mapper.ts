import { Invitation } from '../domain/invitation';

export interface InvitationRow {
  id: string;
  khatmId: string;
  createdByUserId: string;
  tokenHash: string;
  createdAt: Date;
  expiresAt: Date;
  acceptedAt: Date | null;
  acceptedByUserId: string | null;
  cancelledAt: Date | null;
}

export function toInvitation(row: InvitationRow): Invitation {
  return Invitation.restore({
    id: row.id,
    khatmId: row.khatmId,
    createdByUserId: row.createdByUserId,
    tokenHash: row.tokenHash,
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
    acceptedAt: row.acceptedAt,
    acceptedByUserId: row.acceptedByUserId,
    cancelledAt: row.cancelledAt,
  });
}
