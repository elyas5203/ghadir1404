import { Injectable } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import type { InvitationToken } from '../domain/invitation.repository';

/**
 * CSPRNG + SHA-256 {@link InvitationToken} (DEC-0068). A 32-byte (256-bit) random
 * token is the shareable invite code; only its SHA-256 hex hash is stored, so a
 * leaked database cannot reverse it — no pepper needed (same rationale as session
 * tokens, DEC-0059). The raw token is returned once and never persisted or logged.
 */
@Injectable()
export class CryptoInvitationToken implements InvitationToken {
  generate(): { token: string; tokenHash: string } {
    const token = randomBytes(32).toString('base64url');
    return { token, tokenHash: this.hash(token) };
  }

  hash(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }
}
