import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { Invitation } from '../domain/invitation';
import type { InvitationRepository } from '../domain/invitation.repository';
import { toInvitation } from './invitation.mapper';

/**
 * Prisma-backed {@link InvitationRepository} — the only invitation persistence that
 * sees Prisma; returns domain objects, never rows. Accept/cancel are guarded
 * `updateMany`s (open → terminal) so a concurrent accept/cancel cannot both win, and
 * history is retained (a timestamp is stamped, nothing is deleted).
 */
@Injectable()
export class PrismaInvitationRepository implements InvitationRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(invitation: Invitation): Promise<Invitation> {
    const row = await this.prisma.khatmInvitation.create({
      data: {
        id: invitation.id,
        khatmId: invitation.khatmId,
        createdByUserId: invitation.createdByUserId,
        tokenHash: invitation.tokenHash,
        createdAt: invitation.createdAt,
        expiresAt: invitation.expiresAt,
      },
    });
    return toInvitation(row);
  }

  async findByTokenHash(tokenHash: string): Promise<Invitation | null> {
    const row = await this.prisma.khatmInvitation.findUnique({ where: { tokenHash } });
    return row ? toInvitation(row) : null;
  }

  async findById(id: string): Promise<Invitation | null> {
    const row = await this.prisma.khatmInvitation.findUnique({ where: { id } });
    return row ? toInvitation(row) : null;
  }

  async findByKhatm(khatmId: string): Promise<Invitation[]> {
    const rows = await this.prisma.khatmInvitation.findMany({
      where: { khatmId },
      orderBy: { createdAt: 'desc' },
    });
    return rows.map(toInvitation);
  }

  async markAccepted(id: string, acceptedByUserId: string, acceptedAt: Date): Promise<number> {
    const result = await this.prisma.khatmInvitation.updateMany({
      where: { id, acceptedAt: null, cancelledAt: null },
      data: { acceptedAt, acceptedByUserId },
    });
    return result.count;
  }

  async markCancelled(id: string, cancelledAt: Date): Promise<number> {
    const result = await this.prisma.khatmInvitation.updateMany({
      where: { id, acceptedAt: null, cancelledAt: null },
      data: { cancelledAt },
    });
    return result.count;
  }
}
