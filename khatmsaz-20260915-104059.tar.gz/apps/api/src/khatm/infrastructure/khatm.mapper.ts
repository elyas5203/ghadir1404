/**
 * Mapping between persistence rows and Khatm-capability domain entities. This file
 * lives in infrastructure precisely so the Prisma-shaped rows are converted to
 * Prisma-free domain objects here and nowhere else (DEC-0031). The domain factories
 * re-validate every invariant, so a corrupt row cannot enter the domain silently.
 */

import { Khatm } from '../domain/khatm';
import type { KhatmStatus } from '../domain/khatm-status';
import type { KhatmTemplateType } from '../domain/khatm-template';
import type { KhatmType } from '../domain/khatm-type';
import { Participation } from '../domain/participation';
import type { ParticipationStatus } from '../domain/participation-status';
import { Assignment } from '../domain/assignment';
import type { AssignmentStatus } from '../domain/assignment-status';
import { Portion } from '../domain/portion';
import type { AssignmentUnitKind } from '../domain/portion';

/** Shape of a `khatms` row the mapper needs. */
export interface KhatmRow {
  id: string;
  creatorUserId: string;
  title: string;
  description: string | null;
  templateType: string;
  khatmType: string;
  status: string;
  quranEditionId: string | null;
  surahNumber: number | null;
  repetitionTarget: number | null;
  publicSlug: string | null;
  niyyat: string | null;
  createdAt: Date;
  updatedAt: Date;
}

/** Shape of a `khatm_participations` row the mapper needs. */
export interface ParticipationRow {
  id: string;
  khatmId: string;
  userId: string;
  status: string;
  joinedAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

/** Shape of an `assignments` row the mapper needs. */
export interface AssignmentRow {
  id: string;
  khatmId: string;
  participationId: string;
  unitKind: string;
  unitStart: number | null;
  unitEnd: number | null;
  quantity: number | null;
  status: string;
  completedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export function toKhatm(row: KhatmRow): Khatm {
  return Khatm.restore({
    id: row.id,
    creatorUserId: row.creatorUserId,
    title: row.title,
    description: row.description,
    templateType: row.templateType as KhatmTemplateType,
    khatmType: row.khatmType as KhatmType,
    status: row.status as KhatmStatus,
    quranEditionId: row.quranEditionId ?? null,
    surahNumber: row.surahNumber ?? null,
    repetitionTarget: row.repetitionTarget ?? null,
    publicSlug: row.publicSlug ?? null,
    niyyat: row.niyyat ?? null,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}

export function toParticipation(row: ParticipationRow): Participation {
  return Participation.restore({
    id: row.id,
    khatmId: row.khatmId,
    userId: row.userId,
    status: row.status as ParticipationStatus,
    joinedAt: row.joinedAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}

export function toAssignment(row: AssignmentRow): Assignment {
  return Assignment.restore({
    id: row.id,
    khatmId: row.khatmId,
    participationId: row.participationId,
    portion: Portion.restore({
      kind: row.unitKind as AssignmentUnitKind,
      unitStart: row.unitStart,
      unitEnd: row.unitEnd,
      quantity: row.quantity,
    }),
    status: row.status as AssignmentStatus,
    completedAt: row.completedAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}
