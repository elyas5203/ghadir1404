import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { AssignmentStatus } from '../domain/assignment-status';
import type { Assignment } from '../domain/assignment';
import type {
  AssignmentRepository,
  CreateAssignmentInput,
  KhatmProgress,
} from '../domain/assignment.repository';
import {
  AssignmentNotPendingError,
  AssignmentTargetNotFoundError,
} from '../domain/khatm.errors';
import { toAssignment } from './khatm.mapper';
import { PRISMA_FOREIGN_KEY_VIOLATION, prismaErrorCode } from './prisma-error';

/**
 * Prisma-backed {@link AssignmentRepository}. Flattens the domain {@link
 * import('../domain/portion').Portion} into its nullable columns on write and
 * reconstructs it on read (via the mapper). `complete` is guarded on the assignment
 * being PENDING; `progressForKhatm` derives progress with two count queries.
 */
@Injectable()
export class PrismaAssignmentRepository implements AssignmentRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateAssignmentInput): Promise<Assignment> {
    try {
      const row = await this.prisma.assignment.create({
        data: {
          id: input.id,
          khatmId: input.khatmId,
          participationId: input.participationId,
          unitKind: input.portion.kind,
          unitStart: input.portion.unitStart,
          unitEnd: input.portion.unitEnd,
          quantity: input.portion.quantity,
        },
      });
      return toAssignment(row);
    } catch (error) {
      if (prismaErrorCode(error) === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new AssignmentTargetNotFoundError();
      }
      throw error;
    }
  }

  async findById(id: string): Promise<Assignment | null> {
    const row = await this.prisma.assignment.findUnique({ where: { id } });
    return row ? toAssignment(row) : null;
  }

  async complete(id: string, completedAt: Date): Promise<void> {
    const result = await this.prisma.assignment.updateMany({
      where: { id, status: AssignmentStatus.PENDING },
      data: { status: AssignmentStatus.COMPLETED, completedAt },
    });
    if (result.count === 0) {
      throw new AssignmentNotPendingError();
    }
  }

  async progressForKhatm(khatmId: string): Promise<KhatmProgress> {
    const [total, completed] = await Promise.all([
      this.prisma.assignment.count({ where: { khatmId } }),
      this.prisma.assignment.count({
        where: { khatmId, status: AssignmentStatus.COMPLETED },
      }),
    ]);
    return { total, completed };
  }
}
