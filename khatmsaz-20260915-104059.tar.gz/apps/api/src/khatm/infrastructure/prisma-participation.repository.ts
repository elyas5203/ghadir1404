import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { Participation } from '../domain/participation';
import type { ParticipationStatus } from '../domain/participation-status';
import type {
  CreateParticipationInput,
  ParticipationRepository,
} from '../domain/participation.repository';
import {
  DuplicateParticipationError,
  ParticipationNotActiveError,
  ParticipationTargetNotFoundError,
} from '../domain/khatm.errors';
import { toParticipation } from './khatm.mapper';
import {
  PRISMA_FOREIGN_KEY_VIOLATION,
  PRISMA_UNIQUE_VIOLATION,
  prismaErrorCode,
} from './prisma-error';

/**
 * Prisma-backed {@link ParticipationRepository}.
 *
 * `create` inserts directly and lets the database partial unique index (one ACTIVE
 * participation per (khatm, user) — DEC-0050) decide the winner of any
 * concurrent/duplicate active join; it does not pre-check to gate the write.
 * `transition` is guarded on the expected prior status.
 */
@Injectable()
export class PrismaParticipationRepository implements ParticipationRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateParticipationInput): Promise<Participation> {
    try {
      const row = await this.prisma.participation.create({
        data: { id: input.id, khatmId: input.khatmId, userId: input.userId },
      });
      return toParticipation(row);
    } catch (error) {
      const code = prismaErrorCode(error);
      if (code === PRISMA_UNIQUE_VIOLATION) {
        throw new DuplicateParticipationError();
      }
      if (code === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new ParticipationTargetNotFoundError();
      }
      throw error;
    }
  }

  async findById(id: string): Promise<Participation | null> {
    const row = await this.prisma.participation.findUnique({ where: { id } });
    return row ? toParticipation(row) : null;
  }

  async findByKhatm(khatmId: string): Promise<Participation[]> {
    const rows = await this.prisma.participation.findMany({
      where: { khatmId },
      orderBy: { joinedAt: 'desc' },
    });
    return rows.map(toParticipation);
  }

  async findByUser(userId: string): Promise<Participation[]> {
    const rows = await this.prisma.participation.findMany({
      where: { userId },
      orderBy: { joinedAt: 'desc' },
    });
    return rows.map(toParticipation);
  }

  async transition(
    id: string,
    from: ParticipationStatus,
    to: ParticipationStatus,
  ): Promise<void> {
    const result = await this.prisma.participation.updateMany({
      where: { id, status: from },
      data: { status: to },
    });
    if (result.count === 0) {
      throw new ParticipationNotActiveError();
    }
  }
}
