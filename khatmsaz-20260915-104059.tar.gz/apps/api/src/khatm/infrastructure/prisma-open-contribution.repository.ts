import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { OpenContribution } from '../domain/open-contribution';
import type {
  OpenContributionRepository,
  OpenContributionProgress,
} from '../domain/open-contribution.repository';

@Injectable()
export class PrismaOpenContributionRepository implements OpenContributionRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(contribution: OpenContribution): Promise<OpenContribution> {
    await this.prisma.openContribution.create({
      data: {
        id: contribution.id,
        khatmId: contribution.khatmId,
        participationId: contribution.participationId,
        amount: contribution.amount,
        note: contribution.note,
        recordedAt: contribution.recordedAt,
      },
    });
    return contribution;
  }

  async findByParticipation(participationId: string): Promise<OpenContribution[]> {
    const rows = await this.prisma.openContribution.findMany({
      where: { participationId },
      orderBy: { recordedAt: 'desc' },
    });
    return rows.map((r) => toOpenContribution(r));
  }

  async progressForKhatm(khatmId: string): Promise<OpenContributionProgress> {
    const [agg, participantCount] = await Promise.all([
      this.prisma.openContribution.aggregate({
        where: { khatmId },
        _sum: { amount: true },
      }),
      this.prisma.openContribution.groupBy({
        by: ['participationId'],
        where: { khatmId },
      }),
    ]);
    return {
      totalContributed: agg._sum.amount ?? 0,
      participantCount: participantCount.length,
    };
  }
}

function toOpenContribution(row: {
  id: string;
  khatmId: string;
  participationId: string;
  amount: number;
  note: string | null;
  recordedAt: Date;
  createdAt: Date;
}): OpenContribution {
  return OpenContribution.restore({
    id: row.id,
    khatmId: row.khatmId,
    participationId: row.participationId,
    amount: row.amount,
    note: row.note,
    recordedAt: row.recordedAt,
    createdAt: row.createdAt,
  });
}
