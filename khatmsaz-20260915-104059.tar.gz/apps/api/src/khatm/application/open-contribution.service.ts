import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, isUuidV7 } from '@khatmsaz/kernel';
import { OpenContribution } from '../domain/open-contribution';
import { OpenContributionNotAllowedError } from '../domain/contribution.errors';
import { KhatmType } from '../domain/khatm-type';
import { OPEN_CONTRIBUTION_REPOSITORY } from '../domain/open-contribution.repository';
import type {
  OpenContributionRepository,
  OpenContributionProgress,
} from '../domain/open-contribution.repository';
import { KHATM_REPOSITORY } from '../domain/khatm.repository';
import type { KhatmRepository } from '../domain/khatm.repository';
import { KhatmNotFoundError } from '../domain/khatm.errors';
import { PARTICIPATION_REPOSITORY } from '../domain/participation.repository';
import type { ParticipationRepository } from '../domain/participation.repository';
import { ParticipationNotFoundError } from '../domain/khatm.errors';

@Injectable()
export class OpenContributionService {
  constructor(
    @Inject(KHATM_REPOSITORY) private readonly khatms: KhatmRepository,
    @Inject(PARTICIPATION_REPOSITORY) private readonly participations: ParticipationRepository,
    @Inject(OPEN_CONTRIBUTION_REPOSITORY)
    private readonly contributions: OpenContributionRepository,
  ) {}

  /** Record a contribution. The khatm must be OPEN and ACTIVE; the participation must be ACTIVE. */
  async recordContribution(input: {
    khatmId: string;
    participationId: string;
    amount: number;
    note?: string | null;
  }): Promise<OpenContribution> {
    if (!isUuidV7(input.khatmId)) throw new KhatmNotFoundError();

    const khatm = await this.khatms.findById(input.khatmId);
    if (!khatm) throw new KhatmNotFoundError();
    if (khatm.khatmType !== KhatmType.OPEN) throw new OpenContributionNotAllowedError();
    if (!khatm.isActive) throw new OpenContributionNotAllowedError();

    const participation = await this.participations.findById(input.participationId);
    if (!participation || participation.khatmId !== input.khatmId) {
      throw new ParticipationNotFoundError();
    }

    const contribution = OpenContribution.create({
      id: newUuidV7(),
      khatmId: input.khatmId,
      participationId: input.participationId,
      amount: input.amount,
      note: input.note,
    });
    return this.contributions.create(contribution);
  }

  /** List a participant's contributions in a khatm. Non-UUIDv7 yields []. */
  async listMyContributions(participationId: string): Promise<OpenContribution[]> {
    if (!isUuidV7(participationId)) return [];
    return this.contributions.findByParticipation(participationId);
  }

  /** Aggregate progress for an OPEN khatm. Non-UUIDv7 yields zero progress. */
  async openProgress(khatmId: string): Promise<OpenContributionProgress> {
    if (!isUuidV7(khatmId)) return { totalContributed: 0, participantCount: 0 };
    return this.contributions.progressForKhatm(khatmId);
  }
}
