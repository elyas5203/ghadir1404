import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { KhatmService } from './khatm.service';
import { Khatm } from '../domain/khatm';
import { KhatmStatus } from '../domain/khatm-status';
import { KhatmTemplateType } from '../domain/khatm-template';
import { KhatmType } from '../domain/khatm-type';
import { Participation } from '../domain/participation';
import type { ParticipationStatus } from '../domain/participation-status';
import { Assignment } from '../domain/assignment';
import { AssignmentStatus } from '../domain/assignment-status';
import { Portion } from '../domain/portion';
import {
  DuplicateParticipationError,
  KhatmNotActiveError,
  KhatmNotFoundError,
  ParticipationNotFoundError,
} from '../domain/khatm.errors';
import { KHATM_REPOSITORY } from '../domain/khatm.repository';
import type { KhatmRepository } from '../domain/khatm.repository';
import { PARTICIPATION_REPOSITORY } from '../domain/participation.repository';
import type {
  CreateParticipationInput,
  ParticipationRepository,
} from '../domain/participation.repository';
import { ASSIGNMENT_REPOSITORY } from '../domain/assignment.repository';
import type {
  AssignmentRepository,
  CreateAssignmentInput,
  KhatmProgress,
} from '../domain/assignment.repository';

/** In-memory KhatmRepository with a guarded status transition. */
class FakeKhatmRepository implements KhatmRepository {
  readonly khatms = new Map<string, Khatm>();
  async create(khatm: Khatm): Promise<Khatm> {
    this.khatms.set(khatm.id, khatm);
    return khatm;
  }
  async findById(id: string): Promise<Khatm | null> {
    return this.khatms.get(id) ?? null;
  }
  async findBySlug(slug: string): Promise<Khatm | null> {
    return [...this.khatms.values()].find((k) => k.publicSlug === slug) ?? null;
  }
  async findByCreator(creatorUserId: string): Promise<Khatm[]> {
    return [...this.khatms.values()].filter((k) => k.creatorUserId === creatorUserId);
  }
  async transition(id: string, from: KhatmStatus, to: KhatmStatus): Promise<void> {
    const khatm = this.khatms.get(id);
    if (!khatm || khatm.status !== from) throw new Error('unexpected state');
    this.khatms.set(id, Khatm.restore({ ...khatm, description: khatm.description, status: to }));
  }
  async listAll(limit: number, offset: number): Promise<Khatm[]> {
    return [...this.khatms.values()].slice(offset, offset + limit);
  }
  async countAll(): Promise<number> { return this.khatms.size; }
  async setPublicSlug(id: string, slug: string): Promise<void> {
    const khatm = this.khatms.get(id);
    if (khatm) this.khatms.set(id, Khatm.restore({ ...khatm, publicSlug: slug }));
  }
  async countByStatus(status: KhatmStatus): Promise<number> {
    return [...this.khatms.values()].filter((k) => k.status === status).length;
  }
}

/** In-memory ParticipationRepository emulating the one-ACTIVE partial unique index. */
class FakeParticipationRepository implements ParticipationRepository {
  readonly rows: Participation[] = [];
  async create(input: CreateParticipationInput): Promise<Participation> {
    const active = this.rows.some(
      (p) => p.khatmId === input.khatmId && p.userId === input.userId && p.isActive,
    );
    if (active) throw new DuplicateParticipationError();
    const p = Participation.create(input);
    this.rows.push(p);
    return p;
  }
  async findById(id: string): Promise<Participation | null> {
    return this.rows.find((p) => p.id === id) ?? null;
  }
  async findByKhatm(khatmId: string): Promise<Participation[]> {
    return this.rows.filter((p) => p.khatmId === khatmId);
  }
  async findByUser(userId: string): Promise<Participation[]> {
    return this.rows.filter((p) => p.userId === userId);
  }
  async transition(id: string, from: ParticipationStatus, to: ParticipationStatus): Promise<void> {
    const idx = this.rows.findIndex((p) => p.id === id);
    const p = this.rows[idx];
    if (!p || p.status !== from) throw new Error('unexpected state');
    this.rows[idx] = Participation.restore({
      id: p.id,
      khatmId: p.khatmId,
      userId: p.userId,
      status: to,
      joinedAt: p.joinedAt,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt,
    });
  }
}

/** In-memory AssignmentRepository. */
class FakeAssignmentRepository implements AssignmentRepository {
  readonly rows: Assignment[] = [];
  async create(input: CreateAssignmentInput): Promise<Assignment> {
    const a = Assignment.create(input);
    this.rows.push(a);
    return a;
  }
  async findById(id: string): Promise<Assignment | null> {
    return this.rows.find((a) => a.id === id) ?? null;
  }
  async complete(id: string, completedAt: Date): Promise<void> {
    const idx = this.rows.findIndex((a) => a.id === id);
    const a = this.rows[idx];
    if (!a || !a.isPending) throw new Error('not pending');
    this.rows[idx] = a.complete(completedAt);
  }
  async progressForKhatm(khatmId: string): Promise<KhatmProgress> {
    const scoped = this.rows.filter((a) => a.khatmId === khatmId);
    return {
      total: scoped.length,
      completed: scoped.filter((a) => a.status === AssignmentStatus.COMPLETED).length,
    };
  }
}

describe('KhatmService', () => {
  let service: KhatmService;
  let khatms: FakeKhatmRepository;
  const creatorUserId = '018f9a2b-0000-7000-8000-000000000001';
  const userId = '018f9a2b-0000-7000-8000-000000000002';

  beforeEach(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      providers: [
        KhatmService,
        { provide: KHATM_REPOSITORY, useClass: FakeKhatmRepository },
        { provide: PARTICIPATION_REPOSITORY, useClass: FakeParticipationRepository },
        { provide: ASSIGNMENT_REPOSITORY, useClass: FakeAssignmentRepository },
      ],
    }).compile();
    service = moduleRef.get(KhatmService);
    khatms = moduleRef.get(KHATM_REPOSITORY);
  });

  const createActive = async () => {
    const khatm = await service.createKhatm({
      creatorUserId,
      title: 'ختم',
      templateType: KhatmTemplateType.SALAWAT,
      khatmType: KhatmType.COMMITMENT,
    });
    await service.activateKhatm(khatm.id);
    return khatm;
  };

  it('creates a DRAFT khatm and moves it through its lifecycle', async () => {
    const khatm = await service.createKhatm({
      creatorUserId,
      title: 'ختم قرآن',
      templateType: KhatmTemplateType.SALAWAT,
      khatmType: KhatmType.COMMITMENT,
    });
    expect(khatm.status).toBe(KhatmStatus.DRAFT);
    await service.activateKhatm(khatm.id);
    expect(khatms.khatms.get(khatm.id)?.status).toBe(KhatmStatus.ACTIVE);
    await service.completeKhatm(khatm.id);
    expect(khatms.khatms.get(khatm.id)?.status).toBe(KhatmStatus.COMPLETED);
  });

  it('rejects joining a DRAFT khatm (only ACTIVE accepts participants)', async () => {
    const khatm = await service.createKhatm({
      creatorUserId,
      title: 'ختم',
      templateType: KhatmTemplateType.SALAWAT,
      khatmType: KhatmType.COMMITMENT,
    });
    await expect(service.join(khatm.id, userId)).rejects.toThrow(KhatmNotActiveError);
  });

  it('lets a user join an ACTIVE khatm but forbids a duplicate active participation', async () => {
    const khatm = await createActive();
    const p = await service.join(khatm.id, userId);
    expect(p.isActive).toBe(true);
    await expect(service.join(khatm.id, userId)).rejects.toThrow(DuplicateParticipationError);
  });

  it('allows re-joining after leaving (history retained)', async () => {
    const khatm = await createActive();
    const first = await service.join(khatm.id, userId);
    await service.leaveParticipation(first.id);
    const second = await service.join(khatm.id, userId);
    expect(second.id).not.toBe(first.id);
    expect(second.isActive).toBe(true);
  });

  it('assigns a portion only while the khatm can receive assignments, and tracks progress', async () => {
    const khatm = await createActive();
    const p = await service.join(khatm.id, userId);

    const a = await service.assignPortion(p.id, Portion.positional(1, 15));
    await service.assignPortion(p.id, Portion.positional(16, 30));
    expect(await service.khatmProgress(khatm.id)).toEqual({ total: 2, completed: 0 });

    await service.completeAssignment(a.id);
    expect(await service.khatmProgress(khatm.id)).toEqual({ total: 2, completed: 1 });

    await service.completeKhatm(khatm.id);
    await expect(service.assignPortion(p.id, Portion.quantity(10))).rejects.toThrow(
      KhatmNotActiveError,
    );
  });

  it('throws for a missing khatm or participation', async () => {
    const missing = '018f9a2b-0000-7000-8000-0000000000ff';
    await expect(service.activateKhatm(missing)).rejects.toThrow(KhatmNotFoundError);
    await expect(service.completeParticipation(missing)).rejects.toThrow(
      ParticipationNotFoundError,
    );
    await expect(service.findKhatmById('not-a-uuid')).resolves.toBeNull();
  });
});
