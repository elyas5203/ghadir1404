import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, isUuidV7 } from '@khatmsaz/kernel';
import { Khatm } from '../domain/khatm';
import type { KhatmTemplateType } from '../domain/khatm-template';
import type { KhatmType } from '../domain/khatm-type';
import { Participation } from '../domain/participation';
import { Assignment } from '../domain/assignment';
import type { Portion } from '../domain/portion';
import {
  KhatmNotActiveError,
  KhatmNotFoundError,
  ParticipationNotFoundError,
} from '../domain/khatm.errors';
import { KHATM_REPOSITORY } from '../domain/khatm.repository';
import type { KhatmRepository } from '../domain/khatm.repository';
import { PARTICIPATION_REPOSITORY } from '../domain/participation.repository';
import type { ParticipationRepository } from '../domain/participation.repository';
import { ASSIGNMENT_REPOSITORY } from '../domain/assignment.repository';
import type { AssignmentRepository, KhatmProgress } from '../domain/assignment.repository';

/**
 * Khatm engine use-cases. Application code: it orchestrates the domain lifecycle
 * rules and the persistence ports, and is entirely Prisma-free (DEC-0031). Only the
 * operations this foundation phase needs exist here.
 *
 * Lifecycle legality is decided by the domain entities (their transition methods);
 * the repositories apply the change guarded on the expected prior status, so a
 * concurrent change is rejected rather than silently lost (mirrors the identity
 * tombstone pattern). No {@link import('@khatmsaz/kernel').UnitOfWork} is used yet:
 * every operation here is a single-aggregate write. Batch allocation (which would
 * be atomic) belongs to the later, generic allocation engine.
 *
 * Lookups are lenient (invalid id → `null`); commands are strict (a missing target
 * throws a domain error). Uniqueness of an ACTIVE participation is guaranteed by
 * the database index, surfaced as a domain error — never by a pre-check alone.
 */
@Injectable()
export class KhatmService {
  constructor(
    @Inject(KHATM_REPOSITORY) private readonly khatms: KhatmRepository,
    @Inject(PARTICIPATION_REPOSITORY) private readonly participations: ParticipationRepository,
    @Inject(ASSIGNMENT_REPOSITORY) private readonly assignments: AssignmentRepository,
  ) {}

  /** Create a new khatm in DRAFT with an application-generated UUIDv7 id. */
  async createKhatm(input: {
    creatorUserId: string;
    title: string;
    description?: string | null;
    templateType: KhatmTemplateType;
    khatmType: KhatmType;
    quranEditionId?: string | null;
    surahNumber?: number | null;
    repetitionTarget?: number | null;
  }): Promise<Khatm> {
    const khatm = Khatm.create({
      id: newUuidV7(),
      creatorUserId: input.creatorUserId,
      title: input.title,
      description: input.description ?? null,
      templateType: input.templateType,
      khatmType: input.khatmType,
      quranEditionId: input.quranEditionId,
      surahNumber: input.surahNumber,
      repetitionTarget: input.repetitionTarget,
    });
    return this.khatms.create(khatm);
  }

  /** Find a khatm by id. An id that is not a UUIDv7 yields `null`. */
  async findKhatmById(id: string): Promise<Khatm | null> {
    if (!isUuidV7(id)) return null;
    return this.khatms.findById(id);
  }

  /** Find a khatm by its public slug (Sprint Phase 05). Returns `null` if not found. */
  async findKhatmBySlug(slug: string): Promise<Khatm | null> {
    if (!slug || slug.trim().length === 0) return null;
    return this.khatms.findBySlug(slug.trim());
  }

  /** List the khatms a user created, newest first. A non-UUIDv7 id yields `[]`. */
  async listKhatmsByCreator(creatorUserId: string): Promise<Khatm[]> {
    if (!isUuidV7(creatorUserId)) return [];
    return this.khatms.findByCreator(creatorUserId);
  }

  /** List all participations of a khatm, newest first. A non-UUIDv7 id yields `[]`. */
  async listParticipations(khatmId: string): Promise<Participation[]> {
    if (!isUuidV7(khatmId)) return [];
    return this.participations.findByKhatm(khatmId);
  }

  /** The khatms a user participates in (via an ACTIVE participation), newest first. */
  async listKhatmsForParticipant(userId: string): Promise<Khatm[]> {
    if (!isUuidV7(userId)) return [];
    const parts = await this.participations.findByUser(userId);
    const khatms: Khatm[] = [];
    const seen = new Set<string>();
    for (const p of parts) {
      if (!p.isActive || seen.has(p.khatmId)) continue;
      seen.add(p.khatmId);
      const khatm = await this.khatms.findById(p.khatmId);
      if (khatm) khatms.push(khatm);
    }
    return khatms;
  }

  /** Look up any participation by its ID, regardless of status. */
  async findParticipationById(id: string): Promise<Participation | null> {
    return isUuidV7(id) ? this.participations.findById(id) : null;
  }

  /** The user's ACTIVE participation in a khatm, or `null`. */
  async findParticipation(khatmId: string, userId: string): Promise<Participation | null> {
    if (!isUuidV7(khatmId) || !isUuidV7(userId)) return null;
    const parts = await this.participations.findByKhatm(khatmId);
    return parts.find((p) => p.userId === userId && p.isActive) ?? null;
  }

  /** DRAFT → ACTIVE. */
  async activateKhatm(id: string): Promise<void> {
    const khatm = await this.requireKhatm(id);
    const next = khatm.activate();
    await this.khatms.transition(khatm.id, khatm.status, next.status);
  }

  /** ACTIVE → COMPLETED. */
  async completeKhatm(id: string): Promise<void> {
    const khatm = await this.requireKhatm(id);
    const next = khatm.complete();
    await this.khatms.transition(khatm.id, khatm.status, next.status);
  }

  /** DRAFT/ACTIVE → CANCELLED. */
  async cancelKhatm(id: string): Promise<void> {
    const khatm = await this.requireKhatm(id);
    const next = khatm.cancel();
    await this.khatms.transition(khatm.id, khatm.status, next.status);
  }

  /**
   * Join a khatm: create an ACTIVE participation for the user. Only an ACTIVE
   * khatm accepts participants; a duplicate active join is rejected by the
   * database index as a {@link
   * import('../domain/khatm.errors').DuplicateParticipationError}.
   */
  async join(khatmId: string, userId: string): Promise<Participation> {
    const khatm = await this.requireKhatm(khatmId);
    if (!khatm.canAcceptParticipants) {
      throw new KhatmNotActiveError();
    }
    const participation = Participation.create({ id: newUuidV7(), khatmId, userId });
    return this.participations.create({
      id: participation.id,
      khatmId: participation.khatmId,
      userId: participation.userId,
    });
  }

  /** ACTIVE participation → COMPLETED. */
  async completeParticipation(id: string): Promise<void> {
    const participation = await this.requireParticipation(id);
    const next = participation.complete();
    await this.participations.transition(participation.id, participation.status, next.status);
  }

  /** ACTIVE participation → LEFT (voluntary). */
  async leaveParticipation(id: string): Promise<void> {
    const participation = await this.requireParticipation(id);
    const next = participation.leave();
    await this.participations.transition(participation.id, participation.status, next.status);
  }

  /** ACTIVE participation → REMOVED (by the creator/an operator). */
  async removeParticipation(id: string): Promise<void> {
    const participation = await this.requireParticipation(id);
    const next = participation.remove();
    await this.participations.transition(participation.id, participation.status, next.status);
  }

  /**
   * Allocate a portion to a participation. The khatm must be able to receive
   * assignments (ACTIVE); the assignment is scoped to the participation's khatm.
   */
  async assignPortion(participationId: string, portion: Portion): Promise<Assignment> {
    const participation = await this.requireParticipation(participationId);
    const khatm = await this.requireKhatm(participation.khatmId);
    if (!khatm.canReceiveAssignments) {
      throw new KhatmNotActiveError();
    }
    const assignment = Assignment.create({
      id: newUuidV7(),
      khatmId: khatm.id,
      participationId: participation.id,
      portion,
    });
    return this.assignments.create({
      id: assignment.id,
      khatmId: assignment.khatmId,
      participationId: assignment.participationId,
      portion: assignment.portion,
    });
  }

  /** PENDING assignment → COMPLETED, stamped with the completion time. */
  async completeAssignment(id: string): Promise<void> {
    await this.assignments.complete(id, new Date());
  }

  /** Derive a khatm's progress (total assignments and completed count). */
  async khatmProgress(khatmId: string): Promise<KhatmProgress> {
    await this.requireKhatm(khatmId);
    return this.assignments.progressForKhatm(khatmId);
  }

  /** List all khatms (admin use only). */
  async listAllKhatms(limit = 50, offset = 0): Promise<Khatm[]> {
    return this.khatms.listAll(limit, offset);
  }

  /** Total khatm count (admin use only). */
  async countAllKhatms(): Promise<number> {
    return this.khatms.countAll();
  }

  /** Count khatms in ACTIVE status (admin stats). */
  async countActiveKhatms(): Promise<number> {
    return this.khatms.countByStatus('ACTIVE');
  }

  /**
   * Return the khatm's existing public slug, or generate and persist a new one.
   * The slug is a 10-char base58 string derived from a fresh UUIDv7, which gives
   * effectively-unique short URLs without a pre-check loop.
   */
  async getOrCreateInviteSlug(khatmId: string): Promise<string> {
    const khatm = await this.requireKhatm(khatmId);
    if (khatm.publicSlug) return khatm.publicSlug;
    const slug = generateSlug();
    await this.khatms.setPublicSlug(khatmId, slug);
    return slug;
  }

  private async requireKhatm(id: string): Promise<Khatm> {
    const khatm = isUuidV7(id) ? await this.khatms.findById(id) : null;
    if (!khatm) throw new KhatmNotFoundError();
    return khatm;
  }

  private async requireParticipation(id: string): Promise<Participation> {
    const participation = isUuidV7(id) ? await this.participations.findById(id) : null;
    if (!participation) throw new ParticipationNotFoundError();
    return participation;
  }
}

const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const SLUG_LENGTH = 10;

function generateSlug(): string {
  const bytes = new Uint8Array(SLUG_LENGTH);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => BASE58_ALPHABET[b % BASE58_ALPHABET.length])
    .join('');
}
