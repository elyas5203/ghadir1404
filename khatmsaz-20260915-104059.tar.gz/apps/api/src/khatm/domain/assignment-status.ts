/**
 * The lifecycle of an {@link import('./assignment').Assignment} — a DOMAIN-owned
 * concept.
 *
 * PENDING is the state of a freshly allocated portion; COMPLETED marks it as
 * fulfilled and is terminal, carrying a `completedAt`. Reallocation of a portion
 * (when a participant leaves) is a later-phase concern and is deliberately not
 * modelled as a status here (DEC-0049) — no speculative states.
 *
 * The string values intentionally match the persistence enum `assignment_status`.
 */

export const AssignmentStatus = {
  PENDING: 'PENDING',
  COMPLETED: 'COMPLETED',
} as const;

export type AssignmentStatus = (typeof AssignmentStatus)[keyof typeof AssignmentStatus];

export const ALL_ASSIGNMENT_STATUSES: readonly AssignmentStatus[] =
  Object.values(AssignmentStatus);

/** Narrows an unknown value to a known {@link AssignmentStatus}. */
export function isAssignmentStatus(value: unknown): value is AssignmentStatus {
  return (
    typeof value === 'string' && (ALL_ASSIGNMENT_STATUSES as readonly string[]).includes(value)
  );
}
