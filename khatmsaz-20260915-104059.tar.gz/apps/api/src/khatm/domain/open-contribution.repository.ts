import type { OpenContribution } from './open-contribution';

export interface OpenContributionProgress {
  readonly totalContributed: number;
  readonly participantCount: number;
}

export const OPEN_CONTRIBUTION_REPOSITORY = 'OPEN_CONTRIBUTION_REPOSITORY';

export interface OpenContributionRepository {
  create(contribution: OpenContribution): Promise<OpenContribution>;
  findByParticipation(participationId: string): Promise<OpenContribution[]>;
  progressForKhatm(khatmId: string): Promise<OpenContributionProgress>;
}
