import { KhatmError } from './khatm.errors';

export class InvalidContributionAmountError extends KhatmError {
  constructor() {
    super('Contribution amount must be a positive number.');
  }
}

export class ContributionNotFoundError extends KhatmError {
  constructor() {
    super('The referenced contribution does not exist.');
  }
}

export class OpenContributionNotAllowedError extends KhatmError {
  constructor() {
    super('Contributions can only be recorded on OPEN khatms.');
  }
}
