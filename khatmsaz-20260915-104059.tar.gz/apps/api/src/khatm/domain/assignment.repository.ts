/**
 * AssignmentRepository — a persistence port OWNED BY THE DOMAIN.
 *
 * Expressed in domain terms ({@link Assignment}, {@link Portion}, string ids). Its
 * Prisma-backed implementation lives in infrastructure (DEC-0031). Only the
 * operations this phase needs are declared — no speculative methods.
 */

import type { Assignment } from './assignment';
import type { Portion } from './portion';

/** DI token for {@link AssignmentRepository}. */
export const ASSIGNMENT_REPOSITORY = Symbol('ASSIGNMENT_REPOSITORY');

/** Input to allocate a new PENDING assignment. */
export interface CreateAssignmentInput {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly portion: Portion;
}

/** A khatm's assignment progress: total allocated and how many are completed. */
export interface KhatmProgress {
  readonly total: number;
  readonly completed: number;
}

export interface AssignmentRepository {
  /**
   * Allocate a new PENDING assignment. A missing khatm or participation throws
   * {@link import('./khatm.errors').AssignmentTargetNotFoundError}.
   */
  create(input: CreateAssignmentInput): Promise<Assignment>;
  /** Find an assignment by id, or `null` when none exists. */
  findById(id: string): Promise<Assignment | null>;
  /**
   * Mark a PENDING assignment COMPLETED, guarded on it being PENDING. Throws
   * {@link import('./khatm.errors').AssignmentNotPendingError} when no row matches.
   */
  complete(id: string, completedAt: Date): Promise<void>;
  /** Count a khatm's assignments and its completed ones, for progress. */
  progressForKhatm(khatmId: string): Promise<KhatmProgress>;
}
