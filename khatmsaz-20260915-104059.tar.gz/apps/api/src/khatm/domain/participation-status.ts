/**
 * The lifecycle of a {@link import('./participation').Participation} — a
 * DOMAIN-owned concept.
 *
 * ACTIVE is the normal state. COMPLETED, LEFT and REMOVED are terminal and are
 * RETAINED as history (a Participation is never deleted — DEC-0025): a user who
 * LEFT may join again as a new ACTIVE row while the old one remains. At most one
 * ACTIVE participation may exist per (khatm, user); that invariant is enforced by
 * a database partial unique index (DEC-0050), not by these values alone.
 *
 * The string values intentionally match the persistence enum `participation_status`.
 */

export const ParticipationStatus = {
  ACTIVE: 'ACTIVE',
  COMPLETED: 'COMPLETED',
  LEFT: 'LEFT',
  REMOVED: 'REMOVED',
} as const;

export type ParticipationStatus =
  (typeof ParticipationStatus)[keyof typeof ParticipationStatus];

export const ALL_PARTICIPATION_STATUSES: readonly ParticipationStatus[] =
  Object.values(ParticipationStatus);

/** Narrows an unknown value to a known {@link ParticipationStatus}. */
export function isParticipationStatus(value: unknown): value is ParticipationStatus {
  return (
    typeof value === 'string' && (ALL_PARTICIPATION_STATUSES as readonly string[]).includes(value)
  );
}
