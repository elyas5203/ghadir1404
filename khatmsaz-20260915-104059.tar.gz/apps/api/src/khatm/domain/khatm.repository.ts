/**
 * KhatmRepository — a persistence port OWNED BY THE DOMAIN.
 *
 * Expressed in domain terms ({@link Khatm}, string ids, {@link KhatmStatus}). Its
 * Prisma-backed implementation lives in infrastructure and is the only code that
 * sees Prisma types (DEC-0031). Only the operations this phase needs are declared —
 * no speculative methods.
 */

import type { Khatm } from './khatm';
import type { KhatmStatus } from './khatm-status';

/** DI token for {@link KhatmRepository}. */
export const KHATM_REPOSITORY = Symbol('KHATM_REPOSITORY');

export interface KhatmRepository {
  /** Persist a new (DRAFT) khatm. Fails if the creator does not exist. */
  create(khatm: Khatm): Promise<Khatm>;
  /** Find a khatm by id, or `null` when none exists. */
  findById(id: string): Promise<Khatm | null>;
  /** Find a khatm by its public slug (Sprint Phase 05), or `null` when none. */
  findBySlug(slug: string): Promise<Khatm | null>;
  /** List the khatms a user created, newest first (empty when none). */
  findByCreator(creatorUserId: string): Promise<Khatm[]>;
  /**
   * Move a khatm from `from` to `to`, guarded on it currently being in `from`
   * (concurrency-safe; the caller has already validated the transition on the
   * entity). Throws {@link import('./khatm.errors').KhatmNotInExpectedStateError}
   * when no row matches.
   */
  transition(id: string, from: KhatmStatus, to: KhatmStatus): Promise<void>;
  /** List all khatms, newest first. Admin use only. */
  listAll(limit: number, offset: number): Promise<Khatm[]>;
  /** Count all khatms. Admin use only. */
  countAll(): Promise<number>;
  /** Write a public slug onto a khatm row. Throws on duplicate slug. */
  setPublicSlug(id: string, slug: string): Promise<void>;
  /** Count khatms in a given status. */
  countByStatus(status: KhatmStatus): Promise<number>;
}
