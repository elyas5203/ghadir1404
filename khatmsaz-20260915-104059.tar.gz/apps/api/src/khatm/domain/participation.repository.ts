/**
 * ParticipationRepository — a persistence port OWNED BY THE DOMAIN.
 *
 * The "one ACTIVE participation per (khatm, user)" invariant (DEC-0050) is enforced
 * by a database partial unique index, surfaced here as a domain error — never by a
 * pre-check alone, which is what makes concurrent joins safe. Only the operations
 * this phase needs are declared.
 */

import type { Participation } from './participation';
import type { ParticipationStatus } from './participation-status';

/** DI token for {@link ParticipationRepository}. */
export const PARTICIPATION_REPOSITORY = Symbol('PARTICIPATION_REPOSITORY');

/** Input to create a new ACTIVE participation. */
export interface CreateParticipationInput {
  readonly id: string;
  readonly khatmId: string;
  readonly userId: string;
}

export interface ParticipationRepository {
  /**
   * Create a new ACTIVE participation. A concurrent/duplicate active join hits the
   * partial unique index and throws
   * {@link import('./khatm.errors').DuplicateParticipationError}; a missing khatm
   * or user throws
   * {@link import('./khatm.errors').ParticipationTargetNotFoundError}.
   */
  create(input: CreateParticipationInput): Promise<Participation>;
  /** Find a participation by id, or `null` when none exists. */
  findById(id: string): Promise<Participation | null>;
  /** List all participations of a khatm, newest first (empty when none). */
  findByKhatm(khatmId: string): Promise<Participation[]>;
  /** List a user's participations across khatms, newest first (empty when none). */
  findByUser(userId: string): Promise<Participation[]>;
  /**
   * Move a participation from `from` to `to`, guarded on its current status.
   * Throws {@link import('./khatm.errors').ParticipationNotActiveError} when no row
   * matches (it was not in `from`).
   */
  transition(id: string, from: ParticipationStatus, to: ParticipationStatus): Promise<void>;
}
