import {
  QURAN_EDITIONS,
  findQuranEdition,
  SURAHS,
  findSurah,
  isValidSurahNumber,
} from '@khatmsaz/shared';

describe('Quran edition registry (QURAN-001)', () => {
  it('contains at least one edition and every edition has a positive totalPages', () => {
    expect(QURAN_EDITIONS.length).toBeGreaterThan(0);
    for (const ed of QURAN_EDITIONS) {
      expect(ed.totalPages).toBeGreaterThan(0);
    }
  });

  it('findQuranEdition returns the matching edition', () => {
    const ed = findQuranEdition('MADINA_HAFS');
    expect(ed).not.toBeNull();
    expect(ed?.totalPages).toBe(604);
  });

  it('findQuranEdition returns null for an unknown id', () => {
    expect(findQuranEdition('UNKNOWN')).toBeNull();
  });

  it('edition ids are unique', () => {
    const ids = QURAN_EDITIONS.map((e) => e.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe('Surah registry (QURAN-001)', () => {
  it('contains exactly 114 surahs numbered 1–114 sequentially', () => {
    expect(SURAHS).toHaveLength(114);
    SURAHS.forEach((s, idx) => {
      expect(s.number).toBe(idx + 1);
    });
  });

  it('findSurah returns the expected surah', () => {
    const hamd = findSurah(1);
    expect(hamd).not.toBeNull();
    expect(hamd?.number).toBe(1);
    const yasin = findSurah(36);
    expect(yasin?.nameFa).toBe('یس');
  });

  it('findSurah returns null for out-of-range numbers', () => {
    expect(findSurah(0)).toBeNull();
    expect(findSurah(115)).toBeNull();
  });

  it('isValidSurahNumber accepts 1–114 and rejects everything else', () => {
    expect(isValidSurahNumber(1)).toBe(true);
    expect(isValidSurahNumber(114)).toBe(true);
    expect(isValidSurahNumber(0)).toBe(false);
    expect(isValidSurahNumber(115)).toBe(false);
    expect(isValidSurahNumber('36')).toBe(false);
    expect(isValidSurahNumber(null)).toBe(false);
  });
});
