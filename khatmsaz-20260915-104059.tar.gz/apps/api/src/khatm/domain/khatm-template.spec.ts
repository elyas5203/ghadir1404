import {
  KhatmTemplateType,
  ALL_KHATM_TEMPLATE_TYPES,
  isKhatmTemplateType,
} from './khatm-template';

describe('KhatmTemplateType (domain)', () => {
  it('enumerates all seven template types', () => {
    expect(ALL_KHATM_TEMPLATE_TYPES).toEqual([
      'SURAH',
      'QURAN_PAGE',
      'QURAN_SURAH',
      'SALAWAT',
      'DUA',
      'ZIYARAT',
      'CUSTOM',
    ]);
  });

  it('narrows known values and rejects unknown ones', () => {
    expect(isKhatmTemplateType(KhatmTemplateType.SALAWAT)).toBe(true);
    expect(isKhatmTemplateType('SURAH')).toBe(true);
    expect(isKhatmTemplateType('PRAYER')).toBe(false);
    expect(isKhatmTemplateType(42)).toBe(false);
    expect(isKhatmTemplateType(null)).toBe(false);
  });
});
