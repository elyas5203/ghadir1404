/**
 * Participation — a User's membership in a Khatm (DEC-0050); realises the
 * DOMAIN_MODEL "Membership" concept.
 *
 * A user JOINS a Khatm, creating an ACTIVE participation. From ACTIVE it may move
 * to a terminal state:
 *
 *   ACTIVE ── complete ──▶ COMPLETED
 *   ACTIVE ── leave ─────▶ LEFT
 *   ACTIVE ── remove ────▶ REMOVED
 *
 * Terminal participations are RETAINED as history, never deleted (DEC-0025): a user
 * who LEFT may join again as a NEW active participation while the old one remains.
 * At most one ACTIVE participation may exist per (khatm, user) — enforced by a
 * database partial unique index (DEC-0050), not by this entity. Transition methods
 * return a NEW Participation (the entity is immutable). Plain domain object; no
 * Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { ParticipationStatus, isParticipationStatus } from './participation-status';
import {
  InvalidParticipationTransitionError,
  UnknownParticipationStatusError,
} from './khatm.errors';

export interface ParticipationProps {
  readonly id: string;
  readonly khatmId: string;
  readonly userId: string;
  readonly status: ParticipationStatus;
  readonly joinedAt: Date;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** Input to create a brand-new Participation (always born ACTIVE). */
export interface NewParticipationProps {
  readonly id: string;
  readonly khatmId: string;
  readonly userId: string;
}

export class Participation {
  readonly id: string;
  readonly khatmId: string;
  readonly userId: string;
  readonly status: ParticipationStatus;
  readonly joinedAt: Date;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: ParticipationProps) {
    this.id = props.id;
    this.khatmId = props.khatmId;
    this.userId = props.userId;
    this.status = props.status;
    this.joinedAt = props.joinedAt;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  get isActive(): boolean {
    return this.status === ParticipationStatus.ACTIVE;
  }

  /** ACTIVE → COMPLETED. */
  complete(): Participation {
    return this.transitionTo(ParticipationStatus.COMPLETED);
  }

  /** ACTIVE → LEFT (the participant voluntarily left). */
  leave(): Participation {
    return this.transitionTo(ParticipationStatus.LEFT);
  }

  /** ACTIVE → REMOVED (removed by the creator/an operator). */
  remove(): Participation {
    return this.transitionTo(ParticipationStatus.REMOVED);
  }

  private transitionTo(next: ParticipationStatus): Participation {
    if (this.status !== ParticipationStatus.ACTIVE) {
      throw new InvalidParticipationTransitionError(
        `a participation can only leave the ${ParticipationStatus.ACTIVE} state`,
      );
    }
    return new Participation({ ...this, status: next });
  }

  /** Create a brand-new ACTIVE participation. `joinedAt`/timestamps are set by the DB. */
  static create(props: NewParticipationProps): Participation {
    assertUuidV7(props.id, 'Participation.id');
    assertUuidV7(props.khatmId, 'Participation.khatmId');
    assertUuidV7(props.userId, 'Participation.userId');
    const now = new Date();
    return new Participation({
      id: props.id,
      khatmId: props.khatmId,
      userId: props.userId,
      status: ParticipationStatus.ACTIVE,
      joinedAt: now,
      createdAt: now,
      updatedAt: now,
    });
  }

  /**
   * Reconstitute a persisted participation, enforcing its invariants: ids are
   * UUIDv7 and the status is known.
   */
  static restore(props: ParticipationProps): Participation {
    assertUuidV7(props.id, 'Participation.id');
    assertUuidV7(props.khatmId, 'Participation.khatmId');
    assertUuidV7(props.userId, 'Participation.userId');
    if (!isParticipationStatus(props.status)) {
      throw new UnknownParticipationStatusError();
    }
    return new Participation(props);
  }
}
