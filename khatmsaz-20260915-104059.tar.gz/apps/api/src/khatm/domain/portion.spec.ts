import { Portion, AssignmentUnitKind } from './portion';
import { InvalidAssignmentError, UnknownAssignmentUnitKindError } from './khatm.errors';

describe('Portion (domain)', () => {
  describe('positional (e.g. Qur\'an Juz 1-30)', () => {
    it('accepts a valid range and reports its size', () => {
      const p = Portion.positional(1, 30);
      expect(p.kind).toBe(AssignmentUnitKind.POSITIONAL);
      expect(p.unitStart).toBe(1);
      expect(p.unitEnd).toBe(30);
      expect(p.quantity).toBeNull();
      expect(p.isPositional).toBe(true);
      expect(p.size).toBe(30);
    });

    it('accepts a single unit (start === end)', () => {
      expect(Portion.positional(5, 5).size).toBe(1);
    });

    it('rejects start > end', () => {
      expect(() => Portion.positional(10, 3)).toThrow(InvalidAssignmentError);
    });

    it('rejects non-positive or non-integer bounds', () => {
      expect(() => Portion.positional(0, 5)).toThrow(InvalidAssignmentError);
      expect(() => Portion.positional(1, 2.5)).toThrow(InvalidAssignmentError);
    });
  });

  describe('quantity (e.g. 500 Salawat)', () => {
    it('accepts a positive amount', () => {
      const p = Portion.quantity(500);
      expect(p.kind).toBe(AssignmentUnitKind.QUANTITY);
      expect(p.quantity).toBe(500);
      expect(p.unitStart).toBeNull();
      expect(p.unitEnd).toBeNull();
      expect(p.size).toBe(500);
    });

    it('rejects zero, negative, or non-integer amounts', () => {
      expect(() => Portion.quantity(0)).toThrow(InvalidAssignmentError);
      expect(() => Portion.quantity(-3)).toThrow(InvalidAssignmentError);
      expect(() => Portion.quantity(1.5)).toThrow(InvalidAssignmentError);
    });
  });

  describe('restore (from flattened persistence columns)', () => {
    it('round-trips a positional portion', () => {
      const p = Portion.restore({ kind: AssignmentUnitKind.POSITIONAL, unitStart: 2, unitEnd: 4, quantity: null });
      expect(p.size).toBe(3);
    });

    it('round-trips a quantity portion', () => {
      const p = Portion.restore({ kind: AssignmentUnitKind.QUANTITY, unitStart: null, unitEnd: null, quantity: 12 });
      expect(p.quantity).toBe(12);
    });

    it('rejects mixed columns (positional carrying a quantity)', () => {
      expect(() =>
        Portion.restore({ kind: AssignmentUnitKind.POSITIONAL, unitStart: 1, unitEnd: 2, quantity: 9 }),
      ).toThrow(InvalidAssignmentError);
    });

    it('rejects a quantity portion carrying positional bounds', () => {
      expect(() =>
        Portion.restore({ kind: AssignmentUnitKind.QUANTITY, unitStart: 1, unitEnd: null, quantity: 9 }),
      ).toThrow(InvalidAssignmentError);
    });

    it('rejects an unknown unit kind', () => {
      expect(() =>
        Portion.restore({ kind: 'WEIRD' as AssignmentUnitKind, unitStart: null, unitEnd: null, quantity: 1 }),
      ).toThrow(UnknownAssignmentUnitKindError);
    });
  });
});
