/**
 * Khatm — the core aggregate of KhatmSaz (DEC-0048).
 *
 * A Khatm is a collective recitation effort: a creator defines a content target
 * from a template, participants join, and portions of the content are assigned to
 * them. This entity owns the Khatm's identity, ownership, template classification,
 * and — crucially — its LIFECYCLE rules:
 *
 *   DRAFT ── activate ──▶ ACTIVE ── complete ──▶ COMPLETED (terminal)
 *     │                     │
 *     └──── cancel ─────────┴──── cancel ──────▶ CANCELLED (terminal)
 *
 * Only an ACTIVE Khatm accepts participants and assignments (`canAcceptParticipants`
 * / `canReceiveAssignments`); COMPLETED and CANCELLED are terminal and reject any
 * further transition. Creator ownership (`creatorUserId`) is fixed at creation and
 * never changes here. Transition methods return a NEW Khatm (the entity is
 * immutable) and throw {@link InvalidKhatmTransitionError} for an illegal move, so
 * the lifecycle is expressed and tested in the domain, not scattered across
 * services. Plain domain object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { KhatmStatus, isKhatmStatus } from './khatm-status';
import { KhatmTemplateType, isKhatmTemplateType } from './khatm-template';
import { KhatmType, isKhatmType } from './khatm-type';
import {
  InvalidKhatmTitleError,
  InvalidKhatmTransitionError,
  UnknownKhatmStatusError,
  UnknownKhatmTemplateTypeError,
  UnknownKhatmTypeError,
} from './khatm.errors';

export interface KhatmProps {
  readonly id: string;
  readonly creatorUserId: string;
  readonly title: string;
  readonly description: string | null;
  readonly templateType: KhatmTemplateType;
  readonly khatmType: KhatmType;
  readonly status: KhatmStatus;
  /** QURAN_PAGE only: references the static QuranEdition registry (QURAN-001). */
  readonly quranEditionId: string | null;
  /** QURAN_SURAH only: surah number 1–114 (QURAN-001). */
  readonly surahNumber: number | null;
  /** QURAN_SURAH only: collective repetition target ≥ 1 (QURAN-001). */
  readonly repetitionTarget: number | null;
  /** Sprint Phase 05: URL-safe public slug for sharing. Null until set by creator. */
  readonly publicSlug?: string | null;
  /** Sprint Phase 05: organizer's recitation intention (نیت). */
  readonly niyyat?: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** Input to create a brand-new Khatm (always born DRAFT). */
export interface NewKhatmProps {
  readonly id: string;
  readonly creatorUserId: string;
  readonly title: string;
  readonly description?: string | null;
  readonly templateType: KhatmTemplateType;
  readonly khatmType: KhatmType;
  readonly quranEditionId?: string | null;
  readonly surahNumber?: number | null;
  readonly repetitionTarget?: number | null;
}

/**
 * Normalise a raw title: trim surrounding whitespace and reject an empty value.
 * Returns the cleaned title or throws {@link InvalidKhatmTitleError}. (No maximum
 * length is imposed here — a content limit is a product rule, not invented at this
 * foundation.)
 */
export function requireTitle(raw: string): string {
  const trimmed = typeof raw === 'string' ? raw.trim() : '';
  if (trimmed.length === 0) {
    throw new InvalidKhatmTitleError();
  }
  return trimmed;
}

/** Normalise an optional description: trim, and treat blank as absent (null). */
export function normaliseDescription(raw: string | null | undefined): string | null {
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  return trimmed.length === 0 ? null : trimmed;
}

export class Khatm {
  readonly id: string;
  readonly creatorUserId: string;
  readonly title: string;
  readonly description: string | null;
  readonly templateType: KhatmTemplateType;
  readonly khatmType: KhatmType;
  readonly status: KhatmStatus;
  readonly quranEditionId: string | null;
  readonly surahNumber: number | null;
  readonly repetitionTarget: number | null;
  readonly publicSlug: string | null;
  readonly niyyat: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: KhatmProps) {
    this.id = props.id;
    this.creatorUserId = props.creatorUserId;
    this.title = props.title;
    this.description = props.description;
    this.templateType = props.templateType;
    this.khatmType = props.khatmType;
    this.status = props.status;
    this.quranEditionId = props.quranEditionId;
    this.surahNumber = props.surahNumber;
    this.repetitionTarget = props.repetitionTarget;
    this.publicSlug = props.publicSlug ?? null;
    this.niyyat = props.niyyat ?? null;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  get isActive(): boolean {
    return this.status === KhatmStatus.ACTIVE;
  }

  get isTerminal(): boolean {
    return this.status === KhatmStatus.COMPLETED || this.status === KhatmStatus.CANCELLED;
  }

  /** Only an ACTIVE khatm accepts new participants (task rule). */
  get canAcceptParticipants(): boolean {
    return this.status === KhatmStatus.ACTIVE;
  }

  /** A completed/cancelled khatm cannot receive new assignments (task rule). */
  get canReceiveAssignments(): boolean {
    return this.status === KhatmStatus.ACTIVE;
  }

  /** DRAFT → ACTIVE. Throws for any other current status. */
  activate(): Khatm {
    return this.transitionTo(KhatmStatus.ACTIVE, [KhatmStatus.DRAFT]);
  }

  /** ACTIVE → COMPLETED. Throws for any other current status. */
  complete(): Khatm {
    return this.transitionTo(KhatmStatus.COMPLETED, [KhatmStatus.ACTIVE]);
  }

  /** DRAFT/ACTIVE → CANCELLED. Throws once terminal. */
  cancel(): Khatm {
    return this.transitionTo(KhatmStatus.CANCELLED, [KhatmStatus.DRAFT, KhatmStatus.ACTIVE]);
  }

  private transitionTo(next: KhatmStatus, allowedFrom: readonly KhatmStatus[]): Khatm {
    if (!allowedFrom.includes(this.status)) {
      throw new InvalidKhatmTransitionError(this.status, next);
    }
    return new Khatm({ ...this, status: next });
  }

  /**
   * Create a brand-new Khatm in DRAFT. Validates the id, creator id, title and
   * template; `createdAt`/`updatedAt` are placeholders here and are authoritatively
   * set by the database on insert.
   */
  static create(props: NewKhatmProps): Khatm {
    assertUuidV7(props.id, 'Khatm.id');
    assertUuidV7(props.creatorUserId, 'Khatm.creatorUserId');
    if (!isKhatmTemplateType(props.templateType)) {
      throw new UnknownKhatmTemplateTypeError();
    }
    if (!isKhatmType(props.khatmType)) {
      throw new UnknownKhatmTypeError();
    }
    const now = new Date();
    return new Khatm({
      id: props.id,
      creatorUserId: props.creatorUserId,
      title: requireTitle(props.title),
      description: normaliseDescription(props.description),
      templateType: props.templateType,
      khatmType: props.khatmType,
      status: KhatmStatus.DRAFT,
      quranEditionId: props.quranEditionId ?? null,
      surahNumber: props.surahNumber ?? null,
      repetitionTarget: props.repetitionTarget ?? null,
      publicSlug: null,
      niyyat: null,
      createdAt: now,
      updatedAt: now,
    });
  }

  /**
   * Reconstitute a persisted Khatm, enforcing its invariants: ids are UUIDv7, the
   * title is non-empty, and the template and status are known. The domain never
   * trusts stored state blindly.
   */
  static restore(props: KhatmProps): Khatm {
    assertUuidV7(props.id, 'Khatm.id');
    assertUuidV7(props.creatorUserId, 'Khatm.creatorUserId');
    if (!isKhatmTemplateType(props.templateType)) {
      throw new UnknownKhatmTemplateTypeError();
    }
    if (!isKhatmType(props.khatmType)) {
      throw new UnknownKhatmTypeError();
    }
    if (!isKhatmStatus(props.status)) {
      throw new UnknownKhatmStatusError();
    }
    return new Khatm({
      ...props,
      title: requireTitle(props.title),
      description: normaliseDescription(props.description),
      quranEditionId: props.quranEditionId ?? null,
      surahNumber: props.surahNumber ?? null,
      repetitionTarget: props.repetitionTarget ?? null,
      publicSlug: props.publicSlug ?? null,
      niyyat: props.niyyat ?? null,
    });
  }
}
