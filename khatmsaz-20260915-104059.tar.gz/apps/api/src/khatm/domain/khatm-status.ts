/**
 * The lifecycle of a Khatm — a DOMAIN-owned concept.
 *
 * A Khatm moves DRAFT → ACTIVE → COMPLETED, or is CANCELLED from DRAFT/ACTIVE.
 * COMPLETED and CANCELLED are terminal. Only an ACTIVE Khatm accepts participants
 * and assignments; the transition rules themselves live on the {@link
 * import('./khatm').Khatm} entity. The string values intentionally match the
 * persistence enum `khatm_status` so mapping is a straight pass-through, but
 * nothing outside infrastructure depends on the Prisma-generated enum.
 */

export const KhatmStatus = {
  DRAFT: 'DRAFT',
  ACTIVE: 'ACTIVE',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',
} as const;

export type KhatmStatus = (typeof KhatmStatus)[keyof typeof KhatmStatus];

export const ALL_KHATM_STATUSES: readonly KhatmStatus[] = Object.values(KhatmStatus);

/** Narrows an unknown value to a known {@link KhatmStatus}. */
export function isKhatmStatus(value: unknown): value is KhatmStatus {
  return typeof value === 'string' && (ALL_KHATM_STATUSES as readonly string[]).includes(value);
}
