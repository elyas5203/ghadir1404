/**
 * Assignment — a unit of content ({@link Portion}) allocated to a participant
 * within a Khatm (DEC-0049).
 *
 * An Assignment BELONGS TO A PARTICIPATION (`participationId`) and is scoped to its
 * Khatm (`khatmId`, always the participation's khatm). Its completion is tracked as
 * a simple lifecycle: PENDING → COMPLETED (terminal), the completion carrying a
 * `completedAt`. Progress for a Khatm is derivable by counting its assignments and
 * how many are COMPLETED — no separate progress field is stored.
 *
 * Reallocation of a portion (when a participant leaves) and reminders are LATER
 * phases and are deliberately absent here (DEC-0049). Plain domain object; no
 * Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { AssignmentStatus, isAssignmentStatus } from './assignment-status';
import { Portion } from './portion';
import { InvalidAssignmentError, UnknownAssignmentStatusError } from './khatm.errors';

export interface AssignmentProps {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly portion: Portion;
  readonly status: AssignmentStatus;
  readonly completedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** Input to allocate a brand-new Assignment (always born PENDING). */
export interface NewAssignmentProps {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly portion: Portion;
}

export class Assignment {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly portion: Portion;
  readonly status: AssignmentStatus;
  readonly completedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: AssignmentProps) {
    this.id = props.id;
    this.khatmId = props.khatmId;
    this.participationId = props.participationId;
    this.portion = props.portion;
    this.status = props.status;
    this.completedAt = props.completedAt;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  get isPending(): boolean {
    return this.status === AssignmentStatus.PENDING;
  }

  get isCompleted(): boolean {
    return this.status === AssignmentStatus.COMPLETED;
  }

  /**
   * PENDING → COMPLETED. Returns a new Assignment carrying `completedAt`; throws
   * {@link InvalidAssignmentError} if it is not currently PENDING.
   */
  complete(completedAt: Date): Assignment {
    if (this.status !== AssignmentStatus.PENDING) {
      throw new InvalidAssignmentError('only a pending assignment can be completed');
    }
    return new Assignment({ ...this, status: AssignmentStatus.COMPLETED, completedAt });
  }

  /** Allocate a brand-new Assignment in PENDING. Validates ids and the portion. */
  static create(props: NewAssignmentProps): Assignment {
    assertUuidV7(props.id, 'Assignment.id');
    assertUuidV7(props.khatmId, 'Assignment.khatmId');
    assertUuidV7(props.participationId, 'Assignment.participationId');
    const now = new Date();
    return new Assignment({
      id: props.id,
      khatmId: props.khatmId,
      participationId: props.participationId,
      portion: props.portion,
      status: AssignmentStatus.PENDING,
      completedAt: null,
      createdAt: now,
      updatedAt: now,
    });
  }

  /**
   * Reconstitute a persisted Assignment, enforcing its invariants: ids are UUIDv7,
   * the status is known, and a COMPLETED assignment carries a `completedAt` (the
   * lifecycle stays internally consistent).
   */
  static restore(props: AssignmentProps): Assignment {
    assertUuidV7(props.id, 'Assignment.id');
    assertUuidV7(props.khatmId, 'Assignment.khatmId');
    assertUuidV7(props.participationId, 'Assignment.participationId');
    if (!isAssignmentStatus(props.status)) {
      throw new UnknownAssignmentStatusError();
    }
    if (props.status === AssignmentStatus.COMPLETED && !props.completedAt) {
      throw new InvalidAssignmentError('a completed assignment requires completedAt');
    }
    return new Assignment(props);
  }
}
