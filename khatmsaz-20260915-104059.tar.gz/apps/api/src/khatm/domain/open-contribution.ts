/**
 * OpenContribution — a participant's freely-recorded contribution to an OPEN khatm.
 *
 * OPEN khatms have no mandatory portion allocation. Participants may record one or
 * more contributions (e.g. "I read 50 pages today"). Progress is the aggregate sum
 * of all contributions. Plain domain object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { InvalidContributionAmountError } from './contribution.errors';

export interface OpenContributionProps {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly amount: number;
  readonly note: string | null;
  readonly recordedAt: Date;
  readonly createdAt: Date;
}

export interface NewOpenContributionProps {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly amount: number;
  readonly note?: string | null;
}

export class OpenContribution {
  readonly id: string;
  readonly khatmId: string;
  readonly participationId: string;
  readonly amount: number;
  readonly note: string | null;
  readonly recordedAt: Date;
  readonly createdAt: Date;

  private constructor(props: OpenContributionProps) {
    this.id = props.id;
    this.khatmId = props.khatmId;
    this.participationId = props.participationId;
    this.amount = props.amount;
    this.note = props.note;
    this.recordedAt = props.recordedAt;
    this.createdAt = props.createdAt;
  }

  static create(props: NewOpenContributionProps): OpenContribution {
    assertUuidV7(props.id, 'OpenContribution.id');
    assertUuidV7(props.khatmId, 'OpenContribution.khatmId');
    assertUuidV7(props.participationId, 'OpenContribution.participationId');
    if (!Number.isFinite(props.amount) || props.amount <= 0) {
      throw new InvalidContributionAmountError();
    }
    const now = new Date();
    return new OpenContribution({
      id: props.id,
      khatmId: props.khatmId,
      participationId: props.participationId,
      amount: props.amount,
      note: typeof props.note === 'string' && props.note.trim().length > 0
        ? props.note.trim()
        : null,
      recordedAt: now,
      createdAt: now,
    });
  }

  static restore(props: OpenContributionProps): OpenContribution {
    assertUuidV7(props.id, 'OpenContribution.id');
    assertUuidV7(props.khatmId, 'OpenContribution.khatmId');
    assertUuidV7(props.participationId, 'OpenContribution.participationId');
    return new OpenContribution(props);
  }
}
