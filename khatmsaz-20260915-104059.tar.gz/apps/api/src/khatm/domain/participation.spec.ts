import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { Participation } from './participation';
import { ParticipationStatus } from './participation-status';
import {
  InvalidParticipationTransitionError,
  UnknownParticipationStatusError,
} from './khatm.errors';

const newActive = () =>
  Participation.create({ id: newUuidV7(), khatmId: newUuidV7(), userId: newUuidV7() });

describe('Participation (domain)', () => {
  it('is born ACTIVE with a joinedAt', () => {
    const p = newActive();
    expect(p.status).toBe(ParticipationStatus.ACTIVE);
    expect(p.isActive).toBe(true);
    expect(p.joinedAt).toBeInstanceOf(Date);
  });

  it('rejects non-UUIDv7 ids', () => {
    expect(() =>
      Participation.create({ id: 'x', khatmId: newUuidV7(), userId: newUuidV7() }),
    ).toThrow(InvalidUuidV7Error);
  });

  describe('transitions from ACTIVE', () => {
    it('complete() → COMPLETED', () => {
      expect(newActive().complete().status).toBe(ParticipationStatus.COMPLETED);
    });
    it('leave() → LEFT', () => {
      expect(newActive().leave().status).toBe(ParticipationStatus.LEFT);
    });
    it('remove() → REMOVED', () => {
      expect(newActive().remove().status).toBe(ParticipationStatus.REMOVED);
    });
    it('does not mutate the original (immutable)', () => {
      const p = newActive();
      p.leave();
      expect(p.status).toBe(ParticipationStatus.ACTIVE);
    });
  });

  describe('invalid transitions', () => {
    it('a terminal participation cannot transition again', () => {
      const left = newActive().leave();
      expect(() => left.complete()).toThrow(InvalidParticipationTransitionError);
      expect(() => left.remove()).toThrow(InvalidParticipationTransitionError);
      const completed = newActive().complete();
      expect(() => completed.leave()).toThrow(InvalidParticipationTransitionError);
    });
  });

  describe('restore', () => {
    it('rejects an unknown status', () => {
      const now = new Date();
      expect(() =>
        Participation.restore({
          id: newUuidV7(),
          khatmId: newUuidV7(),
          userId: newUuidV7(),
          status: 'NOPE' as ParticipationStatus,
          joinedAt: now,
          createdAt: now,
          updatedAt: now,
        }),
      ).toThrow(UnknownParticipationStatusError);
    });
  });
});
