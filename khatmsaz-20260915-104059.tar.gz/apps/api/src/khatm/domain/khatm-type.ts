/**
 * KhatmType — whether participation is commitment-based (each participant is
 * assigned mandatory portions) or open (participants contribute freely, no
 * mandatory allocation). (DEC-0071)
 */

export const KhatmType = {
  /** Participants are assigned specific portions; progress tracks assignments. */
  COMMITMENT: 'COMMITMENT',
  /** Participants contribute freely; progress aggregates recorded contributions. */
  OPEN: 'OPEN',
} as const;

export type KhatmType = (typeof KhatmType)[keyof typeof KhatmType];

export const ALL_KHATM_TYPES: readonly KhatmType[] = Object.values(KhatmType);

export function isKhatmType(value: unknown): value is KhatmType {
  return typeof value === 'string' && (ALL_KHATM_TYPES as readonly string[]).includes(value);
}
