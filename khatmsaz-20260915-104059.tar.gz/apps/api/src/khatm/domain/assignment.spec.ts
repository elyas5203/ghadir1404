import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { Assignment } from './assignment';
import { AssignmentStatus } from './assignment-status';
import { Portion } from './portion';
import { InvalidAssignmentError, UnknownAssignmentStatusError } from './khatm.errors';

const newPending = (portion = Portion.positional(1, 1)) =>
  Assignment.create({
    id: newUuidV7(),
    khatmId: newUuidV7(),
    participationId: newUuidV7(),
    portion,
  });

describe('Assignment (domain)', () => {
  it('is born PENDING with no completedAt and belongs to a participation', () => {
    const a = newPending();
    expect(a.status).toBe(AssignmentStatus.PENDING);
    expect(a.isPending).toBe(true);
    expect(a.completedAt).toBeNull();
    expect(a.participationId).toBeDefined();
  });

  it('carries its portion (both families)', () => {
    expect(newPending(Portion.positional(1, 30)).portion.size).toBe(30);
    expect(newPending(Portion.quantity(1000)).portion.quantity).toBe(1000);
  });

  it('rejects non-UUIDv7 ids', () => {
    expect(() =>
      Assignment.create({ id: 'x', khatmId: newUuidV7(), participationId: newUuidV7(), portion: Portion.quantity(1) }),
    ).toThrow(InvalidUuidV7Error);
  });

  describe('completion', () => {
    it('PENDING → COMPLETED stamps completedAt', () => {
      const at = new Date();
      const done = newPending().complete(at);
      expect(done.status).toBe(AssignmentStatus.COMPLETED);
      expect(done.completedAt).toBe(at);
      expect(done.isCompleted).toBe(true);
    });

    it('does not mutate the original (immutable)', () => {
      const a = newPending();
      a.complete(new Date());
      expect(a.status).toBe(AssignmentStatus.PENDING);
    });

    it('cannot complete an already completed assignment', () => {
      const done = newPending().complete(new Date());
      expect(() => done.complete(new Date())).toThrow(InvalidAssignmentError);
    });
  });

  describe('restore', () => {
    it('rejects a COMPLETED assignment with no completedAt', () => {
      const now = new Date();
      expect(() =>
        Assignment.restore({
          id: newUuidV7(),
          khatmId: newUuidV7(),
          participationId: newUuidV7(),
          portion: Portion.quantity(3),
          status: AssignmentStatus.COMPLETED,
          completedAt: null,
          createdAt: now,
          updatedAt: now,
        }),
      ).toThrow(InvalidAssignmentError);
    });

    it('rejects an unknown status', () => {
      const now = new Date();
      expect(() =>
        Assignment.restore({
          id: newUuidV7(),
          khatmId: newUuidV7(),
          participationId: newUuidV7(),
          portion: Portion.quantity(3),
          status: 'NOPE' as AssignmentStatus,
          completedAt: null,
          createdAt: now,
          updatedAt: now,
        }),
      ).toThrow(UnknownAssignmentStatusError);
    });
  });
});
