/**
 * Portion — the unit of content allocated to a participant, as a DOMAIN value
 * object (DEC-0049).
 *
 * KhatmSaz content divides in two generic ways, and a Portion expresses both
 * without a class or table per template type:
 *
 *   - POSITIONAL — a discrete, identifiable range within a fixed structure, e.g.
 *     Qur'an Juz 1-30 (or a single Juz 5, where `unitStart === unitEnd`). The
 *     range identifies WHICH portion, so the engine can avoid handing the same Juz
 *     to two people. `unitStart`/`unitEnd` are positive integers, start ≤ end.
 *   - QUANTITY — a count of repetitions with no positional identity, e.g. 500
 *     Salawat. `quantity` is a positive integer.
 *
 * Exactly one shape is populated. This value object deliberately does NOT know how
 * many units a given template has (how many Juz, how a count is split) — that is
 * the allocation engine's job in a later phase, so no per-template rule is invented
 * here. Plain domain object; no Prisma or framework dependency.
 */

import {
  InvalidAssignmentError,
  UnknownAssignmentUnitKindError,
} from './khatm.errors';

/** How a {@link Portion} is expressed. Mirrors the persistence enum `assignment_unit_kind`. */
export const AssignmentUnitKind = {
  POSITIONAL: 'POSITIONAL',
  QUANTITY: 'QUANTITY',
} as const;

export type AssignmentUnitKind = (typeof AssignmentUnitKind)[keyof typeof AssignmentUnitKind];

export const ALL_ASSIGNMENT_UNIT_KINDS: readonly AssignmentUnitKind[] =
  Object.values(AssignmentUnitKind);

export function isAssignmentUnitKind(value: unknown): value is AssignmentUnitKind {
  return (
    typeof value === 'string' && (ALL_ASSIGNMENT_UNIT_KINDS as readonly string[]).includes(value)
  );
}

/** The flattened persistence shape of a Portion (nullable columns per kind). */
export interface PortionProps {
  readonly kind: AssignmentUnitKind;
  readonly unitStart: number | null;
  readonly unitEnd: number | null;
  readonly quantity: number | null;
}

function isPositiveInt(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 1;
}

export class Portion {
  readonly kind: AssignmentUnitKind;
  readonly unitStart: number | null;
  readonly unitEnd: number | null;
  readonly quantity: number | null;

  private constructor(props: PortionProps) {
    this.kind = props.kind;
    this.unitStart = props.unitStart;
    this.unitEnd = props.unitEnd;
    this.quantity = props.quantity;
  }

  /** True when this portion identifies a positional range (e.g. Juz 1-30). */
  get isPositional(): boolean {
    return this.kind === AssignmentUnitKind.POSITIONAL;
  }

  /**
   * How many units the portion covers: for POSITIONAL, the inclusive span
   * (`unitEnd - unitStart + 1`); for QUANTITY, the count. A convenience for later
   * progress weighting — the foundation does not depend on it.
   */
  get size(): number {
    return this.kind === AssignmentUnitKind.POSITIONAL
      ? (this.unitEnd as number) - (this.unitStart as number) + 1
      : (this.quantity as number);
  }

  /** A positional range, e.g. `Portion.positional(1, 30)` for Juz 1-30. */
  static positional(unitStart: number, unitEnd: number): Portion {
    if (!isPositiveInt(unitStart) || !isPositiveInt(unitEnd)) {
      throw new InvalidAssignmentError('a positional portion needs positive integer bounds');
    }
    if (unitStart > unitEnd) {
      throw new InvalidAssignmentError('a positional portion must have unitStart <= unitEnd');
    }
    return new Portion({ kind: AssignmentUnitKind.POSITIONAL, unitStart, unitEnd, quantity: null });
  }

  /** A count-based amount, e.g. `Portion.quantity(500)` for 500 Salawat. */
  static quantity(amount: number): Portion {
    if (!isPositiveInt(amount)) {
      throw new InvalidAssignmentError('a quantity portion needs a positive integer amount');
    }
    return new Portion({
      kind: AssignmentUnitKind.QUANTITY,
      unitStart: null,
      unitEnd: null,
      quantity: amount,
    });
  }

  /**
   * Reconstitute a portion from its flattened persistence columns, enforcing that
   * exactly the fields for its kind are populated and valid.
   */
  static restore(props: PortionProps): Portion {
    if (!isAssignmentUnitKind(props.kind)) {
      throw new UnknownAssignmentUnitKindError();
    }
    if (props.kind === AssignmentUnitKind.POSITIONAL) {
      if (props.quantity !== null) {
        throw new InvalidAssignmentError('a positional portion must not carry a quantity');
      }
      return Portion.positional(props.unitStart as number, props.unitEnd as number);
    }
    if (props.unitStart !== null || props.unitEnd !== null) {
      throw new InvalidAssignmentError('a quantity portion must not carry positional bounds');
    }
    return Portion.quantity(props.quantity as number);
  }
}
