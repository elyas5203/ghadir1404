/**
 * Domain errors for the Khatm capability.
 *
 * These are framework- and Prisma-independent. Infrastructure repositories
 * translate persistence failures (unique / foreign-key violations, guarded
 * updates that match no row) into these domain errors so nothing outside
 * infrastructure sees a Prisma error type. Messages never include user-supplied
 * free text (a title, a description) or any credential.
 */

import type { KhatmStatus } from './khatm-status';

/** Base class for all Khatm domain errors. */
export class KhatmError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A Khatm title was missing or blank. */
export class InvalidKhatmTitleError extends KhatmError {
  constructor() {
    super('Invalid khatm: a non-empty title is required.');
  }
}

/** An unknown Khatm template type was supplied. */
export class UnknownKhatmTemplateTypeError extends KhatmError {
  constructor() {
    super('Invalid khatm: unknown template type.');
  }
}

/** An unknown Khatm type was supplied. */
export class UnknownKhatmTypeError extends KhatmError {
  constructor() {
    super('Invalid khatm: unknown khatm type.');
  }
}

/** An unknown Khatm lifecycle status was supplied. */
export class UnknownKhatmStatusError extends KhatmError {
  constructor() {
    super('Invalid khatm: unknown status.');
  }
}

/** An illegal Khatm lifecycle transition was attempted. */
export class InvalidKhatmTransitionError extends KhatmError {
  constructor(from: KhatmStatus, to: KhatmStatus) {
    super(`Invalid khatm transition: cannot move from ${from} to ${to}.`);
  }
}

/**
 * A guarded Khatm status update matched no row: the Khatm was not in the status
 * the caller expected (it was changed concurrently, or does not exist).
 */
export class KhatmNotInExpectedStateError extends KhatmError {
  constructor() {
    super('The khatm is not in the expected state.');
  }
}

/** Creating a Khatm failed because the referenced creator does not exist. */
export class KhatmCreatorNotFoundError extends KhatmError {
  constructor() {
    super('Cannot create khatm: the referenced creator does not exist.');
  }
}

/** An operation required an ACTIVE Khatm (accepting participants/assignments). */
export class KhatmNotActiveError extends KhatmError {
  constructor() {
    super('The khatm is not active and cannot accept participants or assignments.');
  }
}

/** A referenced Khatm does not exist. */
export class KhatmNotFoundError extends KhatmError {
  constructor() {
    super('The referenced khatm does not exist.');
  }
}

/** A Participation's fields were internally inconsistent. */
export class InvalidParticipationError extends KhatmError {
  constructor(reason: string) {
    super(`Invalid participation: ${reason}.`);
  }
}

/** An unknown Participation status was supplied. */
export class UnknownParticipationStatusError extends KhatmError {
  constructor() {
    super('Invalid participation: unknown status.');
  }
}

/** An illegal Participation lifecycle transition was attempted. */
export class InvalidParticipationTransitionError extends KhatmError {
  constructor(reason: string) {
    super(`Invalid participation transition: ${reason}.`);
  }
}

/**
 * The (khatm, user) pair already has an ACTIVE participation. Raised when a
 * concurrent or repeated join hits the database partial unique index (DEC-0050) —
 * a user may hold at most one ACTIVE participation in a given khatm.
 */
export class DuplicateParticipationError extends KhatmError {
  constructor() {
    super('This user already has an active participation in the khatm.');
  }
}

/**
 * A guarded Participation status update matched no row: it was not ACTIVE (it was
 * changed concurrently, or does not exist).
 */
export class ParticipationNotActiveError extends KhatmError {
  constructor() {
    super('The participation is not active.');
  }
}

/** Joining failed because the referenced khatm or user does not exist. */
export class ParticipationTargetNotFoundError extends KhatmError {
  constructor() {
    super('Cannot join: the referenced khatm or user does not exist.');
  }
}

/** A referenced Participation does not exist. */
export class ParticipationNotFoundError extends KhatmError {
  constructor() {
    super('The referenced participation does not exist.');
  }
}

/** An Assignment's portion or fields were internally inconsistent. */
export class InvalidAssignmentError extends KhatmError {
  constructor(reason: string) {
    super(`Invalid assignment: ${reason}.`);
  }
}

/** An unknown Assignment status was supplied. */
export class UnknownAssignmentStatusError extends KhatmError {
  constructor() {
    super('Invalid assignment: unknown status.');
  }
}

/** An unknown Assignment unit kind was supplied. */
export class UnknownAssignmentUnitKindError extends KhatmError {
  constructor() {
    super('Invalid assignment: unknown unit kind.');
  }
}

/**
 * A guarded Assignment completion matched no row: it was not PENDING (already
 * completed, or does not exist).
 */
export class AssignmentNotPendingError extends KhatmError {
  constructor() {
    super('The assignment is not pending.');
  }
}

/** Creating an Assignment failed because the referenced khatm or participation does not exist. */
export class AssignmentTargetNotFoundError extends KhatmError {
  constructor() {
    super('Cannot create assignment: the referenced khatm or participation does not exist.');
  }
}
