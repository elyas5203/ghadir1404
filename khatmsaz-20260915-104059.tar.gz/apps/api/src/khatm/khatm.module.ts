import { Module } from '@nestjs/common';
import { KhatmService } from './application/khatm.service';
import { OpenContributionService } from './application/open-contribution.service';
import { KHATM_REPOSITORY } from './domain/khatm.repository';
import { PARTICIPATION_REPOSITORY } from './domain/participation.repository';
import { ASSIGNMENT_REPOSITORY } from './domain/assignment.repository';
import { OPEN_CONTRIBUTION_REPOSITORY } from './domain/open-contribution.repository';
import { PrismaKhatmRepository } from './infrastructure/prisma-khatm.repository';
import { PrismaParticipationRepository } from './infrastructure/prisma-participation.repository';
import { PrismaAssignmentRepository } from './infrastructure/prisma-assignment.repository';
import { PrismaOpenContributionRepository } from './infrastructure/prisma-open-contribution.repository';

/**
 * Khatm capability module — the core business domain of KhatmSaz (Phase 4).
 *
 * Binds the domain-owned persistence ports (Khatm, Participation, Assignment) to
 * their Prisma-backed implementations. The rest of the application depends on
 * {@link KhatmService} and the domain ports; Prisma lives only behind these
 * bindings (DEC-0031). The `@Global` DatabaseModule provides `PrismaService`.
 *
 * This phase deliberately exposes no HTTP controller and no bot surface — it is the
 * domain foundation (aggregate, templates, participation, assignments) only. No
 * reminders, payments, creator roles, or authentication (see ROADMAP Phase 4).
 */
@Module({
  providers: [
    KhatmService,
    OpenContributionService,
    { provide: KHATM_REPOSITORY, useClass: PrismaKhatmRepository },
    { provide: PARTICIPATION_REPOSITORY, useClass: PrismaParticipationRepository },
    { provide: ASSIGNMENT_REPOSITORY, useClass: PrismaAssignmentRepository },
    { provide: OPEN_CONTRIBUTION_REPOSITORY, useClass: PrismaOpenContributionRepository },
  ],
  exports: [KhatmService, OpenContributionService],
})
export class KhatmModule {}
