import { Injectable } from '@nestjs/common';
import { IdentityService } from '../../identity/application/identity.service';
import { KhatmService } from '../../khatm/application/khatm.service';
import type { Khatm } from '../../khatm/domain/khatm';
import type { KhatmTemplateType } from '../../khatm/domain/khatm-template';
import { KhatmType } from '../../khatm/domain/khatm-type';
import type { Participation } from '../../khatm/domain/participation';
import {
  KhatmNotFoundError,
  ParticipationNotFoundError,
} from '../../khatm/domain/khatm.errors';
import { AllocationService } from '../../allocation/application/allocation.service';
import type { AllocationPlan } from '../../allocation/domain/allocation-plan';
import type { PlanPortion } from '../../allocation/domain/plan-portion';
import type { PlanSpec } from '../../allocation/domain/plan-spec';
import type { PortionProgress } from '../../allocation/domain/plan-portion.repository';
import { AuthorizationService } from '../../authorization/application/authorization.service';
import { CapabilityType } from '../../authorization/domain/capability-type';
import { ResourceOwnershipError } from '../../authorization/domain/authorization.errors';
import { WaitingListService } from '../../waiting-list/application/waiting-list.service';
import { NotificationService } from '../../notification/application/notification.service';
import {
  InactiveCreatorError,
  InactiveParticipantError,
  KhatmNotCompletableError,
  KhatmNotConfiguredError,
} from './khatm-workflow.errors';

/** A participation enriched with the user's display name for the management view. */
export interface ParticipationWithProfile {
  readonly participation: Participation;
  readonly displayName: string | null;
}

/** Input to the create-khatm workflow. */
export interface CreateKhatmWorkflowInput {
  readonly creatorUserId: string;
  readonly title: string;
  readonly description?: string | null;
  readonly templateType: KhatmTemplateType;
  readonly khatmType: KhatmType;
  /** QURAN_PAGE only: ID of the static QuranEdition (QURAN-001). */
  readonly quranEditionId?: string | null;
  /** QURAN_SURAH only: surah number 1–114 (QURAN-001). */
  readonly surahNumber?: number | null;
  /** QURAN_SURAH only: collective repetition target ≥ 1 (QURAN-001). */
  readonly repetitionTarget?: number | null;
}

/**
 * Khatm workflow ORCHESTRATION (Phase 4.2, DEC-0054).
 *
 * An application-only orchestration capability — the sanctioned pattern for a
 * use-case spanning capabilities (like `account-merge`): it composes the EXPORTED
 * SERVICES of identity, khatm and allocation and coordinates them, rather than any
 * capability importing another's domain. It adds only the CROSS-CAPABILITY
 * preconditions the individual services cannot own alone (an active creator/joiner,
 * a khatm configured with a plan before activation, completion only when every
 * portion is done); each capability keeps enforcing its own rules and transactions.
 *
 * Phase 7 (DEC-0061/0063) adds AUTHORIZATION here — the layer where "who" (the
 * authenticated principal) meets "what" (the khatm): creating requires the CREATOR
 * capability, and managing a khatm requires ownership (`actingUserId ===
 * khatm.creatorUserId`), closing the Phase-6 IDOR. Authorization ("is the user
 * allowed?") stays out of the domain ("is the action valid?") and out of transport.
 *
 * It introduces NO new persistence and NO transaction of its own: the multi-write
 * steps (plan generation, batch allocation, holder-checked completion) already run
 * inside the allocation capability's `UnitOfWork` (DEC-0044); the orchestrator
 * delegates and never duplicates allocation logic.
 */
@Injectable()
export class KhatmWorkflowService {
  constructor(
    private readonly identity: IdentityService,
    private readonly khatms: KhatmService,
    private readonly allocation: AllocationService,
    private readonly authorization: AuthorizationService,
    private readonly waitingList: WaitingListService,
    private readonly notifications: NotificationService,
  ) {}

  /**
   * Create-khatm flow: the creator must be an ACTIVE user AND hold the CREATOR
   * capability (DEC-0063); then create the khatm in DRAFT. Creator ownership and all
   * lifecycle/domain rules stay inside the khatm capability.
   */
  async createKhatm(input: CreateKhatmWorkflowInput): Promise<Khatm> {
    await this.requireActiveUser(input.creatorUserId, () => new InactiveCreatorError());
    await this.authorization.requireCapability(input.creatorUserId, CapabilityType.CREATOR);
    return this.khatms.createKhatm(input);
  }

  /**
   * Activate-khatm flow: only the khatm's owner may activate (DEC-0063), and it must
   * be configured with a valid allocation plan (≥1 portion, DEC-0055). The DRAFT→
   * ACTIVE transition itself is enforced by the khatm capability.
   */
  async activateKhatm(khatmId: string, actingUserId: string): Promise<void> {
    const khatm = await this.requireKhatmOwner(actingUserId, khatmId);
    // OPEN khatms do not require an allocation plan (DEC-0071).
    if (khatm.khatmType === KhatmType.COMMITMENT) {
      const plan = await this.allocation.findPlan(khatmId);
      if (!plan || plan.totalPortions < 1) {
        throw new KhatmNotConfiguredError();
      }
    }
    await this.khatms.activateKhatm(khatmId);
    await this.notifications.onKhatmActivated(khatmId);
  }

  /**
   * Join-khatm flow: the user must be an ACTIVE user (a merged/tombstoned or unknown
   * user is rejected — DEC-0054). Only an ACTIVE khatm accepts participants and a
   * duplicate active participation is rejected — both enforced by the khatm capability.
   */
  async joinKhatm(khatmId: string, userId: string): Promise<Participation> {
    await this.requireActiveUser(userId, () => new InactiveParticipantError());
    return this.khatms.join(khatmId, userId);
  }

  /**
   * Leave-khatm flow: the participant voluntarily leaves. For COMMITMENT khatms the
   * next person on the waiting list is automatically promoted and joined in their place
   * (FIX A — Sprint 2). The promotion is best-effort; a failure to join the next person
   * does not roll back the cancellation.
   */
  async leaveKhatm(khatmId: string, userId: string): Promise<void> {
    const khatm = await this.khatms.findKhatmById(khatmId);
    if (!khatm) throw new KhatmNotFoundError();
    const participation = await this.khatms.findParticipation(khatmId, userId);
    if (!participation) throw new ParticipationNotFoundError();
    await this.khatms.leaveParticipation(participation.id);
    if (khatm.khatmType === KhatmType.COMMITMENT) {
      const nextUserId = await this.waitingList.promoteNext(khatmId);
      if (nextUserId) {
        await this.khatms.join(khatmId, nextUserId);
      }
    }
  }

  /**
   * Generate-allocation flow: only the khatm's owner may generate its plan
   * (DEC-0063). Delegates to the allocation capability (which validates the khatm is
   * plannable and enforces one plan per khatm) — no allocation logic is duplicated.
   */
  async generateAllocationPlan(
    khatmId: string,
    actingUserId: string,
    spec: PlanSpec,
  ): Promise<AllocationPlan> {
    await this.requireKhatmOwner(actingUserId, khatmId);
    return this.allocation.generatePlan(khatmId, spec);
  }

  /**
   * Allocate open portions to a participant — only the khatm's owner may allocate
   * (DEC-0063). Delegates to the allocation capability, which enforces the khatm is
   * ACTIVE and the participation is active, and guarantees non-overlap.
   */
  async allocatePortions(
    khatmId: string,
    actingUserId: string,
    participationId: string,
    count: number,
  ): Promise<PlanPortion[]> {
    await this.requireKhatmOwner(actingUserId, khatmId);
    return this.allocation.allocateOpenPortions(khatmId, participationId, count);
  }

  /**
   * Complete-portion flow: the assigned holder completes their portion. Only the
   * holder may complete it and a completed portion cannot be completed again — both
   * enforced by the allocation capability (holder check + guarded transition).
   */
  async completePortion(portionId: string, participationId: string): Promise<void> {
    await this.allocation.completeHeldPortion(portionId, participationId);
  }

  /**
   * HTTP-layer completion: resolves the caller's participation in the khatm by
   * userId, then delegates to the holder-checked completion. Throws
   * {@link ParticipationNotFoundError} if the user is not an active participant
   * of this khatm, or {@link import('../../allocation/domain/allocation.errors').PortionNotHeldByParticipationError}
   * if the portion belongs to a different participant.
   */
  async completeMyPortion(khatmId: string, portionId: string, userId: string): Promise<void> {
    const participation = await this.khatms.findParticipation(khatmId, userId);
    if (!participation) throw new ParticipationNotFoundError();
    await this.allocation.completeHeldPortion(portionId, participation.id);
  }

  /**
   * Telegram "Done" button handler (Phase 19): completes ALL ASSIGNED portions the
   * caller holds in this khatm in a single step. Returns the count of portions
   * completed (0 when the user has no ASSIGNED portions — caller should surface a
   * friendly toast rather than an error).
   */
  async completeAllMyPortions(khatmId: string, userId: string): Promise<number> {
    const participation = await this.khatms.findParticipation(khatmId, userId);
    if (!participation) return 0;
    const portions = await this.allocation.listPortionsForParticipation(participation.id);
    const assigned = portions.filter((p) => p.isAssigned);
    for (const p of assigned) {
      await this.allocation.completeHeldPortion(p.id, participation.id);
    }
    return assigned.length;
  }

  /**
   * Complete-khatm flow: only the owner may complete. For COMMITMENT khatms every
   * portion must be done (DEC-0056). For OPEN khatms the creator decides when the
   * khatm is over — there are no portions to check (DEC-0072).
   */
  async completeKhatm(khatmId: string, actingUserId: string): Promise<void> {
    const khatm = await this.requireKhatmOwner(actingUserId, khatmId);
    if (khatm.khatmType === KhatmType.COMMITMENT) {
      const progress = await this.allocation.progress(khatmId);
      if (progress.total < 1 || progress.completed !== progress.total) {
        throw new KhatmNotCompletableError();
      }
    }
    await this.khatms.completeKhatm(khatmId);
  }

  /** Convenience read: the khatm's allocation progress (derived, never stored). */
  async progress(khatmId: string): Promise<PortionProgress> {
    return this.allocation.progress(khatmId);
  }

  /** List a khatm's participations — owner only (creator management view, DEC-0063). */
  async listParticipations(khatmId: string, actingUserId: string): Promise<Participation[]> {
    await this.requireKhatmOwner(actingUserId, khatmId);
    return this.khatms.listParticipations(khatmId);
  }

  /**
   * Participations enriched with each user's display name (Phase 14). The identity
   * lookups run in parallel — one round-trip per participant, acceptable for MVP
   * participant counts.
   */
  async listParticipationsEnriched(
    khatmId: string,
    actingUserId: string,
  ): Promise<ParticipationWithProfile[]> {
    const participations = await this.listParticipations(khatmId, actingUserId);
    return Promise.all(
      participations.map(async (p) => {
        const user = await this.identity.findUserById(p.userId);
        return { participation: p, displayName: user?.displayName ?? null };
      }),
    );
  }

  /** The khatms a user participates in (participant dashboard). */
  async listMyKhatms(userId: string): Promise<Khatm[]> {
    return this.khatms.listKhatmsForParticipant(userId);
  }

  /**
   * Find the caller's active participation in a khatm. Used by contribution and portion
   * endpoints to resolve the participationId from (khatmId, userId).
   * Throws {@link ParticipationNotFoundError} when not found.
   */
  async findMyParticipation(khatmId: string, userId: string): Promise<Participation> {
    const participation = await this.khatms.findParticipation(khatmId, userId);
    if (!participation) {
      throw new ParticipationNotFoundError();
    }
    return participation;
  }

  /**
   * A participant's own portions in a khatm. Returns `[]` when the user is not an
   * active participant — a participant only ever sees their OWN portions.
   */
  async listMyPortions(khatmId: string, userId: string): Promise<PlanPortion[]> {
    const participation = await this.khatms.findParticipation(khatmId, userId);
    if (!participation) return [];
    return this.allocation.listPortionsForParticipation(participation.id);
  }

  private async requireActiveUser(userId: string, error: () => Error): Promise<void> {
    const user = await this.identity.findUserById(userId);
    if (!user || !user.isActive) {
      throw error();
    }
  }

  /**
   * Ownership check for creator-only management (DEC-0063): the khatm must exist and
   * `actingUserId` must be its creator, else a 403 ({@link ResourceOwnershipError}).
   * Returns the khatm so callers can reuse it. A missing khatm is a 404.
   */
  private async requireKhatmOwner(actingUserId: string, khatmId: string): Promise<Khatm> {
    const khatm = await this.khatms.findKhatmById(khatmId);
    if (!khatm) throw new KhatmNotFoundError();
    if (khatm.creatorUserId !== actingUserId) {
      throw new ResourceOwnershipError();
    }
    return khatm;
  }
}
