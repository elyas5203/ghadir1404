import { KhatmWorkflowService } from './khatm-workflow.service';
import type { CreateKhatmWorkflowInput } from './khatm-workflow.service';
import {
  InactiveCreatorError,
  InactiveParticipantError,
  KhatmNotCompletableError,
  KhatmNotConfiguredError,
} from './khatm-workflow.errors';
import { ParticipationNotFoundError } from '../../khatm/domain/khatm.errors';
import type { IdentityService } from '../../identity/application/identity.service';
import type { KhatmService } from '../../khatm/application/khatm.service';
import { KhatmNotFoundError } from '../../khatm/domain/khatm.errors';
import type { AllocationService } from '../../allocation/application/allocation.service';
import type { AuthorizationService } from '../../authorization/application/authorization.service';
import type { WaitingListService } from '../../waiting-list/application/waiting-list.service';
import type { NotificationService } from '../../notification/application/notification.service';
import {
  CapabilityRequiredError,
  ResourceOwnershipError,
} from '../../authorization/domain/authorization.errors';

const KHATM_ID = '018f9a2b-0000-7000-8000-000000000c01';
const USER_ID = '018f9a2b-0000-7000-8000-000000000c02';
const OTHER_USER = '018f9a2b-0000-7000-8000-000000000c03';

/** Build the service over stubs, overriding only the methods a test exercises. */
function make(overrides: {
  identity?: Partial<IdentityService>;
  khatms?: Partial<KhatmService>;
  allocation?: Partial<AllocationService>;
  authorization?: Partial<AuthorizationService>;
  waitingList?: Partial<WaitingListService>;
  notifications?: Partial<NotificationService>;
}): {
  service: KhatmWorkflowService;
  calls: Record<string, unknown[]>;
} {
  const calls: Record<string, unknown[]> = {};
  const record = (name: string, value?: unknown) => {
    calls[name] = (calls[name] ?? []).concat([value]);
  };

  const identity = {
    findUserById: async () => ({ isActive: true }),
    ...overrides.identity,
  } as unknown as IdentityService;

  const khatms = {
    createKhatm: async (input: unknown) => {
      record('createKhatm', input);
      return {} as never;
    },
    // Owned by USER_ID by default, COMMITMENT so plan check applies; others do not.
    findKhatmById: async () => ({ id: KHATM_ID, creatorUserId: USER_ID, khatmType: 'COMMITMENT' } as never),
    activateKhatm: async (id: unknown) => record('activateKhatm', id),
    join: async (khatmId: unknown, userId: unknown) => {
      record('join', { khatmId, userId });
      return {} as never;
    },
    leaveParticipation: async (id: unknown) => record('leaveParticipation', id),
    findParticipation: async () => ({ id: 'participation-1' } as never),
    completeKhatm: async (id: unknown) => record('completeKhatm', id),
    ...overrides.khatms,
  } as unknown as KhatmService;

  const allocation = {
    findPlan: async () => ({ totalPortions: 30 }),
    progress: async () => ({ total: 30, open: 0, assigned: 0, completed: 30 }),
    generatePlan: async () => {
      record('generatePlan');
      return {};
    },
    allocateOpenPortions: async () => {
      record('allocateOpenPortions');
      return [];
    },
    completeHeldPortion: async (portionId: unknown, participationId: unknown) =>
      record('completeHeldPortion', { portionId, participationId }),
    ...overrides.allocation,
  } as unknown as AllocationService;

  const authorization = {
    requireCapability: async () => undefined, // granted by default
    ...overrides.authorization,
  } as unknown as AuthorizationService;

  const waitingList = {
    promoteNext: async (khatmId: unknown) => {
      record('promoteNext', khatmId);
      return null; // no one waiting by default
    },
    ...overrides.waitingList,
  } as unknown as WaitingListService;

  const notifications = {
    onKhatmActivated: async (khatmId: unknown) => record('onKhatmActivated', khatmId),
    onKhatmClosed: async (khatmId: unknown) => record('onKhatmClosed', khatmId),
    ...overrides.notifications,
  } as unknown as NotificationService;

  return {
    service: new KhatmWorkflowService(identity, khatms, allocation, authorization, waitingList, notifications),
    calls,
  };
}

const createInput: CreateKhatmWorkflowInput = {
  creatorUserId: USER_ID,
  title: 'ختم',
  templateType: 'QURAN_FULL' as CreateKhatmWorkflowInput['templateType'],
  khatmType: 'COMMITMENT' as CreateKhatmWorkflowInput['khatmType'],
};

/** An authorization stub that denies the CREATOR capability. */
const denyCreator: Partial<AuthorizationService> = {
  requireCapability: async () => {
    throw new CapabilityRequiredError();
  },
};

describe('KhatmWorkflowService', () => {
  describe('createKhatm', () => {
    it('creates when the creator is active and holds CREATOR', async () => {
      const { service, calls } = make({});
      await service.createKhatm(createInput);
      expect(calls.createKhatm).toHaveLength(1);
    });

    it('rejects a merged/inactive creator', async () => {
      const { service, calls } = make({ identity: { findUserById: async () => ({ isActive: false }) as never } });
      await expect(service.createKhatm(createInput)).rejects.toBeInstanceOf(InactiveCreatorError);
      expect(calls.createKhatm).toBeUndefined();
    });

    it('rejects an unknown creator', async () => {
      const { service } = make({ identity: { findUserById: async () => null } });
      await expect(service.createKhatm(createInput)).rejects.toBeInstanceOf(InactiveCreatorError);
    });

    it('rejects a user without the CREATOR capability (403)', async () => {
      const { service, calls } = make({ authorization: denyCreator });
      await expect(service.createKhatm(createInput)).rejects.toBeInstanceOf(CapabilityRequiredError);
      expect(calls.createKhatm).toBeUndefined();
    });
  });

  describe('activateKhatm (owner only)', () => {
    it('activates when the owner acts and a valid plan exists', async () => {
      const { service, calls } = make({});
      await service.activateKhatm(KHATM_ID, USER_ID);
      expect(calls.activateKhatm).toEqual([KHATM_ID]);
    });

    it('rejects a non-owner (403) before any mutation', async () => {
      const { service, calls } = make({});
      await expect(service.activateKhatm(KHATM_ID, OTHER_USER)).rejects.toBeInstanceOf(
        ResourceOwnershipError,
      );
      expect(calls.activateKhatm).toBeUndefined();
    });

    it('rejects activation with no plan or an empty plan', async () => {
      const noPlan = make({ allocation: { findPlan: async () => null } });
      await expect(noPlan.service.activateKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(
        KhatmNotConfiguredError,
      );
      expect(noPlan.calls.activateKhatm).toBeUndefined();

      const emptyPlan = make({ allocation: { findPlan: async () => ({ totalPortions: 0 }) as never } });
      await expect(emptyPlan.service.activateKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(
        KhatmNotConfiguredError,
      );
    });

    it('rejects activating an unknown khatm', async () => {
      const { service } = make({ khatms: { findKhatmById: async () => null } });
      await expect(service.activateKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(KhatmNotFoundError);
    });

    it('activates an OPEN khatm without a plan (DEC-0071)', async () => {
      const openKhatm = make({
        khatms: {
          findKhatmById: async () => ({
            id: KHATM_ID,
            creatorUserId: USER_ID,
            khatmType: 'OPEN',
          } as never),
        },
        allocation: { findPlan: async () => null },
      });
      await openKhatm.service.activateKhatm(KHATM_ID, USER_ID);
      expect(openKhatm.calls.activateKhatm).toEqual([KHATM_ID]);
    });
  });

  describe('generateAllocationPlan / allocatePortions (owner only)', () => {
    const spec = { kind: 'QUANTITY', total: 10, chunk: 5 } as never;
    it('lets the owner generate and allocate', async () => {
      const { service, calls } = make({});
      await service.generateAllocationPlan(KHATM_ID, USER_ID, spec);
      await service.allocatePortions(KHATM_ID, USER_ID, 'p1', 5);
      expect(calls.generatePlan).toHaveLength(1);
      expect(calls.allocateOpenPortions).toHaveLength(1);
    });

    it('rejects a non-owner (403) for both', async () => {
      const { service, calls } = make({});
      await expect(service.generateAllocationPlan(KHATM_ID, OTHER_USER, spec)).rejects.toBeInstanceOf(
        ResourceOwnershipError,
      );
      await expect(service.allocatePortions(KHATM_ID, OTHER_USER, 'p1', 5)).rejects.toBeInstanceOf(
        ResourceOwnershipError,
      );
      expect(calls.generatePlan).toBeUndefined();
      expect(calls.allocateOpenPortions).toBeUndefined();
    });
  });

  describe('joinKhatm (participant — no CREATOR needed)', () => {
    it('joins when the user is active', async () => {
      const { service, calls } = make({ authorization: denyCreator });
      await service.joinKhatm(KHATM_ID, USER_ID);
      expect(calls.join).toEqual([{ khatmId: KHATM_ID, userId: USER_ID }]);
    });

    it('rejects a merged/inactive user before touching the khatm', async () => {
      const { service, calls } = make({ identity: { findUserById: async () => ({ isActive: false }) as never } });
      await expect(service.joinKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(InactiveParticipantError);
      expect(calls.join).toBeUndefined();
    });
  });

  describe('completePortion (participant holder)', () => {
    it('delegates to the holder-checked completion', async () => {
      const { service, calls } = make({});
      await service.completePortion('018f9a2b-0000-7000-8000-000000000c09', USER_ID);
      expect(calls.completeHeldPortion).toEqual([
        { portionId: '018f9a2b-0000-7000-8000-000000000c09', participationId: USER_ID },
      ]);
    });
  });

  describe('completeMyPortion (HTTP-layer: userId → participation → holder check)', () => {
    const PORTION_ID = '018f9a2b-0000-7000-8000-000000000c0a';
    const PARTICIPATION_ID = '018f9a2b-0000-7000-8000-000000000c0b';

    it('resolves the participation and delegates to holder-checked completion', async () => {
      const { service, calls } = make({
        khatms: {
          findParticipation: async () => ({ id: PARTICIPATION_ID } as never),
        },
      });
      await service.completeMyPortion(KHATM_ID, PORTION_ID, USER_ID);
      expect(calls.completeHeldPortion).toEqual([
        { portionId: PORTION_ID, participationId: PARTICIPATION_ID },
      ]);
    });

    it('rejects when the user is not a participant of the khatm', async () => {
      const { service } = make({
        khatms: { findParticipation: async () => null },
      });
      await expect(
        service.completeMyPortion(KHATM_ID, PORTION_ID, USER_ID),
      ).rejects.toBeInstanceOf(ParticipationNotFoundError);
    });
  });

  describe('completeKhatm (owner only)', () => {
    it('completes when the owner acts and every portion is completed', async () => {
      const { service, calls } = make({});
      await service.completeKhatm(KHATM_ID, USER_ID);
      expect(calls.completeKhatm).toEqual([KHATM_ID]);
    });

    it('rejects a non-owner (403)', async () => {
      const { service, calls } = make({});
      await expect(service.completeKhatm(KHATM_ID, OTHER_USER)).rejects.toBeInstanceOf(
        ResourceOwnershipError,
      );
      expect(calls.completeKhatm).toBeUndefined();
    });

    it('rejects when not all portions are completed', async () => {
      const { service, calls } = make({
        allocation: { progress: async () => ({ total: 30, open: 5, assigned: 10, completed: 15 }) },
      });
      await expect(service.completeKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(
        KhatmNotCompletableError,
      );
      expect(calls.completeKhatm).toBeUndefined();
    });

    it('rejects when there are no portions at all (COMMITMENT)', async () => {
      const { service } = make({
        allocation: { progress: async () => ({ total: 0, open: 0, assigned: 0, completed: 0 }) },
      });
      await expect(service.completeKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(
        KhatmNotCompletableError,
      );
    });

    it('completes an OPEN khatm without any portions (DEC-0072)', async () => {
      const { service, calls } = make({
        khatms: {
          findKhatmById: async () => ({
            id: KHATM_ID,
            creatorUserId: USER_ID,
            khatmType: 'OPEN',
          } as never),
        },
        allocation: { progress: async () => ({ total: 0, open: 0, assigned: 0, completed: 0 }) },
      });
      await service.completeKhatm(KHATM_ID, USER_ID);
      expect(calls.completeKhatm).toEqual([KHATM_ID]);
    });

    it('still rejects OPEN khatm for a non-owner', async () => {
      const { service } = make({
        khatms: {
          findKhatmById: async () => ({
            id: KHATM_ID,
            creatorUserId: USER_ID,
            khatmType: 'OPEN',
          } as never),
        },
      });
      await expect(service.completeKhatm(KHATM_ID, OTHER_USER)).rejects.toBeInstanceOf(
        ResourceOwnershipError,
      );
    });
  });

  describe('activateKhatm — notification lifecycle (FIX B)', () => {
    it('schedules notifications after activating a COMMITMENT khatm', async () => {
      const { service, calls } = make({});
      await service.activateKhatm(KHATM_ID, USER_ID);
      expect(calls.onKhatmActivated).toEqual([KHATM_ID]);
    });

    it('schedules notifications after activating an OPEN khatm too', async () => {
      const { service, calls } = make({
        khatms: {
          findKhatmById: async () => ({ id: KHATM_ID, creatorUserId: USER_ID, khatmType: 'OPEN' } as never),
        },
      });
      await service.activateKhatm(KHATM_ID, USER_ID);
      expect(calls.onKhatmActivated).toEqual([KHATM_ID]);
    });
  });

  describe('leaveKhatm — waiting list auto-promotion (FIX A)', () => {
    it('leaves and promotes the next person from the waiting list for COMMITMENT khatms', async () => {
      const { service, calls } = make({
        waitingList: {
          promoteNext: async (khatmId: unknown) => {
            (calls['promoteNext'] = calls['promoteNext'] ?? []).push(khatmId);
            return OTHER_USER;
          },
        },
      });
      await service.leaveKhatm(KHATM_ID, USER_ID);
      expect(calls.leaveParticipation).toEqual(['participation-1']);
      expect(calls.promoteNext).toEqual([KHATM_ID]);
      expect(calls.join).toEqual([{ khatmId: KHATM_ID, userId: OTHER_USER }]);
    });

    it('leaves but does NOT promote when nobody is waiting', async () => {
      const { service, calls } = make({});
      await service.leaveKhatm(KHATM_ID, USER_ID);
      expect(calls.leaveParticipation).toEqual(['participation-1']);
      expect(calls.promoteNext).toEqual([KHATM_ID]);
      expect(calls.join).toBeUndefined();
    });

    it('leaves an OPEN khatm without touching the waiting list', async () => {
      const { service, calls } = make({
        khatms: {
          findKhatmById: async () => ({ id: KHATM_ID, creatorUserId: USER_ID, khatmType: 'OPEN' } as never),
          findParticipation: async () => ({ id: 'participation-1' } as never),
          leaveParticipation: async (id: unknown) => { (calls['leaveParticipation'] = calls['leaveParticipation'] ?? []).push(id); },
          join: async (khatmId: unknown, userId: unknown) => { (calls['join'] = calls['join'] ?? []).push({ khatmId, userId }); return {} as never; },
        },
      });
      await service.leaveKhatm(KHATM_ID, USER_ID);
      expect(calls.leaveParticipation).toEqual(['participation-1']);
      expect(calls.promoteNext).toBeUndefined();
    });

    it('throws KhatmNotFoundError when the khatm does not exist', async () => {
      const { service } = make({ khatms: { findKhatmById: async () => null } });
      await expect(service.leaveKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(KhatmNotFoundError);
    });

    it('throws ParticipationNotFoundError when the user is not a participant', async () => {
      const { service } = make({ khatms: { findParticipation: async () => null } });
      await expect(service.leaveKhatm(KHATM_ID, USER_ID)).rejects.toBeInstanceOf(ParticipationNotFoundError);
    });
  });
});
