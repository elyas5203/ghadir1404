/**
 * Application-level errors for the Khatm workflow orchestration (Phase 4.2).
 *
 * These express WORKFLOW preconditions that span capabilities (an inactive user, a
 * khatm that is not yet configured for activation, a khatm whose completion
 * conditions are not met). They are framework-free plain errors; the underlying
 * capabilities keep raising their own domain errors, which the orchestrator lets
 * propagate unchanged.
 */

export class KhatmWorkflowError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** The creator is not a known ACTIVE user (missing or a merged tombstone). */
export class InactiveCreatorError extends KhatmWorkflowError {
  constructor() {
    super('The creator is not an active user and cannot create a khatm.');
  }
}

/** The joining user is not a known ACTIVE user (missing or a merged tombstone). */
export class InactiveParticipantError extends KhatmWorkflowError {
  constructor() {
    super('The user is not an active user and cannot join a khatm.');
  }
}

/**
 * A khatm cannot be activated because it has no valid allocation plan yet — the
 * required configuration is missing (DEC-0055).
 */
export class KhatmNotConfiguredError extends KhatmWorkflowError {
  constructor() {
    super('The khatm has no valid allocation plan and cannot be activated.');
  }
}

/**
 * A khatm's completion conditions are not met: it has no plan, or not every portion
 * is completed (DEC-0056).
 */
export class KhatmNotCompletableError extends KhatmWorkflowError {
  constructor() {
    super('The khatm cannot be completed: not all portions are completed.');
  }
}
