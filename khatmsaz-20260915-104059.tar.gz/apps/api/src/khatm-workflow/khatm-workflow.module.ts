import { Module } from '@nestjs/common';
import { IdentityModule } from '../identity/identity.module';
import { KhatmModule } from '../khatm/khatm.module';
import { AllocationModule } from '../allocation/allocation.module';
import { AuthorizationModule } from '../authorization/authorization.module';
import { WaitingListModule } from '../waiting-list/waiting-list.module';
import { NotificationModule } from '../notification/notification.module';
import { KhatmWorkflowService } from './application/khatm-workflow.service';

/**
 * Khatm workflow orchestration module (Phase 4.2, DEC-0054).
 *
 * An application-only ORCHESTRATION module (the account-merge pattern): it imports
 * the identity, khatm and allocation capability modules and composes their EXPORTED
 * SERVICES into end-to-end workflows (create → activate → join → allocate →
 * complete). It owns no domain, no persistence and no transaction of its own — the
 * capabilities keep their own rules and `UnitOfWork` boundaries; the orchestrator
 * only adds the cross-capability preconditions and, from Phase 7, the AUTHORIZATION
 * checks (CREATOR capability + khatm ownership, DEC-0061/0063).
 *
 * Intra-product (DEC-0047).
 */
@Module({
  imports: [IdentityModule, KhatmModule, AllocationModule, AuthorizationModule, WaitingListModule, NotificationModule],
  providers: [KhatmWorkflowService],
  exports: [KhatmWorkflowService],
})
export class KhatmWorkflowModule {}
