export class AlreadyOnWaitingListError extends Error {
  constructor() {
    super('User is already on this khatm waiting list.');
    this.name = 'AlreadyOnWaitingListError';
  }
}

export class NotOnWaitingListError extends Error {
  constructor() {
    super('User is not on this khatm waiting list.');
    this.name = 'NotOnWaitingListError';
  }
}
