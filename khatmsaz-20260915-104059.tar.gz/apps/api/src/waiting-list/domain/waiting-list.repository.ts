export interface WaitingListEntry {
  readonly id: string;
  readonly khatmId: string;
  readonly userId: string;
  readonly position: number;
  readonly joinedAt: Date;
}

export interface WaitingListRepository {
  findByKhatmAndUser(khatmId: string, userId: string): Promise<WaitingListEntry | null>;
  /** Returns the next unqueued position (max + 1) for the khatm. */
  nextPosition(khatmId: string): Promise<number>;
  add(entry: WaitingListEntry): Promise<void>;
  remove(khatmId: string, userId: string): Promise<void>;
  /** Returns entries ordered by position ASC. */
  listByKhatm(khatmId: string): Promise<WaitingListEntry[]>;
  /** First entry in line (lowest position). */
  peekFirst(khatmId: string): Promise<WaitingListEntry | null>;
}

export const WAITING_LIST_REPOSITORY = Symbol('WaitingListRepository');
