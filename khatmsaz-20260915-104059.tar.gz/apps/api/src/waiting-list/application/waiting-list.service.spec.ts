import { WaitingListService } from './waiting-list.service';
import type { WaitingListRepository, WaitingListEntry } from '../domain/waiting-list.repository';
import { WAITING_LIST_REPOSITORY } from '../domain/waiting-list.repository';
import { AlreadyOnWaitingListError, NotOnWaitingListError } from '../domain/waiting-list.errors';
import { Test } from '@nestjs/testing';

function makeEntry(overrides: Partial<WaitingListEntry> = {}): WaitingListEntry {
  return {
    id: 'eid',
    khatmId: 'kid',
    userId: 'uid',
    position: 1,
    joinedAt: new Date(),
    ...overrides,
  };
}

function fakeRepo(overrides: Partial<WaitingListRepository> = {}): WaitingListRepository {
  return {
    findByKhatmAndUser: async () => null,
    nextPosition: async () => 1,
    add: async () => undefined,
    remove: async () => undefined,
    listByKhatm: async () => [],
    peekFirst: async () => null,
    ...overrides,
  };
}

async function buildService(repo: WaitingListRepository): Promise<WaitingListService> {
  const module = await Test.createTestingModule({
    providers: [
      WaitingListService,
      { provide: WAITING_LIST_REPOSITORY, useValue: repo },
    ],
  }).compile();
  return module.get(WaitingListService);
}

describe('WaitingListService', () => {
  describe('joinWaitingList', () => {
    it('adds a new entry when user is not already waiting', async () => {
      let added: WaitingListEntry | null = null;
      const repo = fakeRepo({ add: async (e) => { added = e; } });
      const svc = await buildService(repo);
      const result = await svc.joinWaitingList('k1', 'u1');
      expect(result.khatmId).toBe('k1');
      expect(result.userId).toBe('u1');
      expect(added).not.toBeNull();
    });

    it('throws AlreadyOnWaitingListError when user is already waiting', async () => {
      const repo = fakeRepo({ findByKhatmAndUser: async () => makeEntry() });
      const svc = await buildService(repo);
      await expect(svc.joinWaitingList('k1', 'u1')).rejects.toBeInstanceOf(AlreadyOnWaitingListError);
    });
  });

  describe('leaveWaitingList', () => {
    it('removes user when they are on the list', async () => {
      let removed = false;
      const repo = fakeRepo({
        findByKhatmAndUser: async () => makeEntry(),
        remove: async () => { removed = true; },
      });
      const svc = await buildService(repo);
      await svc.leaveWaitingList('k1', 'u1');
      expect(removed).toBe(true);
    });

    it('throws NotOnWaitingListError when user is not waiting', async () => {
      const repo = fakeRepo();
      const svc = await buildService(repo);
      await expect(svc.leaveWaitingList('k1', 'u1')).rejects.toBeInstanceOf(NotOnWaitingListError);
    });
  });

  describe('promoteNext', () => {
    it('returns null when nobody is waiting', async () => {
      const svc = await buildService(fakeRepo());
      expect(await svc.promoteNext('k1')).toBeNull();
    });

    it('removes and returns the first user in line', async () => {
      let removed = false;
      const repo = fakeRepo({
        peekFirst: async () => makeEntry({ userId: 'promoted' }),
        remove: async () => { removed = true; },
      });
      const svc = await buildService(repo);
      const result = await svc.promoteNext('k1');
      expect(result).toBe('promoted');
      expect(removed).toBe(true);
    });
  });
});
