import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7 } from '@khatmsaz/kernel';
import {
  WAITING_LIST_REPOSITORY,
  type WaitingListRepository,
  type WaitingListEntry,
} from '../domain/waiting-list.repository';
import { AlreadyOnWaitingListError, NotOnWaitingListError } from '../domain/waiting-list.errors';

/**
 * Waiting list capability (Sprint Phase 02).
 *
 * When a COMMITMENT khatm is full (all portions assigned), a user may join the
 * waiting list. When an existing participant leaves, the service promotes the
 * next person in line via {@link replaceParticipant}.
 *
 * The actual re-allocation logic is orchestrated in KhatmWorkflowService which
 * injects this service; no domain logic lives here.
 */
@Injectable()
export class WaitingListService {
  constructor(
    @Inject(WAITING_LIST_REPOSITORY) private readonly repo: WaitingListRepository,
  ) {}

  async joinWaitingList(khatmId: string, userId: string): Promise<WaitingListEntry> {
    const existing = await this.repo.findByKhatmAndUser(khatmId, userId);
    if (existing) throw new AlreadyOnWaitingListError();

    const position = await this.repo.nextPosition(khatmId);
    const entry: WaitingListEntry = {
      id: newUuidV7(),
      khatmId,
      userId,
      position,
      joinedAt: new Date(),
    };
    await this.repo.add(entry);
    return entry;
  }

  async leaveWaitingList(khatmId: string, userId: string): Promise<void> {
    const existing = await this.repo.findByKhatmAndUser(khatmId, userId);
    if (!existing) throw new NotOnWaitingListError();
    await this.repo.remove(khatmId, userId);
  }

  /** Returns the userId of the next person in line, without removing them yet. */
  async getNextInLine(khatmId: string): Promise<string | null> {
    const first = await this.repo.peekFirst(khatmId);
    return first?.userId ?? null;
  }

  /**
   * Promotes the next person in line after a participant leaves.
   * Returns the promoted userId (or null if nobody is waiting).
   * The caller (KhatmWorkflowService) is responsible for re-assigning portions
   * and sending welcome/farewell notifications.
   */
  async promoteNext(khatmId: string): Promise<string | null> {
    const first = await this.repo.peekFirst(khatmId);
    if (!first) return null;
    await this.repo.remove(khatmId, first.userId);
    return first.userId;
  }

  async listWaiting(khatmId: string): Promise<WaitingListEntry[]> {
    return this.repo.listByKhatm(khatmId);
  }

  async isWaiting(khatmId: string, userId: string): Promise<boolean> {
    return (await this.repo.findByKhatmAndUser(khatmId, userId)) !== null;
  }
}
