import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { WaitingListRepository, WaitingListEntry } from '../domain/waiting-list.repository';

@Injectable()
export class PrismaWaitingListRepository implements WaitingListRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findByKhatmAndUser(khatmId: string, userId: string): Promise<WaitingListEntry | null> {
    const row = await this.prisma.waitingList.findUnique({
      where: { khatmId_userId: { khatmId, userId } },
    });
    return row ? this.toDomain(row) : null;
  }

  async nextPosition(khatmId: string): Promise<number> {
    const agg = await this.prisma.waitingList.aggregate({
      where: { khatmId },
      _max: { position: true },
    });
    return (agg._max.position ?? 0) + 1;
  }

  async add(entry: WaitingListEntry): Promise<void> {
    await this.prisma.waitingList.create({
      data: {
        id: entry.id,
        khatmId: entry.khatmId,
        userId: entry.userId,
        position: entry.position,
        joinedAt: entry.joinedAt,
      },
    });
  }

  async remove(khatmId: string, userId: string): Promise<void> {
    await this.prisma.waitingList.delete({
      where: { khatmId_userId: { khatmId, userId } },
    });
  }

  async listByKhatm(khatmId: string): Promise<WaitingListEntry[]> {
    const rows = await this.prisma.waitingList.findMany({
      where: { khatmId },
      orderBy: { position: 'asc' },
    });
    return rows.map((r) => this.toDomain(r));
  }

  async peekFirst(khatmId: string): Promise<WaitingListEntry | null> {
    const row = await this.prisma.waitingList.findFirst({
      where: { khatmId },
      orderBy: { position: 'asc' },
    });
    return row ? this.toDomain(row) : null;
  }

  private toDomain(row: {
    id: string;
    khatmId: string;
    userId: string;
    position: number;
    joinedAt: Date;
  }): WaitingListEntry {
    return {
      id: row.id,
      khatmId: row.khatmId,
      userId: row.userId,
      position: row.position,
      joinedAt: row.joinedAt,
    };
  }
}
