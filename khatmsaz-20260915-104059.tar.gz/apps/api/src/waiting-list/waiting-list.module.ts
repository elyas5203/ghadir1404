import { Module } from '@nestjs/common';
import { WaitingListService } from './application/waiting-list.service';
import { WAITING_LIST_REPOSITORY } from './domain/waiting-list.repository';
import { PrismaWaitingListRepository } from './infrastructure/prisma-waiting-list.repository';

@Module({
  providers: [
    WaitingListService,
    { provide: WAITING_LIST_REPOSITORY, useClass: PrismaWaitingListRepository },
  ],
  exports: [WaitingListService],
})
export class WaitingListModule {}
