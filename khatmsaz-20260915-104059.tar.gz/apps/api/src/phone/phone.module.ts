import { Module } from '@nestjs/common';
import { otpHmacSecret, otpPolicyConfig, phoneDefaultRegion, localOtpEnabled, smsConfig } from '@khatmsaz/config';
import { LocalOtpDeliveryAdapter } from './infrastructure/local-otp-delivery.adapter';
import { SmsOtpDeliveryAdapter } from './infrastructure/sms-otp-delivery.adapter';
import { PhoneVerificationService } from './application/phone-verification.service';
import { OTP_POLICY } from './application/otp-policy';
import { CLOCK } from './domain/clock';
import { PHONE_NORMALIZER } from './domain/phone-normalizer';
import { OTP_CODE_GENERATOR, OTP_CODE_HASHER } from './domain/otp-code';
import { OTP_DELIVERY } from './domain/otp-delivery';
import { PHONE_CLAIM_REPOSITORY } from './domain/phone-claim.repository';
import { OTP_CHALLENGE_REPOSITORY } from './domain/otp-challenge.repository';
import { PrismaPhoneClaimRepository } from './infrastructure/prisma-phone-claim.repository';
import { PrismaOtpChallengeRepository } from './infrastructure/prisma-otp-challenge.repository';
import { LibphonenumberPhoneNormalizer } from './infrastructure/libphonenumber-phone-normalizer';
import { CryptoOtpCodeGenerator } from './infrastructure/crypto-otp-code-generator';
import { HmacOtpCodeHasher } from './infrastructure/hmac-otp-code-hasher';
import { NoopOtpDeliveryAdapter } from './infrastructure/noop-otp-delivery.adapter';
import { KavenegarSmsService } from '../sms/infrastructure/kavenegar-sms.service';
import { SystemClock } from './infrastructure/system-clock';

/**
 * Phone-verification capability module (Phase 3A).
 *
 * Binds the domain-owned ports — persistence repositories, the phone normalizer,
 * the OTP code generator/hasher, the delivery seam, and the clock — to their
 * infrastructure implementations. The rest of the application depends on
 * {@link PhoneVerificationService} and the domain ports; Prisma, the phone
 * library, and the (future) SMS provider live only behind these bindings
 * (DEC-0018, DEC-0031, DEC-0033). The `@Global` DatabaseModule provides
 * `PrismaService`.
 *
 * This phase deliberately exposes NO HTTP controller and NO bot handler — there
 * is no registration, creator, or login surface yet. The module exists so the
 * phone-verification use-cases are wired and testable.
 */
@Module({
  providers: [
    PhoneVerificationService,
    { provide: PHONE_CLAIM_REPOSITORY, useClass: PrismaPhoneClaimRepository },
    { provide: OTP_CHALLENGE_REPOSITORY, useClass: PrismaOtpChallengeRepository },
    // These two take a plain-string constructor arg (config, not a provider), so
    // they are built via factory rather than useClass to avoid Nest trying to
    // inject a `String`.
    { provide: PHONE_NORMALIZER, useFactory: () => new LibphonenumberPhoneNormalizer(phoneDefaultRegion()) },
    { provide: OTP_CODE_GENERATOR, useClass: CryptoOtpCodeGenerator },
    { provide: OTP_CODE_HASHER, useFactory: () => new HmacOtpCodeHasher(otpHmacSecret()) },
    {
      provide: OTP_DELIVERY,
      useFactory: () => {
        if (localOtpEnabled()) return new LocalOtpDeliveryAdapter();
        const cfg = smsConfig();
        if (cfg.provider === 'kavenegar' && cfg.kavenegarApiKey.length > 0) {
          return new SmsOtpDeliveryAdapter(new KavenegarSmsService(cfg));
        }
        return new NoopOtpDeliveryAdapter();
      },
    },
    { provide: CLOCK, useClass: SystemClock },
    { provide: OTP_POLICY, useFactory: otpPolicyConfig },
  ],
  // Export the phone-claim port so the account-merge orchestration module can move
  // a merged account's phone claims (DEC-0047, intra-product).
  exports: [PhoneVerificationService, PHONE_CLAIM_REPOSITORY],
})
export class PhoneModule {}
