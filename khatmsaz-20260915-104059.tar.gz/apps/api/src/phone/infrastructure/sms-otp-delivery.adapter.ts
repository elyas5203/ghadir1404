import type { OtpDelivery, OtpDeliveryRequest } from '../domain/otp-delivery';
import type { SmsProvider } from '../../sms/domain/sms.types';

/**
 * SMS-backed OTP delivery adapter (DEC-NEXT-002).
 * Wraps the SMS_PROVIDER port so the Phone capability never imports a vendor SDK.
 * The code is never logged; only a coarse delivery result is recorded.
 */
export class SmsOtpDeliveryAdapter implements OtpDelivery {
  constructor(private readonly sms: SmsProvider) {}

  async deliver(request: OtpDeliveryRequest): Promise<void> {
    const text = `کد تأیید ختم‌ساز: ${request.code}\nاین کد تا ${Math.round((request.expiresAt.getTime() - Date.now()) / 60_000)} دقیقه معتبر است.`;
    await this.sms.send(request.e164, text);
  }
}
