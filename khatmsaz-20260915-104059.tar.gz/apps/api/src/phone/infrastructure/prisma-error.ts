/**
 * Minimal, resilient inspection of Prisma request errors by their stable public
 * error codes (documented at https://pris.ly/d/error-reference). Duck-typing the
 * `code` avoids depending on a specific error-class identity across module copies
 * while staying entirely inside the infrastructure layer. Mirrors the identity
 * capability's helper; each capability keeps its own so no cross-module infra
 * import is needed.
 */

/** Prisma "unique constraint failed" (covers partial unique indexes). */
export const PRISMA_UNIQUE_VIOLATION = 'P2002';
/** Prisma "foreign key constraint failed". */
export const PRISMA_FOREIGN_KEY_VIOLATION = 'P2003';
/** Prisma "record to update not found". */
export const PRISMA_RECORD_NOT_FOUND = 'P2025';

/** Return the Prisma error code of `error`, if it carries one. */
export function prismaErrorCode(error: unknown): string | undefined {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code;
    return typeof code === 'string' ? code : undefined;
  }
  return undefined;
}
