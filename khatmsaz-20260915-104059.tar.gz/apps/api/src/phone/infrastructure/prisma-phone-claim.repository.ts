import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import { PhoneClaimStatus } from '../domain/phone-claim';
import type { PhoneClaim } from '../domain/phone-claim';
import type {
  CreatePhoneClaimInput,
  PhoneClaimRepository,
} from '../domain/phone-claim.repository';
import {
  ActivePhoneClaimExistsError,
  PhoneClaimUserNotFoundError,
  PhoneOwnershipConflictError,
} from '../domain/phone.errors';
import { toPhoneClaim } from './phone.mapper';
import {
  PRISMA_FOREIGN_KEY_VIOLATION,
  PRISMA_UNIQUE_VIOLATION,
  prismaErrorCode,
} from './prisma-error';

/**
 * Prisma-backed {@link PhoneClaimRepository}. The only phone-claim persistence
 * code that sees Prisma; it returns domain {@link PhoneClaim} objects, never
 * Prisma rows.
 *
 * Both uniqueness invariants are enforced by DATABASE partial unique indexes
 * created in the migration (Prisma cannot express a filtered unique index in the
 * schema — DEC-0033). This repository never pre-reads to gate a write; it writes
 * and translates the resulting constraint violation into a domain error, which is
 * what makes concurrent verification safe.
 */
@Injectable()
export class PrismaPhoneClaimRepository implements PhoneClaimRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findActiveByUserAndPhone(userId: string, e164: string): Promise<PhoneClaim | null> {
    const row = await this.prisma.phoneClaim.findFirst({
      where: { userId, e164, status: { not: PhoneClaimStatus.REVOKED } },
    });
    return row ? toPhoneClaim(row) : null;
  }

  async createUnverified(input: CreatePhoneClaimInput): Promise<PhoneClaim> {
    try {
      const row = await this.prisma.phoneClaim.create({
        data: {
          id: input.id,
          userId: input.userId,
          e164: input.e164,
          region: input.region,
          status: PhoneClaimStatus.UNVERIFIED,
        },
      });
      return toPhoneClaim(row);
    } catch (error) {
      const code = prismaErrorCode(error);
      if (code === PRISMA_UNIQUE_VIOLATION) {
        throw new ActivePhoneClaimExistsError();
      }
      if (code === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new PhoneClaimUserNotFoundError();
      }
      throw error;
    }
  }

  async markVerified(
    claimId: string,
    verifiedAt: Date,
    tx?: TransactionContext,
  ): Promise<PhoneClaim> {
    try {
      const row = await dbClient(this.prisma, tx).phoneClaim.update({
        where: { id: claimId },
        data: { status: PhoneClaimStatus.VERIFIED, verifiedAt },
      });
      return toPhoneClaim(row);
    } catch (error) {
      // A partial unique index on VERIFIED claims rejects a conflict — the global
      // per-number one (another owner) or the per-user one (DEC-0046). Either way
      // the caller treats it as an ownership conflict handed to the merge phase.
      if (prismaErrorCode(error) === PRISMA_UNIQUE_VIOLATION) {
        throw new PhoneOwnershipConflictError();
      }
      throw error;
    }
  }

  async findVerifiedByUser(userId: string, tx?: TransactionContext): Promise<PhoneClaim | null> {
    const row = await dbClient(this.prisma, tx).phoneClaim.findFirst({
      where: { userId, status: PhoneClaimStatus.VERIFIED },
    });
    return row ? toPhoneClaim(row) : null;
  }

  async findVerifiedOwnerId(e164: string, tx?: TransactionContext): Promise<string | null> {
    const row = await dbClient(this.prisma, tx).phoneClaim.findFirst({
      where: { e164, status: PhoneClaimStatus.VERIFIED },
      select: { userId: true },
    });
    return row?.userId ?? null;
  }

  async revoke(claimId: string, revokedAt: Date, tx?: TransactionContext): Promise<PhoneClaim> {
    const row = await dbClient(this.prisma, tx).phoneClaim.update({
      where: { id: claimId },
      data: { status: PhoneClaimStatus.REVOKED, revokedAt },
    });
    return toPhoneClaim(row);
  }

  async revokeAllActiveByUser(
    userId: string,
    revokedAt: Date,
    tx?: TransactionContext,
  ): Promise<number> {
    const result = await dbClient(this.prisma, tx).phoneClaim.updateMany({
      where: { userId, status: { not: PhoneClaimStatus.REVOKED } },
      data: { status: PhoneClaimStatus.REVOKED, revokedAt },
    });
    return result.count;
  }

  async reassignOwner(
    fromUserId: string,
    toUserId: string,
    tx?: TransactionContext,
  ): Promise<number> {
    const result = await dbClient(this.prisma, tx).phoneClaim.updateMany({
      where: { userId: fromUserId },
      data: { userId: toUserId },
    });
    return result.count;
  }
}
