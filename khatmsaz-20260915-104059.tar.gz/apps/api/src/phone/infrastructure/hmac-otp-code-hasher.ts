import { Injectable } from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { otpHmacSecret } from '@khatmsaz/config';
import type { OtpCodeHasher, OtpHashContext } from '../domain/otp-code';

/**
 * Keyed-HMAC OTP hasher (DEC-0035).
 *
 * A six-digit code has only ~20 bits of entropy — a plain fast hash of it would
 * be trivially brute-forced from a leaked database. Instead the code is protected
 * with HMAC-SHA-256 keyed by a SERVER-SIDE SECRET (a pepper) that never enters
 * the database, so an attacker with the DB but not the pepper cannot precompute
 * or reverse the stored value. The HMAC message binds the code to its `e164` and
 * `purpose`, so a stored hash can only ever validate the exact target it was made
 * for (no cross-number or cross-purpose replay).
 *
 * The pepper is injected via `@khatmsaz/config.otpHmacSecret()`, which fails fast
 * in production when unset and uses a clearly-marked local placeholder otherwise.
 * The secret is read once at construction and NEVER logged or surfaced in errors.
 * Comparison is constant-time to avoid timing side channels.
 */
@Injectable()
export class HmacOtpCodeHasher implements OtpCodeHasher {
  private readonly secret: string;

  constructor(secret: string = otpHmacSecret()) {
    this.secret = secret;
  }

  hash(code: string, ctx: OtpHashContext): string {
    const message = `${ctx.purpose}:${ctx.e164}:${code}`;
    return createHmac('sha256', this.secret).update(message).digest('hex');
  }

  verify(code: string, storedHash: string, ctx: OtpHashContext): boolean {
    const computed = this.hash(code, ctx);
    const a = Buffer.from(computed, 'hex');
    const b = Buffer.from(storedHash, 'hex');
    // Lengths must match for timingSafeEqual; a differing length is a mismatch.
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  }
}
