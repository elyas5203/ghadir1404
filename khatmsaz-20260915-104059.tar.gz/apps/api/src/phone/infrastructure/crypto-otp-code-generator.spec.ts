import { CryptoOtpCodeGenerator } from './crypto-otp-code-generator';

describe('CryptoOtpCodeGenerator', () => {
  const generator = new CryptoOtpCodeGenerator();

  it('generates a numeric code of the requested length', () => {
    for (let i = 0; i < 200; i += 1) {
      const code = generator.generate(6);
      expect(code).toMatch(/^[0-9]{6}$/);
    }
  });

  it('can produce codes with leading zeros (full length preserved)', () => {
    let sawLeadingZero = false;
    for (let i = 0; i < 2000 && !sawLeadingZero; i += 1) {
      if (generator.generate(6).startsWith('0')) sawLeadingZero = true;
    }
    expect(sawLeadingZero).toBe(true);
  });

  it('is not trivially constant across draws', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 50; i += 1) seen.add(generator.generate(6));
    expect(seen.size).toBeGreaterThan(1);
  });

  it('rejects an out-of-range length', () => {
    expect(() => generator.generate(0)).toThrow();
    expect(() => generator.generate(13)).toThrow();
  });
});
