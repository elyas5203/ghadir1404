import { Injectable } from '@nestjs/common';
import type { TransactionContext } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { dbClient } from '../../infrastructure/database/prisma/prisma-unit-of-work';
import type { OtpChallenge, OtpPurpose } from '../domain/otp-challenge';
import type {
  CreateOtpChallengeInput,
  OtpChallengeRepository,
} from '../domain/otp-challenge.repository';
import { toOtpChallenge } from './phone.mapper';
import { PRISMA_RECORD_NOT_FOUND, prismaErrorCode } from './prisma-error';

/**
 * Prisma-backed {@link OtpChallengeRepository}. The only OTP persistence code
 * that sees Prisma; it returns domain {@link OtpChallenge} objects, never Prisma
 * rows, and NEVER logs the stored hash. Attempt counting uses an atomic
 * `increment` so concurrent verification attempts cannot lose a count.
 */
@Injectable()
export class PrismaOtpChallengeRepository implements OtpChallengeRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateOtpChallengeInput): Promise<OtpChallenge> {
    const row = await this.prisma.otpChallenge.create({
      data: {
        id: input.id,
        userId: input.userId,
        e164: input.e164,
        purpose: input.purpose,
        codeHash: input.codeHash,
        maxAttempts: input.maxAttempts,
        expiresAt: input.expiresAt,
      },
    });
    return toOtpChallenge(row);
  }

  async findLatestForTarget(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
  ): Promise<OtpChallenge | null> {
    const row = await this.prisma.otpChallenge.findFirst({
      where: { userId, e164, purpose },
      orderBy: { createdAt: 'desc' },
    });
    return row ? toOtpChallenge(row) : null;
  }

  async supersedeActive(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
    at: Date,
  ): Promise<number> {
    const result = await this.prisma.otpChallenge.updateMany({
      where: {
        userId,
        e164,
        purpose,
        consumedAt: null,
        supersededAt: null,
        expiresAt: { gt: at },
      },
      data: { supersededAt: at },
    });
    return result.count;
  }

  async findLatestUserless(e164: string, purpose: OtpPurpose): Promise<OtpChallenge | null> {
    const row = await this.prisma.otpChallenge.findFirst({
      where: { userId: null, e164, purpose },
      orderBy: { createdAt: 'desc' },
    });
    return row ? toOtpChallenge(row) : null;
  }

  async supersedeActiveUserless(e164: string, purpose: OtpPurpose, at: Date): Promise<number> {
    const result = await this.prisma.otpChallenge.updateMany({
      where: {
        userId: null,
        e164,
        purpose,
        consumedAt: null,
        supersededAt: null,
        expiresAt: { gt: at },
      },
      data: { supersededAt: at },
    });
    return result.count;
  }

  async recordFailedAttempt(challengeId: string): Promise<void> {
    await this.prisma.otpChallenge.update({
      where: { id: challengeId },
      data: { attempts: { increment: 1 } },
    });
  }

  async consume(challengeId: string, at: Date, tx?: TransactionContext): Promise<void> {
    try {
      await dbClient(this.prisma, tx).otpChallenge.update({
        where: { id: challengeId, consumedAt: null },
        data: { consumedAt: at },
      });
    } catch (error) {
      // Already consumed by a racing call — the single-use guarantee still holds.
      if (prismaErrorCode(error) === PRISMA_RECORD_NOT_FOUND) return;
      throw error;
    }
  }
}
