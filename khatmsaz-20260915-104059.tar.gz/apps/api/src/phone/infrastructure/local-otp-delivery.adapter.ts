import { createServer } from 'node:http';
import type { Server } from 'node:http';
import { chmod, lstat, mkdir } from 'node:fs/promises';
import type { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { assertLocalDevelopment, localOtpEnabled } from '@khatmsaz/config';
import type { OtpDelivery, OtpDeliveryRequest } from '../domain/otp-delivery';
import { localOtpDirectory, localOtpSocket } from './local-otp-socket';

/** Explicit opt-in local delivery. Credentials live only in bounded process memory. */
export class LocalOtpDeliveryAdapter implements OtpDelivery, OnModuleInit, OnModuleDestroy {
  private readonly codes = new Map<string, OtpDeliveryRequest>();
  private server?: Server;
  private timer?: ReturnType<typeof setInterval>;

  async onModuleInit(): Promise<void> {
    if (!localOtpEnabled()) return;
    assertLocalDevelopment();
    const directory = localOtpDirectory();
    await mkdir(directory, { mode: 0o700, recursive: true });
    const stat = await lstat(directory);
    if (!stat.isDirectory() || stat.uid !== process.getuid?.() || (stat.mode & 0o777) !== 0o700) {
      throw new Error('Local OTP directory must be private and owned by the current user.');
    }
    this.server = createServer((req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      // Runtime guard as well as provider-selection guard. Never log requests.
      if (!localOtpEnabled() || req.method !== 'GET') {
        res.writeHead(404).end();
        return;
      }
      let url: URL;
      try {
        url = new URL(req.url ?? '/', 'http://local');
      } catch {
        res.writeHead(400).end();
        return;
      }
      const code =
        url.pathname === '/latest' ? this.takeLatest(url.searchParams.get('e164') ?? '') : null;
      if (!code) {
        res.writeHead(404).end();
        return;
      }
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ code }));
    });
    // Never unlink an existing socket: another API may own it. Fail closed.
    await new Promise<void>((resolve, reject) => {
      this.server!.once('error', () =>
        reject(
          new Error(
            'Local OTP socket unavailable; stop the other local API or remove a stale socket.',
          ),
        ),
      );
      this.server!.listen(localOtpSocket(), resolve);
    });
    try {
      await chmod(localOtpSocket(), 0o600);
    } catch {
      await this.onModuleDestroy();
      throw new Error('Cannot secure local OTP socket.');
    }
    this.timer = setInterval(() => this.prune(), 1000);
    this.timer.unref();
  }

  async deliver(request: OtpDeliveryRequest): Promise<void> {
    if (!localOtpEnabled()) {
      this.codes.clear();
      return;
    }
    this.prune();
    if (request.purpose !== 'PHONE_LOGIN' || request.expiresAt.getTime() <= Date.now()) return;
    this.codes.delete(request.e164);
    if (this.codes.size >= 1000) this.codes.delete(this.codes.keys().next().value!);
    this.codes.set(request.e164, { ...request });
  }

  /** One local read removes the delivery copy; normal OTP verification remains authoritative. */
  takeLatest(e164: string): string | null {
    if (!localOtpEnabled()) {
      this.codes.clear();
      return null;
    }
    this.prune();
    const delivered = this.codes.get(e164);
    this.codes.delete(e164);
    return delivered?.code ?? null;
  }

  private prune(): void {
    for (const [key, value] of this.codes) {
      if (value.expiresAt.getTime() <= Date.now()) this.codes.delete(key);
    }
  }

  async onModuleDestroy(): Promise<void> {
    if (this.timer) clearInterval(this.timer);
    this.codes.clear();
    if (this.server?.listening)
      await new Promise<void>((resolve) => this.server!.close(() => resolve()));
  }
}
