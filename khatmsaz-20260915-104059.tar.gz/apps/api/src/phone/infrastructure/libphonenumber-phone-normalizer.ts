import { Injectable } from '@nestjs/common';
import { parsePhoneNumberWithError } from 'libphonenumber-js';
import { phoneDefaultRegion } from '@khatmsaz/config';
import { PhoneNumber } from '../domain/phone-number';
import type { PhoneNormalizer } from '../domain/phone-normalizer';
import { InvalidPhoneNumberError } from '../domain/phone.errors';

/**
 * {@link PhoneNormalizer} backed by `libphonenumber-js` — a maintained, MIT,
 * dependency-free port of Google's libphonenumber (DEC-0033). This is the only
 * code that imports the phone library; the domain stays vendor-free.
 *
 * The default region (Iran today) is CONFIGURATION, not a hard-coded assumption,
 * so country expansion does not touch the domain. Common Iranian inputs all
 * normalise predictably to E.164:
 *   09123456789   → +989123456789   (national, leading 0)
 *   9123456789    → +989123456789   (national, no 0)
 *   00989123456789→ +989123456789   (00 international prefix)
 *   989123456789  → +989123456789   (country code, no +)
 *   +989123456789 → +989123456789   (already E.164)
 * Persian/Arabic-Indic digits are folded to ASCII first, since users type them.
 */
@Injectable()
export class LibphonenumberPhoneNormalizer implements PhoneNormalizer {
  private readonly defaultRegion: string;

  constructor(defaultRegion: string = phoneDefaultRegion()) {
    this.defaultRegion = defaultRegion;
  }

  normalize(raw: string): PhoneNumber {
    if (typeof raw !== 'string') {
      throw new InvalidPhoneNumberError();
    }

    const folded = foldDigits(raw).trim();
    if (folded.length === 0) {
      throw new InvalidPhoneNumberError();
    }

    // Keep only digits and a single leading '+'; turn a 00 international prefix
    // into '+' so a country-code-without-plus form is understood.
    let candidate = folded.replace(/(?!^\+)[^\d]/g, '').replace(/(?!^)\+/g, '');
    if (candidate.startsWith('00')) {
      candidate = `+${candidate.slice(2)}`;
    }

    // Attempt 1: interpret using the default region (handles national forms).
    const primary = this.tryParse(candidate, this.defaultRegion);
    if (primary) return primary;

    // Attempt 2: if not already international, treat the digits as an E.164 body.
    if (!candidate.startsWith('+')) {
      const international = this.tryParse(`+${candidate}`, undefined);
      if (international) return international;
    }

    throw new InvalidPhoneNumberError();
  }

  private tryParse(input: string, region: string | undefined): PhoneNumber | null {
    try {
      const parsed = parsePhoneNumberWithError(
        input,
        region as Parameters<typeof parsePhoneNumberWithError>[1],
      );
      if (!parsed.isValid()) return null;
      return PhoneNumber.fromE164(parsed.number, parsed.country ?? null);
    } catch {
      return null;
    }
  }
}

/** Fold Persian (۰-۹) and Arabic-Indic (٠-٩) digits to ASCII 0-9. */
function foldDigits(value: string): string {
  let out = '';
  for (const ch of value) {
    const code = ch.codePointAt(0) ?? 0;
    if (code >= 0x06f0 && code <= 0x06f9) {
      out += String.fromCharCode(code - 0x06f0 + 0x30); // Persian
    } else if (code >= 0x0660 && code <= 0x0669) {
      out += String.fromCharCode(code - 0x0660 + 0x30); // Arabic-Indic
    } else {
      out += ch;
    }
  }
  return out;
}
