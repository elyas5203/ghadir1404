/**
 * Mapping between persistence rows and domain entities for the phone capability.
 * Lives in infrastructure so Prisma-shaped rows become Prisma-free domain
 * objects here and nowhere else (DEC-0031). The domain factories re-validate
 * every invariant, so a corrupt row cannot enter the domain silently.
 */

import { PhoneClaim } from '../domain/phone-claim';
import type { PhoneClaimStatus } from '../domain/phone-claim';
import { OtpChallenge } from '../domain/otp-challenge';
import type { OtpPurpose } from '../domain/otp-challenge';

/** Shape of a `phone_claims` row the mapper needs. */
export interface PhoneClaimRow {
  id: string;
  userId: string;
  e164: string;
  region: string | null;
  status: string;
  verifiedAt: Date | null;
  revokedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

/** Shape of an `otp_challenges` row the mapper needs. */
export interface OtpChallengeRow {
  id: string;
  userId: string | null;
  e164: string;
  purpose: string;
  codeHash: string;
  attempts: number;
  maxAttempts: number;
  expiresAt: Date;
  consumedAt: Date | null;
  supersededAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export function toPhoneClaim(row: PhoneClaimRow): PhoneClaim {
  return PhoneClaim.restore({
    id: row.id,
    userId: row.userId,
    e164: row.e164,
    region: row.region,
    status: row.status as PhoneClaimStatus,
    verifiedAt: row.verifiedAt,
    revokedAt: row.revokedAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}

export function toOtpChallenge(row: OtpChallengeRow): OtpChallenge {
  return OtpChallenge.restore({
    id: row.id,
    userId: row.userId,
    e164: row.e164,
    purpose: row.purpose as OtpPurpose,
    codeHash: row.codeHash,
    attempts: row.attempts,
    maxAttempts: row.maxAttempts,
    expiresAt: row.expiresAt,
    consumedAt: row.consumedAt,
    supersededAt: row.supersededAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  });
}
