import { join } from 'node:path';
import { tmpdir } from 'node:os';

/** WSL/Linux only. No TCP listener and no public API route. */
export function localOtpDirectory(): string {
  if (process.platform !== 'linux' || !process.getuid) {
    throw new Error('Local OTP tooling requires Linux/WSL.');
  }
  return join(tmpdir(), `khatmsaz-otp-${process.getuid()}`);
}

export function localOtpSocket(): string {
  return join(localOtpDirectory(), 'delivery.sock');
}
