import { HmacOtpCodeHasher } from './hmac-otp-code-hasher';
import { OtpPurpose } from '../domain/otp-challenge';

const ctx = { e164: '+989123456789', purpose: OtpPurpose.PHONE_VERIFICATION };

describe('HmacOtpCodeHasher', () => {
  const hasher = new HmacOtpCodeHasher('unit-test-pepper');

  it('produces a hex digest that is not the plaintext code', () => {
    const hash = hasher.hash('123456', ctx);
    expect(hash).toMatch(/^[0-9a-f]{64}$/); // SHA-256 hex
    expect(hash).not.toContain('123456');
  });

  it('verifies a correct code and rejects a wrong one', () => {
    const hash = hasher.hash('123456', ctx);
    expect(hasher.verify('123456', hash, ctx)).toBe(true);
    expect(hasher.verify('654321', hash, ctx)).toBe(false);
  });

  it('binds the hash to the phone number (no cross-number replay)', () => {
    const hash = hasher.hash('123456', ctx);
    expect(hasher.verify('123456', hash, { ...ctx, e164: '+989120000000' })).toBe(false);
  });

  it('binds the hash to the purpose', () => {
    const hash = hasher.hash('123456', ctx);
    // A different purpose must not validate, even with the same code + number.
    expect(hasher.verify('123456', hash, { ...ctx, purpose: 'LOGIN' as OtpPurpose })).toBe(false);
  });

  it('uses the secret as a key: a different pepper yields a different hash', () => {
    const other = new HmacOtpCodeHasher('a-different-pepper');
    expect(other.hash('123456', ctx)).not.toBe(hasher.hash('123456', ctx));
    // And a hash made under one pepper cannot be verified under another.
    expect(other.verify('123456', hasher.hash('123456', ctx), ctx)).toBe(false);
  });

  it('returns false (not throw) for a malformed stored hash', () => {
    expect(hasher.verify('123456', 'not-hex', ctx)).toBe(false);
    expect(hasher.verify('123456', '', ctx)).toBe(false);
  });
});
