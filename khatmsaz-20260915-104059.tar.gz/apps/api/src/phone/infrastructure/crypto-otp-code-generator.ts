import { Injectable } from '@nestjs/common';
import { randomInt } from 'node:crypto';
import type { OtpCodeGenerator } from '../domain/otp-code';

/**
 * Cryptographically secure numeric OTP generator. Uses Node's `crypto.randomInt`
 * (a CSPRNG) — never `Math.random`. Each digit is drawn uniformly; the code is
 * left-padded so a leading zero is never dropped, keeping full length entropy.
 */
@Injectable()
export class CryptoOtpCodeGenerator implements OtpCodeGenerator {
  generate(length: number): string {
    if (!Number.isInteger(length) || length < 1 || length > 12) {
      throw new Error('OTP code length must be an integer between 1 and 12.');
    }
    // randomInt(max) is uniform over [0, max); build digit by digit so very large
    // lengths never overflow the safe-integer range.
    let code = '';
    for (let i = 0; i < length; i += 1) {
      code += randomInt(0, 10).toString();
    }
    return code;
  }
}
