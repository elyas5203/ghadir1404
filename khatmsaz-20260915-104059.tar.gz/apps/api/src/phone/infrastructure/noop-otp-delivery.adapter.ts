import { Injectable, Logger } from '@nestjs/common';
import type { OtpDelivery, OtpDeliveryRequest } from '../domain/otp-delivery';

/**
 * The default {@link OtpDelivery} binding for this phase: it accepts a delivery
 * request and does nothing with the code. No real SMS provider is integrated yet
 * (DEC-0036); that adapter arrives in a later transport phase.
 *
 * SECURITY: this adapter logs NEITHER the code NOR the phone number. Logging an
 * OTP "to make local development easier" would leak a live credential, and phone
 * numbers are PII that must never be logged (SECURITY.md). It records only that a
 * delivery was requested, and the purpose — nothing sensitive.
 */
@Injectable()
export class NoopOtpDeliveryAdapter implements OtpDelivery {
  private readonly logger = new Logger(NoopOtpDeliveryAdapter.name);

  async deliver(request: OtpDeliveryRequest): Promise<void> {
    this.logger.debug(`OTP delivery requested (purpose=${request.purpose}); no provider configured.`);
  }
}
