import { LibphonenumberPhoneNormalizer } from './libphonenumber-phone-normalizer';
import { InvalidPhoneNumberError } from '../domain/phone.errors';

describe('LibphonenumberPhoneNormalizer (default region IR)', () => {
  const normalizer = new LibphonenumberPhoneNormalizer('IR');

  it.each([
    ['national with leading zero', '09123456789'],
    ['national without leading zero', '9123456789'],
    ['country code without plus', '989123456789'],
    ['full E.164', '+989123456789'],
    ['00 international prefix', '00989123456789'],
    ['spaced and dashed', '0912-345 6789'],
    ['parenthesised', '(0912) 345 6789'],
  ])('normalises an Iranian mobile given as %s to E.164', (_label, input) => {
    const result = normalizer.normalize(input);
    expect(result.e164).toBe('+989123456789');
    expect(result.region).toBe('IR');
  });

  it('folds Persian and Arabic-Indic digits before parsing', () => {
    // ۰۹۱۲۳۴۵۶۷۸۹ (Persian) and ٠٩١٢٣٤٥٦٧٨٩ (Arabic-Indic)
    expect(normalizer.normalize('۰۹۱۲۳۴۵۶۷۸۹').e164).toBe('+989123456789');
    expect(normalizer.normalize('٠٩١٢٣٤٥٦٧٨٩').e164).toBe('+989123456789');
  });

  it('normalises a full international number from another country', () => {
    const us = normalizer.normalize('+1 415 555 2671');
    expect(us.e164).toBe('+14155552671');
    expect(us.region).toBe('US');
  });

  it.each([
    ['empty', ''],
    ['whitespace', '   '],
    ['letters', 'not-a-phone'],
    ['too short', '0912'],
    ['too long', '0912345678901234'],
    ['invalid Iranian landline-as-mobile pattern', '00000000000'],
  ])('rejects an invalid input (%s) with InvalidPhoneNumberError', (_label, input) => {
    expect(() => normalizer.normalize(input)).toThrow(InvalidPhoneNumberError);
  });

  it('never echoes the offending input in the error message', () => {
    try {
      normalizer.normalize('12345garbage');
      fail('expected throw');
    } catch (e) {
      expect((e as Error).message).not.toContain('12345garbage');
    }
  });

  it('respects a different default region without code changes', () => {
    const gb = new LibphonenumberPhoneNormalizer('GB');
    // A UK mobile in national form.
    expect(gb.normalize('07400123456').e164).toBe('+447400123456');
  });
});
