import { mkdtemp, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { request } from 'node:http';
import { assertLocalDevelopment, localOtpEnabled } from '@khatmsaz/config';
import { LocalOtpDeliveryAdapter } from './local-otp-delivery.adapter';
import * as paths from './local-otp-socket';

describe('local OTP delivery', () => {
  const originalEnv = { ...process.env };
  let directory: string;
  let adapter: LocalOtpDeliveryAdapter;
  const phone = '+989120000001';
  const delivery = (code = '123456', expiresAt = new Date(Date.now() + 60000)) => ({
    e164: phone,
    code,
    expiresAt,
    purpose: 'PHONE_LOGIN' as const,
  });

  beforeEach(async () => {
    process.env.NODE_ENV = 'development';
    process.env.KHATMSAZ_DEV_OTP = '1';
    process.env.DATABASE_URL = 'postgresql://local:local@127.0.0.1/local';
    directory = await mkdtemp(join(tmpdir(), 'khatmsaz-otp-test-'));
    jest.spyOn(paths, 'localOtpDirectory').mockReturnValue(directory);
    jest.spyOn(paths, 'localOtpSocket').mockReturnValue(join(directory, 'delivery.sock'));
    adapter = new LocalOtpDeliveryAdapter();
  });
  afterEach(async () => {
    await adapter.onModuleDestroy();
    await rm(directory, { recursive: true, force: true });
    jest.restoreAllMocks();
    process.env = { ...originalEnv };
  });
  const read = (path = `/latest?e164=${encodeURIComponent(phone)}`, method = 'GET') =>
    new Promise<{ status: number; body: string }>((resolve, reject) => {
      const req = request({ socketPath: paths.localOtpSocket(), path, method }, (res) => {
        let body = '';
        res.on('data', (chunk: Buffer) => {
          body += chunk.toString();
        });
        res.on('end', () => resolve({ status: res.statusCode!, body }));
      });
      req.on('error', reject);
      req.end();
    });

  it('delivers the latest code once through an owner-only socket, without logging', async () => {
    const log = jest.spyOn(console, 'log');
    const error = jest.spyOn(console, 'error');
    await adapter.onModuleInit();
    expect((await stat(paths.localOtpSocket())).mode & 0o777).toBe(0o600);
    await adapter.deliver(delivery());
    await adapter.deliver(delivery('654321'));
    expect((await read('/wrong')).status).toBe(404);
    expect((await read(undefined, 'POST')).status).toBe(404);
    expect(await read()).toEqual({ status: 200, body: JSON.stringify({ code: '654321' }) });
    expect((await read()).status).toBe(404);
    expect(log).not.toHaveBeenCalled();
    expect(error).not.toHaveBeenCalled();
    await adapter.onModuleDestroy();
    await expect(stat(paths.localOtpSocket())).rejects.toThrow();
  });
  it.each(['production', 'test', 'staging', ''])(
    'never opens a socket or retains credentials in %s',
    async (mode) => {
      process.env.NODE_ENV = mode;
      expect(localOtpEnabled()).toBe(false);
      await adapter.onModuleInit();
      await adapter.deliver(delivery());
      expect(adapter.takeLatest(phone)).toBeNull();
      await expect(stat(paths.localOtpSocket())).rejects.toThrow();
      expect(() => assertLocalDevelopment()).toThrow();
    },
  );
  it('requires explicit opt-in even in development', async () => {
    delete process.env.KHATMSAZ_DEV_OTP;
    await adapter.onModuleInit();
    await adapter.deliver(delivery());
    expect(adapter.takeLatest(phone)).toBeNull();
    await expect(stat(paths.localOtpSocket())).rejects.toThrow();
  });
  it('rejects remote databases and libpq host overrides', () => {
    for (const url of [
      'postgresql://local:local@example.com/db',
      'postgresql://local:local@localhost/db?host=example.com',
    ]) {
      process.env.DATABASE_URL = url;
      expect(() => assertLocalDevelopment()).toThrow();
    }
  });
  it('drops expired and non-login codes and clears memory when disabled', async () => {
    await adapter.deliver(delivery('123456', new Date(0)));
    expect(adapter.takeLatest(phone)).toBeNull();
    await adapter.deliver({ ...delivery(), purpose: 'PHONE_VERIFICATION' });
    expect(adapter.takeLatest(phone)).toBeNull();
    await adapter.deliver(delivery());
    process.env.NODE_ENV = 'production';
    expect(adapter.takeLatest(phone)).toBeNull();
    process.env.NODE_ENV = 'development';
    expect(adapter.takeLatest(phone)).toBeNull();
  });
  it('fails closed when another listener already owns the socket', async () => {
    await adapter.onModuleInit();
    const other = new LocalOtpDeliveryAdapter();
    await expect(other.onModuleInit()).rejects.toThrow('unavailable');
    await other.onModuleDestroy();
    await adapter.deliver(delivery());
    expect((await read()).status).toBe(200);
  });
  it('denies retrieval if the mode changes after startup', async () => {
    await adapter.onModuleInit();
    await adapter.deliver(delivery());
    process.env.NODE_ENV = 'production';
    expect((await read()).status).toBe(404);
  });
});
