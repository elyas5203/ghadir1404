import { Injectable } from '@nestjs/common';
import type { Clock } from '../domain/clock';

/** {@link Clock} bound to the real system time. Tests inject a controllable one. */
@Injectable()
export class SystemClock implements Clock {
  now(): Date {
    return new Date();
  }
}
