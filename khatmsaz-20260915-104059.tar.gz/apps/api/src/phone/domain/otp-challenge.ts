/**
 * OtpChallenge — a DOMAIN entity for a single one-time-password verification
 * challenge (DEC-0033, DEC-0035).
 *
 * The challenge NEVER holds the plaintext code. It holds only a keyed HMAC of
 * the code (`codeHash`, computed in infrastructure with a server pepper); the
 * plaintext exists just long enough to be delivered and is then unrecoverable.
 * The entity therefore has no way to leak a code, and its lifecycle is expressed
 * with explicit event timestamps and counters rather than opaque booleans:
 *
 *   - `expiresAt`         — a short TTL; past it the challenge is dead.
 *   - `attempts`/`maxAttempts` — bounded wrong submissions.
 *   - `consumedAt`        — set once, on the single successful verification.
 *   - `supersededAt`      — set when a newer challenge replaces this one (resend).
 *
 * A challenge is usable only while none of those has ended it. Each field is a
 * distinct real-world event, so there is no ambiguous boolean soup.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { isE164 } from './phone-number';
import { InvalidPhoneClaimError, InvalidPhoneNumberError, UnknownOtpPurposeError } from './phone.errors';

/**
 * Why a challenge exists. Only PHONE_VERIFICATION is used today; the enum exists
 * so further purposes (e.g. login, recovery) can be added later WITHOUT a schema
 * reshuffle. No speculative purpose is added now. Mirrors the persistence enum
 * `otp_purpose`.
 */
export const OtpPurpose = {
  PHONE_VERIFICATION: 'PHONE_VERIFICATION',
  /** Phone-first login: a USER-LESS possession proof (user_id null, DEC-0066). */
  PHONE_LOGIN: 'PHONE_LOGIN',
} as const;

export type OtpPurpose = (typeof OtpPurpose)[keyof typeof OtpPurpose];

export const ALL_OTP_PURPOSES: readonly OtpPurpose[] = Object.values(OtpPurpose);

export function isOtpPurpose(value: unknown): value is OtpPurpose {
  return typeof value === 'string' && (ALL_OTP_PURPOSES as readonly string[]).includes(value);
}

export interface OtpChallengeProps {
  readonly id: string;
  /** The user the challenge belongs to. Nullable to allow future userless purposes. */
  readonly userId: string | null;
  readonly e164: string;
  readonly purpose: OtpPurpose;
  /** Keyed HMAC of the code — never the code itself. */
  readonly codeHash: string;
  readonly attempts: number;
  readonly maxAttempts: number;
  readonly expiresAt: Date;
  readonly consumedAt: Date | null;
  readonly supersededAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export class OtpChallenge {
  readonly id: string;
  readonly userId: string | null;
  readonly e164: string;
  readonly purpose: OtpPurpose;
  readonly codeHash: string;
  readonly attempts: number;
  readonly maxAttempts: number;
  readonly expiresAt: Date;
  readonly consumedAt: Date | null;
  readonly supersededAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: OtpChallengeProps) {
    this.id = props.id;
    this.userId = props.userId;
    this.e164 = props.e164;
    this.purpose = props.purpose;
    this.codeHash = props.codeHash;
    this.attempts = props.attempts;
    this.maxAttempts = props.maxAttempts;
    this.expiresAt = props.expiresAt;
    this.consumedAt = props.consumedAt;
    this.supersededAt = props.supersededAt;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  isConsumed(): boolean {
    return this.consumedAt !== null;
  }

  isSuperseded(): boolean {
    return this.supersededAt !== null;
  }

  isExpired(now: Date): boolean {
    return now.getTime() >= this.expiresAt.getTime();
  }

  attemptsExhausted(): boolean {
    return this.attempts >= this.maxAttempts;
  }

  /** True only while the challenge can still accept a verification attempt. */
  isActive(now: Date): boolean {
    return !this.isConsumed() && !this.isSuperseded() && !this.isExpired(now) && !this.attemptsExhausted();
  }

  static restore(props: OtpChallengeProps): OtpChallenge {
    assertUuidV7(props.id, 'OtpChallenge.id');
    if (props.userId !== null) {
      assertUuidV7(props.userId, 'OtpChallenge.userId');
    }
    if (!isE164(props.e164)) {
      throw new InvalidPhoneNumberError();
    }
    if (!isOtpPurpose(props.purpose)) {
      throw new UnknownOtpPurposeError();
    }
    if (typeof props.codeHash !== 'string' || props.codeHash.length === 0) {
      throw new InvalidPhoneClaimError('codeHash');
    }
    if (!Number.isInteger(props.attempts) || props.attempts < 0) {
      throw new InvalidPhoneClaimError('attempts');
    }
    if (!Number.isInteger(props.maxAttempts) || props.maxAttempts <= 0) {
      throw new InvalidPhoneClaimError('maxAttempts');
    }
    return new OtpChallenge(props);
  }
}
