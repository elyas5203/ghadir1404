/**
 * OtpDelivery — a PORT owned by the domain for sending a code to its recipient
 * (DEC-0018, DEC-0036).
 *
 * This is the seam a real SMS provider will sit behind LATER. This phase ships
 * NO real provider: the default binding is a no-op adapter, and tests use an
 * in-memory fake. Application code depends only on this interface, so no future
 * SMS vendor can leak into the domain.
 *
 * SECURITY: an implementation must NEVER log the code or the phone number. The
 * no-op adapter deliberately drops the code and logs neither — a code logged
 * "for convenience" is a leaked credential (SECURITY.md).
 */

import type { OtpPurpose } from './otp-challenge';

/** DI token for {@link OtpDelivery}. */
export const OTP_DELIVERY = Symbol('OTP_DELIVERY');

/** Everything an adapter needs to deliver one code. The `code` is plaintext. */
export interface OtpDeliveryRequest {
  readonly e164: string;
  readonly code: string;
  readonly purpose: OtpPurpose;
  readonly expiresAt: Date;
}

export interface OtpDelivery {
  /** Deliver the code to `request.e164`. Must not log the code or the number. */
  deliver(request: OtpDeliveryRequest): Promise<void>;
}
