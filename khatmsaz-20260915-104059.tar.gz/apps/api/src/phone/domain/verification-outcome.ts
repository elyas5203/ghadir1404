/**
 * The result of a successful-code verification attempt (DEC-0034, DEC-0037).
 *
 * A wrong/expired/exhausted code is signalled by a thrown domain error. Once the
 * code itself is correct, the OUTCOME describes what the correct code led to —
 * and this is where the phone-ownership rule lives:
 *
 *   - VERIFIED         — the claim is now this user's verified number. When the
 *                        user already had a different verified number, it was
 *                        revoked to keep one verified phone per user (DEC-0046) and
 *                        its E.164 is reported as `replacedE164`.
 *   - ALREADY_VERIFIED — this user had already verified this number (idempotent).
 *   - MERGE_REQUIRED   — the number is actively verified by a DIFFERENT account.
 *                        The code was right, but ownership is NOT transferred and
 *                        accounts are NOT merged here. This is the explicit hand-
 *                        off to the Phase 3B account-merge workflow. It carries
 *                        NO detail about the other account, so a future public
 *                        response can surface it without enabling enumeration.
 */

import type { PhoneClaim } from './phone-claim';

export const VerificationOutcome = {
  VERIFIED: 'VERIFIED',
  ALREADY_VERIFIED: 'ALREADY_VERIFIED',
  MERGE_REQUIRED: 'MERGE_REQUIRED',
} as const;

export type VerificationOutcome = (typeof VerificationOutcome)[keyof typeof VerificationOutcome];

export type PhoneVerificationResult =
  | { readonly outcome: 'VERIFIED'; readonly claim: PhoneClaim; readonly replacedE164?: string }
  | { readonly outcome: 'ALREADY_VERIFIED'; readonly claim: PhoneClaim }
  | { readonly outcome: 'MERGE_REQUIRED' };
