/**
 * OtpChallengeRepository — a persistence PORT OWNED BY THE DOMAIN.
 *
 * Expressed in domain terms; the Prisma-backed implementation lives in
 * infrastructure (DEC-0031). Only this phase's operations are declared. Attempt
 * counting and supersession are performed as atomic writes so concurrent
 * verification attempts cannot lose an increment.
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { OtpChallenge, OtpPurpose } from './otp-challenge';

/** DI token for {@link OtpChallengeRepository}. */
export const OTP_CHALLENGE_REPOSITORY = Symbol('OTP_CHALLENGE_REPOSITORY');

/** Inputs for creating a new OTP challenge. */
export interface CreateOtpChallengeInput {
  readonly id: string;
  readonly userId: string | null;
  readonly e164: string;
  readonly purpose: OtpPurpose;
  readonly codeHash: string;
  readonly maxAttempts: number;
  readonly expiresAt: Date;
}

export interface OtpChallengeRepository {
  /** Insert a new challenge (`attempts` starts at 0). */
  create(input: CreateOtpChallengeInput): Promise<OtpChallenge>;

  /** The most recently created challenge for (userId, e164, purpose), or `null`. */
  findLatestForTarget(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
  ): Promise<OtpChallenge | null>;

  /**
   * The most recently created USER-LESS challenge for (e164, purpose) — used by the
   * phone-first login flow, where `user_id` is null (DEC-0066).
   */
  findLatestUserless(e164: string, purpose: OtpPurpose): Promise<OtpChallenge | null>;

  /** Supersede every still-active USER-LESS challenge for (e164, purpose) as of `at`. */
  supersedeActiveUserless(e164: string, purpose: OtpPurpose, at: Date): Promise<number>;

  /**
   * Mark every still-active challenge for (userId, e164, purpose) as superseded
   * as of `at`. Used when issuing a replacement so only one challenge is ever
   * live for a target. Returns the number of rows superseded.
   */
  supersedeActive(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
    at: Date,
  ): Promise<number>;

  /** Atomically increment the attempt counter of a challenge by one. */
  recordFailedAttempt(challengeId: string): Promise<void>;

  /** Mark a challenge consumed (single-use) as of `at`. Idempotent-safe. */
  consume(challengeId: string, at: Date, tx?: TransactionContext): Promise<void>;
}
