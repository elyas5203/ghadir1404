import { newUuidV7 as newIdentityId } from '@khatmsaz/kernel';
import { OtpChallenge, OtpPurpose, isOtpPurpose } from './otp-challenge';
import { InvalidPhoneClaimError, InvalidPhoneNumberError, UnknownOtpPurposeError } from './phone.errors';

const NOW = new Date('2026-09-06T12:00:00.000Z');

const base = () => ({
  id: newIdentityId(),
  userId: newIdentityId() as string | null,
  e164: '+989123456789',
  purpose: OtpPurpose.PHONE_VERIFICATION as OtpPurpose,
  codeHash: 'a'.repeat(64),
  attempts: 0,
  maxAttempts: 5,
  expiresAt: new Date(NOW.getTime() + 300_000),
  consumedAt: null as Date | null,
  supersededAt: null as Date | null,
  createdAt: NOW,
  updatedAt: NOW,
});

describe('OtpChallenge lifecycle', () => {
  it('is active when fresh, unconsumed, unsuperseded and within attempts', () => {
    const c = OtpChallenge.restore(base());
    expect(c.isActive(NOW)).toBe(true);
  });

  it('is expired at or after expiresAt', () => {
    const c = OtpChallenge.restore(base());
    expect(c.isExpired(new Date(NOW.getTime() + 299_999))).toBe(false);
    expect(c.isExpired(new Date(NOW.getTime() + 300_000))).toBe(true);
    expect(c.isActive(new Date(NOW.getTime() + 300_000))).toBe(false);
  });

  it('is exhausted when attempts reach maxAttempts', () => {
    const c = OtpChallenge.restore({ ...base(), attempts: 5, maxAttempts: 5 });
    expect(c.attemptsExhausted()).toBe(true);
    expect(c.isActive(NOW)).toBe(false);
  });

  it('is inactive once consumed', () => {
    const c = OtpChallenge.restore({ ...base(), consumedAt: NOW });
    expect(c.isConsumed()).toBe(true);
    expect(c.isActive(NOW)).toBe(false);
  });

  it('is inactive once superseded', () => {
    const c = OtpChallenge.restore({ ...base(), supersededAt: NOW });
    expect(c.isSuperseded()).toBe(true);
    expect(c.isActive(NOW)).toBe(false);
  });

  it('allows a null userId (future userless purposes)', () => {
    expect(() => OtpChallenge.restore({ ...base(), userId: null })).not.toThrow();
  });

  it('rejects an empty codeHash, bad counters, non-E.164, unknown purpose', () => {
    expect(() => OtpChallenge.restore({ ...base(), codeHash: '' })).toThrow(InvalidPhoneClaimError);
    expect(() => OtpChallenge.restore({ ...base(), maxAttempts: 0 })).toThrow(InvalidPhoneClaimError);
    expect(() => OtpChallenge.restore({ ...base(), attempts: -1 })).toThrow(InvalidPhoneClaimError);
    expect(() => OtpChallenge.restore({ ...base(), e164: '0912' })).toThrow(InvalidPhoneNumberError);
    expect(() =>
      OtpChallenge.restore({ ...base(), purpose: 'LOGIN' as OtpPurpose }),
    ).toThrow(UnknownOtpPurposeError);
  });

  it('narrows known purposes only', () => {
    expect(isOtpPurpose('PHONE_VERIFICATION')).toBe(true);
    expect(isOtpPurpose('LOGIN')).toBe(false);
  });
});
