/**
 * Clock — a tiny PORT owned by the domain so time-dependent use-cases (OTP
 * expiry, resend cooldown) are deterministic under test. Production binds it to
 * the system clock; tests inject a controllable one.
 */

/** DI token for {@link Clock}. */
export const CLOCK = Symbol('CLOCK');

export interface Clock {
  now(): Date;
}
