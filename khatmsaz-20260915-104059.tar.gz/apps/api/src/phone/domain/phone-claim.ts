/**
 * PhoneClaim — a DOMAIN entity capturing a user's claim on a phone number and
 * where that claim sits in its lifecycle (DEC-0033, DEC-0034).
 *
 * A phone number means two very different things in KhatmSaz and this entity
 * keeps them distinct rather than as a pair of booleans:
 *
 *   - UNVERIFIED — merely contact/profile information the user typed. It proves
 *     NOTHING, is not account ownership, does NOT have to be globally unique,
 *     and must never drive authorisation (DEC-0011).
 *   - VERIFIED — a strong, OTP-proven claim. Globally unique among ACTIVE
 *     verified claims (a partial unique index), and the basis for future
 *     recovery/login and account merging (DEC-0012).
 *   - REVOKED — an ended/historical claim. Kept, never deleted, so a user's
 *     phone history is preserved (DEC-0025).
 *
 * Plain domain object: no Prisma, no framework, no vendor SDK.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { isE164 } from './phone-number';
import { InvalidPhoneClaimError, InvalidPhoneNumberError, UnknownPhoneClaimStatusError } from './phone.errors';

/** Lifecycle of a phone claim. Mirrors the persistence enum `phone_claim_status`. */
export const PhoneClaimStatus = {
  UNVERIFIED: 'UNVERIFIED',
  VERIFIED: 'VERIFIED',
  REVOKED: 'REVOKED',
} as const;

export type PhoneClaimStatus = (typeof PhoneClaimStatus)[keyof typeof PhoneClaimStatus];

export const ALL_PHONE_CLAIM_STATUSES: readonly PhoneClaimStatus[] = Object.values(PhoneClaimStatus);

export function isPhoneClaimStatus(value: unknown): value is PhoneClaimStatus {
  return typeof value === 'string' && (ALL_PHONE_CLAIM_STATUSES as readonly string[]).includes(value);
}

export interface PhoneClaimProps {
  readonly id: string;
  readonly userId: string;
  readonly e164: string;
  readonly region: string | null;
  readonly status: PhoneClaimStatus;
  readonly verifiedAt: Date | null;
  readonly revokedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export class PhoneClaim {
  readonly id: string;
  readonly userId: string;
  readonly e164: string;
  readonly region: string | null;
  readonly status: PhoneClaimStatus;
  readonly verifiedAt: Date | null;
  readonly revokedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;

  private constructor(props: PhoneClaimProps) {
    this.id = props.id;
    this.userId = props.userId;
    this.e164 = props.e164;
    this.region = props.region;
    this.status = props.status;
    this.verifiedAt = props.verifiedAt;
    this.revokedAt = props.revokedAt;
    this.createdAt = props.createdAt;
    this.updatedAt = props.updatedAt;
  }

  get isVerified(): boolean {
    return this.status === PhoneClaimStatus.VERIFIED;
  }

  get isUnverified(): boolean {
    return this.status === PhoneClaimStatus.UNVERIFIED;
  }

  get isRevoked(): boolean {
    return this.status === PhoneClaimStatus.REVOKED;
  }

  /**
   * Reconstitute a persisted claim, enforcing every identity invariant: ids are
   * UUIDv7, the number is canonical E.164, and the status is known. A VERIFIED
   * claim must carry a `verifiedAt`; a REVOKED claim must carry a `revokedAt` —
   * the lifecycle stays internally consistent, not a free-for-all of booleans.
   */
  static restore(props: PhoneClaimProps): PhoneClaim {
    assertUuidV7(props.id, 'PhoneClaim.id');
    assertUuidV7(props.userId, 'PhoneClaim.userId');
    if (!isE164(props.e164)) {
      throw new InvalidPhoneNumberError();
    }
    if (!isPhoneClaimStatus(props.status)) {
      throw new UnknownPhoneClaimStatusError();
    }
    if (props.status === PhoneClaimStatus.VERIFIED && !props.verifiedAt) {
      throw new InvalidPhoneClaimError('verifiedAt');
    }
    if (props.status === PhoneClaimStatus.REVOKED && !props.revokedAt) {
      throw new InvalidPhoneClaimError('revokedAt');
    }
    return new PhoneClaim(props);
  }
}
