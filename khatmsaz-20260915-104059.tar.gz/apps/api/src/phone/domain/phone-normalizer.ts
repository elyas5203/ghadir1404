/**
 * PhoneNormalizer — a PORT owned by the domain (DEC-0018, DEC-0033).
 *
 * Turning a raw, user-typed phone string (Iranian local `09xxxxxxxxx`, national
 * `9xxxxxxxxx`, `989xxxxxxxxx`, `+989xxxxxxxxx`, and — later — other countries)
 * into a canonical E.164 {@link PhoneNumber} needs a real phone-number library.
 * The domain owns this interface and stays vendor-free; the implementation
 * (backed by a maintained parsing library) lives in infrastructure. This mirrors
 * the platform-adapter rule: the domain depends on an interface it owns.
 *
 * The architecture is deliberately NOT hard-wired to Iran: the default region is
 * a parameter of the implementation, so country expansion is a configuration
 * change, not a code change.
 */

import type { PhoneNumber } from './phone-number';

/** DI token for {@link PhoneNormalizer}. */
export const PHONE_NORMALIZER = Symbol('PHONE_NORMALIZER');

export interface PhoneNormalizer {
  /**
   * Normalise a raw phone string to canonical E.164. Throws
   * {@link import('./phone.errors').InvalidPhoneNumberError} when the input is
   * not a valid phone number. Must never echo the input in the error (PII).
   */
  normalize(raw: string): PhoneNumber;
}
