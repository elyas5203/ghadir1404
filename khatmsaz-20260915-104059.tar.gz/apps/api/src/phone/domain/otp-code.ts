/**
 * OTP code generation and hashing — PORTS owned by the domain.
 *
 * Both are implemented in infrastructure with Node's crypto primitives:
 *
 *   - {@link OtpCodeGenerator} produces a numeric code using a cryptographically
 *     secure RNG (never `Math.random`).
 *   - {@link OtpCodeHasher} protects the low-entropy code at rest with a
 *     server-secret keyed HMAC (a pepper), so a leaked database cannot be
 *     brute-forced offline without also stealing the secret. `hash` and `verify`
 *     bind the code to its target and purpose so a hash for one number/purpose
 *     can never validate another.
 *
 * The domain and application never see the pepper; they depend only on these
 * interfaces, which keeps the secret injectable and the code testable.
 */

import type { OtpPurpose } from './otp-challenge';

/** DI token for {@link OtpCodeGenerator}. */
export const OTP_CODE_GENERATOR = Symbol('OTP_CODE_GENERATOR');
/** DI token for {@link OtpCodeHasher}. */
export const OTP_CODE_HASHER = Symbol('OTP_CODE_HASHER');

export interface OtpCodeGenerator {
  /** Generate a fresh numeric code of `length` digits using a secure RNG. */
  generate(length: number): string;
}

/** The context a code is bound to, so a hash is only valid for that target. */
export interface OtpHashContext {
  readonly e164: string;
  readonly purpose: OtpPurpose;
}

export interface OtpCodeHasher {
  /** Compute the keyed HMAC of `code` bound to `ctx`. The result is safe to store. */
  hash(code: string, ctx: OtpHashContext): string;
  /**
   * Constant-time check that `code` matches `storedHash` for `ctx`. Returns a
   * boolean; never throws for a mismatch and never reveals the code or hash.
   */
  verify(code: string, storedHash: string, ctx: OtpHashContext): boolean;
}
