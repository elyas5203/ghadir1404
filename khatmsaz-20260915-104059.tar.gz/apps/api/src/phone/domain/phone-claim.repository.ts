/**
 * PhoneClaimRepository — a persistence PORT OWNED BY THE DOMAIN.
 *
 * Expressed in domain terms ({@link PhoneClaim}, string ids, E.164 strings). The
 * Prisma-backed implementation lives in infrastructure and is the only code that
 * sees Prisma types (DEC-0031). Only this phase's operations are declared.
 *
 * The two hard invariants are enforced by DATABASE constraints, surfaced here as
 * domain errors — never by a read-then-write pre-check:
 *   - at most ONE active VERIFIED claim per canonical number, globally;
 *   - at most ONE active (non-revoked) claim per (user, number).
 */

import type { TransactionContext } from '@khatmsaz/kernel';
import type { PhoneClaim } from './phone-claim';

/** DI token for {@link PhoneClaimRepository}. */
export const PHONE_CLAIM_REPOSITORY = Symbol('PHONE_CLAIM_REPOSITORY');

/** Inputs for creating a new UNVERIFIED phone claim. */
export interface CreatePhoneClaimInput {
  readonly id: string;
  readonly userId: string;
  readonly e164: string;
  readonly region: string | null;
}

export interface PhoneClaimRepository {
  /**
   * The user's active (non-revoked) claim for `e164`, or `null`. There is at
   * most one, enforced by a partial unique index.
   */
  findActiveByUserAndPhone(userId: string, e164: string): Promise<PhoneClaim | null>;

  /**
   * Insert a new UNVERIFIED claim. A missing user (FK) throws
   * {@link import('./phone.errors').PhoneClaimUserNotFoundError}. A concurrent or
   * duplicate active claim for the same (user, number) violates the partial
   * unique index and throws
   * {@link import('./phone.errors').ActivePhoneClaimExistsError}, so the caller
   * can re-read the existing row and keep claim creation idempotent.
   */
  createUnverified(input: CreatePhoneClaimInput): Promise<PhoneClaim>;

  /**
   * Promote an UNVERIFIED claim (by id) to VERIFIED, stamping `verifiedAt`. The
   * global partial unique index on VERIFIED numbers decides concurrency: if the
   * number is already actively verified by another claim, this throws
   * {@link import('./phone.errors').PhoneOwnershipConflictError}. The per-user
   * VERIFIED partial index (DEC-0046) likewise throws it if the user already has a
   * verified claim — so a change-of-phone must revoke the old one first, in the
   * same transaction. Implementations rely on the constraints, not a pre-check.
   */
  markVerified(claimId: string, verifiedAt: Date, tx?: TransactionContext): Promise<PhoneClaim>;

  /** The user's VERIFIED claim, or `null`. At most one exists (DEC-0046). */
  findVerifiedByUser(userId: string, tx?: TransactionContext): Promise<PhoneClaim | null>;

  /** The id of the user who has `e164` VERIFIED, or `null`. At most one (DEC-0034). */
  findVerifiedOwnerId(e164: string, tx?: TransactionContext): Promise<string | null>;

  /** Revoke a claim (by id): status REVOKED, stamping `revokedAt`. Kept as history. */
  revoke(claimId: string, revokedAt: Date, tx?: TransactionContext): Promise<PhoneClaim>;

  /**
   * Revoke every non-revoked claim of a user (status REVOKED, `revokedAt`).
   * Used by the merge use-case before reparenting the loser's claims. Returns the
   * number of claims revoked.
   */
  revokeAllActiveByUser(userId: string, revokedAt: Date, tx?: TransactionContext): Promise<number>;

  /**
   * Reassign every phone claim of `fromUserId` to `toUserId` (an UPDATE — never a
   * delete, so history is preserved and the FK RESTRICT is respected). The caller
   * must first ensure the moved rows cannot violate a partial unique index (e.g.
   * revoke the source's active claims). Returns the number moved.
   */
  reassignOwner(fromUserId: string, toUserId: string, tx?: TransactionContext): Promise<number>;
}
