import { newUuidV7 as newIdentityId } from '@khatmsaz/kernel';
import { PhoneClaim, PhoneClaimStatus, isPhoneClaimStatus } from './phone-claim';
import {
  InvalidPhoneClaimError,
  InvalidPhoneNumberError,
  UnknownPhoneClaimStatusError,
} from './phone.errors';

const base = () => ({
  id: newIdentityId(),
  userId: newIdentityId(),
  e164: '+989123456789',
  region: 'IR' as string | null,
  status: PhoneClaimStatus.UNVERIFIED as PhoneClaimStatus,
  verifiedAt: null as Date | null,
  revokedAt: null as Date | null,
  createdAt: new Date(),
  updatedAt: new Date(),
});

describe('PhoneClaim', () => {
  it('restores an unverified claim and reports its lifecycle', () => {
    const claim = PhoneClaim.restore(base());
    expect(claim.isUnverified).toBe(true);
    expect(claim.isVerified).toBe(false);
    expect(claim.isRevoked).toBe(false);
  });

  it('restores a verified claim carrying verifiedAt', () => {
    const claim = PhoneClaim.restore({
      ...base(),
      status: PhoneClaimStatus.VERIFIED,
      verifiedAt: new Date(),
    });
    expect(claim.isVerified).toBe(true);
  });

  it('rejects a VERIFIED claim without verifiedAt (lifecycle consistency)', () => {
    expect(() => PhoneClaim.restore({ ...base(), status: PhoneClaimStatus.VERIFIED })).toThrow(
      InvalidPhoneClaimError,
    );
  });

  it('rejects a REVOKED claim without revokedAt', () => {
    expect(() => PhoneClaim.restore({ ...base(), status: PhoneClaimStatus.REVOKED })).toThrow(
      InvalidPhoneClaimError,
    );
  });

  it('rejects a non-UUIDv7 id', () => {
    expect(() => PhoneClaim.restore({ ...base(), id: 'not-a-uuid' })).toThrow();
  });

  it('rejects a non-E.164 number', () => {
    expect(() => PhoneClaim.restore({ ...base(), e164: '09123456789' })).toThrow(
      InvalidPhoneNumberError,
    );
  });

  it('rejects an unknown status', () => {
    expect(() =>
      PhoneClaim.restore({ ...base(), status: 'PENDING' as PhoneClaimStatus }),
    ).toThrow(UnknownPhoneClaimStatusError);
  });

  it('narrows known statuses only', () => {
    expect(isPhoneClaimStatus('VERIFIED')).toBe(true);
    expect(isPhoneClaimStatus('PENDING')).toBe(false);
    expect(isPhoneClaimStatus(7)).toBe(false);
  });
});
