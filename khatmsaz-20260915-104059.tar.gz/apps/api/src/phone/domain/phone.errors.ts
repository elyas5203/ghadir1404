/**
 * Domain errors for the phone-verification capability.
 *
 * These are framework- and Prisma-independent. Infrastructure repositories
 * translate persistence failures (unique / foreign-key violations) into these
 * domain errors so nothing outside infrastructure sees a Prisma error type.
 *
 * CRITICAL: no error here ever includes a phone number, an OTP code, an OTP
 * hash, or any other secret/PII. A six-digit code and a raw phone number are
 * both sensitive; error messages stay generic on purpose (see SECURITY.md).
 */

/** Base class for all phone-verification domain errors. */
export class PhoneError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A raw phone string could not be normalised to a valid E.164 number. */
export class InvalidPhoneNumberError extends PhoneError {
  constructor() {
    super('The phone number is not valid.');
  }
}

/** A phone-claim id / user id that must be a UUIDv7 was not one. */
export class InvalidPhoneClaimError extends PhoneError {
  constructor(label: string) {
    super(`Invalid phone claim: ${label} must be a UUIDv7.`);
  }
}

/** An unknown phone-claim lifecycle status was supplied. */
export class UnknownPhoneClaimStatusError extends PhoneError {
  constructor() {
    super('Invalid phone claim: unknown status.');
  }
}

/** A verification action referenced a user that does not exist (FK violation). */
export class PhoneClaimUserNotFoundError extends PhoneError {
  constructor() {
    super('Cannot record phone claim: the referenced user does not exist.');
  }
}

/** Verification was attempted but the user has no phone claim for that number. */
export class NoPhoneClaimError extends PhoneError {
  constructor() {
    super('No phone claim exists for this user and number.');
  }
}

/**
 * An active (non-revoked) claim for the same (user, number) already exists.
 * Surfaced from the database partial unique index so claim creation stays
 * idempotent: the caller re-reads and returns the existing claim.
 */
export class ActivePhoneClaimExistsError extends PhoneError {
  constructor() {
    super('An active phone claim already exists for this user and number.');
  }
}

/**
 * A correct OTP was supplied, but the number is already actively verified by a
 * DIFFERENT user. This is NOT an error the caller can fix by retrying: it is the
 * signal that an account-merge decision is required (Phase 3B). It deliberately
 * carries NO information about which user owns the number, so it can never drive
 * account enumeration through a future public response.
 */
export class PhoneOwnershipConflictError extends PhoneError {
  constructor() {
    super('This phone number is already verified by another account.');
  }
}

/** No active (unconsumed, unexpired, unsuperseded) OTP challenge exists. */
export class NoActiveOtpChallengeError extends PhoneError {
  constructor() {
    super('No active verification challenge. Request a new code.');
  }
}

/** The active OTP challenge has expired. */
export class OtpExpiredError extends PhoneError {
  constructor() {
    super('The verification code has expired. Request a new code.');
  }
}

/** The active OTP challenge has reached its maximum number of attempts. */
export class OtpAttemptsExhaustedError extends PhoneError {
  constructor() {
    super('Too many incorrect attempts. Request a new code.');
  }
}

/** The submitted OTP code did not match. Never includes the code or the hash. */
export class InvalidOtpCodeError extends PhoneError {
  constructor() {
    super('The verification code is incorrect.');
  }
}

/** An unknown OTP purpose was supplied. */
export class UnknownOtpPurposeError extends PhoneError {
  constructor() {
    super('Invalid verification challenge: unknown purpose.');
  }
}

/**
 * A new verification code was requested before the resend cooldown elapsed.
 * `retryAfterSeconds` is a non-secret hint for the caller.
 */
export class OtpResendTooSoonError extends PhoneError {
  constructor(public readonly retryAfterSeconds: number) {
    super('A verification code was requested too recently. Please wait before retrying.');
  }
}
