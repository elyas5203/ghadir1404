import { PhoneNumber, isE164 } from './phone-number';
import { InvalidPhoneNumberError } from './phone.errors';

describe('PhoneNumber / isE164', () => {
  it('accepts well-formed E.164 numbers', () => {
    expect(isE164('+989123456789')).toBe(true);
    expect(isE164('+14155552671')).toBe(true);
  });

  it('rejects non-E.164 shapes', () => {
    expect(isE164('989123456789')).toBe(false); // no +
    expect(isE164('+0989123456789')).toBe(false); // leading zero after +
    expect(isE164('+98 912 345 6789')).toBe(false); // spaces
    expect(isE164('09123456789')).toBe(false); // national
    expect(isE164('')).toBe(false);
    expect(isE164('+')).toBe(false);
  });

  it('builds a PhoneNumber from canonical E.164 and normalises the region', () => {
    const p = PhoneNumber.fromE164('+989123456789', 'ir');
    expect(p.e164).toBe('+989123456789');
    expect(p.region).toBe('IR');
  });

  it('treats a blank region as null', () => {
    expect(PhoneNumber.fromE164('+989123456789', '  ').region).toBeNull();
    expect(PhoneNumber.fromE164('+989123456789').region).toBeNull();
  });

  it('throws on a non-E.164 value without echoing the value', () => {
    expect(() => PhoneNumber.fromE164('09123456789')).toThrow(InvalidPhoneNumberError);
    try {
      PhoneNumber.fromE164('09123456789');
      fail('expected throw');
    } catch (e) {
      expect((e as Error).message).not.toContain('09123456789');
    }
  });
});
