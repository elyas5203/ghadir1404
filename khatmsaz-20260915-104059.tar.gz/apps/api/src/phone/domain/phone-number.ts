/**
 * PhoneNumber — a DOMAIN value object for a canonical phone number.
 *
 * The canonical storage form is E.164 (DEC-0033): a leading `+`, a country
 * calling code, then the national number, digits only, at most 15 digits total.
 * The domain validates the SHAPE with a plain regex and owns no third-party
 * parsing library — turning a raw user string into a canonical E.164 value is a
 * PORT (`PhoneNormalizer`) implemented in infrastructure, keeping the domain
 * free of any vendor SDK (DEC-0018, DEC-0033).
 *
 * `region` is an optional ISO 3166-1 alpha-2 code (e.g. `IR`) kept for display
 * and future country expansion; it is metadata, never part of identity.
 */

import { InvalidPhoneNumberError } from './phone.errors';

/** RFC 3966 / E.164: `+`, a non-zero leading digit, up to 15 digits total. */
const E164_PATTERN = /^\+[1-9]\d{1,14}$/;

/** True when `value` is a syntactically valid E.164 phone number. */
export function isE164(value: string): boolean {
  return typeof value === 'string' && E164_PATTERN.test(value);
}

export interface PhoneNumberProps {
  readonly e164: string;
  readonly region: string | null;
}

export class PhoneNumber {
  readonly e164: string;
  readonly region: string | null;

  private constructor(props: PhoneNumberProps) {
    this.e164 = props.e164;
    this.region = props.region;
  }

  /**
   * Build a PhoneNumber from an already-canonical E.164 string, enforcing the
   * E.164 shape. Throws {@link InvalidPhoneNumberError} for anything else. The
   * error never echoes the offending value (a phone number is PII).
   */
  static fromE164(e164: string, region: string | null = null): PhoneNumber {
    if (!isE164(e164)) {
      throw new InvalidPhoneNumberError();
    }
    const normalizedRegion = region && region.trim().length > 0 ? region.trim().toUpperCase() : null;
    return new PhoneNumber({ e164, region: normalizedRegion });
  }
}
