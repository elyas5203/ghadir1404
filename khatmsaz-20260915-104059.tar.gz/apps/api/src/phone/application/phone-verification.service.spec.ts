import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { OtpPolicyConfig } from '@khatmsaz/config';
import {
  newUuidV7 as newIdentityId,
  isUuidV7,
  InvalidUuidV7Error,
  UNIT_OF_WORK,
} from '@khatmsaz/kernel';
import type { TransactionContext, UnitOfWork } from '@khatmsaz/kernel';
import { PhoneVerificationService } from './phone-verification.service';
import { OTP_POLICY } from './otp-policy';
import { CLOCK } from '../domain/clock';
import type { Clock } from '../domain/clock';
import { PhoneClaim, PhoneClaimStatus } from '../domain/phone-claim';
import { OtpChallenge } from '../domain/otp-challenge';
import type { OtpPurpose } from '../domain/otp-challenge';
import { PHONE_NORMALIZER } from '../domain/phone-normalizer';
import { OTP_CODE_GENERATOR, OTP_CODE_HASHER } from '../domain/otp-code';
import { OTP_DELIVERY } from '../domain/otp-delivery';
import type { OtpDeliveryRequest } from '../domain/otp-delivery';
import { PHONE_CLAIM_REPOSITORY } from '../domain/phone-claim.repository';
import type {
  CreatePhoneClaimInput,
  PhoneClaimRepository,
} from '../domain/phone-claim.repository';
import { OTP_CHALLENGE_REPOSITORY } from '../domain/otp-challenge.repository';
import type {
  CreateOtpChallengeInput,
  OtpChallengeRepository,
} from '../domain/otp-challenge.repository';
import {
  ActivePhoneClaimExistsError,
  InvalidOtpCodeError,
  InvalidPhoneNumberError,
  NoActiveOtpChallengeError,
  NoPhoneClaimError,
  OtpAttemptsExhaustedError,
  OtpExpiredError,
  OtpResendTooSoonError,
  PhoneOwnershipConflictError,
} from '../domain/phone.errors';
import { LibphonenumberPhoneNormalizer } from '../infrastructure/libphonenumber-phone-normalizer';
import { HmacOtpCodeHasher } from '../infrastructure/hmac-otp-code-hasher';

/**
 * In-memory UnitOfWork: runs the callback with a dummy context. The in-memory
 * fakes ignore the context, so atomicity/rollback are not modelled here — that is
 * covered by the integration tests against real PostgreSQL.
 */
class FakeUnitOfWork implements UnitOfWork {
  run<T>(work: (tx: TransactionContext) => Promise<T>): Promise<T> {
    return work({} as TransactionContext);
  }
}

/** Controllable clock. */
class FakeClock implements Clock {
  constructor(public current = new Date('2026-09-06T12:00:00.000Z')) {}
  now(): Date {
    return new Date(this.current);
  }
  advance(ms: number): void {
    this.current = new Date(this.current.getTime() + ms);
  }
}

/** Code generator returning a fixed, inspectable value. */
class FakeCodeGenerator {
  next = '123456';
  generate(length: number): string {
    return this.next.padStart(length, '0').slice(-length);
  }
}

/** Captures delivered requests, exposing the plaintext code the way an SMS would. */
class FakeDelivery {
  readonly sent: OtpDeliveryRequest[] = [];
  async deliver(request: OtpDeliveryRequest): Promise<void> {
    this.sent.push(request);
  }
  lastCode(): string {
    const last = this.sent.at(-1);
    if (!last) throw new Error('no OTP was delivered');
    return last.code;
  }
}

interface ClaimRecord extends Omit<CreatePhoneClaimInput, 'userId'> {
  userId: string; // mutable so the fake can emulate reassignOwner during a merge
  status: PhoneClaimStatus;
  verifiedAt: Date | null;
  revokedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

/** In-memory PhoneClaimRepository emulating the two partial unique indexes. */
class FakePhoneClaimRepository implements PhoneClaimRepository {
  readonly records: ClaimRecord[] = [];
  constructor(private readonly clock: FakeClock) {}

  private toClaim(r: ClaimRecord): PhoneClaim {
    return PhoneClaim.restore({
      id: r.id,
      userId: r.userId,
      e164: r.e164,
      region: r.region,
      status: r.status,
      verifiedAt: r.verifiedAt,
      revokedAt: r.revokedAt,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
    });
  }

  async findActiveByUserAndPhone(userId: string, e164: string): Promise<PhoneClaim | null> {
    const r = this.records.find(
      (x) => x.userId === userId && x.e164 === e164 && x.status !== PhoneClaimStatus.REVOKED,
    );
    return r ? this.toClaim(r) : null;
  }

  async createUnverified(input: CreatePhoneClaimInput): Promise<PhoneClaim> {
    // Partial unique (user_id, e164) WHERE status <> REVOKED.
    if (
      this.records.some(
        (x) => x.userId === input.userId && x.e164 === input.e164 && x.status !== PhoneClaimStatus.REVOKED,
      )
    ) {
      throw new ActivePhoneClaimExistsError();
    }
    const now = this.clock.now();
    const record: ClaimRecord = {
      ...input,
      status: PhoneClaimStatus.UNVERIFIED,
      verifiedAt: null,
      revokedAt: null,
      createdAt: now,
      updatedAt: now,
    };
    this.records.push(record);
    return this.toClaim(record);
  }

  async markVerified(claimId: string, verifiedAt: Date): Promise<PhoneClaim> {
    const record = this.records.find((x) => x.id === claimId);
    if (!record) throw new Error('claim not found');
    // Partial unique (e164) WHERE status = VERIFIED: one global verified owner.
    if (
      this.records.some(
        (x) => x.e164 === record.e164 && x.id !== record.id && x.status === PhoneClaimStatus.VERIFIED,
      )
    ) {
      throw new PhoneOwnershipConflictError();
    }
    // Partial unique (user_id) WHERE status = VERIFIED: one verified per user (DEC-0046).
    if (
      this.records.some(
        (x) => x.userId === record.userId && x.id !== record.id && x.status === PhoneClaimStatus.VERIFIED,
      )
    ) {
      throw new PhoneOwnershipConflictError();
    }
    record.status = PhoneClaimStatus.VERIFIED;
    record.verifiedAt = verifiedAt;
    record.updatedAt = verifiedAt;
    return this.toClaim(record);
  }

  async findVerifiedByUser(userId: string): Promise<PhoneClaim | null> {
    const r = this.records.find(
      (x) => x.userId === userId && x.status === PhoneClaimStatus.VERIFIED,
    );
    return r ? this.toClaim(r) : null;
  }

  async findVerifiedOwnerId(e164: string): Promise<string | null> {
    const r = this.records.find(
      (x) => x.e164 === e164 && x.status === PhoneClaimStatus.VERIFIED,
    );
    return r?.userId ?? null;
  }

  async revoke(claimId: string, revokedAt: Date): Promise<PhoneClaim> {
    const record = this.records.find((x) => x.id === claimId);
    if (!record) throw new Error('claim not found');
    record.status = PhoneClaimStatus.REVOKED;
    record.revokedAt = revokedAt;
    record.updatedAt = revokedAt;
    return this.toClaim(record);
  }

  async revokeAllActiveByUser(userId: string, revokedAt: Date): Promise<number> {
    let count = 0;
    for (const r of this.records) {
      if (r.userId === userId && r.status !== PhoneClaimStatus.REVOKED) {
        r.status = PhoneClaimStatus.REVOKED;
        r.revokedAt = revokedAt;
        r.updatedAt = revokedAt;
        count += 1;
      }
    }
    return count;
  }

  async reassignOwner(fromUserId: string, toUserId: string): Promise<number> {
    let count = 0;
    for (const r of this.records) {
      if (r.userId === fromUserId) {
        r.userId = toUserId;
        count += 1;
      }
    }
    return count;
  }
}

interface ChallengeRecord extends CreateOtpChallengeInput {
  attempts: number;
  consumedAt: Date | null;
  supersededAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

/** In-memory OtpChallengeRepository. */
class FakeOtpChallengeRepository implements OtpChallengeRepository {
  readonly records: ChallengeRecord[] = [];
  constructor(private readonly clock: FakeClock) {}

  private toChallenge(r: ChallengeRecord): OtpChallenge {
    return OtpChallenge.restore({
      id: r.id,
      userId: r.userId,
      e164: r.e164,
      purpose: r.purpose,
      codeHash: r.codeHash,
      attempts: r.attempts,
      maxAttempts: r.maxAttempts,
      expiresAt: r.expiresAt,
      consumedAt: r.consumedAt,
      supersededAt: r.supersededAt,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
    });
  }

  async create(input: CreateOtpChallengeInput): Promise<OtpChallenge> {
    const now = this.clock.now();
    const record: ChallengeRecord = {
      ...input,
      attempts: 0,
      consumedAt: null,
      supersededAt: null,
      createdAt: now,
      updatedAt: now,
    };
    this.records.push(record);
    return this.toChallenge(record);
  }

  async findLatestForTarget(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
  ): Promise<OtpChallenge | null> {
    const matches = this.records
      .filter((x) => x.userId === userId && x.e164 === e164 && x.purpose === purpose)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return matches[0] ? this.toChallenge(matches[0]) : null;
  }

  async findLatestUserless(e164: string, purpose: OtpPurpose): Promise<OtpChallenge | null> {
    const matches = this.records
      .filter((x) => x.userId === null && x.e164 === e164 && x.purpose === purpose)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return matches[0] ? this.toChallenge(matches[0]) : null;
  }

  async supersedeActiveUserless(e164: string, purpose: OtpPurpose, at: Date): Promise<number> {
    let count = 0;
    for (const r of this.records) {
      if (
        r.userId === null &&
        r.e164 === e164 &&
        r.purpose === purpose &&
        r.consumedAt === null &&
        r.supersededAt === null &&
        r.expiresAt.getTime() > at.getTime()
      ) {
        r.supersededAt = at;
        count += 1;
      }
    }
    return count;
  }

  async supersedeActive(
    userId: string,
    e164: string,
    purpose: OtpPurpose,
    at: Date,
  ): Promise<number> {
    let count = 0;
    for (const r of this.records) {
      if (
        r.userId === userId &&
        r.e164 === e164 &&
        r.purpose === purpose &&
        r.consumedAt === null &&
        r.supersededAt === null &&
        r.expiresAt.getTime() > at.getTime()
      ) {
        r.supersededAt = at;
        count += 1;
      }
    }
    return count;
  }

  async recordFailedAttempt(challengeId: string): Promise<void> {
    const r = this.records.find((x) => x.id === challengeId);
    if (r) r.attempts += 1;
  }

  async consume(challengeId: string, at: Date): Promise<void> {
    const r = this.records.find((x) => x.id === challengeId);
    if (r && r.consumedAt === null) r.consumedAt = at;
  }
}

const POLICY: OtpPolicyConfig = {
  codeLength: 6,
  ttlSeconds: 300,
  maxAttempts: 3,
  resendCooldownSeconds: 60,
};

const IR_NUMBER = '09123456789'; // → +989123456789
const IR_NUMBER_E164 = '+989123456789';

describe('PhoneVerificationService', () => {
  let service: PhoneVerificationService;
  let clock: FakeClock;
  let claims: FakePhoneClaimRepository;
  let challenges: FakeOtpChallengeRepository;
  let codes: FakeCodeGenerator;
  let delivery: FakeDelivery;
  let userId: string;

  beforeEach(async () => {
    clock = new FakeClock();
    claims = new FakePhoneClaimRepository(clock);
    challenges = new FakeOtpChallengeRepository(clock);
    codes = new FakeCodeGenerator();
    delivery = new FakeDelivery();
    userId = newIdentityId();

    const moduleRef: TestingModule = await Test.createTestingModule({
      providers: [
        PhoneVerificationService,
        { provide: PHONE_CLAIM_REPOSITORY, useValue: claims },
        { provide: OTP_CHALLENGE_REPOSITORY, useValue: challenges },
        { provide: PHONE_NORMALIZER, useValue: new LibphonenumberPhoneNormalizer('IR') },
        { provide: OTP_CODE_GENERATOR, useValue: codes },
        { provide: OTP_CODE_HASHER, useValue: new HmacOtpCodeHasher('unit-test-pepper') },
        { provide: OTP_DELIVERY, useValue: delivery },
        { provide: CLOCK, useValue: clock },
        { provide: OTP_POLICY, useValue: POLICY },
        { provide: UNIT_OF_WORK, useValue: new FakeUnitOfWork() },
      ],
    }).compile();
    service = moduleRef.get(PhoneVerificationService);
  });

  describe('claimPhone', () => {
    it('stores an UNVERIFIED claim with a UUIDv7 id and canonical E.164', async () => {
      const claim = await service.claimPhone(userId, IR_NUMBER);
      expect(isUuidV7(claim.id)).toBe(true);
      expect(claim.e164).toBe(IR_NUMBER_E164);
      expect(claim.isUnverified).toBe(true);
      expect(claim.region).toBe('IR');
    });

    it('is idempotent across input formats for the same user', async () => {
      const a = await service.claimPhone(userId, IR_NUMBER);
      const b = await service.claimPhone(userId, IR_NUMBER_E164);
      expect(b.id).toBe(a.id);
      expect(claims.records).toHaveLength(1);
    });

    it('allows the SAME unverified number to be claimed by DIFFERENT users', async () => {
      const other = newIdentityId();
      await service.claimPhone(userId, IR_NUMBER);
      await expect(service.claimPhone(other, IR_NUMBER)).resolves.toBeDefined();
      expect(claims.records).toHaveLength(2);
    });

    it('rejects a non-UUIDv7 userId', async () => {
      await expect(service.claimPhone('nope', IR_NUMBER)).rejects.toBeInstanceOf(
        InvalidUuidV7Error,
      );
    });

    it('rejects an invalid phone number', async () => {
      await expect(service.claimPhone(userId, 'not-a-phone')).rejects.toBeInstanceOf(
        InvalidPhoneNumberError,
      );
    });
  });

  describe('requestPhoneVerification', () => {
    it('creates a challenge, delivers a code, and never returns the code', async () => {
      const result = await service.requestPhoneVerification(userId, IR_NUMBER);
      expect(result.e164).toBe(IR_NUMBER_E164);
      expect(isUuidV7(result.challengeId)).toBe(true);
      expect(result.expiresAt.getTime()).toBe(clock.now().getTime() + POLICY.ttlSeconds * 1000);
      // The result exposes no code field and no value equal to the delivered code.
      expect(result).not.toHaveProperty('code');
      expect(Object.values(result)).not.toContain(delivery.lastCode());
      expect(delivery.sent).toHaveLength(1);
      // The stored challenge holds only a keyed HMAC, never the plaintext code.
      expect(challenges.records[0]?.codeHash).toMatch(/^[0-9a-f]{64}$/);
      expect(challenges.records[0]?.codeHash).not.toBe(delivery.lastCode());
    });

    it('enforces the resend cooldown, then allows and supersedes after it passes', async () => {
      await service.requestPhoneVerification(userId, IR_NUMBER);
      await expect(service.requestPhoneVerification(userId, IR_NUMBER)).rejects.toBeInstanceOf(
        OtpResendTooSoonError,
      );

      clock.advance(POLICY.resendCooldownSeconds * 1000);
      await service.requestPhoneVerification(userId, IR_NUMBER);
      expect(challenges.records).toHaveLength(2);
      // The first challenge is now superseded.
      expect(challenges.records[0]?.supersededAt).not.toBeNull();
    });
  });

  describe('verifyPhone', () => {
    async function request(): Promise<string> {
      await service.requestPhoneVerification(userId, IR_NUMBER);
      return delivery.lastCode();
    }

    it('verifies a correct code, marking the claim VERIFIED and consuming the challenge', async () => {
      const code = await request();
      const result = await service.verifyPhone(userId, IR_NUMBER, code);
      expect(result.outcome).toBe('VERIFIED');
      if (result.outcome === 'VERIFIED') expect(result.claim.isVerified).toBe(true);
      expect(challenges.records[0]?.consumedAt).not.toBeNull();
    });

    it('rejects a wrong code, counts the attempt, and exhausts after maxAttempts', async () => {
      await request();
      for (let i = 0; i < POLICY.maxAttempts; i += 1) {
        await expect(service.verifyPhone(userId, IR_NUMBER, '000000')).rejects.toBeInstanceOf(
          InvalidOtpCodeError,
        );
      }
      expect(challenges.records[0]?.attempts).toBe(POLICY.maxAttempts);
      // Next attempt is refused as exhausted, even with the right code.
      await expect(service.verifyPhone(userId, IR_NUMBER, codes.next)).rejects.toBeInstanceOf(
        OtpAttemptsExhaustedError,
      );
    });

    it('rejects an expired code', async () => {
      const code = await request();
      clock.advance(POLICY.ttlSeconds * 1000);
      await expect(service.verifyPhone(userId, IR_NUMBER, code)).rejects.toBeInstanceOf(
        OtpExpiredError,
      );
    });

    it('refuses to reuse a consumed challenge', async () => {
      const code = await request();
      // Consume it out-of-band, claim still unverified.
      const [firstChallenge] = challenges.records;
      if (!firstChallenge) throw new Error('expected a challenge');
      await challenges.consume(firstChallenge.id, clock.now());
      await expect(service.verifyPhone(userId, IR_NUMBER, code)).rejects.toBeInstanceOf(
        NoActiveOtpChallengeError,
      );
    });

    it('is idempotent: a second verify returns ALREADY_VERIFIED', async () => {
      const code = await request();
      await service.verifyPhone(userId, IR_NUMBER, code);
      const again = await service.verifyPhone(userId, IR_NUMBER, code);
      expect(again.outcome).toBe('ALREADY_VERIFIED');
    });

    it('throws when the user has no claim for the number', async () => {
      await expect(service.verifyPhone(userId, IR_NUMBER, '123456')).rejects.toBeInstanceOf(
        NoPhoneClaimError,
      );
    });

    it('returns MERGE_REQUIRED when the number is already verified by another user — no transfer, no consume', async () => {
      // User A verifies the number.
      const codeA = await request();
      await service.verifyPhone(userId, IR_NUMBER, codeA);

      // User B claims and verifies the SAME number.
      const userB = newIdentityId();
      await service.requestPhoneVerification(userB, IR_NUMBER);
      const codeB = delivery.lastCode();
      const result = await service.verifyPhone(userB, IR_NUMBER, codeB);

      expect(result.outcome).toBe('MERGE_REQUIRED');
      // B's claim stays unverified and B's challenge is NOT consumed.
      const bClaim = claims.records.find((r) => r.userId === userB);
      expect(bClaim?.status).toBe(PhoneClaimStatus.UNVERIFIED);
      const bChallenge = challenges.records.find((r) => r.userId === userB);
      expect(bChallenge?.consumedAt).toBeNull();
      // Still exactly one verified owner.
      const verified = claims.records.filter((r) => r.status === PhoneClaimStatus.VERIFIED);
      expect(verified).toHaveLength(1);
      expect(verified[0]?.userId).toBe(userId);
    });

    it('never leaks the OTP code in a wrong-code error (message or stack)', async () => {
      const code = await request();
      try {
        await service.verifyPhone(userId, IR_NUMBER, '000000');
        fail('expected throw');
      } catch (e) {
        const err = e as Error;
        expect(err).toBeInstanceOf(InvalidOtpCodeError);
        expect(err.message).not.toContain(code);
        expect(err.message).not.toContain('000000');
        expect(err.stack ?? '').not.toContain(code);
      }
    });
  });

  describe('change phone via OTP (DEC-0046)', () => {
    const SECOND = '09123456780';
    const SECOND_E164 = '+989123456780';

    async function verify(national: string): Promise<void> {
      await service.requestPhoneVerification(userId, national);
      const code = delivery.lastCode();
      await service.verifyPhone(userId, national, code);
    }

    it('revokes the previous verified number and promotes the new one', async () => {
      await verify(IR_NUMBER);

      await service.requestPhoneVerification(userId, SECOND);
      const result = await service.verifyPhone(userId, SECOND, delivery.lastCode());

      expect(result.outcome).toBe('VERIFIED');
      if (result.outcome === 'VERIFIED') {
        expect(result.claim.e164).toBe(SECOND_E164);
        expect(result.replacedE164).toBe(IR_NUMBER_E164);
      }

      const old = claims.records.find((r) => r.e164 === IR_NUMBER_E164);
      const fresh = claims.records.find((r) => r.e164 === SECOND_E164);
      expect(old?.status).toBe(PhoneClaimStatus.REVOKED); // history retained, not deleted
      expect(fresh?.status).toBe(PhoneClaimStatus.VERIFIED);
    });

    it('maintains exactly one verified phone per user after a change', async () => {
      await verify(IR_NUMBER);
      await service.requestPhoneVerification(userId, SECOND);
      await service.verifyPhone(userId, SECOND, delivery.lastCode());

      const verified = claims.records.filter(
        (r) => r.userId === userId && r.status === PhoneClaimStatus.VERIFIED,
      );
      expect(verified).toHaveLength(1);
      expect(verified[0]?.e164).toBe(SECOND_E164);
    });

    it('does not report a replacement when the user had no previous verified phone', async () => {
      await service.requestPhoneVerification(userId, IR_NUMBER);
      const result = await service.verifyPhone(userId, IR_NUMBER, delivery.lastCode());
      expect(result.outcome).toBe('VERIFIED');
      if (result.outcome === 'VERIFIED') expect(result.replacedE164).toBeUndefined();
    });
  });
});
