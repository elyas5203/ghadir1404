/**
 * DI token for the {@link import('@khatmsaz/config').OtpPolicyConfig} — the
 * non-secret OTP limits (code length, TTL, max attempts, resend cooldown). The
 * module provides the value from `@khatmsaz/config.otpPolicyConfig()`; tests
 * provide a fake so timing behaviour is deterministic.
 */
export const OTP_POLICY = Symbol('OTP_POLICY');
