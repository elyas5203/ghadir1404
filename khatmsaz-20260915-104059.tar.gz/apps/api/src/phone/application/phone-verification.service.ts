import { Inject, Injectable } from '@nestjs/common';
import type { OtpPolicyConfig } from '@khatmsaz/config';
import { newUuidV7, assertUuidV7, UNIT_OF_WORK } from '@khatmsaz/kernel';
import type { UnitOfWork } from '@khatmsaz/kernel';
import { CLOCK } from '../domain/clock';
import type { Clock } from '../domain/clock';
import { OtpPurpose } from '../domain/otp-challenge';
import { OTP_CODE_GENERATOR, OTP_CODE_HASHER } from '../domain/otp-code';
import type { OtpCodeGenerator, OtpCodeHasher } from '../domain/otp-code';
import { OTP_DELIVERY } from '../domain/otp-delivery';
import type { OtpDelivery } from '../domain/otp-delivery';
import { PHONE_NORMALIZER } from '../domain/phone-normalizer';
import type { PhoneNormalizer } from '../domain/phone-normalizer';
import type { PhoneClaim } from '../domain/phone-claim';
import { PHONE_CLAIM_REPOSITORY } from '../domain/phone-claim.repository';
import type { PhoneClaimRepository } from '../domain/phone-claim.repository';
import { OTP_CHALLENGE_REPOSITORY } from '../domain/otp-challenge.repository';
import type { OtpChallengeRepository } from '../domain/otp-challenge.repository';
import { OTP_POLICY } from './otp-policy';
import {
  ActivePhoneClaimExistsError,
  InvalidOtpCodeError,
  NoActiveOtpChallengeError,
  NoPhoneClaimError,
  OtpAttemptsExhaustedError,
  OtpExpiredError,
  OtpResendTooSoonError,
  PhoneOwnershipConflictError,
} from '../domain/phone.errors';
import type { PhoneVerificationResult } from '../domain/verification-outcome';

/** Non-secret summary returned when a verification code is requested. Never the code. */
export interface RequestVerificationResult {
  readonly challengeId: string;
  readonly e164: string;
  readonly expiresAt: Date;
  readonly resendCooldownSeconds: number;
}

/**
 * Phone-verification use-cases. Application code: it orchestrates the domain
 * rules and the persistence/crypto/delivery ports, and is entirely Prisma- and
 * vendor-free.
 *
 * The binding product distinction is honoured throughout: a CLAIMED phone is
 * mere contact data (unverified, not unique, not identity); a VERIFIED phone is
 * a unique proven claim. A correct code for a number already owned by another
 * account does NOT merge or transfer — it returns MERGE_REQUIRED for Phase 3B.
 */
@Injectable()
export class PhoneVerificationService {
  private readonly purpose = OtpPurpose.PHONE_VERIFICATION;

  constructor(
    @Inject(PHONE_CLAIM_REPOSITORY) private readonly phoneClaims: PhoneClaimRepository,
    @Inject(OTP_CHALLENGE_REPOSITORY) private readonly challenges: OtpChallengeRepository,
    @Inject(PHONE_NORMALIZER) private readonly normalizer: PhoneNormalizer,
    @Inject(OTP_CODE_GENERATOR) private readonly codes: OtpCodeGenerator,
    @Inject(OTP_CODE_HASHER) private readonly hasher: OtpCodeHasher,
    @Inject(OTP_DELIVERY) private readonly delivery: OtpDelivery,
    @Inject(CLOCK) private readonly clock: Clock,
    @Inject(OTP_POLICY) private readonly policy: OtpPolicyConfig,
    @Inject(UNIT_OF_WORK) private readonly uow: UnitOfWork,
  ) {}

  /**
   * Claim (or return the existing claim for) an UNVERIFIED contact phone. This
   * stores contact data only — it is NOT proof of identity and does not have to
   * be globally unique. Idempotent per (user, number). Does not touch the user's
   * other numbers, so history is preserved.
   */
  async claimPhone(userId: string, rawPhone: string): Promise<PhoneClaim> {
    assertUuidV7(userId, 'userId');
    const phone = this.normalizer.normalize(rawPhone);
    return this.ensureActiveClaim(userId, phone.e164, phone.region);
  }

  /**
   * Request a verification code for a number. Ensures an (unverified) claim
   * exists, enforces the resend cooldown, supersedes any live challenge, then
   * generates, hashes, stores and delivers a fresh code. The plaintext code is
   * never returned, logged, or persisted — only its keyed HMAC is stored.
   */
  async requestPhoneVerification(
    userId: string,
    rawPhone: string,
  ): Promise<RequestVerificationResult> {
    assertUuidV7(userId, 'userId');
    const phone = this.normalizer.normalize(rawPhone);
    const now = this.clock.now();

    await this.ensureActiveClaim(userId, phone.e164, phone.region);

    const latest = await this.challenges.findLatestForTarget(userId, phone.e164, this.purpose);
    if (latest) {
      const elapsed = (now.getTime() - latest.createdAt.getTime()) / 1000;
      if (elapsed < this.policy.resendCooldownSeconds) {
        throw new OtpResendTooSoonError(Math.ceil(this.policy.resendCooldownSeconds - elapsed));
      }
    }

    // Only one challenge may be live for a target at a time.
    await this.challenges.supersedeActive(userId, phone.e164, this.purpose, now);

    const code = this.codes.generate(this.policy.codeLength);
    const codeHash = this.hasher.hash(code, { e164: phone.e164, purpose: this.purpose });
    const expiresAt = new Date(now.getTime() + this.policy.ttlSeconds * 1000);

    const challenge = await this.challenges.create({
      id: newUuidV7(),
      userId,
      e164: phone.e164,
      purpose: this.purpose,
      codeHash,
      maxAttempts: this.policy.maxAttempts,
      expiresAt,
    });

    // Delivery is the SMS seam (no real provider yet). It must not log the code.
    await this.delivery.deliver({
      e164: phone.e164,
      code,
      purpose: this.purpose,
      expiresAt,
    });

    return {
      challengeId: challenge.id,
      e164: phone.e164,
      expiresAt,
      resendCooldownSeconds: this.policy.resendCooldownSeconds,
    };
  }

  /**
   * Verify a submitted code and, on success, mark the claim VERIFIED.
   *
   * A wrong/expired/exhausted/absent code throws a domain error (and a wrong
   * code costs one attempt). A correct code returns a {@link PhoneVerificationResult}:
   * VERIFIED, ALREADY_VERIFIED (this user), or MERGE_REQUIRED when the number is
   * actively verified by another account. Global single-owner uniqueness is
   * guaranteed by the database partial unique index, not by application checks,
   * so two users verifying the same number concurrently cannot both win.
   */
  async verifyPhone(
    userId: string,
    rawPhone: string,
    code: string,
  ): Promise<PhoneVerificationResult> {
    assertUuidV7(userId, 'userId');
    const phone = this.normalizer.normalize(rawPhone);
    const now = this.clock.now();

    const claim = await this.phoneClaims.findActiveByUserAndPhone(userId, phone.e164);
    if (!claim) {
      throw new NoPhoneClaimError();
    }
    if (claim.isVerified) {
      return { outcome: 'ALREADY_VERIFIED', claim };
    }

    const challenge = await this.challenges.findLatestForTarget(userId, phone.e164, this.purpose);
    if (!challenge || challenge.isConsumed() || challenge.isSuperseded()) {
      throw new NoActiveOtpChallengeError();
    }
    if (challenge.isExpired(now)) {
      throw new OtpExpiredError();
    }
    if (challenge.attemptsExhausted()) {
      throw new OtpAttemptsExhaustedError();
    }

    const matches = this.hasher.verify(code, challenge.codeHash, {
      e164: phone.e164,
      purpose: this.purpose,
    });
    if (!matches) {
      await this.challenges.recordFailedAttempt(challenge.id);
      throw new InvalidOtpCodeError();
    }

    // Correct code. If the number is already verified by a DIFFERENT account, this
    // is a cross-account conflict: do NOT consume, do NOT transfer — hand it to the
    // merge workflow. (The partial unique indexes remain the source of truth under
    // concurrency; this pre-check just distinguishes the outcomes.)
    const verifiedOwnerId = await this.phoneClaims.findVerifiedOwnerId(phone.e164);
    if (verifiedOwnerId !== null && verifiedOwnerId !== userId) {
      return { outcome: 'MERGE_REQUIRED' };
    }

    // A user may hold only ONE verified phone (DEC-0046): verifying a new number
    // REVOKES the user's previous verified one (change phone via OTP). The revoke,
    // the promotion, and the challenge consumption run atomically in one
    // transaction so the per-user VERIFIED index is never transiently violated.
    const previousVerified = await this.phoneClaims.findVerifiedByUser(userId);
    const replaces =
      previousVerified && previousVerified.id !== claim.id ? previousVerified : null;

    try {
      const verified = await this.uow.run(async (tx) => {
        if (replaces) {
          await this.phoneClaims.revoke(replaces.id, now, tx);
        }
        const promoted = await this.phoneClaims.markVerified(claim.id, now, tx);
        await this.challenges.consume(challenge.id, now, tx);
        return promoted;
      });
      return replaces
        ? { outcome: 'VERIFIED', claim: verified, replacedE164: replaces.e164 }
        : { outcome: 'VERIFIED', claim: verified };
    } catch (error) {
      if (error instanceof PhoneOwnershipConflictError) {
        // A concurrent verification won the number first (or a per-user race); the
        // transaction rolled back — nothing was consumed or revoked.
        return { outcome: 'MERGE_REQUIRED' };
      }
      throw error;
    }
  }

  // ── Phone-first login extension (DEC-0066) ────────────────────────────────
  // A USER-LESS possession proof, decoupled from any user or claim. It reuses the
  // same generator/hasher/delivery/challenge repository; it does not touch claims
  // or the verified-ownership invariants. Resolving/creating a USER is the session
  // orchestration's job — this capability still never imports Identity.

  /** Normalize a raw phone to its canonical E.164 + region (for orchestration keys). */
  normalize(rawPhone: string): { e164: string; region: string | null } {
    const phone = this.normalizer.normalize(rawPhone);
    return { e164: phone.e164, region: phone.region };
  }

  /** The user that verifiably owns `e164`, or `null`. Reuses the claim invariant. */
  async findVerifiedOwner(e164: string): Promise<string | null> {
    return this.phoneClaims.findVerifiedOwnerId(e164);
  }

  /** Issue a user-less PHONE_LOGIN code for a number (possession proof). */
  async requestLoginCode(rawPhone: string): Promise<RequestVerificationResult> {
    const phone = this.normalizer.normalize(rawPhone);
    const now = this.clock.now();
    const purpose = OtpPurpose.PHONE_LOGIN;

    const latest = await this.challenges.findLatestUserless(phone.e164, purpose);
    if (latest) {
      const elapsed = (now.getTime() - latest.createdAt.getTime()) / 1000;
      if (elapsed < this.policy.resendCooldownSeconds) {
        throw new OtpResendTooSoonError(Math.ceil(this.policy.resendCooldownSeconds - elapsed));
      }
    }

    await this.challenges.supersedeActiveUserless(phone.e164, purpose, now);

    const code = this.codes.generate(this.policy.codeLength);
    const codeHash = this.hasher.hash(code, { e164: phone.e164, purpose });
    const expiresAt = new Date(now.getTime() + this.policy.ttlSeconds * 1000);

    const challenge = await this.challenges.create({
      id: newUuidV7(),
      userId: null,
      e164: phone.e164,
      purpose,
      codeHash,
      maxAttempts: this.policy.maxAttempts,
      expiresAt,
    });

    await this.delivery.deliver({ e164: phone.e164, code, purpose, expiresAt });

    return {
      challengeId: challenge.id,
      e164: phone.e164,
      expiresAt,
      resendCooldownSeconds: this.policy.resendCooldownSeconds,
    };
  }

  /**
   * Verify a user-less PHONE_LOGIN code — proves possession of the number without
   * touching any user or claim. Throws on wrong/expired/exhausted/absent (a wrong
   * code costs one attempt). On success the challenge is consumed and the canonical
   * number is returned for the orchestration to bind to a user.
   */
  async verifyLoginCode(
    rawPhone: string,
    code: string,
  ): Promise<{ e164: string; region: string | null }> {
    const phone = this.normalizer.normalize(rawPhone);
    const now = this.clock.now();
    const purpose = OtpPurpose.PHONE_LOGIN;

    const challenge = await this.challenges.findLatestUserless(phone.e164, purpose);
    if (!challenge || challenge.isConsumed() || challenge.isSuperseded()) {
      throw new NoActiveOtpChallengeError();
    }
    if (challenge.isExpired(now)) {
      throw new OtpExpiredError();
    }
    if (challenge.attemptsExhausted()) {
      throw new OtpAttemptsExhaustedError();
    }

    const matches = this.hasher.verify(code, challenge.codeHash, { e164: phone.e164, purpose });
    if (!matches) {
      await this.challenges.recordFailedAttempt(challenge.id);
      throw new InvalidOtpCodeError();
    }

    await this.challenges.consume(challenge.id, now);
    return { e164: phone.e164, region: phone.region };
  }

  /**
   * Bind `e164` to `userId` as their VERIFIED claim, given possession was already
   * proven (by {@link verifyLoginCode}). Respects one-verified-phone-per-user
   * (revoking a previous one) and the global single-owner index — a losing race
   * throws {@link PhoneOwnershipConflictError} for the caller to resolve.
   */
  async establishVerifiedOwnership(
    userId: string,
    e164: string,
    region: string | null,
  ): Promise<PhoneClaim> {
    assertUuidV7(userId, 'userId');
    const claim = await this.ensureActiveClaim(userId, e164, region);
    if (claim.isVerified) return claim;

    const now = this.clock.now();
    const previousVerified = await this.phoneClaims.findVerifiedByUser(userId);
    const replaces =
      previousVerified && previousVerified.id !== claim.id ? previousVerified : null;

    return this.uow.run(async (tx) => {
      if (replaces) {
        await this.phoneClaims.revoke(replaces.id, now, tx);
      }
      return this.phoneClaims.markVerified(claim.id, now, tx);
    });
  }

  /**
   * Return the user's existing active claim for `e164`, creating an UNVERIFIED
   * one if none exists. Idempotent under concurrency: a losing INSERT race is
   * resolved by re-reading the winner.
   */
  private async ensureActiveClaim(
    userId: string,
    e164: string,
    region: string | null,
  ): Promise<PhoneClaim> {
    const existing = await this.phoneClaims.findActiveByUserAndPhone(userId, e164);
    if (existing) return existing;

    try {
      return await this.phoneClaims.createUnverified({
        id: newUuidV7(),
        userId,
        e164,
        region,
      });
    } catch (error) {
      if (error instanceof ActivePhoneClaimExistsError) {
        const winner = await this.phoneClaims.findActiveByUserAndPhone(userId, e164);
        if (winner) return winner;
      }
      throw error;
    }
  }
}
