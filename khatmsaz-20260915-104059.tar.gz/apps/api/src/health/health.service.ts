import { Injectable } from '@nestjs/common';
import type { HealthResponse } from '@khatmsaz/contracts';
import { nowIso } from '@khatmsaz/shared';

const SERVICE_NAME = 'khatmsaz-api';
const SERVICE_VERSION = '0.1.0';

@Injectable()
export class HealthService {
  /**
   * Reports liveness only.
   *
   * This response must never include environment variables, configuration
   * values, secrets, dependency versions, or host details. See SECURITY.md.
   */
  getHealth(): HealthResponse {
    return {
      status: 'ok',
      service: SERVICE_NAME,
      version: SERVICE_VERSION,
      timestamp: nowIso(),
      uptimeSeconds: Math.floor(process.uptime()),
    };
  }
}
