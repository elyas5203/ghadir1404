import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { Response } from 'express';
import type { ReadinessResponse } from '@khatmsaz/contracts';
import { DatabaseReadinessService } from '../infrastructure/database/database-readiness.service';
import { HealthController } from './health.controller';
import { HealthService } from './health.service';

/** A fake readiness service so the controller is tested without a database. */
function readinessStub(response: ReadinessResponse): DatabaseReadinessService {
  return {
    getReadiness: async (): Promise<ReadinessResponse> => response,
  } as unknown as DatabaseReadinessService;
}

/** A minimal Express Response spy that records the status code. */
function responseSpy(): { res: Response; statusCode: number | undefined } {
  const state: { statusCode: number | undefined } = { statusCode: undefined };
  const res = {
    status(code: number): Response {
      state.statusCode = code;
      return res;
    },
  } as unknown as Response;
  return {
    res,
    get statusCode(): number | undefined {
      return state.statusCode;
    },
  };
}

describe('HealthController', () => {
  async function build(readiness: DatabaseReadinessService): Promise<HealthController> {
    const moduleRef: TestingModule = await Test.createTestingModule({
      controllers: [HealthController],
      providers: [
        HealthService,
        { provide: DatabaseReadinessService, useValue: readiness },
      ],
    }).compile();
    return moduleRef.get(HealthController);
  }

  describe('liveness', () => {
    it('reports the service as alive', async () => {
      const controller = await build(
        readinessStub({ status: 'ready', checks: { database: 'up' }, timestamp: new Date().toISOString() }),
      );

      const result = controller.getHealth();

      expect(result.status).toBe('ok');
      expect(result.service).toBe('khatmsaz-api');
      expect(result.version).toBe('0.1.0');
      expect(Number.isFinite(result.uptimeSeconds)).toBe(true);
      expect(result.uptimeSeconds).toBeGreaterThanOrEqual(0);
      expect(() => new Date(result.timestamp).toISOString()).not.toThrow();
    });

    it('does not leak configuration or environment values', async () => {
      const controller = await build(
        readinessStub({ status: 'ready', checks: { database: 'up' }, timestamp: new Date().toISOString() }),
      );

      const keys = Object.keys(controller.getHealth()).sort();

      expect(keys).toEqual(['service', 'status', 'timestamp', 'uptimeSeconds', 'version']);
    });

    it('does not depend on the database (stays alive when it is down)', async () => {
      const controller = await build(
        readinessStub({ status: 'not_ready', checks: { database: 'down' }, timestamp: new Date().toISOString() }),
      );

      expect(controller.getHealth().status).toBe('ok');
    });
  });

  describe('readiness', () => {
    it('returns 200 and ready when the database is up', async () => {
      const controller = await build(
        readinessStub({ status: 'ready', checks: { database: 'up' }, timestamp: new Date().toISOString() }),
      );
      const spy = responseSpy();

      const result = await controller.getReadiness(spy.res);

      expect(result.status).toBe('ready');
      expect(result.checks.database).toBe('up');
      expect(spy.statusCode).toBe(200);
    });

    it('returns 503 and not_ready when the database is down', async () => {
      const controller = await build(
        readinessStub({ status: 'not_ready', checks: { database: 'down' }, timestamp: new Date().toISOString() }),
      );
      const spy = responseSpy();

      const result = await controller.getReadiness(spy.res);

      expect(result.status).toBe('not_ready');
      expect(result.checks.database).toBe('down');
      expect(spy.statusCode).toBe(503);
    });

    it('exposes only status, checks and timestamp — no configuration', async () => {
      const controller = await build(
        readinessStub({ status: 'ready', checks: { database: 'up' }, timestamp: new Date().toISOString() }),
      );
      const spy = responseSpy();

      const result = await controller.getReadiness(spy.res);

      expect(Object.keys(result).sort()).toEqual(['checks', 'status', 'timestamp']);
      expect(Object.keys(result.checks)).toEqual(['database']);
    });
  });
});
