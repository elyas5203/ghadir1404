import { Controller, Get, HttpStatus, Res } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import type { Response } from 'express';
import type { HealthResponse, ReadinessResponse } from '@khatmsaz/contracts';
import { DatabaseReadinessService } from '../infrastructure/database/database-readiness.service';
import { HealthService } from './health.service';

@SkipThrottle()
@Controller('health')
export class HealthController {
  constructor(
    private readonly healthService: HealthService,
    private readonly readiness: DatabaseReadinessService,
  ) {}

  /**
   * Liveness. Answers only "is this process running?". It must never depend on
   * the database or any other external dependency — a temporarily unreachable
   * database must not make an otherwise-healthy process report unhealthy.
   */
  @Get()
  getHealth(): HealthResponse {
    return this.healthService.getHealth();
  }

  /**
   * Readiness. Verifies the dependencies the API needs to serve requests
   * (currently PostgreSQL) with a real query and a short timeout. Returns HTTP
   * 200 when ready and 503 when not, so orchestrators can route accordingly.
   * The body is small and stable and never exposes configuration or secrets.
   */
  @Get('ready')
  async getReadiness(
    @Res({ passthrough: true }) res: Response,
  ): Promise<ReadinessResponse> {
    const result = await this.readiness.getReadiness();
    res.status(
      result.status === 'ready' ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE,
    );
    return result;
  }
}
