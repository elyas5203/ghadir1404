import { Module } from '@nestjs/common';
import { sessionPolicyConfig } from '@khatmsaz/config';
import { IdentityModule } from '../identity/identity.module';
import { PhoneModule } from '../phone/phone.module';
import { AuthenticationService } from './application/authentication.service';
import { PhoneOtpLoginService } from './application/phone-otp-login.service';
import { PhoneAuthService } from './application/phone-auth.service';
import { SESSION_POLICY } from './application/session-policy';
import { SESSION_REPOSITORY } from './domain/session.repository';
import { SESSION_TOKEN_GENERATOR, SESSION_TOKEN_HASHER } from './domain/session-token';
import { CLOCK } from './domain/clock';
import { PrismaSessionRepository } from './infrastructure/prisma-session.repository';
import { CryptoSessionTokenGenerator } from './infrastructure/crypto-session-token-generator';
import { Sha256SessionTokenHasher } from './infrastructure/sha256-session-token-hasher';
import { SystemClock } from './infrastructure/system-clock';

/**
 * Session / authentication capability (Phase 6, DEC-0059/0060). It owns the Session
 * domain and the authentication use-cases, binding the domain-owned ports to their
 * infrastructure implementations (Prisma repository, CSPRNG token generator, SHA-256
 * hasher, system clock). It imports IdentityModule (to confirm a session's user is an
 * active account) and PhoneModule (for the phone-OTP login bridge, which consumes the
 * phone capability's existing verification). Exports the services transports use.
 */
@Module({
  imports: [IdentityModule, PhoneModule],
  providers: [
    AuthenticationService,
    PhoneOtpLoginService,
    PhoneAuthService,
    { provide: SESSION_REPOSITORY, useClass: PrismaSessionRepository },
    { provide: SESSION_TOKEN_GENERATOR, useClass: CryptoSessionTokenGenerator },
    { provide: SESSION_TOKEN_HASHER, useClass: Sha256SessionTokenHasher },
    { provide: CLOCK, useClass: SystemClock },
    { provide: SESSION_POLICY, useFactory: sessionPolicyConfig },
  ],
  exports: [AuthenticationService, PhoneOtpLoginService, PhoneAuthService],
})
export class SessionModule {}
