/**
 * The lifecycle status of a {@link import('./session').Session} — DERIVED, never
 * stored, so it can never drift from the timestamps that define it (DEC-0059):
 *
 *   REVOKED  — `revokedAt` is set (explicit logout / server revocation). Terminal.
 *   EXPIRED  — not revoked, but `expiresAt` has passed. Terminal.
 *   ACTIVE   — neither revoked nor expired. The only status that authenticates.
 *
 * Revocation takes precedence over expiry. The status is computed from the entity
 * and the current time; the persistence layer stores only `revokedAt`/`expiresAt`.
 */

export const SessionStatus = {
  ACTIVE: 'ACTIVE',
  REVOKED: 'REVOKED',
  EXPIRED: 'EXPIRED',
} as const;

export type SessionStatus = (typeof SessionStatus)[keyof typeof SessionStatus];
