/**
 * AuthenticatedPrincipal — who the caller is, as resolved by a transport (DEC-0060).
 *
 * It is the ONE thing transports pass to the application instead of a raw,
 * caller-supplied user id. `sessionId` is set when the principal was proven by a
 * server-side session (HTTP bearer token) and `null` when the channel itself
 * authenticates the caller (Telegram: the platform vouches for the user id). It
 * never carries a token or any credential.
 */

export interface AuthenticatedPrincipal {
  /** Canonical KhatmSaz user id (UUIDv7). */
  readonly userId: string;
  /** The session that proved it, or `null` for a channel-authenticated principal. */
  readonly sessionId: string | null;
}
