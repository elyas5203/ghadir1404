/**
 * Session — the DOMAIN entity for an authenticated principal's server-side session
 * (DEC-0059). It stores only the SHA-256 HASH of the opaque token, never the raw
 * token (which is returned to the caller exactly once, at creation, and never
 * persisted or logged). Status is DERIVED from `revokedAt`/`expiresAt` at a given
 * time, so it cannot drift. Plain domain object; no Prisma or framework dependency.
 */

import { assertUuidV7 } from '@khatmsaz/kernel';
import { SessionStatus } from './session-status';
import { InvalidSessionError } from './session.errors';

export interface SessionProps {
  readonly id: string;
  readonly userId: string;
  /** SHA-256 hex of the raw token. NEVER the raw token. */
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly revokedAt: Date | null;
  readonly lastUsedAt: Date | null;
}

export interface NewSessionProps {
  readonly id: string;
  readonly userId: string;
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
}

const SHA256_HEX = /^[0-9a-f]{64}$/;

export class Session {
  readonly id: string;
  readonly userId: string;
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly revokedAt: Date | null;
  readonly lastUsedAt: Date | null;

  private constructor(props: SessionProps) {
    this.id = props.id;
    this.userId = props.userId;
    this.tokenHash = props.tokenHash;
    this.createdAt = props.createdAt;
    this.expiresAt = props.expiresAt;
    this.revokedAt = props.revokedAt;
    this.lastUsedAt = props.lastUsedAt;
  }

  /** Derive the status at `now`. Revocation wins over expiry (DEC-0059). */
  statusAt(now: Date): SessionStatus {
    if (this.revokedAt !== null) return SessionStatus.REVOKED;
    if (this.expiresAt.getTime() <= now.getTime()) return SessionStatus.EXPIRED;
    return SessionStatus.ACTIVE;
  }

  /** True only when the session can authenticate at `now` (ACTIVE). */
  isActiveAt(now: Date): boolean {
    return this.statusAt(now) === SessionStatus.ACTIVE;
  }

  static create(props: NewSessionProps): Session {
    assertUuidV7(props.id, 'Session.id');
    assertUuidV7(props.userId, 'Session.userId');
    if (!SHA256_HEX.test(props.tokenHash)) {
      throw new InvalidSessionError('tokenHash must be a SHA-256 hex digest');
    }
    if (props.expiresAt.getTime() <= props.createdAt.getTime()) {
      throw new InvalidSessionError('expiresAt must be after createdAt');
    }
    return new Session({ ...props, revokedAt: null, lastUsedAt: null });
  }

  static restore(props: SessionProps): Session {
    assertUuidV7(props.id, 'Session.id');
    assertUuidV7(props.userId, 'Session.userId');
    if (!SHA256_HEX.test(props.tokenHash)) {
      throw new InvalidSessionError('tokenHash must be a SHA-256 hex digest');
    }
    return new Session(props);
  }
}
