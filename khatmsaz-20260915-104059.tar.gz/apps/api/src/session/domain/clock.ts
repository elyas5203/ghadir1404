/**
 * Clock — a tiny time port owned by the session domain, so lifecycle/expiry logic
 * is deterministically testable without importing another capability's clock
 * (capabilities never share domain except through the kernel, DEC-0039). The system
 * implementation lives in infrastructure.
 */

export const CLOCK = Symbol('SESSION_CLOCK');

export interface Clock {
  now(): Date;
}
