/**
 * Domain errors for the session capability (Phase 6). Framework- and Prisma-free.
 *
 * SECURITY: no error message ever contains a raw token, a token hash, or any
 * secret. Authentication failures are deliberately COARSE — a caller cannot tell an
 * unknown token from a revoked or expired one beyond the error kind, and never
 * learns whether a token "exists".
 */

export class SessionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A session's fields were internally inconsistent on construction. */
export class InvalidSessionError extends SessionError {
  constructor(reason: string) {
    super(`Invalid session: ${reason}.`);
  }
}

/** Base class for "this token cannot authenticate" — carries no token detail. */
export class SessionAuthenticationError extends SessionError {}

/** No active session matches the presented token (unknown or already gone). */
export class InvalidSessionTokenError extends SessionAuthenticationError {
  constructor() {
    super('The session token is invalid.');
  }
}

/** The session was explicitly revoked and can no longer authenticate. */
export class SessionRevokedError extends SessionAuthenticationError {
  constructor() {
    super('The session has been revoked.');
  }
}

/** The session has passed its expiry and can no longer authenticate. */
export class SessionExpiredError extends SessionAuthenticationError {
  constructor() {
    super('The session has expired.');
  }
}

/** A session was created/authenticated for a user that is not an active account. */
export class SessionUserNotActiveError extends SessionAuthenticationError {
  constructor() {
    super('The account for this session is not active.');
  }
}
