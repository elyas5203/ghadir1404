/**
 * Session token PORTS — owned by the domain, implemented in infrastructure with
 * Node crypto (DEC-0059):
 *
 *   - {@link SessionTokenGenerator} produces a fresh high-entropy opaque token with
 *     a cryptographically secure RNG (never `Math.random`). This raw token is
 *     returned to the caller exactly ONCE and is never stored.
 *   - {@link SessionTokenHasher} maps a raw token to the value stored in the
 *     database (a SHA-256 hex digest) and does a CONSTANT-TIME comparison. No
 *     pepper is needed: a 256-bit random token cannot be brute-forced from its
 *     hash, unlike a 6-digit OTP (contrast the keyed-HMAC OtpCodeHasher, DEC-0035).
 *
 * The domain/application depend only on these interfaces; the crypto lives in
 * infrastructure, which keeps them testable and the raw token out of the core.
 */

/** DI token for {@link SessionTokenGenerator}. */
export const SESSION_TOKEN_GENERATOR = Symbol('SESSION_TOKEN_GENERATOR');
/** DI token for {@link SessionTokenHasher}. */
export const SESSION_TOKEN_HASHER = Symbol('SESSION_TOKEN_HASHER');

export interface SessionTokenGenerator {
  /** Generate a fresh URL-safe opaque token with `bytes` of CSPRNG entropy. */
  generate(bytes: number): string;
}

export interface SessionTokenHasher {
  /** SHA-256 hex digest of a raw token — the value safe to store. */
  hash(rawToken: string): string;
  /** Constant-time check that `rawToken` hashes to `storedHash`. */
  verify(rawToken: string, storedHash: string): boolean;
}
