import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { Session } from './session';
import { SessionStatus } from './session-status';
import { InvalidSessionError } from './session.errors';

const HASH = 'a'.repeat(64); // a well-formed SHA-256 hex digest
const t = (ms: number) => new Date(ms);

const newActive = (createdAt = t(1_000), expiresAt = t(10_000)) =>
  Session.create({ id: newUuidV7(), userId: newUuidV7(), tokenHash: HASH, createdAt, expiresAt });

describe('Session (domain)', () => {
  it('is created ACTIVE with no holder revocation and a valid hash', () => {
    const s = newActive();
    expect(s.revokedAt).toBeNull();
    expect(s.lastUsedAt).toBeNull();
    expect(s.statusAt(t(2_000))).toBe(SessionStatus.ACTIVE);
    expect(s.isActiveAt(t(2_000))).toBe(true);
  });

  it('derives EXPIRED once expiry has passed (boundary is inclusive)', () => {
    const s = newActive(t(1_000), t(10_000));
    expect(s.statusAt(t(9_999))).toBe(SessionStatus.ACTIVE);
    expect(s.statusAt(t(10_000))).toBe(SessionStatus.EXPIRED);
    expect(s.statusAt(t(10_001))).toBe(SessionStatus.EXPIRED);
    expect(s.isActiveAt(t(10_000))).toBe(false);
  });

  it('derives REVOKED, and revocation wins over expiry', () => {
    const revoked = Session.restore({
      id: newUuidV7(),
      userId: newUuidV7(),
      tokenHash: HASH,
      createdAt: t(1_000),
      expiresAt: t(10_000),
      revokedAt: t(2_000),
      lastUsedAt: null,
    });
    expect(revoked.statusAt(t(3_000))).toBe(SessionStatus.REVOKED);
    // Even past expiry, a revoked session reports REVOKED (not EXPIRED).
    expect(revoked.statusAt(t(99_999))).toBe(SessionStatus.REVOKED);
  });

  it('rejects a non-UUIDv7 id/userId', () => {
    expect(() =>
      Session.create({ id: 'x', userId: newUuidV7(), tokenHash: HASH, createdAt: t(1), expiresAt: t(2) }),
    ).toThrow(InvalidUuidV7Error);
  });

  it('rejects a tokenHash that is not a SHA-256 hex digest', () => {
    expect(() =>
      Session.create({ id: newUuidV7(), userId: newUuidV7(), tokenHash: 'nope', createdAt: t(1), expiresAt: t(2) }),
    ).toThrow(InvalidSessionError);
  });

  it('rejects expiry that is not after creation', () => {
    expect(() =>
      Session.create({ id: newUuidV7(), userId: newUuidV7(), tokenHash: HASH, createdAt: t(10), expiresAt: t(10) }),
    ).toThrow(InvalidSessionError);
  });
});
