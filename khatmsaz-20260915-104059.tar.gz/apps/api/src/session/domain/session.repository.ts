/**
 * SessionRepository — a persistence port OWNED BY THE DOMAIN. Its Prisma-backed
 * implementation lives in infrastructure (DEC-0031). Sessions are looked up ONLY by
 * token hash (never the raw token); revocation is an UPDATE (history retained).
 */

import type { Session } from './session';

export const SESSION_REPOSITORY = Symbol('SESSION_REPOSITORY');

export interface SessionRepository {
  /** Persist a newly created session. */
  create(session: Session): Promise<Session>;
  /** Find a session by the SHA-256 hash of its token, or `null` when none exists. */
  findByTokenHash(tokenHash: string): Promise<Session | null>;
  /** Find a session by id, or `null`. */
  findById(id: string): Promise<Session | null>;
  /**
   * Mark a session revoked (idempotent: a no-op if already revoked). Guarded on the
   * row existing; returns whether a row was affected.
   */
  revoke(id: string, revokedAt: Date): Promise<void>;
  /** Best-effort update of `lastUsedAt` on a successful authentication. */
  touchLastUsed(id: string, at: Date): Promise<void>;
  /** Revoke every currently-active session of a user (e.g. "log out everywhere"). */
  revokeAllForUser(userId: string, revokedAt: Date): Promise<number>;
}
