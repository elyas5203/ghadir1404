/**
 * Map `sessions` rows to the domain {@link Session}. Lives in infrastructure so the
 * Prisma row shape is converted to a Prisma-free domain object here and nowhere
 * else (DEC-0031); `Session.restore` re-validates every invariant.
 */

import { Session } from '../domain/session';

export interface SessionRow {
  id: string;
  userId: string;
  tokenHash: string;
  createdAt: Date;
  expiresAt: Date;
  revokedAt: Date | null;
  lastUsedAt: Date | null;
}

export function toSession(row: SessionRow): Session {
  return Session.restore({
    id: row.id,
    userId: row.userId,
    tokenHash: row.tokenHash,
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
    revokedAt: row.revokedAt,
    lastUsedAt: row.lastUsedAt,
  });
}
