import { Injectable } from '@nestjs/common';
import type { Clock } from '../domain/clock';

/** The real system {@link Clock}. Tests bind a fixed clock instead. */
@Injectable()
export class SystemClock implements Clock {
  now(): Date {
    return new Date();
  }
}
