import { Injectable } from '@nestjs/common';
import { createHash, timingSafeEqual } from 'node:crypto';
import type { SessionTokenHasher } from '../domain/session-token';

/**
 * SHA-256 {@link SessionTokenHasher} (DEC-0059). The stored value is the SHA-256 hex
 * digest of the raw token; the raw token is never stored. No keyed HMAC/pepper is
 * used — unlike the low-entropy OTP code (DEC-0035), a 256-bit random session token
 * cannot be reversed or brute-forced from its hash, so a plain cryptographic hash is
 * sufficient and avoids an extra server secret. Comparison is CONSTANT-TIME.
 */
@Injectable()
export class Sha256SessionTokenHasher implements SessionTokenHasher {
  hash(rawToken: string): string {
    return createHash('sha256').update(rawToken).digest('hex');
  }

  verify(rawToken: string, storedHash: string): boolean {
    const computed = Buffer.from(this.hash(rawToken), 'hex');
    let stored: Buffer;
    try {
      stored = Buffer.from(storedHash, 'hex');
    } catch {
      return false;
    }
    // Lengths must match for timingSafeEqual; a differing length is a mismatch.
    if (computed.length !== stored.length) return false;
    return timingSafeEqual(computed, stored);
  }
}
