import { Injectable } from '@nestjs/common';
import { randomBytes } from 'node:crypto';
import type { SessionTokenGenerator } from '../domain/session-token';

/**
 * CSPRNG {@link SessionTokenGenerator}. Produces a URL-safe (base64url) opaque
 * token from `bytes` of cryptographically secure randomness — never `Math.random`.
 * A 32-byte token is 256 bits of entropy, which is why the stored SHA-256 hash
 * needs no pepper (it cannot be brute-forced). The raw token is returned to the
 * caller once and never persisted or logged.
 */
@Injectable()
export class CryptoSessionTokenGenerator implements SessionTokenGenerator {
  generate(bytes: number): string {
    const size = Number.isInteger(bytes) && bytes >= 16 ? bytes : 32;
    return randomBytes(size).toString('base64url');
  }
}
