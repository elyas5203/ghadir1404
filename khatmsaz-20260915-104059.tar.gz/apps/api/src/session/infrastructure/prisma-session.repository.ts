import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { Session } from '../domain/session';
import type { SessionRepository } from '../domain/session.repository';
import { toSession } from './session.mapper';

/**
 * Prisma-backed {@link SessionRepository} — the only session persistence that sees
 * Prisma; returns domain objects, never Prisma rows. Sessions are looked up by
 * token hash (indexed); revocation is an UPDATE that sets `revoked_at` (history is
 * retained, never deleted). No raw token is ever handled here.
 */
@Injectable()
export class PrismaSessionRepository implements SessionRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(session: Session): Promise<Session> {
    const row = await this.prisma.session.create({
      data: {
        id: session.id,
        userId: session.userId,
        tokenHash: session.tokenHash,
        createdAt: session.createdAt,
        expiresAt: session.expiresAt,
        revokedAt: session.revokedAt,
        lastUsedAt: session.lastUsedAt,
      },
    });
    return toSession(row);
  }

  async findByTokenHash(tokenHash: string): Promise<Session | null> {
    const row = await this.prisma.session.findUnique({ where: { tokenHash } });
    return row ? toSession(row) : null;
  }

  async findById(id: string): Promise<Session | null> {
    const row = await this.prisma.session.findUnique({ where: { id } });
    return row ? toSession(row) : null;
  }

  async revoke(id: string, revokedAt: Date): Promise<void> {
    // Idempotent: only an active (not-yet-revoked) row is stamped.
    await this.prisma.session.updateMany({
      where: { id, revokedAt: null },
      data: { revokedAt },
    });
  }

  async touchLastUsed(id: string, at: Date): Promise<void> {
    await this.prisma.session.updateMany({ where: { id }, data: { lastUsedAt: at } });
  }

  async revokeAllForUser(userId: string, revokedAt: Date): Promise<number> {
    const result = await this.prisma.session.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt },
    });
    return result.count;
  }
}
