import { createHash } from 'node:crypto';
import { Sha256SessionTokenHasher } from './sha256-session-token-hasher';

describe('Sha256SessionTokenHasher', () => {
  const hasher = new Sha256SessionTokenHasher();

  it('produces a 64-char hex SHA-256 digest that matches node crypto', () => {
    const token = 'a-random-opaque-token';
    const hash = hasher.hash(token);
    expect(hash).toMatch(/^[0-9a-f]{64}$/);
    expect(hash).toBe(createHash('sha256').update(token).digest('hex'));
  });

  it('never returns the raw token in the hash', () => {
    const token = 'super-secret-token-value';
    expect(hasher.hash(token)).not.toContain(token);
  });

  it('verifies a matching token and rejects a wrong one', () => {
    const token = 'the-real-token';
    const stored = hasher.hash(token);
    expect(hasher.verify(token, stored)).toBe(true);
    expect(hasher.verify('a-different-token', stored)).toBe(false);
  });

  it('rejects a malformed stored hash without throwing (constant-time-safe path)', () => {
    expect(hasher.verify('t', 'not-hex')).toBe(false);
    expect(hasher.verify('t', '')).toBe(false);
  });
});
