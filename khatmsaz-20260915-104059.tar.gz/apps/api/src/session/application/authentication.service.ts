import { Inject, Injectable } from '@nestjs/common';
import { newUuidV7, assertUuidV7 } from '@khatmsaz/kernel';
import { IdentityService } from '../../identity/application/identity.service';
import { Session } from '../domain/session';
import type { AuthenticatedPrincipal } from '../domain/authenticated-principal';
import { SESSION_REPOSITORY } from '../domain/session.repository';
import type { SessionRepository } from '../domain/session.repository';
import {
  SESSION_TOKEN_GENERATOR,
  SESSION_TOKEN_HASHER,
} from '../domain/session-token';
import type { SessionTokenGenerator, SessionTokenHasher } from '../domain/session-token';
import { CLOCK } from '../domain/clock';
import type { Clock } from '../domain/clock';
import {
  InvalidSessionTokenError,
  SessionExpiredError,
  SessionRevokedError,
  SessionUserNotActiveError,
} from '../domain/session.errors';
import { SESSION_POLICY } from './session-policy';
import type { SessionPolicyConfig } from './session-policy';

/** A newly created session and the raw token — the token is returned ONCE, here. */
export interface CreatedSession {
  readonly session: Session;
  /** The raw opaque token. Not stored anywhere; hand to the client immediately. */
  readonly token: string;
}

/**
 * AuthenticationService — the core session use-cases (Phase 6, DEC-0059): mint a
 * session, authenticate a token into a principal, and revoke. It is Prisma-free and
 * transport-agnostic (no HTTP/Telegram concepts). A session authenticates only when
 * it is ACTIVE (not revoked, not expired) AND its user is still an active account —
 * so a merged/tombstoned user's sessions stop working.
 *
 * SECURITY: the raw token exists only in memory during `createSession`; only its
 * SHA-256 hash is persisted. Authentication looks up by hash and additionally does a
 * constant-time compare. No token, hash, or secret is ever logged or put in an error.
 */
@Injectable()
export class AuthenticationService {
  constructor(
    @Inject(SESSION_REPOSITORY) private readonly sessions: SessionRepository,
    @Inject(SESSION_TOKEN_GENERATOR) private readonly generator: SessionTokenGenerator,
    @Inject(SESSION_TOKEN_HASHER) private readonly hasher: SessionTokenHasher,
    @Inject(CLOCK) private readonly clock: Clock,
    @Inject(SESSION_POLICY) private readonly policy: SessionPolicyConfig,
    private readonly identity: IdentityService,
  ) {}

  /** Create a session for an active user, returning the raw token exactly once. */
  async createSession(userId: string): Promise<CreatedSession> {
    assertUuidV7(userId, 'userId');
    await this.requireActiveUser(userId);

    const token = this.generator.generate(this.policy.tokenBytes);
    const now = this.clock.now();
    const session = Session.create({
      id: newUuidV7(),
      userId,
      tokenHash: this.hasher.hash(token),
      createdAt: now,
      expiresAt: new Date(now.getTime() + this.policy.ttlSeconds * 1000),
    });
    const saved = await this.sessions.create(session);
    return { session: saved, token };
  }

  /**
   * Authenticate a raw token into an {@link AuthenticatedPrincipal}. Throws a
   * specific {@link import('../domain/session.errors').SessionAuthenticationError}
   * (invalid / revoked / expired / user-not-active) — never leaking whether a token
   * exists beyond that.
   */
  async authenticate(rawToken: string): Promise<AuthenticatedPrincipal> {
    if (typeof rawToken !== 'string' || rawToken.length === 0) {
      throw new InvalidSessionTokenError();
    }
    const session = await this.sessions.findByTokenHash(this.hasher.hash(rawToken));
    if (!session || !this.hasher.verify(rawToken, session.tokenHash)) {
      throw new InvalidSessionTokenError();
    }

    const now = this.clock.now();
    if (session.revokedAt !== null) throw new SessionRevokedError();
    if (!session.isActiveAt(now)) throw new SessionExpiredError();

    await this.requireActiveUser(session.userId);
    await this.sessions.touchLastUsed(session.id, now);
    return { userId: session.userId, sessionId: session.id };
  }

  /** Revoke a session by id (idempotent). */
  async revokeSession(sessionId: string): Promise<void> {
    assertUuidV7(sessionId, 'sessionId');
    await this.sessions.revoke(sessionId, this.clock.now());
  }

  /** Revoke every active session of a user ("log out everywhere"). */
  async revokeAllForUser(userId: string): Promise<number> {
    assertUuidV7(userId, 'userId');
    return this.sessions.revokeAllForUser(userId, this.clock.now());
  }

  private async requireActiveUser(userId: string): Promise<void> {
    const user = await this.identity.findUserById(userId);
    if (!user || !user.isActive) {
      throw new SessionUserNotActiveError();
    }
  }
}
