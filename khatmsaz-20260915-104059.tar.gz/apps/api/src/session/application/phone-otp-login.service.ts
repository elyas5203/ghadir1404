import { Injectable } from '@nestjs/common';
import { PhoneVerificationService } from '../../phone/application/phone-verification.service';
import { AuthenticationService } from './authentication.service';
import type { Session } from '../domain/session';

/** The result of a phone-OTP login attempt. */
export type PhoneOtpLoginResult =
  | {
      /** The phone was verified (now or already) and a session was issued. */
      readonly outcome: 'VERIFIED' | 'ALREADY_VERIFIED';
      readonly session: Session;
      /** Raw session token — returned once. */
      readonly token: string;
    }
  | {
      /** The number belongs to another account; no session is issued (DEC-0037). */
      readonly outcome: 'MERGE_REQUIRED';
    };

/**
 * Phone-OTP login bridge (Phase 6 Part 5, DEC-0060). It CONSUMES the phone
 * capability's existing verification — it does NOT redesign it: it calls
 * `verifyPhone`, and on a successful verified outcome mints a session via the
 * {@link AuthenticationService}. A wrong/expired/exhausted code surfaces as the
 * phone capability's own thrown error (propagated unchanged); a `MERGE_REQUIRED`
 * conflict yields no session (the caller routes it to the account-merge flow).
 *
 * The caller supplies the `userId` whose claim is being verified — the phone model
 * is user-scoped (a claim belongs to a user); the OTP code is the credential. No
 * transport concepts appear here.
 */
@Injectable()
export class PhoneOtpLoginService {
  constructor(
    private readonly phone: PhoneVerificationService,
    private readonly auth: AuthenticationService,
  ) {}

  /**
   * Issue (or re-issue) an OTP for the user's phone — the first step of login.
   * Delegates to the phone capability unchanged; returns the canonical E.164 (never
   * the code, which is delivered out-of-band). Part of the login flow, so it does
   * not require an existing session.
   */
  async requestOtp(userId: string, rawPhone: string): Promise<{ e164: string }> {
    const claim = await this.phone.requestPhoneVerification(userId, rawPhone);
    return { e164: claim.e164 };
  }

  async loginByPhoneOtp(
    userId: string,
    rawPhone: string,
    code: string,
  ): Promise<PhoneOtpLoginResult> {
    const result = await this.phone.verifyPhone(userId, rawPhone, code);
    if (result.outcome === 'MERGE_REQUIRED') {
      return { outcome: 'MERGE_REQUIRED' };
    }
    const created = await this.auth.createSession(userId);
    return { outcome: result.outcome, session: created.session, token: created.token };
  }
}
