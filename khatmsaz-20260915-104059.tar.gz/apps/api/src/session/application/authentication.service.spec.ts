import { createHash } from 'node:crypto';
import { newUuidV7 } from '@khatmsaz/kernel';
import type { IdentityService } from '../../identity/application/identity.service';
import { AuthenticationService } from './authentication.service';
import { Session } from '../domain/session';
import type { SessionRepository } from '../domain/session.repository';
import {
  InvalidSessionTokenError,
  SessionExpiredError,
  SessionRevokedError,
  SessionUserNotActiveError,
} from '../domain/session.errors';
import { CryptoSessionTokenGenerator } from '../infrastructure/crypto-session-token-generator';
import { Sha256SessionTokenHasher } from '../infrastructure/sha256-session-token-hasher';

/** In-memory session store. */
class FakeSessionRepository implements SessionRepository {
  readonly rows = new Map<string, Session>();
  async create(session: Session): Promise<Session> {
    this.rows.set(session.id, session);
    return session;
  }
  async findByTokenHash(tokenHash: string): Promise<Session | null> {
    return [...this.rows.values()].find((s) => s.tokenHash === tokenHash) ?? null;
  }
  async findById(id: string): Promise<Session | null> {
    return this.rows.get(id) ?? null;
  }
  async revoke(id: string, revokedAt: Date): Promise<void> {
    const s = this.rows.get(id);
    if (s && s.revokedAt === null) {
      this.rows.set(
        id,
        Session.restore({
          id: s.id,
          userId: s.userId,
          tokenHash: s.tokenHash,
          createdAt: s.createdAt,
          expiresAt: s.expiresAt,
          revokedAt,
          lastUsedAt: s.lastUsedAt,
        }),
      );
    }
  }
  async touchLastUsed(): Promise<void> {
    /* no-op for these tests */
  }
  async revokeAllForUser(userId: string, revokedAt: Date): Promise<number> {
    let n = 0;
    for (const [id, s] of this.rows) {
      if (s.userId === userId && s.revokedAt === null) {
        await this.revoke(id, revokedAt);
        n += 1;
      }
    }
    return n;
  }
}

class MutableClock {
  constructor(private current: Date) {}
  now(): Date {
    return this.current;
  }
  set(date: Date): void {
    this.current = date;
  }
}

/** Identity stub: only `findUserById().isActive` is consulted. */
function fakeIdentity(activeFor: Set<string>): IdentityService {
  return {
    async findUserById(id: string) {
      return activeFor.has(id) ? ({ id, isActive: true } as never) : null;
    },
  } as unknown as IdentityService;
}

describe('AuthenticationService', () => {
  const userId = newUuidV7();
  let repo: FakeSessionRepository;
  let clock: MutableClock;
  let active: Set<string>;
  let service: AuthenticationService;

  const build = () => {
    repo = new FakeSessionRepository();
    clock = new MutableClock(new Date(1_000_000));
    active = new Set([userId]);
    service = new AuthenticationService(
      repo,
      new CryptoSessionTokenGenerator(),
      new Sha256SessionTokenHasher(),
      clock,
      { ttlSeconds: 100, tokenBytes: 32 },
      fakeIdentity(active),
    );
  };

  beforeEach(build);

  it('creates a session, returns a raw token once, and authenticates it', async () => {
    const { token, session } = await service.createSession(userId);
    expect(token).toBeTruthy();
    const principal = await service.authenticate(token);
    expect(principal).toEqual({ userId, sessionId: session.id });
  });

  it('stores only the hash of the token, never the raw token', async () => {
    const { token, session } = await service.createSession(userId);
    const stored = repo.rows.get(session.id);
    expect(stored?.tokenHash).not.toContain(token);
    expect(stored?.tokenHash).toBe(createHash('sha256').update(token).digest('hex'));
    expect(stored?.tokenHash).toMatch(/^[0-9a-f]{64}$/);
  });

  it('rejects an invalid/unknown token', async () => {
    await service.createSession(userId);
    await expect(service.authenticate('bogus')).rejects.toBeInstanceOf(InvalidSessionTokenError);
    await expect(service.authenticate('')).rejects.toBeInstanceOf(InvalidSessionTokenError);
  });

  it('rejects an expired session', async () => {
    const { token } = await service.createSession(userId);
    clock.set(new Date(1_000_000 + 100_001)); // past the 100s TTL
    await expect(service.authenticate(token)).rejects.toBeInstanceOf(SessionExpiredError);
  });

  it('rejects a revoked session', async () => {
    const { token, session } = await service.createSession(userId);
    await service.revokeSession(session.id);
    await expect(service.authenticate(token)).rejects.toBeInstanceOf(SessionRevokedError);
  });

  it('refuses to create a session for a non-active user', async () => {
    active.delete(userId);
    await expect(service.createSession(userId)).rejects.toBeInstanceOf(SessionUserNotActiveError);
  });

  it('stops authenticating once the user is no longer active (e.g. merged)', async () => {
    const { token } = await service.createSession(userId);
    active.delete(userId); // user merged/tombstoned after the session was issued
    await expect(service.authenticate(token)).rejects.toBeInstanceOf(SessionUserNotActiveError);
  });
});
