/**
 * DI token for the non-secret {@link SessionPolicyConfig} (TTL, token entropy),
 * resolved from `@khatmsaz/config.sessionPolicyConfig()` and bound in the module.
 * Kept out of the domain so the domain has no configuration dependency.
 */

import type { SessionPolicyConfig } from '@khatmsaz/config';

export const SESSION_POLICY = Symbol('SESSION_POLICY');
export type { SessionPolicyConfig };
