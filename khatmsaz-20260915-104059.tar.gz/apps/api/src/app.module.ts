import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { LoggerModule } from 'nestjs-pino';
import { isProduction, readString } from '@khatmsaz/config';
import { DatabaseModule } from './infrastructure/database/database.module';
import { HealthModule } from './health/health.module';
import { IdentityModule } from './identity/identity.module';
import { PhoneModule } from './phone/phone.module';
import { AccountMergeModule } from './account-merge/account-merge.module';
import { KhatmModule } from './khatm/khatm.module';
import { AllocationModule } from './allocation/allocation.module';
import { AuthorizationModule } from './authorization/authorization.module';
import { InvitationModule } from './invitation/invitation.module';
import { KhatmWorkflowModule } from './khatm-workflow/khatm-workflow.module';
import { SessionModule } from './session/session.module';
import { HttpApiModule } from './http-api/http-api.module';
import { TelegramModule } from './telegram/telegram.module';
import { BaleModule } from './bale/bale.module';
import { NotificationModule } from './notification/notification.module';
import { WaitingListModule } from './waiting-list/waiting-list.module';
import { UserSettingsModule } from './user-settings/user-settings.module';
import { SmsModule } from './sms/sms.module';
import { AuditModule } from './audit/audit.module';

/**
 * Application root.
 *
 * KhatmSaz is a MODULAR MONOLITH. Every future capability arrives as its own
 * Nest module with a clear boundary, imported here. Platform integrations
 * (Telegram, Bale, SMS, payment) will live behind adapter modules and must
 * never leak into domain modules.
 *
 * Phase 2A added the infrastructure DatabaseModule (the single Prisma client and
 * the readiness probe). It is global, so domain modules reach persistence
 * through the abstractions it exports rather than importing Prisma directly.
 *
 * Phase 2B adds the IdentityModule — the first real domain capability (canonical
 * User + PlatformIdentity), depending on repository ports it owns.
 *
 * Phase 3A adds the PhoneModule — phone claims and OTP verification. An
 * unverified phone is contact data only; a verified phone is a unique proven
 * claim. OTP delivery sits behind an adapter with no real SMS provider yet.
 *
 * Phase 4 adds the KhatmModule — the core business domain: the Khatm aggregate and
 * its lifecycle, a generic template classification, participation, and the
 * assignment/portion system. No transport surface yet (no controllers or bots).
 *
 * Phase 4.1 adds the AllocationModule — the generic, template-driven allocation
 * engine (plan generation, non-overlapping portions, allocation/reallocation,
 * progress) built additively on top of Phase 4. Still no transport surface.
 *
 * Phase 4.2 adds the KhatmWorkflowModule — an application-only orchestration
 * capability composing identity, khatm and allocation into end-to-end workflows
 * (create → activate → join → allocate → complete). Still no transport surface.
 *
 * Phase 5 adds the TRANSPORT layer that drives those workflows: the HttpApiModule
 * (REST controllers over the workflows) and the TelegramModule (a channel adapter
 * routing Telegram commands to the workflows, resolving platform identity). Both
 * only translate external input into application use-cases — no business logic,
 * no Prisma, no domain entity on the wire.
 *
 * Phase 6 adds the SessionModule — authentication & sessions: server-side opaque
 * tokens (only their hash stored), an authenticated-principal concept, and a
 * phone-OTP login bridge. Transports now resolve an authenticated principal (HTTP
 * bearer token; Telegram platform identity) instead of trusting explicit user ids.
 */
@Module({
  imports: [
    ThrottlerModule.forRoot([
      { name: 'short', ttl: 60_000,  limit: 10 },
      { name: 'otp',   ttl: 300_000, limit: 3  },
    ]),
    LoggerModule.forRoot({
      pinoHttp: {
        level: readString('LOG_LEVEL', isProduction() ? 'warn' : 'debug'),
        redact: ['req.headers.authorization', 'body.mobile', 'body.otp'],
        ...(isProduction()
          ? {}
          : { transport: { target: 'pino-pretty', options: { colorize: true } } }),
      },
    }),
    DatabaseModule,
    HealthModule,
    IdentityModule,
    PhoneModule,
    AccountMergeModule,
    KhatmModule,
    AllocationModule,
    AuthorizationModule,
    KhatmWorkflowModule,
    InvitationModule,
    SessionModule,
    HttpApiModule,
    TelegramModule,
    BaleModule,
    NotificationModule,
    WaitingListModule,
    UserSettingsModule,
    SmsModule,
    AuditModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
