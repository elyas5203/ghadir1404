import { Injectable } from '@nestjs/common';
import { IdentityService } from '../identity/application/identity.service';
import { Platform } from '../identity/domain/platform';
import type { User } from '../identity/domain/user';

/**
 * Shared utility for bot command services to resolve a user from a platform
 * identity without importing IdentityService in every handler.
 *
 * Uses the existing PlatformIdentity table — no new user-linking tables needed.
 */
@Injectable()
export class BotUserResolverService {
  constructor(private readonly identity: IdentityService) {}

  resolveUser(platform: Platform, chatId: string): Promise<User | null> {
    return this.identity.findUserByPlatformIdentity(platform, chatId);
  }

  async provisionUser(platform: Platform, chatId: string): Promise<User> {
    const existing = await this.identity.findUserByPlatformIdentity(platform, chatId);
    if (existing) return existing;
    const user = await this.identity.createUser();
    await this.identity.attachPlatformIdentity(user.id, platform, chatId);
    return user;
  }

  /** Link an existing verified userId to a bot chatId (OTP account-linking flow). */
  async linkUser(userId: string, platform: Platform, chatId: string): Promise<void> {
    await this.identity.attachPlatformIdentity(userId, platform, chatId);
  }
}
