import { Module } from '@nestjs/common';
import { IdentityModule } from '../identity/identity.module';
import { SessionModule } from '../session/session.module';
import { BotUserResolverService } from './bot-user-resolver.service';

@Module({
  imports: [IdentityModule, SessionModule],
  providers: [BotUserResolverService],
  exports: [BotUserResolverService, SessionModule],
})
export class BotSharedModule {}
