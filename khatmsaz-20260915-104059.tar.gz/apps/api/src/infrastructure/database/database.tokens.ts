/**
 * Database boundary tokens and interfaces.
 *
 * This is the seam that keeps Prisma out of the rest of the application. Code
 * that only needs to know "can I reach the database?" depends on the narrow
 * {@link DatabasePing} interface through the {@link DATABASE_PING} token, never
 * on Prisma types or the generated client. Future domain modules follow the
 * same rule: they depend on repository interfaces the domain owns, and the
 * Prisma-backed implementations live here in the infrastructure layer.
 */

/** DI token for a minimal, Prisma-free database connectivity probe. */
export const DATABASE_PING = Symbol('DATABASE_PING');

/** A minimal database connectivity probe, free of any persistence-tool types. */
export interface DatabasePing {
  /**
   * Runs a trivial round-trip query (`SELECT 1`) against the database.
   * Resolves when the database answered; rejects on error or timeout.
   *
   * @param timeoutMs Maximum time to wait before rejecting.
   */
  pingDatabase(timeoutMs: number): Promise<void>;
}

/**
 * The transaction boundary now lives in the shared kernel (DEC-0044) so that both
 * application use-cases and domain repository PORTS can reference it without
 * importing infrastructure. Re-exported here for the infrastructure consumers that
 * already import it (the Prisma implementation and the DI wiring).
 */
export { UNIT_OF_WORK } from '@khatmsaz/kernel';
export type { TransactionContext, UnitOfWork } from '@khatmsaz/kernel';
