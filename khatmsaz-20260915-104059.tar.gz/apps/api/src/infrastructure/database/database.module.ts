import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma/prisma.service';
import { PrismaUnitOfWork } from './prisma/prisma-unit-of-work';
import { DatabaseReadinessService } from './database-readiness.service';
import { DATABASE_PING, UNIT_OF_WORK } from './database.tokens';

/**
 * Infrastructure database module.
 *
 * Owns the single Prisma client and the readiness probe, and is the ONLY place
 * the rest of the application reaches persistence. It is global so the client
 * is a process-wide singleton; consumers inject the exported abstractions
 * (today: {@link DatabaseReadinessService}) rather than importing Prisma.
 *
 * `PrismaService` is bound to the {@link DATABASE_PING} token so that
 * dependents can probe connectivity without seeing Prisma types. As real domain
 * modules arrive, their repository implementations live here and depend on
 * `PrismaService`; the interfaces they satisfy are owned by the domain.
 *
 * It also provides the Prisma-free transaction boundary (`UNIT_OF_WORK`,
 * DEC-0044): the seam a use-case injects to run several repository operations
 * atomically without importing Prisma. Exported (and global) so any capability
 * can depend on the boundary, not on Prisma.
 */
@Global()
@Module({
  providers: [
    PrismaService,
    { provide: DATABASE_PING, useExisting: PrismaService },
    { provide: UNIT_OF_WORK, useClass: PrismaUnitOfWork },
    DatabaseReadinessService,
  ],
  exports: [PrismaService, DatabaseReadinessService, UNIT_OF_WORK],
})
export class DatabaseModule {}
