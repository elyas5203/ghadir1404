import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { DatabaseReadinessService } from './database-readiness.service';
import { DATABASE_PING } from './database.tokens';
import type { DatabasePing } from './database.tokens';

/** Builds the service with a controllable database probe. No real database. */
async function build(ping: DatabasePing): Promise<DatabaseReadinessService> {
  const moduleRef: TestingModule = await Test.createTestingModule({
    providers: [
      DatabaseReadinessService,
      { provide: DATABASE_PING, useValue: ping },
    ],
  }).compile();
  return moduleRef.get(DatabaseReadinessService);
}

describe('DatabaseReadinessService', () => {
  it('reports ready when the database probe succeeds', async () => {
    const service = await build({ pingDatabase: async () => undefined });

    const result = await service.getReadiness();

    expect(result.status).toBe('ready');
    expect(result.checks.database).toBe('up');
    expect(() => new Date(result.timestamp).toISOString()).not.toThrow();
  });

  it('reports not_ready when the database probe fails', async () => {
    const service = await build({
      pingDatabase: async () => {
        throw new Error('connection refused');
      },
    });

    const result = await service.getReadiness();

    expect(result.status).toBe('not_ready');
    expect(result.checks.database).toBe('down');
  });

  it('passes a bounded timeout to the probe', async () => {
    let received: number | undefined;
    const service = await build({
      pingDatabase: async (timeoutMs: number) => {
        received = timeoutMs;
      },
    });

    await service.getReadiness();

    expect(received).toBeGreaterThan(0);
    expect(received).toBeLessThanOrEqual(5_000);
  });

  it('never surfaces the underlying error (which could carry credentials)', async () => {
    const secret = 'postgresql://u:p@host/db';
    const service = await build({
      pingDatabase: async () => {
        throw new Error(secret);
      },
    });

    const result = await service.getReadiness();

    expect(JSON.stringify(result)).not.toContain(secret);
    expect(JSON.stringify(result)).not.toContain('host');
  });
});
