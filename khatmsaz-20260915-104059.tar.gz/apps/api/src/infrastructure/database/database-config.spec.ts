import {
  assertValidDatabaseUrl,
  databaseUrl,
  resolveDatabaseUrl,
} from '@khatmsaz/config';

/**
 * Validates the database configuration layer (from @khatmsaz/config).
 *
 * These are pure unit tests: they manipulate process.env in-memory and require
 * no database and no Docker. They also assert that failures never echo the
 * connection string or credentials.
 */
describe('database configuration', () => {
  const DB_KEYS = [
    'DATABASE_URL',
    'POSTGRES_HOST',
    'POSTGRES_PORT',
    'POSTGRES_DB',
    'POSTGRES_USER',
    'POSTGRES_PASSWORD',
  ] as const;

  let saved: Record<string, string | undefined>;

  beforeEach(() => {
    saved = {};
    for (const key of DB_KEYS) {
      saved[key] = process.env[key];
      delete process.env[key];
    }
  });

  afterEach(() => {
    for (const key of DB_KEYS) {
      if (saved[key] === undefined) delete process.env[key];
      else process.env[key] = saved[key];
    }
  });

  describe('resolveDatabaseUrl', () => {
    it('prefers an explicit DATABASE_URL', () => {
      process.env.DATABASE_URL = 'postgresql://a:b@db.local:5432/khatmsaz';
      expect(resolveDatabaseUrl()).toBe('postgresql://a:b@db.local:5432/khatmsaz');
    });

    it('composes a URL from discrete POSTGRES_* parts', () => {
      process.env.POSTGRES_HOST = '127.0.0.1';
      process.env.POSTGRES_PORT = '5432';
      process.env.POSTGRES_DB = 'khatmsaz';
      process.env.POSTGRES_USER = 'khatmsaz';
      process.env.POSTGRES_PASSWORD = 'p@ss/word';

      const url = resolveDatabaseUrl();

      expect(url).toBeDefined();
      const parsed = new URL(url!);
      expect(parsed.protocol).toBe('postgresql:');
      expect(parsed.hostname).toBe('127.0.0.1');
      expect(parsed.port).toBe('5432');
      // Special characters in the password are URL-encoded.
      expect(decodeURIComponent(parsed.password)).toBe('p@ss/word');
      expect(parsed.pathname).toBe('/khatmsaz');
    });

    it('returns undefined when neither source is available', () => {
      expect(resolveDatabaseUrl()).toBeUndefined();
    });

    it('returns undefined when the password part is missing', () => {
      process.env.POSTGRES_HOST = '127.0.0.1';
      process.env.POSTGRES_DB = 'khatmsaz';
      process.env.POSTGRES_USER = 'khatmsaz';
      expect(resolveDatabaseUrl()).toBeUndefined();
    });
  });

  describe('assertValidDatabaseUrl', () => {
    it('accepts postgres:// and postgresql:// URLs', () => {
      expect(() => assertValidDatabaseUrl('postgres://u:p@h:5432/d')).not.toThrow();
      expect(() => assertValidDatabaseUrl('postgresql://u:p@h:5432/d')).not.toThrow();
    });

    it('rejects a non-URL string', () => {
      expect(() => assertValidDatabaseUrl('not a url')).toThrow(/not a valid URL/);
    });

    it('rejects a non-postgres protocol', () => {
      expect(() => assertValidDatabaseUrl('mysql://u:p@h/d')).toThrow(/postgresql/);
    });

    it('rejects a URL with no database name', () => {
      expect(() => assertValidDatabaseUrl('postgresql://u:p@h:5432/')).toThrow(/database name/);
    });
  });

  describe('databaseUrl', () => {
    it('fails fast with a clear message when configuration is missing', () => {
      expect(() => databaseUrl()).toThrow(/configuration is missing/);
    });

    it('never includes the connection string or password in the error', () => {
      process.env.DATABASE_URL = 'postgresql://secretuser:secretpass@secrethost:5432';
      let message = '';
      try {
        databaseUrl();
      } catch (error) {
        message = (error as Error).message;
      }
      expect(message).toMatch(/database name/i);
      expect(message).not.toContain('secretpass');
      expect(message).not.toContain('secretuser');
      expect(message).not.toContain('secrethost');
    });

    it('returns a validated URL for good configuration', () => {
      process.env.DATABASE_URL = 'postgresql://u:p@127.0.0.1:5432/khatmsaz?schema=public';
      expect(databaseUrl()).toBe('postgresql://u:p@127.0.0.1:5432/khatmsaz?schema=public');
    });
  });
});
