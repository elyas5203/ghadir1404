import { Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import type { PrismaClient } from './generated/client';
import type { TransactionContext, UnitOfWork } from '../database.tokens';

/**
 * The Prisma transaction client: a `PrismaClient` without the connection- and
 * transaction-management methods (they are unavailable inside an interactive
 * transaction). This type is used ONLY inside infrastructure.
 */
export type PrismaTransactionClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$extends' | '$use'
>;

/**
 * Unwrap a {@link TransactionContext} into the Prisma transaction client. This is
 * the ONE place the opaque handle is cast back to a Prisma type; transaction-aware
 * repositories (Phase 3B) will call this to run their writes on the transaction.
 * Keeping the cast here means the boundary stays Prisma-free everywhere else.
 */
export function txClient(tx: TransactionContext): PrismaTransactionClient {
  return tx as unknown as PrismaTransactionClient;
}

/**
 * Resolve the Prisma client a transaction-aware repository method should use: the
 * transaction client when a {@link TransactionContext} is supplied, otherwise the
 * ordinary app-lifetime client. Centralising this keeps every repository's
 * transaction handling identical and the cast confined to infrastructure.
 */
export function dbClient(
  prisma: PrismaService,
  tx?: TransactionContext,
): PrismaTransactionClient {
  return tx ? txClient(tx) : prisma;
}

/**
 * Prisma-backed {@link UnitOfWork} (DEC-0044). Runs the callback inside a Prisma
 * interactive transaction: any throw rolls the whole transaction back; success
 * commits it. The Prisma transaction client is handed to the callback as an
 * opaque {@link TransactionContext}, so callers never see a Prisma type.
 *
 * This is the transaction seam Phase 3B's account-merge use-case will run inside;
 * it contains no merge logic itself.
 */
@Injectable()
export class PrismaUnitOfWork implements UnitOfWork {
  constructor(private readonly prisma: PrismaService) {}

  run<T>(work: (tx: TransactionContext) => Promise<T>): Promise<T> {
    return this.prisma.$transaction((tx) => work(tx as unknown as TransactionContext));
  }
}
