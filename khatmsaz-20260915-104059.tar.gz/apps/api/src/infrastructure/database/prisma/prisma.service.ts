import { Injectable, Logger } from '@nestjs/common';
import type { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaPg } from '@prisma/adapter-pg';
import { databaseUrl } from '@khatmsaz/config';
import type { DatabasePing } from '../database.tokens';
import { PrismaClient } from './generated/client';

/**
 * The single, application-lifetime Prisma client.
 *
 * One instance is created for the whole process (never one per request). It
 * connects on module init and disconnects on shutdown. Prisma 7 supplies the
 * runtime connection through a driver adapter (`@prisma/adapter-pg`); the
 * connection string is validated by {@link databaseUrl} so a MALFORMED
 * configuration fails fast at construction. A database that is merely
 * unreachable at startup does NOT crash the process — it is logged and the
 * readiness endpoint reports the database as down until it recovers.
 *
 * This class is confined to the infrastructure layer. It exposes the
 * Prisma-free {@link DatabasePing} probe for the readiness check; it must not
 * leak Prisma types into domain modules.
 */
@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy, DatabasePing
{
  private readonly logger = new Logger(PrismaService.name);

  constructor() {
    // `databaseUrl()` throws a clear, secret-free error when the configuration
    // is missing or malformed — the desired fail-fast behaviour at startup.
    super({ adapter: new PrismaPg({ connectionString: databaseUrl() }) });
  }

  async onModuleInit(): Promise<void> {
    try {
      await this.$connect();
      this.logger.log('Database connection established.');
    } catch {
      // Do not crash the process because the database is temporarily down.
      // Never log the error object: it can contain the connection string.
      this.logger.warn(
        'Database not reachable at startup; the API will start and report ' +
          'not-ready until the database becomes available.',
      );
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }

  async pingDatabase(timeoutMs: number): Promise<void> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<never>((_resolve, reject) => {
      timer = setTimeout(
        () => reject(new Error('Database readiness probe timed out.')),
        timeoutMs,
      );
    });

    try {
      await Promise.race([this.$queryRaw`SELECT 1`, timeout]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
}
