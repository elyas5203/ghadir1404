import { Inject, Injectable, Logger } from '@nestjs/common';
import type { ReadinessResponse } from '@khatmsaz/contracts';
import { nowIso } from '@khatmsaz/shared';
import { DATABASE_PING } from './database.tokens';
import type { DatabasePing } from './database.tokens';

/** How long the readiness probe waits for the database before giving up. */
const READINESS_TIMEOUT_MS = 2_000;

/**
 * Computes service readiness by probing required dependencies.
 *
 * Phase 2A has one required dependency: PostgreSQL. The probe depends on the
 * narrow {@link DatabasePing} interface, not on Prisma, so nothing here is
 * coupled to the persistence tool. Add further dependencies to the `checks`
 * object as they become genuinely required for the API to serve requests.
 */
@Injectable()
export class DatabaseReadinessService {
  private readonly logger = new Logger(DatabaseReadinessService.name);

  constructor(@Inject(DATABASE_PING) private readonly database: DatabasePing) {}

  async getReadiness(): Promise<ReadinessResponse> {
    const database = await this.probeDatabase();
    const status = database === 'up' ? 'ready' : 'not_ready';
    return {
      status,
      checks: { database },
      timestamp: nowIso(),
    };
  }

  private async probeDatabase(): Promise<'up' | 'down'> {
    try {
      await this.database.pingDatabase(READINESS_TIMEOUT_MS);
      return 'up';
    } catch {
      // Never log the raw error: it may carry connection details. A stable,
      // non-secret message is enough to signal the dependency is unavailable.
      this.logger.warn('Database readiness probe failed.');
      return 'down';
    }
  }
}
