import { Inject, Injectable } from '@nestjs/common';
import {
  USER_SETTINGS_REPOSITORY,
  type UserSettingsRepository,
} from '../domain/user-settings.repository';
import { DEFAULT_USER_SETTINGS, type UserSettingsData } from '../domain/user-settings';

/**
 * UserSettings use-cases (Sprint Phase 07).
 * Settings are created lazily — a missing row means "use defaults".
 */
@Injectable()
export class UserSettingsService {
  constructor(
    @Inject(USER_SETTINGS_REPOSITORY) private readonly repo: UserSettingsRepository,
  ) {}

  async getSettings(userId: string): Promise<UserSettingsData> {
    const row = await this.repo.findByUserId(userId);
    return row ?? { userId, ...DEFAULT_USER_SETTINGS };
  }

  async updateSettings(
    userId: string,
    patch: Partial<Omit<UserSettingsData, 'userId'>>,
  ): Promise<UserSettingsData> {
    const current = await this.getSettings(userId);
    const updated: UserSettingsData = { ...current, ...patch, userId };
    return this.repo.upsert(updated);
  }
}
