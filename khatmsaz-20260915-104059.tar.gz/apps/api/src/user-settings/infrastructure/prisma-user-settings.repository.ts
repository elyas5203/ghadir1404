import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { UserSettingsRepository } from '../domain/user-settings.repository';
import type { UserSettingsData, FontSize, Gender } from '../domain/user-settings';

@Injectable()
export class PrismaUserSettingsRepository implements UserSettingsRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findByUserId(userId: string): Promise<UserSettingsData | null> {
    const row = await this.prisma.userSettings.findUnique({ where: { userId } });
    return row ? this.toDomain(row) : null;
  }

  async upsert(data: UserSettingsData): Promise<UserSettingsData> {
    const row = await this.prisma.userSettings.upsert({
      where: { userId: data.userId },
      create: {
        userId: data.userId,
        reminderHour: data.reminderHour,
        reminderMinute: data.reminderMinute,
        timezone: data.timezone,
        fontSize: data.fontSize,
        preferredReciter: data.preferredReciter ?? null,
        smsEnabled: data.smsEnabled,
        city: data.city ?? null,
        province: data.province ?? null,
        gender: data.gender ?? null,
        language: data.language,
      },
      update: {
        reminderHour: data.reminderHour,
        reminderMinute: data.reminderMinute,
        timezone: data.timezone,
        fontSize: data.fontSize,
        preferredReciter: data.preferredReciter ?? null,
        smsEnabled: data.smsEnabled,
        city: data.city ?? null,
        province: data.province ?? null,
        gender: data.gender ?? null,
        language: data.language,
      },
    });
    return this.toDomain(row);
  }

  private toDomain(row: {
    userId: string;
    reminderHour: number;
    reminderMinute: number;
    timezone: string;
    fontSize: string;
    preferredReciter: string | null;
    smsEnabled: boolean;
    city: string | null;
    province: string | null;
    gender: string | null;
    language: string;
  }): UserSettingsData {
    return {
      userId: row.userId,
      reminderHour: row.reminderHour,
      reminderMinute: row.reminderMinute,
      timezone: row.timezone,
      fontSize: row.fontSize as FontSize,
      preferredReciter: row.preferredReciter,
      smsEnabled: row.smsEnabled,
      city: row.city,
      province: row.province,
      gender: row.gender as Gender | null,
      language: row.language,
    };
  }
}
