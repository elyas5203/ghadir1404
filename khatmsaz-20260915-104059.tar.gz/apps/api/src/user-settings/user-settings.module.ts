import { Module } from '@nestjs/common';
import { UserSettingsService } from './application/user-settings.service';
import { USER_SETTINGS_REPOSITORY } from './domain/user-settings.repository';
import { PrismaUserSettingsRepository } from './infrastructure/prisma-user-settings.repository';

@Module({
  providers: [
    UserSettingsService,
    { provide: USER_SETTINGS_REPOSITORY, useClass: PrismaUserSettingsRepository },
  ],
  exports: [UserSettingsService],
})
export class UserSettingsModule {}
