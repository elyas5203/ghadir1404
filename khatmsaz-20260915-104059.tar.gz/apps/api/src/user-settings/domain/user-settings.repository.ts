import type { UserSettingsData } from './user-settings';

export interface UserSettingsRepository {
  findByUserId(userId: string): Promise<UserSettingsData | null>;
  upsert(data: UserSettingsData): Promise<UserSettingsData>;
}

export const USER_SETTINGS_REPOSITORY = Symbol('UserSettingsRepository');
