export type FontSize = 'NORMAL' | 'LARGE';
export type Gender = 'MALE' | 'FEMALE';

export interface UserSettingsData {
  readonly userId: string;
  readonly reminderHour: number;
  readonly reminderMinute: number;
  readonly timezone: string;
  readonly fontSize: FontSize;
  readonly preferredReciter: string | null;
  readonly smsEnabled: boolean;
  readonly city: string | null;
  readonly province: string | null;
  readonly gender: Gender | null;
  readonly language: string;
}

/** Defaults used when no settings row exists for a user. */
export const DEFAULT_USER_SETTINGS: Omit<UserSettingsData, 'userId'> = {
  reminderHour: 9,
  reminderMinute: 0,
  timezone: 'Asia/Tehran',
  fontSize: 'NORMAL',
  preferredReciter: null,
  smsEnabled: false,
  city: null,
  province: null,
  gender: null,
  language: 'fa',
};
