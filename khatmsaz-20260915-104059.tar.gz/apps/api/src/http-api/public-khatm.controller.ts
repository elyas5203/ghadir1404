import { Controller, Get, NotFoundException, Param } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import { KhatmService } from '../khatm/application/khatm.service';
import { AllocationService } from '../allocation/application/allocation.service';
import { IdentityService } from '../identity/application/identity.service';

/**
 * Public khatm endpoint — no authentication required (Sprint Phase 05).
 * Returns only the information safe to show publicly.
 */
@SkipThrottle()
@Controller('public/khatm')
export class PublicKhatmController {
  constructor(
    private readonly khatms: KhatmService,
    private readonly allocation: AllocationService,
    private readonly identity: IdentityService,
  ) {}

  @Get(':slug')
  async getPublicKhatm(@Param('slug') slug: string) {
    const khatm = await this.khatms.findKhatmBySlug(slug);
    if (!khatm) throw new NotFoundException('این ختم یافت نشد.');

    const [progress, creator] = await Promise.all([
      this.allocation.progress(khatm.id).catch(() => ({ total: 0, completed: 0, open: 0, assigned: 0 })),
      this.identity.findUserById(khatm.creatorUserId),
    ]);
    const participations = await this.khatms.listParticipations(khatm.id);
    const activeMemberCount = participations.filter((p) => p.isActive).length;

    return {
      id: khatm.id,
      slug: khatm.publicSlug ?? slug,
      title: khatm.title,
      type: khatm.templateType,
      khatmType: khatm.khatmType,
      status: khatm.status,
      niyyat: khatm.niyyat ?? null,
      organizerName: creator?.displayName ?? null,
      progress: {
        total: progress.total,
        completed: progress.completed,
        percent: progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0,
      },
      activeMemberCount,
    };
  }
}
