/**
 * Small, dependency-free validation helpers for the HTTP transport. They turn an
 * untrusted request body into a typed DTO or throw a `BadRequestException` (HTTP
 * 400). Validation POLICY lives here in the transport layer, never in
 * `@khatmsaz/contracts` (which holds shapes only) and never in the domain (which
 * re-validates its own invariants regardless).
 */

import { BadRequestException } from '@nestjs/common';

function fail(message: string): never {
  throw new BadRequestException(message);
}

/** The body must be a plain object. */
export function asObject(body: unknown): Record<string, unknown> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) {
    fail('Request body must be a JSON object.');
  }
  return body as Record<string, unknown>;
}

/** A required, non-empty (after trim) string field. */
export function requireString(obj: Record<string, unknown>, field: string): string {
  const value = obj[field];
  if (typeof value !== 'string' || value.trim().length === 0) {
    fail(`Field "${field}" must be a non-empty string.`);
  }
  return (value as string).trim();
}

/** An optional string field; blank/absent becomes `null`. */
export function optionalString(obj: Record<string, unknown>, field: string): string | null {
  const value = obj[field];
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string') {
    fail(`Field "${field}" must be a string when present.`);
  }
  const trimmed = (value as string).trim();
  return trimmed.length === 0 ? null : trimmed;
}

/** A required positive integer field. */
export function requirePositiveInt(obj: Record<string, unknown>, field: string): number {
  const value = obj[field];
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 1) {
    fail(`Field "${field}" must be a positive integer.`);
  }
  return value as number;
}

/** A required string field constrained to a fixed set of allowed values. */
export function requireEnum<T extends string>(
  obj: Record<string, unknown>,
  field: string,
  allowed: readonly T[],
): T {
  const value = obj[field];
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) {
    fail(`Field "${field}" must be one of: ${allowed.join(', ')}.`);
  }
  return value as T;
}
