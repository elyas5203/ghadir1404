/**
 * Parse + validate incoming HTTP request bodies into typed contract DTOs. Each
 * function is the single place an untrusted body for that endpoint is checked;
 * controllers stay thin and never touch raw `unknown` bodies. Invalid input throws
 * `BadRequestException` (HTTP 400).
 */

import { BadRequestException } from '@nestjs/common';
import {
  KHATM_TEMPLATE_TYPES,
  KHATM_TYPES,
  type AllocatePortionsRequest,
  type AllocationPlanSpecDto,
  type CompletePortionRequest,
  type CreateKhatmRequest,
  type GenerateAllocationRequest,
  type RecordContributionRequest,
} from '@khatmsaz/contracts';
import { findQuranEdition, isValidSurahNumber } from '@khatmsaz/shared';
import {
  asObject,
  optionalString,
  requireEnum,
  requirePositiveInt,
  requireString,
} from './validate';

export function parseCreateKhatm(body: unknown): CreateKhatmRequest {
  const obj = asObject(body);
  const templateType = requireEnum(obj, 'templateType', KHATM_TEMPLATE_TYPES);

  let quranEditionId: string | null = null;
  let surahNumber: number | null = null;
  let repetitionTarget: number | null = null;

  if (templateType === 'QURAN_PAGE') {
    const raw = obj['quranEditionId'];
    if (typeof raw !== 'string' || !findQuranEdition(raw)) {
      throw new BadRequestException('Field "quranEditionId" must be a valid Quran edition id.');
    }
    quranEditionId = raw;
  }

  if (templateType === 'QURAN_SURAH') {
    const rawSurah = obj['surahNumber'];
    if (typeof rawSurah !== 'number' || !Number.isInteger(rawSurah) || !isValidSurahNumber(rawSurah)) {
      throw new BadRequestException('Field "surahNumber" must be an integer between 1 and 114.');
    }
    surahNumber = rawSurah;
    repetitionTarget = requirePositiveInt(obj, 'repetitionTarget');
  }

  // SALAWAT / DUA / ZIYARAT / CUSTOM: optional target count stored in repetitionTarget.
  const COUNT_TYPES = ['SALAWAT', 'DUA', 'ZIYARAT', 'CUSTOM'] as const;
  if ((COUNT_TYPES as readonly string[]).includes(templateType)) {
    const raw = obj['repetitionTarget'];
    if (raw !== undefined && raw !== null) {
      if (typeof raw !== 'number' || !Number.isInteger(raw) || raw < 1) {
        throw new BadRequestException('Field "repetitionTarget" must be a positive integer when provided.');
      }
      repetitionTarget = raw;
    }
  }

  return {
    title: requireString(obj, 'title'),
    description: optionalString(obj, 'description'),
    templateType,
    khatmType: requireEnum(obj, 'khatmType', KHATM_TYPES),
    quranEditionId,
    surahNumber,
    repetitionTarget,
  };
}

export function parseRecordContribution(body: unknown): RecordContributionRequest {
  const obj = asObject(body);
  const amount = obj['amount'];
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) {
    throw new BadRequestException('Field "amount" must be a positive number.');
  }
  return {
    amount,
    note: optionalString(obj, 'note'),
  };
}

export function parseGenerateAllocation(body: unknown): GenerateAllocationRequest {
  const obj = asObject(body);
  const specRaw = obj['spec'];
  if (typeof specRaw !== 'object' || specRaw === null) {
    throw new BadRequestException('Field "spec" must be an object.');
  }
  const spec = specRaw as Record<string, unknown>;
  const kind = requireEnum(spec, 'kind', ['POSITIONAL', 'QUANTITY'] as const);
  const parsed: AllocationPlanSpecDto =
    kind === 'POSITIONAL'
      ? { kind, from: requirePositiveInt(spec, 'from'), to: requirePositiveInt(spec, 'to') }
      : { kind, total: requirePositiveInt(spec, 'total'), chunk: requirePositiveInt(spec, 'chunk') };
  return { spec: parsed };
}

export function parseAllocatePortions(body: unknown): AllocatePortionsRequest {
  const obj = asObject(body);
  return {
    participationId: requireString(obj, 'participationId'),
    count: requirePositiveInt(obj, 'count'),
  };
}

export function parseCompletePortion(body: unknown): CompletePortionRequest {
  const obj = asObject(body);
  return { participationId: requireString(obj, 'participationId') };
}
