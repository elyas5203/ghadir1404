import { BadRequestException } from '@nestjs/common';
import {
  parseAllocatePortions,
  parseCompletePortion,
  parseCreateKhatm,
  parseGenerateAllocation,
} from './khatm-requests';

describe('HTTP request DTO validation', () => {
  describe('parseCreateKhatm', () => {
    it('accepts a valid body and trims strings (creator comes from the principal, not the body)', () => {
      expect(
        parseCreateKhatm({ title: ' ختم ', templateType: 'SALAWAT', khatmType: 'COMMITMENT' }),
      ).toEqual({
        title: 'ختم',
        description: null,
        templateType: 'SALAWAT',
        khatmType: 'COMMITMENT',
        quranEditionId: null,
        surahNumber: null,
        repetitionTarget: null,
      });
    });

    it('accepts QURAN_PAGE with a valid edition id', () => {
      const result = parseCreateKhatm({
        title: 'ختم صفحه‌ای',
        templateType: 'QURAN_PAGE',
        khatmType: 'COMMITMENT',
        quranEditionId: 'MADINA_HAFS',
      });
      expect(result.quranEditionId).toBe('MADINA_HAFS');
      expect(result.surahNumber).toBeNull();
    });

    it('accepts QURAN_SURAH with valid surah + target', () => {
      const result = parseCreateKhatm({
        title: 'ختم یس',
        templateType: 'QURAN_SURAH',
        khatmType: 'OPEN',
        surahNumber: 36,
        repetitionTarget: 1000,
      });
      expect(result.surahNumber).toBe(36);
      expect(result.repetitionTarget).toBe(1000);
    });

    it('rejects QURAN_PAGE with a missing or unknown edition id', () => {
      expect(() =>
        parseCreateKhatm({ title: 't', templateType: 'QURAN_PAGE', khatmType: 'COMMITMENT' }),
      ).toThrow(BadRequestException);
      expect(() =>
        parseCreateKhatm({ title: 't', templateType: 'QURAN_PAGE', khatmType: 'COMMITMENT', quranEditionId: 'NOPE' }),
      ).toThrow(BadRequestException);
    });

    it('rejects QURAN_SURAH with an invalid surah number or missing target', () => {
      expect(() =>
        parseCreateKhatm({ title: 't', templateType: 'QURAN_SURAH', khatmType: 'OPEN', surahNumber: 200 }),
      ).toThrow(BadRequestException);
      expect(() =>
        parseCreateKhatm({ title: 't', templateType: 'QURAN_SURAH', khatmType: 'OPEN', surahNumber: 36 }),
      ).toThrow(BadRequestException);
    });

    it('keeps an optional description', () => {
      expect(
        parseCreateKhatm({ title: 't', templateType: 'DUA', description: ' d ', khatmType: 'OPEN' }).description,
      ).toBe('d');
    });

    it('rejects a missing khatm type', () => {
      expect(() => parseCreateKhatm({ title: 't', templateType: 'DUA' })).toThrow(
        BadRequestException,
      );
    });

    it('rejects an unknown khatm type', () => {
      expect(() =>
        parseCreateKhatm({ title: 't', templateType: 'DUA', khatmType: 'MAYBE' }),
      ).toThrow(BadRequestException);
    });

    it('rejects a non-object body', () => {
      expect(() => parseCreateKhatm('x')).toThrow(BadRequestException);
      expect(() => parseCreateKhatm(null)).toThrow(BadRequestException);
      expect(() => parseCreateKhatm([])).toThrow(BadRequestException);
    });

    it('rejects a missing/blank title', () => {
      expect(() => parseCreateKhatm({ title: '  ', templateType: 'DUA' })).toThrow(
        BadRequestException,
      );
    });

    it('rejects an unknown template type', () => {
      expect(() => parseCreateKhatm({ title: 't', templateType: 'PRAYER' })).toThrow(
        BadRequestException,
      );
    });
  });

  describe('parseGenerateAllocation', () => {
    it('parses a POSITIONAL spec', () => {
      expect(parseGenerateAllocation({ spec: { kind: 'POSITIONAL', from: 1, to: 30 } })).toEqual({
        spec: { kind: 'POSITIONAL', from: 1, to: 30 },
      });
    });

    it('parses a QUANTITY spec', () => {
      expect(parseGenerateAllocation({ spec: { kind: 'QUANTITY', total: 1000, chunk: 100 } })).toEqual({
        spec: { kind: 'QUANTITY', total: 1000, chunk: 100 },
      });
    });

    it('rejects a missing spec or unknown kind', () => {
      expect(() => parseGenerateAllocation({})).toThrow(BadRequestException);
      expect(() => parseGenerateAllocation({ spec: { kind: 'RANGE', from: 1, to: 2 } })).toThrow(
        BadRequestException,
      );
    });

    it('rejects non-positive-integer bounds', () => {
      expect(() => parseGenerateAllocation({ spec: { kind: 'POSITIONAL', from: 0, to: 5 } })).toThrow(
        BadRequestException,
      );
      expect(() =>
        parseGenerateAllocation({ spec: { kind: 'QUANTITY', total: 10, chunk: 1.5 } }),
      ).toThrow(BadRequestException);
    });
  });

  describe('parseAllocatePortions / parseCompletePortion', () => {
    it('parses complete', () => {
      expect(parseCompletePortion({ participationId: 'p1' })).toEqual({ participationId: 'p1' });
    });

    it('parses allocate with a positive count', () => {
      expect(parseAllocatePortions({ participationId: 'p1', count: 5 })).toEqual({
        participationId: 'p1',
        count: 5,
      });
    });

    it('rejects a non-positive count', () => {
      expect(() => parseAllocatePortions({ participationId: 'p1', count: 0 })).toThrow(
        BadRequestException,
      );
    });
  });
});
