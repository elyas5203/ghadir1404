import { Module } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { IdentityModule } from '../identity/identity.module';
import { KhatmModule } from '../khatm/khatm.module';
import { KhatmWorkflowModule } from '../khatm-workflow/khatm-workflow.module';
import { AllocationModule } from '../allocation/allocation.module';
import { SessionModule } from '../session/session.module';
import { AuthorizationModule } from '../authorization/authorization.module';
import { InvitationModule } from '../invitation/invitation.module';
import { PaymentModule } from '../payment/payment.module';
import { AuditModule } from '../audit/audit.module';
import { PhoneModule } from '../phone/phone.module';
import { KhatmController } from './khatm.controller';
import { PortionController } from './portion.controller';
import { AuthController } from './auth.controller';
import { MeController } from './me.controller';
import { InvitationController } from './invitation.controller';
import { QuranController } from './quran.controller';
import { PublicKhatmController } from './public-khatm.controller';
import { PaymentController } from '../payment/infrastructure/payment.controller';
import { AdminController } from './admin/admin.controller';
import { AdminGuard } from './admin/admin.guard';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { DomainExceptionFilter } from './domain-exception.filter';

/**
 * HTTP transport module (Phase 5 DEC-0057; Phase 6 DEC-0060). The API boundary that
 * exposes the khatm workflows over REST and authentication over `/api/auth`. It
 * imports the capability modules whose EXPORTED SERVICES the controllers call
 * (khatm-workflow, khatm, and session for login/logout/authentication) and registers
 * the {@link DomainExceptionFilter} so domain/application errors become a stable HTTP
 * envelope. The `SessionAuthGuard` resolves an authenticated principal from a bearer
 * token on the user-scoped routes (create/join/list/logout), which no longer take a
 * caller-supplied user id. Transport only — no business logic, no Prisma, no domain
 * entity on the wire.
 */
@Module({
  imports: [IdentityModule, KhatmModule, KhatmWorkflowModule, AllocationModule, SessionModule, AuthorizationModule, InvitationModule, PaymentModule, AuditModule, PhoneModule],
  controllers: [KhatmController, PortionController, AuthController, MeController, InvitationController, QuranController, PublicKhatmController, PaymentController, AdminController],
  providers: [SessionAuthGuard, AdminGuard, { provide: APP_FILTER, useClass: DomainExceptionFilter }],
})
export class HttpApiModule {}
