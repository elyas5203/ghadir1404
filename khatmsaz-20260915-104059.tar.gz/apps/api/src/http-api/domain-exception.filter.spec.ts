import { ArgumentsHost, BadRequestException, HttpStatus } from '@nestjs/common';
import { InvalidUuidV7Error } from '@khatmsaz/kernel';
import { DomainExceptionFilter } from './domain-exception.filter';
import { KhatmNotFoundError } from '../khatm/domain/khatm.errors';
import {
  AllocationPlanAlreadyExistsError,
  PortionNotHeldByParticipationError,
} from '../allocation/domain/allocation.errors';
import { InactiveCreatorError } from '../khatm-workflow/application/khatm-workflow.errors';
import { InvalidOtpCodeError, NoActiveOtpChallengeError, OtpExpiredError, OtpResendTooSoonError, OtpAttemptsExhaustedError } from '../phone/domain/phone.errors';

function run(exception: unknown): { status: number; body: unknown } {
  const captured: { status: number; body: unknown } = { status: 0, body: undefined };
  const res = {
    status(code: number) {
      captured.status = code;
      return this;
    },
    json(body: unknown) {
      captured.body = body;
      return this;
    },
  };
  const host = {
    switchToHttp: () => ({ getResponse: () => res }),
  } as unknown as ArgumentsHost;
  new DomainExceptionFilter().catch(exception, host);
  return captured;
}

describe('DomainExceptionFilter', () => {
  it.each([new InvalidOtpCodeError(), new NoActiveOtpChallengeError(), new OtpExpiredError()])('maps expected OTP failure to 400: %s', (error) => {
    expect(run(error).status).toBe(HttpStatus.BAD_REQUEST);
  });
  it.each([new OtpResendTooSoonError(30), new OtpAttemptsExhaustedError()])('maps OTP rate/attempt limits to 429: %s', (error) => {
    expect(run(error).status).toBe(HttpStatus.TOO_MANY_REQUESTS);
  });
  it('maps a not-found domain error to 404 with a stable envelope', () => {
    const out = run(new KhatmNotFoundError());
    expect(out.status).toBe(HttpStatus.NOT_FOUND);
    expect(out.body).toEqual({ error: { code: 'KhatmNotFoundError', message: expect.any(String) } });
  });

  it('maps an already-exists error to 409', () => {
    expect(run(new AllocationPlanAlreadyExistsError()).status).toBe(HttpStatus.CONFLICT);
  });

  it('maps a holder violation to 403', () => {
    expect(run(new PortionNotHeldByParticipationError()).status).toBe(HttpStatus.FORBIDDEN);
  });

  it('maps an invalid-id error to 400', () => {
    expect(run(new InvalidUuidV7Error('khatmId')).status).toBe(HttpStatus.BAD_REQUEST);
  });

  it('maps a precondition error (inactive creator) to 409', () => {
    expect(run(new InactiveCreatorError()).status).toBe(HttpStatus.CONFLICT);
  });

  it('preserves an HttpException status and message', () => {
    const out = run(new BadRequestException('bad input'));
    expect(out.status).toBe(HttpStatus.BAD_REQUEST);
    expect(out.body).toEqual({ error: { code: 'BAD_REQUEST', message: 'bad input' } });
  });

  it('hides an unexpected error behind a generic 500', () => {
    const out = run(new Error('boom with secret detail'));
    expect(out.status).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
    expect(out.body).toEqual({ error: { code: 'INTERNAL_ERROR', message: 'Internal server error.' } });
    expect(JSON.stringify(out.body)).not.toContain('secret');
  });
});
