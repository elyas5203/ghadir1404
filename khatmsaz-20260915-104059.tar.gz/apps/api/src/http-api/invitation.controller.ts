import { Body, Controller, Get, HttpCode, Param, Post, UseGuards } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import type {
  AcceptInvitationResponse,
  CreateInvitationResponse,
  KhatmInvitationsResponse,
} from '@khatmsaz/contracts';
import { InvitationService } from '../invitation/application/invitation.service';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { Principal } from './auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../session/domain/authenticated-principal';
import { toInvitationSummary } from './invitation-view.mapper';
import { asObject, requireString } from './dto/validate';

/**
 * HTTP transport for invitations (Phase 11, DEC-0068). Thin: it validates, calls the
 * invitation orchestration (which enforces ownership for issue/list/cancel and joins
 * through the workflow on accept), and maps the result. Every route requires a valid
 * session; the raw invite token appears only in the create response, once.
 */
@Controller('api')
export class InvitationController {
  constructor(private readonly invitations: InvitationService) {}

  /** Issue an invitation for a khatm (owner only). */
  @Post('khatms/:id/invitations')
  @UseGuards(SessionAuthGuard)
  async create(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') khatmId: string,
  ): Promise<CreateInvitationResponse> {
    const { invitation, token } = await this.invitations.createInvitation(khatmId, principal.userId);
    return { invitationId: invitation.id, token, expiresAt: invitation.expiresAt.toISOString() };
  }

  /** List a khatm's invitations (owner only). */
  @SkipThrottle()
  @Get('khatms/:id/invitations')
  @UseGuards(SessionAuthGuard)
  async list(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') khatmId: string,
  ): Promise<KhatmInvitationsResponse> {
    const invitations = await this.invitations.listInvitations(khatmId, principal.userId);
    return { invitations: invitations.map((i) => toInvitationSummary(i)) };
  }

  /** Cancel an invitation (issuer only). */
  @Post('invitations/:id/cancel')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async cancel(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') invitationId: string,
  ): Promise<void> {
    await this.invitations.cancelInvitation(invitationId, principal.userId);
  }

  /** Accept an invitation (any authenticated user) — joins the khatm. */
  @Post('invitations/accept')
  @UseGuards(SessionAuthGuard)
  async accept(
    @Principal() principal: AuthenticatedPrincipal,
    @Body() body: unknown,
  ): Promise<AcceptInvitationResponse> {
    const token = requireString(asObject(body), 'token');
    return this.invitations.acceptInvitation(token, principal.userId);
  }
}
