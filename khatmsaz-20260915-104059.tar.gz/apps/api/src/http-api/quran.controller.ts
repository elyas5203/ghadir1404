import { Controller, Get } from '@nestjs/common';
import type { QuranEditionDto, SurahDto } from '@khatmsaz/contracts';
import { QURAN_EDITIONS, SURAHS } from '@khatmsaz/shared';

/** Read-only reference data endpoints for static Quran content. No auth required. */
@Controller('api/quran')
export class QuranController {
  @Get('editions')
  editions(): { editions: QuranEditionDto[] } {
    return {
      editions: QURAN_EDITIONS.map((e) => ({
        id: e.id,
        nameFa: e.nameFa,
        totalPages: e.totalPages,
      })),
    };
  }

  @Get('surahs')
  surahs(): { surahs: SurahDto[] } {
    return {
      surahs: SURAHS.map((s) => ({
        number: s.number,
        nameFa: s.nameFa,
      })),
    };
  }
}
