import { Body, Controller, Get, HttpCode, Post, Put, UseGuards } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import type {
  BecomeCreatorResponse,
  KhatmListResponse,
  MeResponse,
  ProfileResponse,
} from '@khatmsaz/contracts';
import { AuthorizationService } from '../authorization/application/authorization.service';
import { CapabilityType } from '../authorization/domain/capability-type';
import { IdentityService } from '../identity/application/identity.service';
import { KhatmWorkflowService } from '../khatm-workflow/application/khatm-workflow.service';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { Principal } from './auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../session/domain/authenticated-principal';
import { toKhatmSummary } from './khatm-view.mapper';
import { asObject, optionalString } from './dto/validate';

/**
 * HTTP transport for the authenticated principal's own view of itself (Phase 8).
 * Thin: it reports the user id and current authorization state so the UI can render
 * itself. The UI treats this as a HINT only — every action is re-authorized by the
 * backend (DEC-0061). Requires a valid session.
 *
 * Phase 14 adds become-creator (DEC-0072) and profile update (DEC-0073).
 */
@Controller('api/me')
export class MeController {
  constructor(
    private readonly authorization: AuthorizationService,
    private readonly identity: IdentityService,
    private readonly workflow: KhatmWorkflowService,
  ) {}

  /**
   * Returns the authenticated caller's profile. Per DEC-0074, every authenticated
   * user is auto-granted the CREATOR capability on first touch so every user can
   * create khatms in the MVP without an explicit call to /become-creator.
   */
  @SkipThrottle()
  @Get()
  @UseGuards(SessionAuthGuard)
  async me(@Principal() principal: AuthenticatedPrincipal): Promise<MeResponse> {
    const [hasCreator, user] = await Promise.all([
      this.authorization.hasCapability(principal.userId, CapabilityType.CREATOR),
      this.identity.findUserById(principal.userId),
    ]);
    if (!hasCreator) {
      await this.authorization.grantCapability(principal.userId, CapabilityType.CREATOR);
    }
    return { userId: principal.userId, isCreator: true, displayName: user?.displayName ?? null, role: (user?.role ?? 'USER') as 'USER' | 'SUPER_ADMIN' };
  }

  /**
   * Idempotently grant the CREATOR capability to the authenticated user (DEC-0070).
   * In the MVP every authenticated user may become a creator — no approval flow.
   */
  @Post('become-creator')
  @HttpCode(200)
  @UseGuards(SessionAuthGuard)
  async becomeCreator(
    @Principal() principal: AuthenticatedPrincipal,
  ): Promise<BecomeCreatorResponse> {
    await this.authorization.grantCapability(principal.userId, CapabilityType.CREATOR);
    return { isCreator: true };
  }

  /** Set or clear the authenticated user's display name (DEC-0073). */
  @Put('profile')
  @UseGuards(SessionAuthGuard)
  async updateProfile(
    @Principal() principal: AuthenticatedPrincipal,
    @Body() body: unknown,
  ): Promise<ProfileResponse> {
    const obj = asObject(body);
    const displayName = optionalString(obj, 'displayName');
    const user = await this.identity.setDisplayName(principal.userId, displayName);
    return { displayName: user.displayName };
  }

  /** The khatms the authenticated user participates in (participant dashboard). */
  @SkipThrottle()
  @Get('khatms')
  @UseGuards(SessionAuthGuard)
  async myKhatms(@Principal() principal: AuthenticatedPrincipal): Promise<KhatmListResponse> {
    const khatms = await this.workflow.listMyKhatms(principal.userId);
    return { khatms: khatms.map(toKhatmSummary) };
  }
}
