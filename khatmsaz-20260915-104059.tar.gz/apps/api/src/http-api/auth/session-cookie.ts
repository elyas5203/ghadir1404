/**
 * Session cookie helpers (DEC-0067). The opaque session token rides an httpOnly,
 * `SameSite=Lax` cookie so it never reaches frontend JavaScript; `Secure` is set in
 * production. Dependency-free: reading parses the raw `Cookie` header, writing uses
 * Express's `res.cookie`/`res.clearCookie`. The server still accepts the token via
 * the `Authorization: Bearer` header too (see the guard), so non-browser clients are
 * unaffected.
 */

import type { CookieOptions, Response } from 'express';
import { isProduction } from '@khatmsaz/config';

export const SESSION_COOKIE_NAME = 'khatmsaz_session';

function baseOptions(): CookieOptions {
  return {
    httpOnly: true,
    secure: isProduction(),
    sameSite: 'lax',
    path: '/',
  };
}

/** Set the session cookie carrying the raw token, expiring with the session. */
export function setSessionCookie(res: Response, token: string, expiresAt: Date): void {
  res.cookie(SESSION_COOKIE_NAME, token, { ...baseOptions(), expires: expiresAt });
}

/** Clear the session cookie (logout). */
export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE_NAME, baseOptions());
}

/** Read the session token from a raw `Cookie` header, or `null` when absent. */
export function readSessionCookie(cookieHeader: string | undefined): string | null {
  if (typeof cookieHeader !== 'string') return null;
  for (const part of cookieHeader.split(';')) {
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    if (part.slice(0, eq).trim() === SESSION_COOKIE_NAME) {
      const value = part.slice(eq + 1).trim();
      return value.length > 0 ? decodeURIComponent(value) : null;
    }
  }
  return null;
}
