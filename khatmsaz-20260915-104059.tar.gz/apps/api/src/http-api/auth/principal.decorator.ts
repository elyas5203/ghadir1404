import { createParamDecorator, ExecutionContext, InternalServerErrorException } from '@nestjs/common';
import type { AuthenticatedPrincipal } from '../../session/domain/authenticated-principal';
import { PRINCIPAL_KEY } from './session-auth.guard';
import type { RequestWithPrincipal } from './session-auth.guard';

/**
 * Injects the {@link AuthenticatedPrincipal} the {@link SessionAuthGuard} attached.
 * Using it on a route that is not guarded is a programming error (the principal is
 * absent) and fails loudly with a 500 rather than silently proceeding unauthenticated.
 */
export const Principal = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): AuthenticatedPrincipal => {
    const req = ctx.switchToHttp().getRequest<RequestWithPrincipal>();
    const principal = req[PRINCIPAL_KEY];
    if (!principal) {
      throw new InternalServerErrorException('Principal is missing; route must be guarded.');
    }
    return principal;
  },
);
