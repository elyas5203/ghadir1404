import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import type { Request } from 'express';
import { AuthenticationService } from '../../session/application/authentication.service';
import { SessionAuthenticationError } from '../../session/domain/session.errors';
import type { AuthenticatedPrincipal } from '../../session/domain/authenticated-principal';
import { readSessionCookie } from './session-cookie';

/** The request property the resolved principal is attached to. */
export const PRINCIPAL_KEY = 'principal';

export interface RequestWithPrincipal extends Request {
  [PRINCIPAL_KEY]?: AuthenticatedPrincipal;
}

/**
 * Authenticates an HTTP request from an `Authorization: Bearer <token>` header
 * (DEC-0060). It calls the {@link AuthenticationService}, and on success attaches
 * the {@link AuthenticatedPrincipal} to the request for `@Principal()` to read.
 * Any authentication failure becomes a 401 with no detail about why (no token,
 * hash, or "exists" signal leaks). This is transport plumbing — it holds no
 * business logic; all validation lives in the session capability.
 */
@Injectable()
export class SessionAuthGuard implements CanActivate {
  constructor(private readonly auth: AuthenticationService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<RequestWithPrincipal>();
    // Prefer the httpOnly session cookie (browsers, DEC-0067); fall back to the
    // Authorization: Bearer header (non-browser clients).
    const token = readSessionCookie(req.headers.cookie) ?? bearerToken(req.headers.authorization);
    if (!token) throw new UnauthorizedException('Authentication required.');

    try {
      req[PRINCIPAL_KEY] = await this.auth.authenticate(token);
      return true;
    } catch (error) {
      if (error instanceof SessionAuthenticationError) {
        throw new UnauthorizedException('Authentication failed.');
      }
      throw error;
    }
  }
}

function bearerToken(header: string | undefined): string | null {
  if (typeof header !== 'string') return null;
  const [scheme, value] = header.split(/\s+/, 2);
  if (!scheme || scheme.toLowerCase() !== 'bearer' || !value) return null;
  return value.trim() || null;
}
