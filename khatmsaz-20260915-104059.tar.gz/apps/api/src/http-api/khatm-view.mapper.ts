/**
 * Translate domain read models into transport DTOs. This lives in the transport
 * layer precisely so that a domain entity never crosses the API boundary as-is: the
 * controller returns a {@link KhatmSummary} contract, not a {@link Khatm} (DEC-0057).
 * Domain enum values already match the wire unions, so mapping is a field copy plus
 * ISO-string timestamps.
 */

import type {
  ContributionSummary,
  KhatmSummary,
  ParticipationSummary,
  PortionSummary,
} from '@khatmsaz/contracts';
import { findQuranEdition, findSurah } from '@khatmsaz/shared';
import type { OpenContribution } from '../khatm/domain/open-contribution';
import type { Khatm } from '../khatm/domain/khatm';
import { KhatmTemplateType } from '../khatm/domain/khatm-template';
import type { Participation } from '../khatm/domain/participation';
import type { PlanPortion } from '../allocation/domain/plan-portion';

export function toKhatmSummary(khatm: Khatm): KhatmSummary {
  let quranPageConfig: KhatmSummary['quranPageConfig'] = null;
  let quranSurahConfig: KhatmSummary['quranSurahConfig'] = null;

  if (khatm.templateType === KhatmTemplateType.QURAN_PAGE && khatm.quranEditionId) {
    const edition = findQuranEdition(khatm.quranEditionId);
    if (edition) {
      quranPageConfig = {
        quranEditionId: edition.id,
        editionNameFa: edition.nameFa,
        totalPages: edition.totalPages,
      };
    }
  }

  if (
    khatm.templateType === KhatmTemplateType.QURAN_SURAH &&
    khatm.surahNumber !== null &&
    khatm.repetitionTarget !== null
  ) {
    const surah = findSurah(khatm.surahNumber);
    if (surah) {
      quranSurahConfig = {
        surahNumber: surah.number,
        surahNameFa: surah.nameFa,
        repetitionTarget: khatm.repetitionTarget,
      };
    }
  }

  return {
    id: khatm.id,
    creatorUserId: khatm.creatorUserId,
    title: khatm.title,
    description: khatm.description,
    templateType: khatm.templateType,
    khatmType: khatm.khatmType,
    status: khatm.status,
    quranPageConfig,
    quranSurahConfig,
    repetitionTarget: khatm.repetitionTarget,
    createdAt: khatm.createdAt.toISOString(),
    updatedAt: khatm.updatedAt.toISOString(),
  };
}

export function toContributionSummary(c: OpenContribution): ContributionSummary {
  return {
    id: c.id,
    participationId: c.participationId,
    amount: c.amount,
    note: c.note,
    recordedAt: c.recordedAt.toISOString(),
  };
}

export function toParticipationSummary(
  p: Participation,
  displayName: string | null = null,
): ParticipationSummary {
  return {
    participationId: p.id,
    userId: p.userId,
    status: p.status,
    joinedAt: p.joinedAt.toISOString(),
    displayName,
  };
}

export function toPortionSummary(p: PlanPortion): PortionSummary {
  return {
    portionId: p.id,
    sequence: p.sequence,
    unitKind: p.spec.kind,
    unitStart: p.spec.unitStart,
    unitEnd: p.spec.unitEnd,
    quantity: p.spec.quantity,
    status: p.status,
  };
}
