import { Body, Controller, HttpCode, Post, Res, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import type { Response } from 'express';
import type {
  PhoneLoginRequest,
  PhoneLoginResponse,
  PhoneSessionResponse,
  RequestOtpResponse,
} from '@khatmsaz/contracts';
import { PhoneOtpLoginService } from '../session/application/phone-otp-login.service';
import { PhoneAuthService } from '../session/application/phone-auth.service';
import { AuthenticationService } from '../session/application/authentication.service';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { Principal } from './auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../session/domain/authenticated-principal';
import { clearSessionCookie, setSessionCookie } from './auth/session-cookie';
import { asObject, requireString } from './dto/validate';

/**
 * HTTP transport for authentication (Phase 6 DEC-0060; Phase 10 DEC-0066/0067).
 * Thin: it validates the request, calls the session/auth application services, and
 * shapes the response. The phone-first flow (`/phone/request` → `/phone/verify`)
 * needs no user id and delivers the session as an httpOnly cookie — the raw token
 * never appears in a response body. No business logic here.
 */
@Controller('api/auth')
export class AuthController {
  constructor(
    private readonly phoneAuth: PhoneAuthService,
    private readonly login: PhoneOtpLoginService,
    private readonly auth: AuthenticationService,
  ) {}

  /** Phone-first login step 1: issue a login code for a phone number. */
  @Throttle({ otp: { ttl: 300_000, limit: 3 } })
  @Post('phone/request')
  async phoneRequest(@Body() body: unknown): Promise<RequestOtpResponse> {
    const obj = asObject(body);
    return this.phoneAuth.requestLogin(requireString(obj, 'phone'));
  }

  /**
   * Phone-first login step 2: verify the code, resolve/create the user, mint a
   * session, and set it as an httpOnly cookie (DEC-0067). The token is NOT returned
   * in the body.
   */
  @Throttle({ otp: { ttl: 300_000, limit: 3 } })
  @Post('phone/verify')
  async phoneVerify(
    @Body() body: unknown,
    @Res({ passthrough: true }) res: Response,
  ): Promise<PhoneSessionResponse> {
    const obj = asObject(body);
    const result = await this.phoneAuth.completeLogin(
      requireString(obj, 'phone'),
      requireString(obj, 'code'),
    );
    setSessionCookie(res, result.token, result.expiresAt);
    return {
      userId: result.userId,
      sessionId: result.sessionId,
      expiresAt: result.expiresAt.toISOString(),
      isNewUser: result.isNewUser,
    };
  }

  /** Revoke the current session (logout) and clear the session cookie. */
  @Post('logout')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async logout(
    @Principal() principal: AuthenticatedPrincipal,
    @Res({ passthrough: true }) res: Response,
  ): Promise<void> {
    if (principal.sessionId) {
      await this.auth.revokeSession(principal.sessionId);
    }
    clearSessionCookie(res);
  }

  // ── Legacy user-scoped login (DEC-0060), superseded by the phone-first flow
  // above (DEC-0066). Retained until no client uses it; returns the raw token in the
  // body (bearer clients / tests). ─────────────────────────────────────────────

  /** Legacy: request an OTP for an explicit user's phone. */
  @Post('request-otp')
  async requestOtp(@Body() body: unknown): Promise<RequestOtpResponse> {
    const obj = asObject(body);
    return this.login.requestOtp(requireString(obj, 'userId'), requireString(obj, 'phone'));
  }

  /** Legacy: verify an explicit user's phone and mint a session (token in body). */
  @Post('login')
  async phoneLogin(@Body() body: unknown): Promise<PhoneLoginResponse> {
    const req = parsePhoneLogin(body);
    const result = await this.login.loginByPhoneOtp(req.userId, req.phone, req.code);
    if (result.outcome === 'MERGE_REQUIRED') {
      return { outcome: 'MERGE_REQUIRED' };
    }
    return {
      outcome: result.outcome,
      token: result.token,
      sessionId: result.session.id,
      expiresAt: result.session.expiresAt.toISOString(),
    };
  }
}

function parsePhoneLogin(body: unknown): PhoneLoginRequest {
  const obj = asObject(body);
  return {
    userId: requireString(obj, 'userId'),
    phone: requireString(obj, 'phone'),
    code: requireString(obj, 'code'),
  };
}
