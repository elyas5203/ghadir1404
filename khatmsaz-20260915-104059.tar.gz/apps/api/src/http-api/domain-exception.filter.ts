import {
  ArgumentsHost,
  Catch,
  HttpException,
  HttpStatus,
  Logger,
  type ExceptionFilter,
} from '@nestjs/common';
import type { Response } from 'express';
import type { TransportErrorResponse } from '@khatmsaz/contracts';
import { InvalidUuidV7Error } from '@khatmsaz/kernel';
import { KhatmError } from '../khatm/domain/khatm.errors';
import { AllocationError } from '../allocation/domain/allocation.errors';
import { IdentityError } from '../identity/domain/identity.errors';
import { AuthorizationError } from '../authorization/domain/authorization.errors';
import { InvitationError } from '../invitation/domain/invitation.errors';
import { PhoneError } from '../phone/domain/phone.errors';
import { KhatmWorkflowError } from '../khatm-workflow/application/khatm-workflow.errors';

/**
 * Translate errors into a stable HTTP envelope ({@link TransportErrorResponse}) —
 * a transport concern, so domain/application errors never reach the client as an
 * opaque 500 nor leak a stack trace. Capability domain errors are mapped to a
 * status by their kind; `HttpException`s (e.g. a DTO `BadRequestException`) keep
 * their status; anything unexpected becomes a generic 500 with no detail. Domain
 * error messages are safe by construction (they never contain secrets or PII).
 */
@Catch()
export class DomainExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('HttpApi');

  catch(exception: unknown, host: ArgumentsHost): void {
    const res = host.switchToHttp().getResponse<Response>();

    if (exception instanceof HttpException) {
      this.send(res, exception.getStatus(), codeFromStatus(exception.getStatus()), httpMessage(exception));
      return;
    }

    if (isDomainError(exception)) {
      this.send(res, statusForDomainError(exception.name), exception.name, exception.message);
      return;
    }

    // Unknown/unexpected — log server-side, reveal nothing.
    this.logger.error(exception instanceof Error ? exception.stack ?? exception.message : String(exception));
    this.send(res, HttpStatus.INTERNAL_SERVER_ERROR, 'INTERNAL_ERROR', 'Internal server error.');
  }

  private send(res: Response, status: number, code: string, message: string): void {
    const body: TransportErrorResponse = { error: { code, message } };
    res.status(status).json(body);
  }
}

function isDomainError(e: unknown): e is Error {
  return (
    e instanceof KhatmError ||
    e instanceof AllocationError ||
    e instanceof KhatmWorkflowError ||
    e instanceof IdentityError ||
    e instanceof AuthorizationError ||
    e instanceof InvitationError ||
    e instanceof PhoneError ||
    e instanceof InvalidUuidV7Error
  );
}

/** Map a capability domain error (by class name) to an HTTP status. */
function statusForDomainError(name: string): number {
  if (name === 'OtpResendTooSoonError' || name === 'OtpAttemptsExhaustedError') {
    return HttpStatus.TOO_MANY_REQUESTS;
  }
  if (name === 'NoActiveOtpChallengeError' || name === 'OtpExpiredError') {
    return HttpStatus.BAD_REQUEST;
  }
  // Authorization denials (holder / capability / ownership) — a 403, distinct from
  // the session guard's 401 (authentication).
  if (
    name === 'PortionNotHeldByParticipationError' ||
    name === 'CapabilityRequiredError' ||
    name === 'ResourceOwnershipError'
  ) {
    return HttpStatus.FORBIDDEN;
  }
  if (name.includes('NotFound')) return HttpStatus.NOT_FOUND;
  if (name.includes('AlreadyExists') || name.includes('Duplicate')) return HttpStatus.CONFLICT;
  if (name.startsWith('Invalid') || name.startsWith('Unknown')) return HttpStatus.BAD_REQUEST;
  // Preconditions / state conflicts (not active, not configured, inactive user, …).
  return HttpStatus.CONFLICT;
}

function codeFromStatus(status: number): string {
  return status === HttpStatus.BAD_REQUEST ? 'BAD_REQUEST' : `HTTP_${status}`;
}

function httpMessage(exception: HttpException): string {
  const response = exception.getResponse();
  if (typeof response === 'string') return response;
  if (typeof response === 'object' && response !== null) {
    const message = (response as { message?: unknown }).message;
    if (typeof message === 'string') return message;
    if (Array.isArray(message)) return message.join('; ');
  }
  return exception.message;
}
