import type { InvitationSummary } from '@khatmsaz/contracts';
import type { Invitation } from '../invitation/domain/invitation';

/** Map an invitation to its owner-facing summary, deriving the status at `now`. */
export function toInvitationSummary(inv: Invitation, now: Date = new Date()): InvitationSummary {
  return {
    invitationId: inv.id,
    khatmId: inv.khatmId,
    status: inv.statusAt(now),
    createdAt: inv.createdAt.toISOString(),
    expiresAt: inv.expiresAt.toISOString(),
    acceptedAt: inv.acceptedAt ? inv.acceptedAt.toISOString() : null,
  };
}
