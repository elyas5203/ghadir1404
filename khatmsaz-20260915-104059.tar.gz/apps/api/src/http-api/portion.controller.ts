import { Body, Controller, HttpCode, Param, Post, UseGuards } from '@nestjs/common';
import { KhatmWorkflowService } from '../khatm-workflow/application/khatm-workflow.service';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { parseCompletePortion } from './dto/khatm-requests';

/**
 * HTTP transport for portion completion. Requires a valid session (DEC-0060). The
 * assigned holder completes their own portion; the holder check and the guarded
 * transition live in the allocation capability (the controller only translates the
 * request). Binding the `participationId` to the authenticated principal is
 * per-resource authorization — Creator-permissions work, deferred (see DEC-0060).
 */
@Controller('api/portions')
export class PortionController {
  constructor(private readonly workflow: KhatmWorkflowService) {}

  /** The holder completes an assigned portion. */
  @Post(':portionId/complete')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async complete(@Param('portionId') portionId: string, @Body() body: unknown): Promise<void> {
    const { participationId } = parseCompletePortion(body);
    await this.workflow.completePortion(portionId, participationId);
  }
}
