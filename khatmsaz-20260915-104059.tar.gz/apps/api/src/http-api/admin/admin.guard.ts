import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { IdentityService } from '../../identity/application/identity.service';
import { PRINCIPAL_KEY } from '../auth/session-auth.guard';
import type { RequestWithPrincipal } from '../auth/session-auth.guard';

/**
 * Requires the authenticated user to hold the SUPER_ADMIN role.
 * Must be applied AFTER SessionAuthGuard so the principal is already resolved.
 */
@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private readonly identity: IdentityService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<RequestWithPrincipal>();
    const principal = req[PRINCIPAL_KEY];
    if (!principal) throw new ForbiddenException();
    const user = await this.identity.findUserById(principal.userId);
    if (!user || user.role !== 'SUPER_ADMIN') throw new ForbiddenException();
    return true;
  }
}
