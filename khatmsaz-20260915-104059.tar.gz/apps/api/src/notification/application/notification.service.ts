import { Inject, Injectable, Logger } from '@nestjs/common';
import { NOTIFICATION_SCHEDULER, type NotificationScheduler } from '../domain/notification-scheduler';

/**
 * Application-layer facade for notification scheduling (Sprint Phase 01).
 * Orchestration only — all queue logic is in the infrastructure scheduler.
 */
@Injectable()
export class NotificationService {
  private readonly logger = new Logger('NotificationService');

  constructor(
    @Inject(NOTIFICATION_SCHEDULER) private readonly scheduler: NotificationScheduler,
  ) {}

  async onKhatmActivated(khatmId: string): Promise<void> {
    try {
      await this.scheduler.scheduleKhatmNotifications(khatmId);
    } catch (err) {
      this.logger.warn(`Failed to schedule notifications for khatm ${khatmId}: ${String(err)}`);
    }
  }

  async onKhatmClosed(khatmId: string): Promise<void> {
    try {
      await this.scheduler.cancelKhatmNotifications(khatmId);
    } catch (err) {
      this.logger.warn(`Failed to cancel notifications for khatm ${khatmId}: ${String(err)}`);
    }
  }
}
