import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Worker, type Job } from 'bullmq';
import { newUuidV7 } from '@khatmsaz/kernel';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import { NOTIFICATION_QUEUE_NAME, type NotificationJobData } from './bullmq-notification-scheduler';

/**
 * BullMQ worker that processes notification jobs (Sprint notification phase).
 *
 * Seed job → expand to per-participation daily reminders.
 * Per-participation reminder:
 *   1. Skip if participation/user is no longer active.
 *   2. Skip if DAILY_REMINDER already sent today (idempotency via NotificationLog).
 *   3. Send via Telegram or Bale Bot API (direct fetch, no SDK).
 *   4. Record in NotificationLog on success.
 *
 * SECURITY: Bot tokens are read from config at startup and NEVER logged.
 */
@Injectable()
export class NotificationProcessorService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('NotificationProcessor');
  private worker: Worker | null = null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly redisUrl: string,
    private readonly telegramToken: string,
    private readonly telegramApiBase: string,
    private readonly baleToken: string,
    private readonly baleApiBase: string,
  ) {}

  onModuleInit(): void {
    const url = new URL(this.redisUrl);
    this.worker = new Worker<NotificationJobData>(
      NOTIFICATION_QUEUE_NAME,
      async (job) => {
        if (job.name === 'seed') {
          await this.processSeedJob(job.data.khatmId);
        } else if (job.name === 'snooze') {
          await this.processSnoozeJob(job.data);
        }
      },
      {
        connection: {
          host: url.hostname,
          port: Number(url.port) || 6379,
          password: url.password || undefined,
        },
      },
    );

    this.worker.on('failed', (job: Job | undefined, err: Error) => {
      this.logger.warn(`Notification job ${String(job?.id)} failed after retries: ${err.message}`);
    });

    this.logger.log('Notification processor started.');
  }

  async onModuleDestroy(): Promise<void> {
    await this.worker?.close();
  }

  /** Deliver a snoozed reminder directly to one platform identity. */
  private async processSnoozeJob(data: NotificationJobData): Promise<void> {
    if (!data.platform || !data.chatId) return;

    const participation = await this.prisma.participation.findUnique({
      where: { id: data.participationId },
      select: { khatmId: true },
    });
    if (!participation) return;

    const khatm = await this.prisma.khatm.findUnique({
      where: { id: participation.khatmId },
      select: { id: true, title: true, status: true },
    });
    if (!khatm || khatm.status !== 'ACTIVE') return;

    const pendingCount = await this.prisma.khatmPortion.count({
      where: { participationId: data.participationId, status: { in: ['OPEN', 'ASSIGNED'] } },
    });
    await this.dispatchMessage(data.platform, data.chatId, khatm.id, data.participationId, khatm.title, pendingCount);
  }

  /** Expand the khatm seed job into per-participation reminder sends. */
  private async processSeedJob(khatmId: string): Promise<void> {
    const khatm = await this.prisma.khatm.findUnique({
      where: { id: khatmId },
      select: { id: true, status: true, title: true },
    });
    if (!khatm || khatm.status !== 'ACTIVE') {
      this.logger.log(`Skipping seed for khatm ${khatmId}: not active.`);
      return;
    }

    const participations = await this.prisma.participation.findMany({
      where: { khatmId, status: 'ACTIVE' },
      select: { id: true, userId: true },
    });

    this.logger.log(`Sending reminders for khatm ${khatmId}: ${participations.length} participants.`);

    await Promise.allSettled(
      participations.map((p) => this.sendReminderForParticipation(khatm.id, khatm.title, p.id, p.userId)),
    );
  }

  private async sendReminderForParticipation(
    khatmId: string,
    khatmTitle: string,
    participationId: string,
    userId: string,
  ): Promise<void> {
    // Skip banned / suspended users
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { status: true },
    });
    if (!user || user.status === 'BANNED' || user.status === 'SUSPENDED') return;

    // Idempotency: skip if already sent today
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const alreadySent = await this.prisma.notificationLog.findFirst({
      where: { participationId, sentAt: { gte: todayStart } },
    });
    if (alreadySent) return;

    // Count unfinished portions to include in the message
    const pendingCount = await this.prisma.khatmPortion.count({
      where: { participationId, status: { in: ['OPEN', 'ASSIGNED'] } },
    });

    // Try each platform identity in turn; stop after first success
    const identities = await this.prisma.platformIdentity.findMany({
      where: { userId },
      select: { platform: true, subject: true },
    });

    for (const identity of identities) {
      const sent = await this.dispatchMessage(
        identity.platform,
        identity.subject,
        khatmId,
        participationId,
        khatmTitle,
        pendingCount,
      );
      if (sent) {
        await this.prisma.notificationLog.create({
          data: { id: newUuidV7(), participationId, kind: 'DAILY_REMINDER' },
        });
        return;
      }
    }
  }

  /**
   * Send a single Telegram/Bale message with MARK_DONE + SNOOZE inline keyboard.
   * Returns true if the HTTP call succeeded; false otherwise (caller retries via next platform).
   * SECURITY: token appears only in the URL path, never in logs.
   */
  private async dispatchMessage(
    platform: string,
    chatId: string,
    khatmId: string,
    participationId: string,
    khatmTitle: string,
    pendingCount: number,
  ): Promise<boolean> {
    let token: string;
    let apiBase: string;

    if (platform === 'TELEGRAM') {
      token = this.telegramToken;
      apiBase = this.telegramApiBase;
    } else if (platform === 'BALE') {
      token = this.baleToken;
      apiBase = this.baleApiBase;
    } else {
      return false;
    }

    if (!token) return false;

    const text =
      pendingCount > 0
        ? `یادآوری ختم «${khatmTitle}»\n${pendingCount} بخش منتظر شماست.`
        : `یادآوری ختم «${khatmTitle}»\nمشارکت در این ختم همچنان ادامه دارد.`;

    const inlineKeyboard = {
      inline_keyboard: [
        [
          { text: '✅ ثبت تلاوت', callback_data: `DONE:${khatmId}` },
          { text: '🔔 بعداً یادآوری', callback_data: `SNOOZE:${participationId}` },
        ],
      ],
    };

    try {
      const res = await fetch(`${apiBase}/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text, reply_markup: inlineKeyboard }),
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) {
        this.logger.warn(`Bot API ${platform} returned ${res.status} for chat ${chatId}.`);
      }
      return res.ok;
    } catch {
      return false;
    }
  }
}
