import { Injectable, Logger } from '@nestjs/common';
import type { NotificationScheduler } from '../domain/notification-scheduler';

/** No-op scheduler used when Redis is not configured. */
@Injectable()
export class NoopNotificationScheduler implements NotificationScheduler {
  private readonly logger = new Logger('NotificationScheduler');

  async scheduleKhatmNotifications(khatmId: string): Promise<void> {
    this.logger.debug(`[noop] scheduleKhatmNotifications(${khatmId}) — Redis not configured.`);
  }

  async cancelKhatmNotifications(khatmId: string): Promise<void> {
    this.logger.debug(`[noop] cancelKhatmNotifications(${khatmId}) — Redis not configured.`);
  }

  async snoozeNotification(participationId: string): Promise<void> {
    this.logger.debug(`[noop] snoozeNotification(${participationId}) — Redis not configured.`);
  }
}
