/** Port: schedules daily reminders for all active participations in a khatm. */
export interface NotificationScheduler {
  scheduleKhatmNotifications(khatmId: string): Promise<void>;
  cancelKhatmNotifications(khatmId: string): Promise<void>;
  /**
   * Schedule a delayed one-shot reminder for one participation.
   * Used by the SNOOZE bot callback: schedules a reminder `delayMs` from now.
   */
  snoozeNotification(
    participationId: string,
    platform: string,
    chatId: string,
    delayMs: number,
  ): Promise<void>;
}

export const NOTIFICATION_SCHEDULER = Symbol('NotificationScheduler');
