export class NotificationSchedulingError extends Error {
  constructor(cause: string) {
    super(`Notification scheduling failed: ${cause}`);
    this.name = 'NotificationSchedulingError';
  }
}
