import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';

export interface AuditEntry {
  actorId?: string;
  actorType?: string;
  action: string;
  targetType?: string;
  targetId?: string;
  meta?: Record<string, unknown>;
}

/**
 * Audit log service — append-only writer for admin and system actions.
 * Logs are stored in the `audit_logs` table (migration 20260913220000).
 * Failures are swallowed and logged to avoid breaking the primary flow.
 */
@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaService) {}

  async log(entry: AuditEntry): Promise<void> {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (this.prisma as any).$queryRawUnsafe(
        `INSERT INTO audit_logs (actor_id, actor_type, action, target_type, target_id, meta)
         VALUES ($1::uuid, $2, $3, $4, $5, $6::jsonb)`,
        entry.actorId ?? null,
        entry.actorType ?? 'ADMIN',
        entry.action,
        entry.targetType ?? null,
        entry.targetId ?? null,
        entry.meta ? JSON.stringify(entry.meta) : null,
      );
    } catch (err) {
      this.logger.error(`Audit log write failed: ${String(err)}`);
    }
  }

  async list(limit = 50, offset = 0): Promise<unknown[]> {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return await (this.prisma as any).$queryRawUnsafe(
        `SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
        limit,
        offset,
      );
    } catch {
      return [];
    }
  }
}
