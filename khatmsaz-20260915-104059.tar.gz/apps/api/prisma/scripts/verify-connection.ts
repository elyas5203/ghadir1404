/**
 * Database connectivity verification (`db:verify`).
 *
 * Proves a real round-trip to PostgreSQL with `SELECT 1`, using the same driver
 * adapter the application uses. It is a local/CI convenience for confirming the
 * database is reachable and correctly configured. It NEVER prints the
 * connection string, credentials, or the underlying error object.
 *
 * Exit code 0 = reachable; 1 = not reachable / misconfigured.
 */

import { resolve } from 'node:path';
import { config as loadEnv } from 'dotenv';
import { PrismaPg } from '@prisma/adapter-pg';
import { databaseUrl } from '@khatmsaz/config';
import { PrismaClient } from '../../src/infrastructure/database/prisma/generated/client';

// Load the repo-root .env for local development (no-op if absent).
loadEnv({ path: resolve(process.cwd(), '../../.env') });
loadEnv({ path: resolve(process.cwd(), '.env') });

async function main(): Promise<void> {
  const client = new PrismaClient({
    adapter: new PrismaPg({ connectionString: databaseUrl() }),
  });
  try {
    const rows = await client.$queryRaw<Array<{ ok: number }>>`SELECT 1 AS ok`;
    if (!Array.isArray(rows) || rows.length !== 1) {
      throw new Error('Unexpected result from readiness query.');
    }
    console.log('Database verify: OK (SELECT 1 succeeded).');
  } finally {
    await client.$disconnect();
  }
}

main().catch(() => {
  // Deliberately do not print the error: it can contain the connection string.
  console.error('Database verify: FAILED (database unreachable or misconfigured).');
  process.exitCode = 1;
});
