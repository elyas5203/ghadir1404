-- Phase 06 — Add user role for super-admin access control.
CREATE TYPE "user_role" AS ENUM ('USER', 'SUPER_ADMIN');
ALTER TABLE "users" ADD COLUMN "role" "user_role" NOT NULL DEFAULT 'USER';
