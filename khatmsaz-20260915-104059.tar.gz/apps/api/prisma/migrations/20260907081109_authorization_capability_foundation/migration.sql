-- CreateEnum
CREATE TYPE "capability_type" AS ENUM ('CREATOR');

-- CreateTable
CREATE TABLE "user_capabilities" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "type" "capability_type" NOT NULL,
    "granted_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "revoked_at" TIMESTAMPTZ(6),

    CONSTRAINT "user_capabilities_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "user_capabilities_user_id_idx" ON "user_capabilities"("user_id");

-- AddForeignKey
ALTER TABLE "user_capabilities" ADD CONSTRAINT "user_capabilities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- PARTIAL UNIQUE INDEX (hand-written — Prisma cannot express a filtered unique index
-- in schema.prisma; DEC-0062, KI-0012). Enforces AT MOST ONE ACTIVE (non-revoked)
-- grant per (user, capability type) in the DATABASE, so a concurrent double-grant
-- resolves to a single active row. Revoked rows (revoked_at IS NOT NULL) accumulate
-- as history and are exempt.
CREATE UNIQUE INDEX "user_capabilities_active_user_type_key" ON "user_capabilities" ("user_id", "type") WHERE "revoked_at" IS NULL;
