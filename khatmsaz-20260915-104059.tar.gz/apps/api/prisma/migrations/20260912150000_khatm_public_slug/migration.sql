-- Sprint Phase 05: public_slug and niyyat on khatms
-- Additive: two nullable columns added; no constraint changes on existing columns.

ALTER TABLE "khatms"
  ADD COLUMN "public_slug" VARCHAR(100),
  ADD COLUMN "niyyat"      VARCHAR(500);

CREATE UNIQUE INDEX ON "khatms" ("public_slug") WHERE "public_slug" IS NOT NULL;
