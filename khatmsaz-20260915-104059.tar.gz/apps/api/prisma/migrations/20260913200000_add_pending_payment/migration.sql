-- Sprint 3: PendingPayment — server-side payment intent for IDOR/replay protection (DEC-0083).
-- Stores authority→(userId, amountToman) before the ZarinPal redirect so verify
-- cannot be replayed and cannot credit a different user's wallet.

CREATE TABLE "pending_payments" (
    "id"          UUID        NOT NULL,
    "user_id"     UUID        NOT NULL,
    "authority"   TEXT        NOT NULL,
    "amount_toman" INTEGER    NOT NULL,
    "description" TEXT        NOT NULL,
    "used"        BOOLEAN     NOT NULL DEFAULT false,
    "expires_at"  TIMESTAMPTZ(6) NOT NULL,
    "created_at"  TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

    CONSTRAINT "pending_payments_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "pending_payments_authority_key" UNIQUE ("authority"),
    CONSTRAINT "pending_payments_user_id_fkey"
        FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE INDEX "pending_payments_authority_idx" ON "pending_payments"("authority");
