-- AlterEnum
ALTER TYPE "otp_purpose" ADD VALUE 'PHONE_LOGIN';
