-- Admin moderation: extend user_status enum with moderation values.
-- Additive only — existing ACTIVE and MERGED rows are unchanged.

ALTER TYPE "user_status" ADD VALUE IF NOT EXISTS 'WARNED';
ALTER TYPE "user_status" ADD VALUE IF NOT EXISTS 'SUSPENDED';
ALTER TYPE "user_status" ADD VALUE IF NOT EXISTS 'BANNED';

-- Audit log: immutable record of admin and system actions.
-- admin_id NULL means a system/automated action.
-- No UPDATE, no DELETE — append only.

CREATE TABLE "audit_logs" (
    "id"          UUID        NOT NULL DEFAULT gen_random_uuid(),
    "actor_id"    UUID,
    "actor_type"  TEXT        NOT NULL DEFAULT 'ADMIN',
    "action"      TEXT        NOT NULL,
    "target_type" TEXT,
    "target_id"   TEXT,
    "meta"        JSONB,
    "created_at"  TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "audit_logs_actor_id_fkey"
        FOREIGN KEY ("actor_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE INDEX "audit_logs_actor_id_idx"   ON "audit_logs"("actor_id");
CREATE INDEX "audit_logs_target_idx"     ON "audit_logs"("target_type", "target_id");
CREATE INDEX "audit_logs_created_at_idx" ON "audit_logs"("created_at" DESC);
