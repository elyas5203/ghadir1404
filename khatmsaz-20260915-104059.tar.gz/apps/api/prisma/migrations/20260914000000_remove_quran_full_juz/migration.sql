-- Migration: Remove deprecated QURAN_FULL and QURAN_JUZ template types.
-- These types were removed from the domain per user requirement (Sprint 7).
-- Any existing rows using these values are converted to CUSTOM before altering
-- the enum, so no data is silently discarded.

-- Step 1: Reassign any rows that still carry the deprecated values.
UPDATE khatms
SET template_type = 'CUSTOM'
WHERE template_type IN ('QURAN_FULL', 'QURAN_JUZ');

-- Step 2: PostgreSQL cannot drop enum values in-place; the standard workaround
-- is to create a new enum type, alter the column, then drop the old type.
ALTER TYPE "khatm_template_type" RENAME TO "khatm_template_type_old";

CREATE TYPE "khatm_template_type" AS ENUM (
  'SURAH',
  'QURAN_PAGE',
  'QURAN_SURAH',
  'SALAWAT',
  'DUA',
  'ZIYARAT',
  'CUSTOM'
);

ALTER TABLE khatms
  ALTER COLUMN template_type TYPE "khatm_template_type"
  USING template_type::text::"khatm_template_type";

DROP TYPE "khatm_template_type_old";
