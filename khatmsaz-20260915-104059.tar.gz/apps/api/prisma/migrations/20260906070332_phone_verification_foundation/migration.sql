-- CreateEnum
CREATE TYPE "phone_claim_status" AS ENUM ('UNVERIFIED', 'VERIFIED', 'REVOKED');

-- CreateEnum
CREATE TYPE "otp_purpose" AS ENUM ('PHONE_VERIFICATION');

-- CreateTable
CREATE TABLE "phone_claims" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "e164" TEXT NOT NULL,
    "region" TEXT,
    "status" "phone_claim_status" NOT NULL DEFAULT 'UNVERIFIED',
    "verified_at" TIMESTAMPTZ(6),
    "revoked_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "phone_claims_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "otp_challenges" (
    "id" UUID NOT NULL,
    "user_id" UUID,
    "e164" TEXT NOT NULL,
    "purpose" "otp_purpose" NOT NULL,
    "code_hash" TEXT NOT NULL,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "max_attempts" INTEGER NOT NULL,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "consumed_at" TIMESTAMPTZ(6),
    "superseded_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "otp_challenges_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "phone_claims_user_id_idx" ON "phone_claims"("user_id");

-- CreateIndex
CREATE INDEX "phone_claims_e164_idx" ON "phone_claims"("e164");

-- CreateIndex
CREATE INDEX "otp_challenges_user_id_e164_purpose_idx" ON "otp_challenges"("user_id", "e164", "purpose");

-- CreateIndex
CREATE INDEX "otp_challenges_e164_idx" ON "otp_challenges"("e164");

-- AddForeignKey
ALTER TABLE "phone_claims" ADD CONSTRAINT "phone_claims_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "otp_challenges" ADD CONSTRAINT "otp_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ---------------------------------------------------------------------------
-- HAND-WRITTEN PARTIAL UNIQUE INDEXES (not expressible in schema.prisma).
--
-- Prisma cannot represent a filtered/partial unique index (WHERE clause) in the
-- schema (DEC-0033). These two indexes enforce the core phone invariants in the
-- DATABASE, so concurrent verification cannot bypass them and they are not
-- merely application-level checks:
--
--   1. phone_claims_verified_e164_key — at most ONE VERIFIED claim per canonical
--      number, GLOBALLY. This is what makes a verified phone a unique proven
--      claim and what makes two users verifying the same number concurrently
--      resolve to exactly one winner (the loser gets a unique violation, which
--      the app surfaces as an ownership-conflict / merge-required outcome).
--      Unverified duplicates are intentionally NOT covered, so different users
--      may each CLAIM the same number as contact data.
--
--   2. phone_claims_active_user_e164_key — at most ONE active (non-revoked)
--      claim per (user, number). Prevents obviously invalid duplicate active
--      state for the same user while still allowing revoked history to accumulate.
--
-- Because these are not in schema.prisma, a future `prisma migrate dev` diff may
-- try to DROP them; that DROP must be removed in review (see docs/ai/DATABASE.md
-- and KNOWN_ISSUES KI-0012). `prisma migrate deploy` and `migrate status` — the
-- shared-environment path — do no drift detection and are unaffected.
-- ---------------------------------------------------------------------------

-- CreateIndex (partial unique): one VERIFIED owner per canonical number, globally.
CREATE UNIQUE INDEX "phone_claims_verified_e164_key"
    ON "phone_claims" ("e164")
    WHERE "status" = 'VERIFIED';

-- CreateIndex (partial unique): one active (non-revoked) claim per (user, number).
CREATE UNIQUE INDEX "phone_claims_active_user_e164_key"
    ON "phone_claims" ("user_id", "e164")
    WHERE "status" <> 'REVOKED';
