-- CreateEnum
CREATE TYPE "khatm_status" AS ENUM ('DRAFT', 'ACTIVE', 'COMPLETED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "khatm_template_type" AS ENUM ('QURAN_FULL', 'QURAN_JUZ', 'SURAH', 'SALAWAT', 'DUA', 'ZIYARAT', 'CUSTOM');

-- CreateEnum
CREATE TYPE "participation_status" AS ENUM ('ACTIVE', 'COMPLETED', 'LEFT', 'REMOVED');

-- CreateEnum
CREATE TYPE "assignment_unit_kind" AS ENUM ('POSITIONAL', 'QUANTITY');

-- CreateEnum
CREATE TYPE "assignment_status" AS ENUM ('PENDING', 'COMPLETED');

-- CreateTable
CREATE TABLE "khatms" (
    "id" UUID NOT NULL,
    "creator_user_id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "template_type" "khatm_template_type" NOT NULL,
    "status" "khatm_status" NOT NULL DEFAULT 'DRAFT',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "khatms_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "khatm_participations" (
    "id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "status" "participation_status" NOT NULL DEFAULT 'ACTIVE',
    "joined_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "khatm_participations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "assignments" (
    "id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "participation_id" UUID NOT NULL,
    "unit_kind" "assignment_unit_kind" NOT NULL,
    "unit_start" INTEGER,
    "unit_end" INTEGER,
    "quantity" INTEGER,
    "status" "assignment_status" NOT NULL DEFAULT 'PENDING',
    "completed_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "assignments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "khatms_creator_user_id_idx" ON "khatms"("creator_user_id");

-- CreateIndex
CREATE INDEX "khatms_status_idx" ON "khatms"("status");

-- CreateIndex
CREATE INDEX "khatm_participations_khatm_id_idx" ON "khatm_participations"("khatm_id");

-- CreateIndex
CREATE INDEX "khatm_participations_user_id_idx" ON "khatm_participations"("user_id");

-- CreateIndex
CREATE INDEX "assignments_khatm_id_idx" ON "assignments"("khatm_id");

-- CreateIndex
CREATE INDEX "assignments_participation_id_idx" ON "assignments"("participation_id");

-- CreateIndex
CREATE INDEX "assignments_status_idx" ON "assignments"("status");

-- AddForeignKey
ALTER TABLE "khatms" ADD CONSTRAINT "khatms_creator_user_id_fkey" FOREIGN KEY ("creator_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_participations" ADD CONSTRAINT "khatm_participations_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_participations" ADD CONSTRAINT "khatm_participations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assignments" ADD CONSTRAINT "assignments_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assignments" ADD CONSTRAINT "assignments_participation_id_fkey" FOREIGN KEY ("participation_id") REFERENCES "khatm_participations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- PARTIAL UNIQUE INDEX (hand-written — Prisma cannot express a filtered unique
-- index in schema.prisma; DEC-0050, KI-0012). Enforces the core participation
-- invariant in the DATABASE, not only in application code: at most ONE ACTIVE
-- participation per (khatm, user). Duplicate/concurrent active joins fail with a
-- P2002 that the repository surfaces as DuplicateParticipationError. Terminal
-- participations (COMPLETED/LEFT/REMOVED) are NOT covered, so history accumulates
-- and a user who LEFT may join again as a new ACTIVE row.
CREATE UNIQUE INDEX "khatm_participations_active_khatm_user_key" ON "khatm_participations" ("khatm_id", "user_id") WHERE "status" = 'ACTIVE';
