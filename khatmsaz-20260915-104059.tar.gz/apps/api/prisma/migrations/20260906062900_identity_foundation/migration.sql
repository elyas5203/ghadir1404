-- CreateEnum
CREATE TYPE "platform" AS ENUM ('TELEGRAM', 'BALE');

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "platform_identities" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "platform" "platform" NOT NULL,
    "subject" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "platform_identities_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "platform_identities_user_id_idx" ON "platform_identities"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "platform_identities_platform_subject_key" ON "platform_identities"("platform", "subject");

-- AddForeignKey
ALTER TABLE "platform_identities" ADD CONSTRAINT "platform_identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
