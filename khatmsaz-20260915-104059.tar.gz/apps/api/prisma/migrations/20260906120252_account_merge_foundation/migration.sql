-- CreateEnum
CREATE TYPE "user_status" AS ENUM ('ACTIVE', 'MERGED');

-- DropForeignKey
ALTER TABLE "phone_claims" DROP CONSTRAINT "phone_claims_user_id_fkey";

-- DropForeignKey
ALTER TABLE "platform_identities" DROP CONSTRAINT "platform_identities_user_id_fkey";

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "merged_into_id" UUID,
ADD COLUMN     "status" "user_status" NOT NULL DEFAULT 'ACTIVE';

-- CreateTable
CREATE TABLE "account_merges" (
    "id" UUID NOT NULL,
    "winner_user_id" UUID NOT NULL,
    "loser_user_id" UUID NOT NULL,
    "verified_e164" TEXT NOT NULL,
    "initiating_challenge_id" UUID,
    "moved_platform_identities" INTEGER NOT NULL DEFAULT 0,
    "moved_phone_claims" INTEGER NOT NULL DEFAULT 0,
    "context" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "account_merges_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "account_merges_winner_user_id_idx" ON "account_merges"("winner_user_id");

-- CreateIndex
CREATE INDEX "account_merges_loser_user_id_idx" ON "account_merges"("loser_user_id");

-- CreateIndex
CREATE INDEX "users_merged_into_id_idx" ON "users"("merged_into_id");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_merged_into_id_fkey" FOREIGN KEY ("merged_into_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "platform_identities" ADD CONSTRAINT "platform_identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "phone_claims" ADD CONSTRAINT "phone_claims_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "account_merges" ADD CONSTRAINT "account_merges_winner_user_id_fkey" FOREIGN KEY ("winner_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "account_merges" ADD CONSTRAINT "account_merges_loser_user_id_fkey" FOREIGN KEY ("loser_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- ---------------------------------------------------------------------------
-- HAND-WRITTEN PARTIAL UNIQUE INDEX (not expressible in schema.prisma).
--
-- DEC-0046: a user may hold at most ONE verified phone claim, across all numbers.
-- Prisma cannot represent a filtered/partial unique index (WHERE clause), so — as
-- with the DEC-0034 indexes — it is added here by hand and enforced in the
-- DATABASE (KI-0012). This is a third partial unique index on phone_claims,
-- complementing the per-number and per-(user,number) ones from the previous
-- migration. Because it is not in schema.prisma, a future `prisma migrate dev`
-- diff may try to DROP it; that DROP must be removed in review.
-- ---------------------------------------------------------------------------

-- CreateIndex (partial unique): one VERIFIED claim per user, across all numbers.
CREATE UNIQUE INDEX "phone_claims_verified_user_key"
    ON "phone_claims" ("user_id")
    WHERE "status" = 'VERIFIED';
