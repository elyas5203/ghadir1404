-- CreateEnum
CREATE TYPE "khatm_type" AS ENUM ('COMMITMENT', 'OPEN');

-- AlterTable
ALTER TABLE "khatms" ADD COLUMN     "khatm_type" "khatm_type" NOT NULL DEFAULT 'COMMITMENT';

-- CreateTable
CREATE TABLE "open_contributions" (
    "id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "participation_id" UUID NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "note" TEXT,
    "recorded_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "open_contributions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "open_contributions_khatm_id_idx" ON "open_contributions"("khatm_id");

-- CreateIndex
CREATE INDEX "open_contributions_participation_id_idx" ON "open_contributions"("participation_id");

-- AddForeignKey
ALTER TABLE "open_contributions" ADD CONSTRAINT "open_contributions_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "open_contributions" ADD CONSTRAINT "open_contributions_participation_id_fkey" FOREIGN KEY ("participation_id") REFERENCES "khatm_participations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
