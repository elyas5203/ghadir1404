-- AlterTable: add optional display_name to users (Phase 14, DEC-0073).
-- The column is nullable so no backfill is required and the migration is non-blocking.
ALTER TABLE "users" ADD COLUMN "display_name" VARCHAR(64);
