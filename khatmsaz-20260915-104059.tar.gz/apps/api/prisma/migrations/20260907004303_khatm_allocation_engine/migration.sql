-- CreateEnum
CREATE TYPE "portion_unit_kind" AS ENUM ('POSITIONAL', 'QUANTITY');

-- CreateEnum
CREATE TYPE "khatm_portion_status" AS ENUM ('OPEN', 'ASSIGNED', 'COMPLETED');

-- CreateTable
CREATE TABLE "khatm_allocation_plans" (
    "id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "unit_kind" "portion_unit_kind" NOT NULL,
    "total_portions" INTEGER NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "khatm_allocation_plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "khatm_portions" (
    "id" UUID NOT NULL,
    "plan_id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "sequence" INTEGER NOT NULL,
    "unit_kind" "portion_unit_kind" NOT NULL,
    "unit_start" INTEGER,
    "unit_end" INTEGER,
    "quantity" INTEGER,
    "status" "khatm_portion_status" NOT NULL DEFAULT 'OPEN',
    "participation_id" UUID,
    "completed_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "khatm_portions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "khatm_allocation_plans_khatm_id_key" ON "khatm_allocation_plans"("khatm_id");

-- CreateIndex
CREATE INDEX "khatm_portions_khatm_id_idx" ON "khatm_portions"("khatm_id");

-- CreateIndex
CREATE INDEX "khatm_portions_plan_id_idx" ON "khatm_portions"("plan_id");

-- CreateIndex
CREATE INDEX "khatm_portions_participation_id_idx" ON "khatm_portions"("participation_id");

-- CreateIndex
CREATE INDEX "khatm_portions_status_idx" ON "khatm_portions"("status");

-- CreateIndex
CREATE UNIQUE INDEX "khatm_portions_plan_id_sequence_key" ON "khatm_portions"("plan_id", "sequence");

-- AddForeignKey
ALTER TABLE "khatm_allocation_plans" ADD CONSTRAINT "khatm_allocation_plans_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_portions" ADD CONSTRAINT "khatm_portions_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "khatm_allocation_plans"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_portions" ADD CONSTRAINT "khatm_portions_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_portions" ADD CONSTRAINT "khatm_portions_participation_id_fkey" FOREIGN KEY ("participation_id") REFERENCES "khatm_participations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- PARTIAL UNIQUE INDEX (hand-written — Prisma cannot express a filtered unique
-- index in schema.prisma; DEC-0053, KI-0012). Enforces NON-OVERLAP of positional
-- portions in the DATABASE: within a plan, at most one POSITIONAL portion may cover
-- a given unit. Engine positional portions are ATOMIC (unit_start = unit_end), so a
-- unique on (plan_id, unit_start) is a full non-overlap guarantee without needing a
-- range-exclusion (gist) constraint. QUANTITY portions (unit_start IS NULL) are not
-- covered — counts do not overlap.
CREATE UNIQUE INDEX "khatm_portions_positional_unit_key" ON "khatm_portions" ("plan_id", "unit_start") WHERE "unit_kind" = 'POSITIONAL';
