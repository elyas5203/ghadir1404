-- Sprint 3: UserPlan — persisted plan tier per user (DEC-0085).
-- Missing row implies FREE; created/updated by admin plan-change endpoint.

CREATE TYPE "plan_tier" AS ENUM ('FREE', 'BASIC', 'PRO');

CREATE TABLE "user_plans" (
    "user_id"    UUID        NOT NULL,
    "plan"       "plan_tier" NOT NULL DEFAULT 'FREE',
    "starts_at"  TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
    "updated_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

    CONSTRAINT "user_plans_pkey" PRIMARY KEY ("user_id"),
    CONSTRAINT "user_plans_user_id_fkey"
        FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
