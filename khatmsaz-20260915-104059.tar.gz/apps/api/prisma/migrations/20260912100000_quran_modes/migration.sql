-- QURAN-001: add QURAN_PAGE and QURAN_SURAH template types and the
-- edition/surah config columns (DEC-0076).
--
-- ADD VALUE IF NOT EXISTS is safe to re-run and does not invalidate existing rows.
-- Column additions are backwards-compatible: existing khatms get NULL for all three,
-- which is correct — they are only populated for the two new template types.
--
-- The CHECK constraints enforce DB-level domain invariants without a separate table:
--   surah_number in [1,114] (the 114 chapters of the Quran)
--   repetition_target > 0 (a positive count)
-- quran_edition_id is a VARCHAR application key — the registry lives in application
-- code (packages/shared), so no FK to a editions table is needed.

ALTER TYPE khatm_template_type ADD VALUE IF NOT EXISTS 'QURAN_PAGE';
ALTER TYPE khatm_template_type ADD VALUE IF NOT EXISTS 'QURAN_SURAH';

ALTER TABLE khatms
  ADD COLUMN IF NOT EXISTS quran_edition_id VARCHAR(64),
  ADD COLUMN IF NOT EXISTS surah_number     SMALLINT,
  ADD COLUMN IF NOT EXISTS repetition_target INTEGER;

-- Enforce domain constraints at the DB level.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'khatms_surah_number_valid'
  ) THEN
    ALTER TABLE khatms
      ADD CONSTRAINT khatms_surah_number_valid
      CHECK (surah_number IS NULL OR (surah_number >= 1 AND surah_number <= 114));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'khatms_repetition_target_valid'
  ) THEN
    ALTER TABLE khatms
      ADD CONSTRAINT khatms_repetition_target_valid
      CHECK (repetition_target IS NULL OR repetition_target > 0);
  END IF;
END $$;
