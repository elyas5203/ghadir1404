-- CreateTable
CREATE TABLE "khatm_invitations" (
    "id" UUID NOT NULL,
    "khatm_id" UUID NOT NULL,
    "created_by_user_id" UUID NOT NULL,
    "token_hash" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "accepted_at" TIMESTAMPTZ(6),
    "accepted_by_user_id" UUID,
    "cancelled_at" TIMESTAMPTZ(6),

    CONSTRAINT "khatm_invitations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "khatm_invitations_token_hash_key" ON "khatm_invitations"("token_hash");

-- CreateIndex
CREATE INDEX "khatm_invitations_khatm_id_idx" ON "khatm_invitations"("khatm_id");

-- AddForeignKey
ALTER TABLE "khatm_invitations" ADD CONSTRAINT "khatm_invitations_khatm_id_fkey" FOREIGN KEY ("khatm_id") REFERENCES "khatms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_invitations" ADD CONSTRAINT "khatm_invitations_created_by_user_id_fkey" FOREIGN KEY ("created_by_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "khatm_invitations" ADD CONSTRAINT "khatm_invitations_accepted_by_user_id_fkey" FOREIGN KEY ("accepted_by_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
