-- Sprint 2026-09-12: Notification Jobs, Waiting List, Wallet, User Settings
-- Additive migration: new tables and enums only; no existing table altered.

-- ─── Enums ────────────────────────────────────────────────────────────────────

CREATE TYPE "notif_channel" AS ENUM ('TELEGRAM', 'BALE', 'SMS');
CREATE TYPE "job_status"    AS ENUM ('PENDING', 'SENT', 'FAILED');
CREATE TYPE "tx_type"       AS ENUM ('CHARGE', 'SPEND', 'REFUND', 'CREDIT');
CREATE TYPE "font_size"     AS ENUM ('NORMAL', 'LARGE');
CREATE TYPE "gender"        AS ENUM ('MALE', 'FEMALE');

-- ─── notification_jobs ────────────────────────────────────────────────────────

CREATE TABLE "notification_jobs" (
  "id"            UUID             NOT NULL PRIMARY KEY,
  "user_id"       UUID             NOT NULL
    REFERENCES "users"("id") ON DELETE RESTRICT,
  "khatm_id"      UUID             NOT NULL
    REFERENCES "khatms"("id") ON DELETE RESTRICT,
  "portion_ids"   TEXT[]           NOT NULL DEFAULT '{}',
  "scheduled_for" TIMESTAMPTZ      NOT NULL,
  "timezone"      TEXT             NOT NULL DEFAULT 'Asia/Tehran',
  "channel"       "notif_channel"  NOT NULL,
  "status"        "job_status"     NOT NULL DEFAULT 'PENDING',
  "created_at"    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  "updated_at"    TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

CREATE INDEX ON "notification_jobs" ("user_id", "status");
CREATE INDEX ON "notification_jobs" ("khatm_id");
CREATE INDEX ON "notification_jobs" ("scheduled_for", "status");

-- ─── waiting_list ─────────────────────────────────────────────────────────────

CREATE TABLE "waiting_list" (
  "id"        UUID        NOT NULL PRIMARY KEY,
  "khatm_id"  UUID        NOT NULL
    REFERENCES "khatms"("id") ON DELETE RESTRICT,
  "user_id"   UUID        NOT NULL
    REFERENCES "users"("id") ON DELETE RESTRICT,
  "position"  INTEGER     NOT NULL,
  "joined_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX ON "waiting_list" ("khatm_id", "user_id");
CREATE INDEX ON "waiting_list" ("khatm_id", "position");

-- ─── wallets ──────────────────────────────────────────────────────────────────

CREATE TABLE "wallets" (
  "id"             UUID        NOT NULL PRIMARY KEY,
  "user_id"        UUID        NOT NULL UNIQUE
    REFERENCES "users"("id") ON DELETE RESTRICT,
  "balance_toman"  INTEGER     NOT NULL DEFAULT 0,
  "credit_toman"   INTEGER     NOT NULL DEFAULT 0,
  "updated_at"     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── wallet_transactions ──────────────────────────────────────────────────────

CREATE TABLE "wallet_transactions" (
  "id"          UUID        NOT NULL PRIMARY KEY,
  "wallet_id"   UUID        NOT NULL
    REFERENCES "wallets"("id") ON DELETE RESTRICT,
  "amount"      INTEGER     NOT NULL,
  "type"        "tx_type"   NOT NULL,
  "ref"         TEXT,
  "description" TEXT,
  "created_at"  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ON "wallet_transactions" ("wallet_id");

-- ─── user_settings ────────────────────────────────────────────────────────────

CREATE TABLE "user_settings" (
  "user_id"           UUID        NOT NULL PRIMARY KEY
    REFERENCES "users"("id") ON DELETE RESTRICT,
  "reminder_hour"     INTEGER     NOT NULL DEFAULT 9,
  "reminder_minute"   INTEGER     NOT NULL DEFAULT 0,
  "timezone"          TEXT        NOT NULL DEFAULT 'Asia/Tehran',
  "font_size"         "font_size" NOT NULL DEFAULT 'NORMAL',
  "preferred_reciter" TEXT,
  "sms_enabled"       BOOLEAN     NOT NULL DEFAULT FALSE,
  "city"              TEXT,
  "province"          TEXT,
  "gender"            "gender",
  "language"          TEXT        NOT NULL DEFAULT 'fa',
  "updated_at"        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
