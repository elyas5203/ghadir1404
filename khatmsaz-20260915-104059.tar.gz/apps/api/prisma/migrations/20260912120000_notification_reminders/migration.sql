-- Phase 19: Reminder Engine
-- notification_preferences: per-participation reminder settings (default: 9 AM Tehran)
-- notification_log: prevents duplicate sends and tracks history
-- notification_kind: enum for the type of reminder

CREATE TYPE "notification_kind" AS ENUM ('DAILY_REMINDER', 'FOLLOW_UP');

CREATE TABLE "notification_preferences" (
  "id"               UUID    NOT NULL PRIMARY KEY,
  "participation_id" UUID    NOT NULL UNIQUE
    REFERENCES "khatm_participations"("id") ON DELETE CASCADE,
  "reminder_hour"    INTEGER NOT NULL DEFAULT 9,
  "enabled"          BOOLEAN NOT NULL DEFAULT TRUE,
  "created_at"       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "notification_log" (
  "id"               UUID                  NOT NULL PRIMARY KEY,
  "participation_id" UUID                  NOT NULL
    REFERENCES "khatm_participations"("id") ON DELETE CASCADE,
  "kind"             "notification_kind"   NOT NULL,
  "sent_at"          TIMESTAMPTZ           NOT NULL DEFAULT NOW()
);

CREATE INDEX ON "notification_log"("participation_id", "sent_at");
