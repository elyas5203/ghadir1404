/**
 * Seed script: promote a user to SUPER_ADMIN by their verified phone number.
 *
 * Usage (from apps/api directory):
 *   ADMIN_PHONE=+989123456789 DATABASE_URL=postgres://... npx tsx prisma/seed-admin.ts
 *
 * The phone must already be a verified E.164 PhoneClaim on a user account.
 */
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main(): Promise<void> {
  const phone = process.env.ADMIN_PHONE;
  if (!phone) {
    console.error('Set ADMIN_PHONE=+98... before running.');
    process.exitCode = 1;
    return;
  }

  const claimResult = await pool.query<{ user_id: string }>(
    `SELECT user_id FROM phone_claims WHERE e164 = $1 AND status = 'VERIFIED' LIMIT 1`,
    [phone],
  );

  if (claimResult.rowCount === 0) {
    console.error(`No verified phone claim found for ${phone}.`);
    process.exitCode = 1;
    return;
  }

  const userId = claimResult.rows[0].user_id;
  await pool.query(
    `UPDATE users SET role = 'SUPER_ADMIN' WHERE id = $1`,
    [userId],
  );

  console.log(`User ${userId} is now SUPER_ADMIN.`);
}

main().finally(() => void pool.end());
