#!/bin/bash
# بکاپ دیتابیس KhatmSaz
# استفاده: bash /opt/khatmsaz/scripts/backup-db.sh
# cronjob پیشنهادی (هر روز ساعت ۴ صبح):
#   0 4 * * * /opt/khatmsaz/scripts/backup-db.sh >> /var/log/khatmsaz-backup.log 2>&1

set -e

KHATMSAZ_DIR="/opt/khatmsaz"
BACKUP_DIR="/opt/khatmsaz-backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
FILENAME="khatmsaz_${TIMESTAMP}.sql.gz"

mkdir -p "$BACKUP_DIR"

docker compose -f "$KHATMSAZ_DIR/docker-compose.prod.yml" exec -T postgres \
  pg_dump -U khatmsaz khatmsaz \
  | gzip > "$BACKUP_DIR/$FILENAME"

# نگه داشتن فقط ۱۴ روز اخیر
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +14 -delete

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Backup done: $BACKUP_DIR/$FILENAME"
