# Local infrastructure

These containers exist for **local development only**. Nothing here is a
production topology and nothing here is deployed by Claude Code.

## Before the first run

```bash
cp .env.example .env      # from the repository root
```

`docker compose` reads `../../.env` (see the `env_file` resolution note below):
run every command through the root npm scripts so the correct env file is used.

## Commands

```bash
npm run infra:config   # validate the compose file (no daemon required)
npm run infra:up       # start postgres, redis, minio
npm run infra:down     # stop them (named volumes are kept)
```

To wipe local data entirely: `docker compose -f infra/docker/docker-compose.yml down -v`.

## Ports (all bound to 127.0.0.1)

| Service        | Port |
| -------------- | ---- |
| PostgreSQL     | 5432 |
| Redis          | 6379 |
| MinIO API      | 9000 |
| MinIO console  | 9001 |

## Why named volumes

The repository lives on `Z:\KhatmSaz`, reached from WSL through `/mnt/z`.
Database files must never be bind-mounted onto that path: the 9p/DrvFs layer is
slow and does not give PostgreSQL the filesystem semantics it expects. Docker
named volumes stay inside the Linux VM.

## Not implemented yet

No schema, no migrations, no seed data. Business schema arrives in a later
phase — see `docs/ai/DATABASE.md`.
