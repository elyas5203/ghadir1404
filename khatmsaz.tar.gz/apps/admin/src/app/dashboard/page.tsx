'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { AdminShell } from '../../components/AdminShell';
import { useAuth } from '../../lib/auth-context';

interface Stats {
  totalUsers: number;
  totalKhatms: number;
}

export default function DashboardPage() {
  const { phase, authed } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (phase === 'anonymous') { router.replace('/login'); return; }
    if (phase !== 'authenticated') return;
    authed<Stats>('/api/admin/stats')
      .then(setStats)
      .catch((err) => setError(err instanceof Error ? err.message : 'خطا در بارگذاری آمار.'));
  }, [phase, authed, router]);

  if (phase === 'loading') return null;

  return (
    <AdminShell>
      <h1 className="admin-page-title">داشبورد</h1>

      {error && <p style={{ color: '#dc2626' }}>{error}</p>}

      <div className="stat-grid">
        <div className="stat-card">
          <span className="stat-card__value">{stats ? stats.totalUsers.toLocaleString('fa-IR') : '—'}</span>
          <span className="stat-card__label">کاربران</span>
        </div>
        <div className="stat-card">
          <span className="stat-card__value">{stats ? stats.totalKhatms.toLocaleString('fa-IR') : '—'}</span>
          <span className="stat-card__label">ختم‌ها</span>
        </div>
      </div>
    </AdminShell>
  );
}
