import { newUuidV7, InvalidUuidV7Error } from '@khatmsaz/kernel';
import { Khatm } from './khatm';
import { KhatmStatus } from './khatm-status';
import { KhatmTemplateType } from './khatm-template';
import { KhatmType } from './khatm-type';
import {
  InvalidKhatmTitleError,
  InvalidKhatmTransitionError,
  UnknownKhatmStatusError,
  UnknownKhatmTemplateTypeError,
  UnknownKhatmTypeError,
} from './khatm.errors';

const base = () => ({
  id: newUuidV7(),
  creatorUserId: newUuidV7(),
  title: 'ختم قرآن خانوادگی',
  templateType: KhatmTemplateType.QURAN_FULL,
  khatmType: KhatmType.COMMITMENT,
  quranEditionId: null,
  surahNumber: null,
  repetitionTarget: null,
});

describe('Khatm (domain)', () => {
  describe('create', () => {
    it('creates a DRAFT khatm with a trimmed title and normalised description', () => {
      const khatm = Khatm.create({ ...base(), title: '  ختم  ', description: '  توضیح  ' });
      expect(khatm.status).toBe(KhatmStatus.DRAFT);
      expect(khatm.title).toBe('ختم');
      expect(khatm.description).toBe('توضیح');
    });

    it('treats a blank description as absent (null)', () => {
      const khatm = Khatm.create({ ...base(), description: '   ' });
      expect(khatm.description).toBeNull();
    });

    it('rejects a blank title', () => {
      expect(() => Khatm.create({ ...base(), title: '   ' })).toThrow(InvalidKhatmTitleError);
    });

    it('rejects an unknown template type', () => {
      expect(() =>
        Khatm.create({ ...base(), templateType: 'NOPE' as KhatmTemplateType }),
      ).toThrow(UnknownKhatmTemplateTypeError);
    });

    it('rejects an unknown khatm type', () => {
      expect(() =>
        Khatm.create({ ...base(), khatmType: 'UNKNOWN' as KhatmType }),
      ).toThrow(UnknownKhatmTypeError);
    });

    it('creates a COMMITMENT khatm by default convention', () => {
      const khatm = Khatm.create(base());
      expect(khatm.khatmType).toBe(KhatmType.COMMITMENT);
    });

    it('creates an OPEN khatm when specified', () => {
      const khatm = Khatm.create({ ...base(), khatmType: KhatmType.OPEN });
      expect(khatm.khatmType).toBe(KhatmType.OPEN);
    });

    it('rejects a non-UUIDv7 id or creator id', () => {
      expect(() => Khatm.create({ ...base(), id: 'not-a-uuid' })).toThrow(InvalidUuidV7Error);
      expect(() => Khatm.create({ ...base(), creatorUserId: 'nope' })).toThrow(
        InvalidUuidV7Error,
      );
    });
  });

  describe('lifecycle transitions', () => {
    const draft = () => Khatm.create(base());

    it('DRAFT → ACTIVE via activate()', () => {
      expect(draft().activate().status).toBe(KhatmStatus.ACTIVE);
    });

    it('ACTIVE → COMPLETED via complete()', () => {
      expect(draft().activate().complete().status).toBe(KhatmStatus.COMPLETED);
    });

    it('DRAFT → CANCELLED and ACTIVE → CANCELLED via cancel()', () => {
      expect(draft().cancel().status).toBe(KhatmStatus.CANCELLED);
      expect(draft().activate().cancel().status).toBe(KhatmStatus.CANCELLED);
    });

    it('preserves creator ownership across a transition', () => {
      const d = draft();
      expect(d.activate().creatorUserId).toBe(d.creatorUserId);
    });

    it('does not mutate the original entity (transitions are immutable)', () => {
      const d = draft();
      d.activate();
      expect(d.status).toBe(KhatmStatus.DRAFT);
    });
  });

  describe('invalid transitions', () => {
    const draft = () => Khatm.create(base());

    it('cannot complete a DRAFT (must activate first)', () => {
      expect(() => draft().complete()).toThrow(InvalidKhatmTransitionError);
    });

    it('cannot activate an already ACTIVE khatm', () => {
      expect(() => draft().activate().activate()).toThrow(InvalidKhatmTransitionError);
    });

    it('cannot transition out of a terminal state', () => {
      const completed = draft().activate().complete();
      expect(() => completed.activate()).toThrow(InvalidKhatmTransitionError);
      expect(() => completed.cancel()).toThrow(InvalidKhatmTransitionError);
      const cancelled = draft().cancel();
      expect(() => cancelled.activate()).toThrow(InvalidKhatmTransitionError);
    });
  });

  describe('guards', () => {
    it('only an ACTIVE khatm accepts participants and assignments', () => {
      const d = Khatm.create(base());
      expect(d.canAcceptParticipants).toBe(false);
      expect(d.canReceiveAssignments).toBe(false);
      const active = d.activate();
      expect(active.canAcceptParticipants).toBe(true);
      expect(active.canReceiveAssignments).toBe(true);
      const completed = active.complete();
      expect(completed.canAcceptParticipants).toBe(false);
      expect(completed.canReceiveAssignments).toBe(false);
    });
  });

  describe('Quran modes (QURAN-001)', () => {
    it('creates a QURAN_PAGE khatm with an edition id and exposes it', () => {
      const khatm = Khatm.create({
        ...base(),
        templateType: KhatmTemplateType.QURAN_PAGE,
        quranEditionId: 'MADINA_HAFS',
      });
      expect(khatm.templateType).toBe(KhatmTemplateType.QURAN_PAGE);
      expect(khatm.quranEditionId).toBe('MADINA_HAFS');
      expect(khatm.surahNumber).toBeNull();
      expect(khatm.repetitionTarget).toBeNull();
    });

    it('creates a QURAN_SURAH khatm with surah number and repetition target', () => {
      const khatm = Khatm.create({
        ...base(),
        templateType: KhatmTemplateType.QURAN_SURAH,
        surahNumber: 36,
        repetitionTarget: 1000,
      });
      expect(khatm.templateType).toBe(KhatmTemplateType.QURAN_SURAH);
      expect(khatm.surahNumber).toBe(36);
      expect(khatm.repetitionTarget).toBe(1000);
      expect(khatm.quranEditionId).toBeNull();
    });

    it('defaults all quran fields to null when not provided', () => {
      const khatm = Khatm.create(base());
      expect(khatm.quranEditionId).toBeNull();
      expect(khatm.surahNumber).toBeNull();
      expect(khatm.repetitionTarget).toBeNull();
    });

    it('preserves quran fields across lifecycle transitions', () => {
      const khatm = Khatm.create({
        ...base(),
        templateType: KhatmTemplateType.QURAN_SURAH,
        surahNumber: 112,
        repetitionTarget: 500,
      });
      const active = khatm.activate();
      expect(active.surahNumber).toBe(112);
      expect(active.repetitionTarget).toBe(500);
    });
  });

  describe('restore', () => {
    it('rejects an unknown status', () => {
      const now = new Date();
      expect(() =>
        Khatm.restore({
          ...base(),
          description: null,
          status: 'WEIRD' as KhatmStatus,
          createdAt: now,
          updatedAt: now,
        }),
      ).toThrow(UnknownKhatmStatusError);
    });

    it('rejects an unknown khatm type', () => {
      const now = new Date();
      expect(() =>
        Khatm.restore({
          ...base(),
          description: null,
          khatmType: 'NOPE' as KhatmType,
          status: KhatmStatus.DRAFT,
          createdAt: now,
          updatedAt: now,
        }),
      ).toThrow(UnknownKhatmTypeError);
    });
  });
});
