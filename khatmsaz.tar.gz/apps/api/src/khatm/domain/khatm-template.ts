/**
 * KhatmTemplateType — the content template a Khatm is instantiated from
 * (DEC-0019, DEC-0048).
 *
 * The execution engine is GENERIC and template-driven rather than a hard-coded
 * subsystem per prayer type: this is a single classifying enum on the Khatm, not a
 * table or class per type. The template classifies WHAT is being recited; how the
 * content is divided into portions (how many Juz, how a count is split) is the
 * concern of the allocation engine (a later phase), not encoded here — so no
 * per-template counts or limits are invented at this foundation.
 *
 * The string values intentionally match the persistence enum `khatm_template_type`;
 * nothing outside infrastructure depends on the Prisma-generated enum. Adding a
 * template must not require the domain to branch on a specific value (DEC-0018).
 */

export const KhatmTemplateType = {
  /** A full Qur'an recitation, divided across participants by Juz. */
  QURAN_FULL: 'QURAN_FULL',
  /** A single Juz (part) of the Qur'an. */
  QURAN_JUZ: 'QURAN_JUZ',
  /** A single Surah (chapter) of the Qur'an — one reading per participant. */
  SURAH: 'SURAH',
  /**
   * Page-based Quran khatm (QURAN-001, DEC-0076).
   * Progress is accumulated pages read; the Quran edition (quranEditionId on the
   * Khatm) supplies the total page count. Cycles = accumulated / edition.totalPages.
   */
  QURAN_PAGE: 'QURAN_PAGE',
  /**
   * Surah-repetition khatm (QURAN-001, DEC-0076).
   * Creator selects one surah (surahNumber) and a collective target count
   * (repetitionTarget). Example: Surah Yasin × 1000. Not a full-Quran cycle.
   */
  QURAN_SURAH: 'QURAN_SURAH',
  /** A collective count of Salawat. */
  SALAWAT: 'SALAWAT',
  /** A collective recitation of a Dua (supplication). */
  DUA: 'DUA',
  /** A collective recitation of a Ziyarat. */
  ZIYARAT: 'ZIYARAT',
  /** A creator-defined activity that does not fit the predefined templates. */
  CUSTOM: 'CUSTOM',
} as const;

export type KhatmTemplateType = (typeof KhatmTemplateType)[keyof typeof KhatmTemplateType];

export const ALL_KHATM_TEMPLATE_TYPES: readonly KhatmTemplateType[] =
  Object.values(KhatmTemplateType);

/** Narrows an unknown value to a known {@link KhatmTemplateType}. */
export function isKhatmTemplateType(value: unknown): value is KhatmTemplateType {
  return (
    typeof value === 'string' && (ALL_KHATM_TEMPLATE_TYPES as readonly string[]).includes(value)
  );
}
