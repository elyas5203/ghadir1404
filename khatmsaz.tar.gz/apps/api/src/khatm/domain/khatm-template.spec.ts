import {
  KhatmTemplateType,
  ALL_KHATM_TEMPLATE_TYPES,
  isKhatmTemplateType,
} from './khatm-template';

describe('KhatmTemplateType (domain)', () => {
  it('enumerates all nine template types including Quran modes', () => {
    expect(ALL_KHATM_TEMPLATE_TYPES).toEqual([
      'QURAN_FULL',
      'QURAN_JUZ',
      'SURAH',
      'QURAN_PAGE',
      'QURAN_SURAH',
      'SALAWAT',
      'DUA',
      'ZIYARAT',
      'CUSTOM',
    ]);
  });

  it('narrows known values and rejects unknown ones', () => {
    expect(isKhatmTemplateType(KhatmTemplateType.SALAWAT)).toBe(true);
    expect(isKhatmTemplateType('QURAN_FULL')).toBe(true);
    expect(isKhatmTemplateType('PRAYER')).toBe(false);
    expect(isKhatmTemplateType(42)).toBe(false);
    expect(isKhatmTemplateType(null)).toBe(false);
  });
});
