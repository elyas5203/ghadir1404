import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma/prisma.service';
import type { Khatm } from '../domain/khatm';
import type { KhatmStatus } from '../domain/khatm-status';
import type { KhatmRepository } from '../domain/khatm.repository';
import {
  KhatmCreatorNotFoundError,
  KhatmNotInExpectedStateError,
} from '../domain/khatm.errors';
import { toKhatm } from './khatm.mapper';
import { PRISMA_FOREIGN_KEY_VIOLATION, prismaErrorCode } from './prisma-error';

/**
 * Prisma-backed {@link KhatmRepository}. The only Khatm persistence code that sees
 * Prisma; it returns domain {@link Khatm} objects, never Prisma rows.
 *
 * `transition` is a guarded `updateMany` keyed on the expected prior status, so two
 * concurrent lifecycle changes cannot both win — the loser matches 0 rows and is
 * rejected (mirrors the identity tombstone pattern).
 */
@Injectable()
export class PrismaKhatmRepository implements KhatmRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(khatm: Khatm): Promise<Khatm> {
    try {
      const row = await this.prisma.khatm.create({
        data: {
          id: khatm.id,
          creatorUserId: khatm.creatorUserId,
          title: khatm.title,
          description: khatm.description,
          templateType: khatm.templateType,
          khatmType: khatm.khatmType,
          status: khatm.status,
          quranEditionId: khatm.quranEditionId,
          surahNumber: khatm.surahNumber,
          repetitionTarget: khatm.repetitionTarget,
        },
      });
      return toKhatm(row);
    } catch (error) {
      if (prismaErrorCode(error) === PRISMA_FOREIGN_KEY_VIOLATION) {
        throw new KhatmCreatorNotFoundError();
      }
      throw error;
    }
  }

  async findById(id: string): Promise<Khatm | null> {
    const row = await this.prisma.khatm.findUnique({ where: { id } });
    return row ? toKhatm(row) : null;
  }

  async findBySlug(slug: string): Promise<Khatm | null> {
    const row = await this.prisma.khatm.findUnique({ where: { publicSlug: slug } });
    return row ? toKhatm(row) : null;
  }

  async findByCreator(creatorUserId: string): Promise<Khatm[]> {
    const rows = await this.prisma.khatm.findMany({
      where: { creatorUserId },
      orderBy: { createdAt: 'desc' },
    });
    return rows.map(toKhatm);
  }

  async transition(id: string, from: KhatmStatus, to: KhatmStatus): Promise<void> {
    // `updated_at` is maintained by Prisma (@updatedAt).
    const result = await this.prisma.khatm.updateMany({
      where: { id, status: from },
      data: { status: to },
    });
    if (result.count === 0) {
      throw new KhatmNotInExpectedStateError();
    }
  }

  async listAll(limit: number, offset: number): Promise<Khatm[]> {
    const rows = await this.prisma.khatm.findMany({
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });
    return rows.map(toKhatm);
  }

  async countAll(): Promise<number> {
    return this.prisma.khatm.count();
  }
}
