/** Port: schedules daily reminders for all active participations in a khatm. */
export interface NotificationScheduler {
  scheduleKhatmNotifications(khatmId: string): Promise<void>;
  cancelKhatmNotifications(khatmId: string): Promise<void>;
}

export const NOTIFICATION_SCHEDULER = Symbol('NotificationScheduler');
