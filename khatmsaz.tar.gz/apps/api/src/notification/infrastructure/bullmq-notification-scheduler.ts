import { Injectable, Logger } from '@nestjs/common';
import { Queue } from 'bullmq';
import type { NotificationScheduler } from '../domain/notification-scheduler';

export const NOTIFICATION_QUEUE_NAME = 'khatmsaz:notifications';

export interface NotificationJobData {
  khatmId: string;
  userId: string;
  participationId: string;
  channel: 'TELEGRAM' | 'BALE' | 'SMS';
}

/**
 * BullMQ-backed scheduler (Sprint Phase 01).
 * Enqueues a repeatable daily job for every active participation in a khatm.
 * The processor (NotificationProcessor) runs on a separate worker queue.
 */
@Injectable()
export class BullmqNotificationScheduler implements NotificationScheduler {
  private readonly logger = new Logger('NotificationScheduler');
  private readonly queue: Queue<NotificationJobData>;

  constructor(redisUrl: string) {
    const url = new URL(redisUrl);
    this.queue = new Queue<NotificationJobData>(NOTIFICATION_QUEUE_NAME, {
      connection: {
        host: url.hostname,
        port: Number(url.port) || 6379,
        password: url.password || undefined,
      },
    });
  }

  async scheduleKhatmNotifications(khatmId: string): Promise<void> {
    // The actual per-participation scheduling is done by the processor or a
    // separate seed job. Here we enqueue a "seed" job so the processor can
    // look up all active participations and schedule their individual reminders.
    await this.queue.add(
      'seed',
      { khatmId, userId: '', participationId: '', channel: 'TELEGRAM' },
      {
        jobId: `seed:${khatmId}`,
        removeOnComplete: true,
        attempts: 3,
        backoff: { type: 'exponential', delay: 5_000 },
      },
    );
    this.logger.log(`Scheduled notification seed job for khatm ${khatmId}.`);
  }

  async cancelKhatmNotifications(khatmId: string): Promise<void> {
    // Remove the job scheduler for this khatm.
    await this.queue.removeJobScheduler(`seed:${khatmId}`);
    this.logger.log(`Cancelled notification jobs for khatm ${khatmId}.`);
  }

  async onApplicationShutdown(): Promise<void> {
    await this.queue.close();
  }
}
