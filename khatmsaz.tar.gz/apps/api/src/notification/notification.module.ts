import { Module } from '@nestjs/common';
import { redisConfig, redisEnabled, telegramConfig, baleConfig } from '@khatmsaz/config';
import { PrismaService } from '../infrastructure/database/prisma/prisma.service';
import { NOTIFICATION_SCHEDULER } from './domain/notification-scheduler';
import { NotificationService } from './application/notification.service';
import { NoopNotificationScheduler } from './infrastructure/noop-notification-scheduler';
import { BullmqNotificationScheduler } from './infrastructure/bullmq-notification-scheduler';
import { NotificationProcessorService } from './infrastructure/notification-processor.service';

/**
 * Notification capability (Sprint Phase 01 + processor phase).
 *
 * Wires BullMQ when REDIS_URL is configured; falls back to the no-op scheduler
 * when it is empty — keeping the app startable and testable without Redis.
 *
 * When Redis is available, also starts the NotificationProcessorService (BullMQ
 * Worker) which consumes seed jobs and delivers daily reminders via Telegram/Bale.
 *
 * NotificationService is exported so KhatmWorkflowModule can call
 * `onKhatmActivated` / `onKhatmClosed` after lifecycle transitions.
 */
@Module({
  providers: [
    NotificationService,
    {
      provide: NOTIFICATION_SCHEDULER,
      useFactory: () => {
        const cfg = redisConfig();
        return redisEnabled(cfg)
          ? new BullmqNotificationScheduler(cfg.url)
          : new NoopNotificationScheduler();
      },
    },
    {
      provide: NotificationProcessorService,
      inject: [PrismaService],
      useFactory: (prisma: PrismaService) => {
        const redis = redisConfig();
        if (!redisEnabled(redis)) return null; // no-op if Redis absent
        const tg = telegramConfig();
        const bale = baleConfig();
        return new NotificationProcessorService(
          prisma,
          redis.url,
          tg.botToken,
          tg.apiBaseUrl,
          bale.botToken,
          bale.apiBaseUrl,
        );
      },
    },
  ],
  exports: [NotificationService],
})
export class NotificationModule {}
