import { Body, Controller, Get, HttpCode, Param, Post, Query, UseGuards } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import type {
  AllocatePortionsResponse,
  ContributionSummary,
  GenerateAllocationResponse,
  JoinKhatmResponse,
  KhatmListResponse,
  KhatmParticipantsResponse,
  KhatmProgressResponse,
  KhatmSummary,
  MyContributionsResponse,
  MyPortionsResponse,
  OpenProgressResponse,
} from '@khatmsaz/contracts';
import { KhatmWorkflowService } from '../khatm-workflow/application/khatm-workflow.service';
import { KhatmService } from '../khatm/application/khatm.service';
import { OpenContributionService } from '../khatm/application/open-contribution.service';
import { KhatmNotFoundError } from '../khatm/domain/khatm.errors';
import { PortionUnitKind } from '../allocation/domain/portion-unit-kind';
import type { PlanSpec } from '../allocation/domain/plan-spec';
import { SessionAuthGuard } from './auth/session-auth.guard';
import { Principal } from './auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../session/domain/authenticated-principal';
import {
  toContributionSummary,
  toKhatmSummary,
  toParticipationSummary,
  toPortionSummary,
} from './khatm-view.mapper';
import {
  parseAllocatePortions,
  parseCreateKhatm,
  parseGenerateAllocation,
  parseRecordContribution,
} from './dto/khatm-requests';

/**
 * HTTP transport for the khatm workflows. Controllers are THIN: they validate the
 * request into a contract DTO, call an application service, and map the result to a
 * contract response. No business logic, no Prisma, no domain entity leaves as-is —
 * the workflow/domain rules stay in the application and domain layers. There is no
 * authentication yet, so identifiers (creator, user) are explicit in the request.
 */
@Controller('api/khatms')
export class KhatmController {
  constructor(
    private readonly workflow: KhatmWorkflowService,
    private readonly khatms: KhatmService,
    private readonly contributions: OpenContributionService,
  ) {}

  /** Create a khatm (DRAFT), owned by the authenticated principal. */
  @Post()
  @UseGuards(SessionAuthGuard)
  async create(
    @Principal() principal: AuthenticatedPrincipal,
    @Body() body: unknown,
  ): Promise<KhatmSummary> {
    const dto = parseCreateKhatm(body);
    const khatm = await this.workflow.createKhatm({ ...dto, creatorUserId: principal.userId });
    return toKhatmSummary(khatm);
  }

  /** List the authenticated principal's own created khatms. */
  @SkipThrottle()
  @Get()
  @UseGuards(SessionAuthGuard)
  async list(@Principal() principal: AuthenticatedPrincipal): Promise<KhatmListResponse> {
    const khatms = await this.khatms.listKhatmsByCreator(principal.userId);
    return { khatms: khatms.map(toKhatmSummary) };
  }

  /** Batch progress for up to 20 khatm IDs in one request. Replaces N parallel calls. */
  @SkipThrottle()
  @Get('batch-progress')
  @UseGuards(SessionAuthGuard)
  async batchProgress(
    @Query('ids') ids: string,
  ): Promise<Record<string, KhatmProgressResponse>> {
    const khatmIds = (ids ?? '').split(',').filter(Boolean).slice(0, 20);
    const out: Record<string, KhatmProgressResponse> = {};
    await Promise.all(
      khatmIds.map((id) =>
        this.workflow
          .progress(id)
          .then((p) => {
            out[id] = { khatmId: id, total: p.total, open: p.open, assigned: p.assigned, completed: p.completed };
          })
          .catch(() => undefined),
      ),
    );
    return out;
  }

  /** Get a single khatm by id. Caller must be the creator or an active participant. */
  @SkipThrottle()
  @Get(':id')
  @UseGuards(SessionAuthGuard)
  async getById(
    @Param('id') id: string,
    @Principal() principal: AuthenticatedPrincipal,
  ): Promise<KhatmSummary> {
    const khatm = await this.khatms.findKhatmById(id);
    if (!khatm) throw new KhatmNotFoundError();
    const isCreator = khatm.creatorUserId === principal.userId;
    const isParticipant =
      !isCreator && !!(await this.khatms.findParticipation(id, principal.userId));
    if (!isCreator && !isParticipant) throw new KhatmNotFoundError();
    return toKhatmSummary(khatm);
  }

  /** Generate the allocation plan for a khatm (owner only). */
  @Post(':id/plan')
  @UseGuards(SessionAuthGuard)
  async generatePlan(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
    @Body() body: unknown,
  ): Promise<GenerateAllocationResponse> {
    const { spec } = parseGenerateAllocation(body);
    const planSpec: PlanSpec =
      spec.kind === 'POSITIONAL'
        ? { kind: PortionUnitKind.POSITIONAL, from: spec.from, to: spec.to }
        : { kind: PortionUnitKind.QUANTITY, total: spec.total, chunk: spec.chunk };
    const plan = await this.workflow.generateAllocationPlan(id, principal.userId, planSpec);
    return { khatmId: id, unitKind: plan.unitKind, totalPortions: plan.totalPortions };
  }

  /** Activate a khatm (DRAFT → ACTIVE). Owner only; requires a valid plan (DEC-0055). */
  @Post(':id/activate')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async activate(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<void> {
    await this.workflow.activateKhatm(id, principal.userId);
  }

  /** The authenticated principal joins a khatm. */
  @Post(':id/join')
  @UseGuards(SessionAuthGuard)
  async join(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<JoinKhatmResponse> {
    const participation = await this.workflow.joinKhatm(id, principal.userId);
    return { participationId: participation.id, khatmId: id, status: participation.status };
  }

  /** Allocate open portions to a participant (owner only). */
  @Post(':id/allocate')
  @UseGuards(SessionAuthGuard)
  async allocate(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
    @Body() body: unknown,
  ): Promise<AllocatePortionsResponse> {
    const { participationId, count } = parseAllocatePortions(body);
    const assigned = await this.workflow.allocatePortions(id, principal.userId, participationId, count);
    return { assignedPortionIds: assigned.map((p) => p.id) };
  }

  /** The khatm's participations (owner only — creator management view). */
  @SkipThrottle()
  @Get(':id/participants')
  @UseGuards(SessionAuthGuard)
  async participants(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<KhatmParticipantsResponse> {
    const enriched = await this.workflow.listParticipationsEnriched(id, principal.userId);
    return {
      participants: enriched.map(({ participation, displayName }) =>
        toParticipationSummary(participation, displayName),
      ),
    };
  }

  /** The khatm's derived allocation progress. */
  @SkipThrottle()
  @Get(':id/progress')
  @UseGuards(SessionAuthGuard)
  async progress(@Param('id') id: string): Promise<KhatmProgressResponse> {
    const p = await this.workflow.progress(id);
    return { khatmId: id, total: p.total, open: p.open, assigned: p.assigned, completed: p.completed };
  }

  /** The authenticated participant's own portions in a khatm (participant view). */
  @SkipThrottle()
  @Get(':id/my-portions')
  @UseGuards(SessionAuthGuard)
  async myPortions(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<MyPortionsResponse> {
    const portions = await this.workflow.listMyPortions(id, principal.userId);
    return { portions: portions.map(toPortionSummary) };
  }

  /**
   * Mark one of the caller's ASSIGNED portions as COMPLETED (participant action).
   * Only the participant whose portion it is may do this; another participant or the
   * creator calling this endpoint is rejected by the allocation domain.
   */
  @Post(':id/portions/:portionId/complete')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async completePortion(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
    @Param('portionId') portionId: string,
  ): Promise<void> {
    await this.workflow.completeMyPortion(id, portionId, principal.userId);
  }

  /** Complete a khatm (owner only; only when every portion is completed — DEC-0056). */
  @Post(':id/complete')
  @UseGuards(SessionAuthGuard)
  @HttpCode(204)
  async complete(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<void> {
    await this.workflow.completeKhatm(id, principal.userId);
  }

  /** Aggregate progress for an OPEN khatm (sum of contributions). */
  @SkipThrottle()
  @Get(':id/open-progress')
  @UseGuards(SessionAuthGuard)
  async openProgress(@Param('id') id: string): Promise<OpenProgressResponse> {
    const p = await this.contributions.openProgress(id);
    return { khatmId: id, totalContributed: p.totalContributed, participantCount: p.participantCount };
  }

  /** Record a contribution in an OPEN khatm (authenticated participant). */
  @Post(':id/contributions')
  @UseGuards(SessionAuthGuard)
  async recordContribution(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
    @Body() body: unknown,
  ): Promise<ContributionSummary> {
    const { amount, note } = parseRecordContribution(body);
    const participation = await this.workflow.findMyParticipation(id, principal.userId);
    const contribution = await this.contributions.recordContribution({
      khatmId: id,
      participationId: participation.id,
      amount,
      note,
    });
    return toContributionSummary(contribution);
  }

  /** The authenticated participant's own contributions in an OPEN khatm. */
  @SkipThrottle()
  @Get(':id/my-contributions')
  @UseGuards(SessionAuthGuard)
  async myContributions(
    @Principal() principal: AuthenticatedPrincipal,
    @Param('id') id: string,
  ): Promise<MyContributionsResponse> {
    const participation = await this.workflow.findMyParticipation(id, principal.userId);
    const list = await this.contributions.listMyContributions(participation.id);
    return { contributions: list.map(toContributionSummary) };
  }
}
