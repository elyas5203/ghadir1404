import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  UseGuards,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { SessionAuthGuard } from '../auth/session-auth.guard';
import { AdminGuard } from './admin.guard';
import { Principal } from '../auth/principal.decorator';
import type { AuthenticatedPrincipal } from '../../session/domain/authenticated-principal';
import { IdentityService } from '../../identity/application/identity.service';
import { KhatmService } from '../../khatm/application/khatm.service';
import { AuthorizationService } from '../../authorization/application/authorization.service';
import { CapabilityType } from '../../authorization/domain/capability-type';
import { PlanService } from '../../payment/application/plan.service';
import type { PlanTier } from '../../payment/application/plan.service';
import { AuditService } from '../../audit/application/audit.service';
import { UserStatus } from '../../identity/domain/user-status';

const VALID_MODERATION_STATUSES: string[] = [
  UserStatus.ACTIVE,
  UserStatus.WARNED,
  UserStatus.SUSPENDED,
  UserStatus.BANNED,
];

/**
 * Super-admin REST endpoints. All require a valid session + SUPER_ADMIN role.
 * Controllers are thin: no business logic; only calling services.
 */
@Controller('admin')
@UseGuards(SessionAuthGuard, AdminGuard)
export class AdminController {
  constructor(
    private readonly identity: IdentityService,
    private readonly khatms: KhatmService,
    private readonly authorization: AuthorizationService,
    private readonly plans: PlanService,
    private readonly audit: AuditService,
  ) {}

  // ─── Dashboard ─────────────────────────────────────────────────────────────

  @Get('stats')
  async getStats() {
    const [totalUsers, totalKhatms] = await Promise.all([
      this.identity.countAllUsers(),
      this.khatms.countAllKhatms(),
    ]);
    return { totalUsers, totalKhatms };
  }

  // ─── User management ───────────────────────────────────────────────────────

  @Get('customers')
  async listCustomers(
    @Query('limit') limitStr?: string,
    @Query('offset') offsetStr?: string,
    @Query('search') search?: string,
  ) {
    const limit = Math.min(parseInt(limitStr ?? '50', 10) || 50, 200);
    const offset = parseInt(offsetStr ?? '0', 10) || 0;
    const users = search?.trim()
      ? await this.identity.searchUsers(search.trim(), limit, offset)
      : await this.identity.listAllUsers(limit, offset);
    return users.map((u) => ({
      id: u.id,
      displayName: u.displayName,
      role: u.role,
      status: u.status,
      createdAt: u.createdAt,
    }));
  }

  @Get('customers/:id')
  async getCustomer(@Param('id') id: string) {
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    const khatms = await this.khatms.listKhatmsByCreator(id);
    let hasCreatorCap = false;
    try {
      await this.authorization.requireCapability(id, CapabilityType.CREATOR);
      hasCreatorCap = true;
    } catch {
      hasCreatorCap = false;
    }
    return {
      id: user.id,
      displayName: user.displayName,
      role: user.role,
      status: user.status,
      createdAt: user.createdAt,
      hasCreatorCapability: hasCreatorCap,
      khatms: khatms.map((k) => ({
        id: k.id,
        title: k.title,
        status: k.status,
        templateType: k.templateType,
        khatmType: k.khatmType,
      })),
    };
  }

  /** Assign a plan tier to a customer. */
  @Post('customers/:id/plan')
  async setCustomerPlan(
    @Param('id') id: string,
    @Body() body: { plan: string },
    @Principal() actor: AuthenticatedPrincipal,
  ) {
    const validPlans: PlanTier[] = ['FREE', 'BASIC', 'PRO'];
    if (!validPlans.includes(body.plan as PlanTier)) {
      throw new BadRequestException('مقدار plan نامعتبر است.');
    }
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    await this.plans.assignPlan(id, body.plan as PlanTier);
    await this.audit.log({
      actorId: actor.userId,
      action: 'ADMIN_SET_PLAN',
      targetType: 'USER',
      targetId: id,
      meta: { plan: body.plan },
    });
    return { userId: id, plan: body.plan, updated: true };
  }

  /** Update a user's moderation status (warn/suspend/ban/reactivate). */
  @Post('customers/:id/status')
  async setCustomerStatus(
    @Param('id') id: string,
    @Body() body: { status: string; reason?: string },
    @Principal() actor: AuthenticatedPrincipal,
  ) {
    if (!VALID_MODERATION_STATUSES.includes(body.status)) {
      throw new BadRequestException('وضعیت نامعتبر است.');
    }
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    if (user.status === 'MERGED') {
      throw new BadRequestException('حساب ادغام‌شده قابل تغییر وضعیت نیست.');
    }
    await this.identity.updateUserStatus(id, body.status as UserStatus);
    await this.audit.log({
      actorId: actor.userId,
      action: `ADMIN_SET_STATUS_${body.status}`,
      targetType: 'USER',
      targetId: id,
      meta: { previousStatus: user.status, reason: body.reason },
    });
    return { userId: id, status: body.status, updated: true };
  }

  /** Grant CREATOR capability to a user. */
  @Post('customers/:id/grant-creator')
  async grantCreator(
    @Param('id') id: string,
    @Principal() actor: AuthenticatedPrincipal,
  ) {
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    await this.authorization.grantCapability(id, CapabilityType.CREATOR);
    await this.audit.log({
      actorId: actor.userId,
      action: 'ADMIN_GRANT_CREATOR',
      targetType: 'USER',
      targetId: id,
    });
    return { userId: id, capability: 'CREATOR', granted: true };
  }

  /** Revoke CREATOR capability from a user. */
  @Post('customers/:id/revoke-creator')
  async revokeCreator(
    @Param('id') id: string,
    @Principal() actor: AuthenticatedPrincipal,
  ) {
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    await this.authorization.revokeCapability(id, CapabilityType.CREATOR);
    await this.audit.log({
      actorId: actor.userId,
      action: 'ADMIN_REVOKE_CREATOR',
      targetType: 'USER',
      targetId: id,
    });
    return { userId: id, capability: 'CREATOR', revoked: true };
  }

  /** Promote a user to SUPER_ADMIN role. */
  @Post('customers/:id/promote')
  async promoteToAdmin(
    @Param('id') id: string,
    @Principal() actor: AuthenticatedPrincipal,
  ) {
    const user = await this.identity.findUserById(id);
    if (!user) throw new NotFoundException('کاربر یافت نشد.');
    await this.identity.updateUserRole(id, 'SUPER_ADMIN');
    await this.audit.log({
      actorId: actor.userId,
      action: 'ADMIN_PROMOTE_TO_ADMIN',
      targetType: 'USER',
      targetId: id,
    });
    return { userId: id, role: 'SUPER_ADMIN', updated: true };
  }

  // ─── Khatm management ──────────────────────────────────────────────────────

  @Get('khatms')
  async listKhatms(
    @Query('limit') limitStr?: string,
    @Query('offset') offsetStr?: string,
    @Query('status') status?: string,
  ) {
    const limit = Math.min(parseInt(limitStr ?? '50', 10) || 50, 200);
    const offset = parseInt(offsetStr ?? '0', 10) || 0;
    const khatms = await this.khatms.listAllKhatms(limit, offset);
    const filtered = status ? khatms.filter((k) => k.status === status) : khatms;
    return filtered.map((k) => ({
      id: k.id,
      title: k.title,
      status: k.status,
      templateType: k.templateType,
      khatmType: k.khatmType,
      creatorUserId: k.creatorUserId,
      createdAt: k.createdAt,
    }));
  }

  @Get('khatms/:id')
  async getKhatm(@Param('id') id: string) {
    const khatm = await this.khatms.findKhatmById(id);
    if (!khatm) throw new NotFoundException('ختم یافت نشد.');
    return {
      id: khatm.id,
      title: khatm.title,
      description: khatm.description,
      status: khatm.status,
      templateType: khatm.templateType,
      khatmType: khatm.khatmType,
      creatorUserId: khatm.creatorUserId,
      createdAt: khatm.createdAt,
    };
  }

  // ─── Audit logs ────────────────────────────────────────────────────────────

  @Get('audit')
  async getAuditLog(
    @Query('limit') limitStr?: string,
    @Query('offset') offsetStr?: string,
  ) {
    const limit = Math.min(parseInt(limitStr ?? '50', 10) || 50, 200);
    const offset = parseInt(offsetStr ?? '0', 10) || 0;
    return this.audit.list(limit, offset);
  }
}
