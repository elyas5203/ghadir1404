import { Inject, Injectable, Optional } from '@nestjs/common';
import { newUuidV7 } from '@khatmsaz/kernel';
import { zarinpalConfig } from '@khatmsaz/config';
import { IdentityService } from '../../identity/application/identity.service';
import { Platform } from '../../identity/domain/platform';
import type { AuthenticatedPrincipal } from '../../session/domain/authenticated-principal';
import { KhatmWorkflowService } from '../../khatm-workflow/application/khatm-workflow.service';
import { KhatmService } from '../../khatm/application/khatm.service';
import { InvitationService } from '../../invitation/application/invitation.service';
import { WalletService } from '../../payment/application/wallet.service';
import { UserSettingsService } from '../../user-settings/application/user-settings.service';
import { ZarinpalService } from '../../payment/infrastructure/zarinpal.service';
import {
  PAYMENT_INTENT_REPOSITORY,
  type PaymentIntentRepository,
} from '../../payment/domain/payment-intent.repository';
import { isKhatmTemplateType } from '../../khatm/domain/khatm-template';
import type { KhatmTemplateType } from '../../khatm/domain/khatm-template';
import { KhatmType } from '../../khatm/domain/khatm-type';
import type { PlanSpec } from '../../allocation/domain/plan-spec';
import {
  parseCommand,
  TelegramCommandName,
  BUTTON_TO_COMMAND,
  BUTTON_LABELS,
} from '../../telegram/domain/telegram-command';
import type { ParsedCommand } from '../../telegram/domain/telegram-command';
import type {
  CallbackReply,
  TelegramCallbackQuery,
  TelegramReply,
  TelegramUpdate,
} from '../../telegram/domain/telegram-message';
import { WIZARD_STATE, InMemoryWizardStateStore, type WizardStateStore } from '../../telegram/application/wizard-state.service';
import type { SessionState, WizardDraft } from '../../telegram/application/wizard-state.types';

// ─── Template categorisation ─────────────────────────────────────────────────

const COMMITMENT_TEMPLATES: readonly KhatmTemplateType[] = [
  'QURAN_FULL',
  'QURAN_JUZ',
  'QURAN_PAGE',
  'QURAN_SURAH',
];

const EDITION_PAGES: Record<string, number> = {
  MADINA_HAFS: 604,
  IRAN_SIMPLE: 560,
  IRAN_POCKET: 286,
};

/**
 * Bale channel command service. Uses Platform.BALE for identity resolution;
 * all business logic is shared with the Telegram command service through the
 * same application services. Only the Platform constant differs (DEC-0057, DEC-0058).
 */
@Injectable()
export class BaleCommandService {
  private readonly store: WizardStateStore;

  constructor(
    private readonly identity: IdentityService,
    private readonly workflow: KhatmWorkflowService,
    private readonly khatms: KhatmService,
    private readonly invitations: InvitationService,
    private readonly wallet: WalletService,
    private readonly settingsSvc: UserSettingsService,
    @Optional() private readonly zarinpal?: ZarinpalService,
    @Optional() @Inject(PAYMENT_INTENT_REPOSITORY) private readonly intents?: PaymentIntentRepository,
    @Optional() @Inject(WIZARD_STATE) storeOverride?: WizardStateStore,
  ) {
    this.store = storeOverride ?? new InMemoryWizardStateStore();
  }

  async handle(update: TelegramUpdate): Promise<TelegramReply> {
    try {
      const parsedForCheck = parseCommand(update.text);
      const isStart = parsedForCheck?.name === TelegramCommandName.START;
      if (!isStart) {
        const user = await this.identity.findUserByPlatformIdentity(
          Platform.BALE,
          update.fromId,
        );
        if (user && !user.isActive) return reply(REPLIES.accountInactive);
      }

      const isCancelButton = update.text === BUTTON_LABELS.CANCEL;
      if (isCancelButton) {
        await this.store.delete(update.chatId);
        return replyWithMenu(REPLIES.cancelled);
      }

      const wizardState = await this.store.get(update.chatId);
      if (wizardState) {
        return await this.advanceWizard(update, wizardState);
      }

      const buttonCommand = BUTTON_TO_COMMAND[update.text];
      const command = parsedForCheck;
      const commandName = buttonCommand ?? (command ? command.name : null);

      if (!commandName) return replyWithMenu(REPLIES.notACommand);

      switch (commandName) {
        case TelegramCommandName.START:    return await this.start(update);
        case TelegramCommandName.MENU:
          await this.store.delete(update.chatId);
          return await this.menu(update);
        case TelegramCommandName.MY_KHATMS: return await this.myKhatms(update);
        case TelegramCommandName.PROGRESS:  return await this.progress(update, command);
        case TelegramCommandName.JOIN:      return await this.join(update, command);
        case TelegramCommandName.LEAVE:     return await this.leave(update, command);
        case TelegramCommandName.PORTIONS:  return await this.portions(update, command);
        case TelegramCommandName.WALLET:    return await this.walletCmd(update);
        case TelegramCommandName.HELP:      return reply(REPLIES.help);
        case TelegramCommandName.SETTINGS:  return await this.settingsMain(update);
        case TelegramCommandName.SUPPORT:   return this.supportStart(null);
        case 'create_wizard':
        case TelegramCommandName.CREATE_KHATM:
          return await this.startCreateWizard(update, command);
        default: return replyWithMenu(REPLIES.unknownCommand);
      }
    } catch (error) {
      return reply(describeError(error));
    }
  }

  async handleCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    try {
      const d = query.data;
      if (d === 'WIZARD_CANCEL') {
        await this.store.delete(query.chatId ?? query.fromId);
        return { toast: 'لغو شد.', text: REPLIES.cancelled };
      }
      if (d === 'NO_NIYYAT') return await this.wizardFinishNiyyat(query, null);
      if (d.startsWith('TEMPLATE:')) return await this.wizardTemplateCallback(query);
      if (d.startsWith('EDITION:')) return await this.wizardEditionCallback(query);
      if (d.startsWith('KHATM_INVITE:')) return await this.inviteCallback(query);
      if (d.startsWith('KHATM_PORTIONS:')) return await this.portionsCallback(query);
      if (d.startsWith('KHATM_PROGRESS:')) return await this.progressCallback(query);
      if (d.startsWith('KHATM_LEAVE:')) return await this.leaveCallback(query);
      if (d.startsWith('KHATM_CLOSE:')) return await this.closeCallback(query);
      if (d.startsWith('DONE:')) return await this.doneCallback(query);
      if (d.startsWith('JOIN:')) return await this.joinCallback(query);
      if (d === 'WALLET_TOPUP') return this.walletTopupOptions();
      if (d.startsWith('WALLET_TOPUP_AMOUNT:')) return await this.walletCreatePaymentCallback(query);
      return { toast: 'دستور نامشخص.' };
    } catch (error) {
      return { toast: describeError(error) };
    }
  }

  // ─── Wizard: text input advancement ────────────────────────────────────────

  private async advanceWizard(
    update: TelegramUpdate,
    state: SessionState,
  ): Promise<TelegramReply> {
    const chatId = update.chatId;
    const text = update.text.trim();

    switch (state.step) {
      case 'create:template': {
        return { text: 'لطفاً یک نوع ختم را از صفحه‌کلید بالا انتخاب کنید.', inlineKeyboard: TEMPLATE_KEYBOARD };
      }

      case 'create:title': {
        if (text.length < 2 || text.length > 120) {
          return reply('عنوان باید بین ۲ تا ۱۲۰ کاراکتر باشد. دوباره وارد کنید:');
        }
        const template = state.template;
        if (template === 'QURAN_PAGE') {
          await this.store.set(chatId, { step: 'create:edition', title: text });
          return { text: 'نسخه قرآن را انتخاب کنید:', inlineKeyboard: EDITION_KEYBOARD };
        }
        if (template === 'QURAN_SURAH') {
          await this.store.set(chatId, { step: 'create:surah_num', title: text });
          return { text: 'شماره سوره را وارد کنید (۱ تا ۱۱۴):', replyKeyboard: CANCEL_KEYBOARD };
        }
        if (template === 'SALAWAT' || template === 'DUA' || template === 'ZIYARAT' || template === 'CUSTOM') {
          await this.store.set(chatId, { step: 'create:quantity', title: text, template });
          return { text: 'تعداد کل را وارد کنید (مثلاً ۱۰۰۰):', replyKeyboard: CANCEL_KEYBOARD };
        }
        await this.store.set(chatId, {
          step: 'create:niyyat',
          draft: { templateType: template, title: text },
        });
        return { text: 'نیت ختم را بنویسید یا «بدون نیت» را بزنید:', replyKeyboard: NIYYAT_KEYBOARD };
      }

      case 'create:edition': {
        return { text: 'لطفاً نسخه قرآن را از صفحه‌کلید بالا انتخاب کنید.', inlineKeyboard: EDITION_KEYBOARD };
      }

      case 'create:surah_num': {
        const n = parsePositiveInt(text);
        if (n === null || n < 1 || n > 114) {
          return reply('عدد معتبری بین ۱ تا ۱۱۴ وارد کنید:');
        }
        await this.store.set(chatId, { step: 'create:repetition', title: state.title, surahNumber: n });
        return { text: 'هدف تعداد تلاوت (برای تمام گروه) را وارد کنید:', replyKeyboard: CANCEL_KEYBOARD };
      }

      case 'create:repetition': {
        const n = parsePositiveInt(text);
        if (n === null || n < 1) {
          return reply('یک عدد مثبت وارد کنید:');
        }
        await this.store.set(chatId, {
          step: 'create:niyyat',
          draft: {
            templateType: 'QURAN_SURAH',
            title: state.title,
            surahNumber: state.surahNumber,
            repetitionTarget: n,
          },
        });
        return { text: 'نیت ختم را بنویسید یا «بدون نیت» را بزنید:', replyKeyboard: NIYYAT_KEYBOARD };
      }

      case 'create:quantity': {
        const n = parsePositiveInt(text);
        if (n === null || n < 1) {
          return reply('یک عدد مثبت وارد کنید:');
        }
        await this.store.set(chatId, {
          step: 'create:niyyat',
          draft: { templateType: state.template, title: state.title, quantity: n },
        });
        return { text: 'نیت ختم را بنویسید یا «بدون نیت» را بزنید:', replyKeyboard: NIYYAT_KEYBOARD };
      }

      case 'create:niyyat': {
        const niyyat = text.length > 0 ? text : null;
        await this.store.delete(chatId);
        return await this.finishCreation(update, { ...state.draft, niyyat });
      }

      case 'settings:reminder_hour': {
        const h = parsePositiveInt(text);
        if (h === null || h < 0 || h > 23) {
          return reply('ساعت باید بین ۰ تا ۲۳ باشد:');
        }
        await this.store.delete(chatId);
        const principal = await this.resolvePrincipal(update);
        if (!principal) return reply(REPLIES.pleaseStart);
        await this.settingsSvc.updateSettings(principal.userId, { reminderHour: h });
        return replyWithMenu(`ساعت یادآوری روی ${h}:۰۰ تنظیم شد.`);
      }
    }
  }

  // ─── Wizard: inline-keyboard callbacks ─────────────────────────────────────

  private async wizardTemplateCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const template = query.data.slice('TEMPLATE:'.length);
    if (!isKhatmTemplateType(template)) return { toast: 'نوع نامعتبر.' };
    const chatId = query.chatId ?? query.fromId;
    await this.store.set(chatId, { step: 'create:title', template: template as KhatmTemplateType });
    return {
      toast: `${TEMPLATE_LABELS[template as KhatmTemplateType] ?? template} انتخاب شد.`,
      text: 'عنوان ختم را بنویسید:',
      replyKeyboard: CANCEL_KEYBOARD,
    };
  }

  private async wizardEditionCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const editionId = query.data.slice('EDITION:'.length);
    if (!EDITION_PAGES[editionId]) return { toast: 'نسخه نامعتبر.' };
    const chatId = query.chatId ?? query.fromId;
    const state = await this.store.get(chatId);
    const title = state?.step === 'create:edition' ? state.title : '';
    await this.store.set(chatId, {
      step: 'create:niyyat',
      draft: { templateType: 'QURAN_PAGE', title, editionId },
    });
    return {
      toast: `${EDITION_LABELS[editionId] ?? editionId} انتخاب شد.`,
      text: 'نیت ختم را بنویسید یا «بدون نیت» را بزنید:',
      replyKeyboard: NIYYAT_KEYBOARD,
    };
  }

  private async wizardFinishNiyyat(
    query: TelegramCallbackQuery,
    niyyat: string | null,
  ): Promise<CallbackReply> {
    const chatId = query.chatId ?? query.fromId;
    const state = await this.store.get(chatId);
    if (!state || state.step !== 'create:niyyat') return { toast: 'وضعیت نامشخص. دوباره شروع کنید.' };
    await this.store.delete(chatId);
    const fakeUpdate: TelegramUpdate = { chatId, fromId: query.fromId, text: '' };
    const r = await this.finishCreation(fakeUpdate, { ...state.draft, niyyat });
    return { toast: 'ختم ایجاد شد.', text: r.text, replyKeyboard: MAIN_MENU };
  }

  // ─── Wizard: finish creation ────────────────────────────────────────────────

  private async finishCreation(update: TelegramUpdate, draft: WizardDraft): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);

    const isCommitment = (COMMITMENT_TEMPLATES as readonly string[]).includes(draft.templateType);
    const khatm = await this.workflow.createKhatm({
      creatorUserId: principal.userId,
      title: draft.title,
      templateType: draft.templateType,
      khatmType: isCommitment ? KhatmType.COMMITMENT : KhatmType.OPEN,
      quranEditionId: draft.editionId ?? null,
      surahNumber: draft.surahNumber ?? null,
      repetitionTarget: draft.repetitionTarget ?? null,
      description: draft.niyyat ?? null,
    });

    if (isCommitment) {
      const spec = computePlanSpec(draft);
      await this.workflow.generateAllocationPlan(khatm.id, principal.userId, spec);
    }
    await this.workflow.activateKhatm(khatm.id, principal.userId);

    const { token } = await this.invitations.createInvitation(khatm.id, principal.userId);

    return {
      text: REPLIES.khatmLive(khatm.title, token),
      replyKeyboard: MAIN_MENU,
    };
  }

  // ─── Private command handlers ───────────────────────────────────────────────

  private async start(update: TelegramUpdate): Promise<TelegramReply> {
    await this.store.delete(update.chatId);
    const existing = await this.identity.findUserByPlatformIdentity(Platform.BALE, update.fromId);
    if (existing) return { text: REPLIES.welcomeBack, replyKeyboard: MAIN_MENU };
    const user = await this.identity.createUser();
    await this.identity.attachPlatformIdentity(user.id, Platform.BALE, update.fromId);
    return { text: REPLIES.welcomeNew, replyKeyboard: MAIN_MENU };
  }

  private async menu(update: TelegramUpdate): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    return { text: REPLIES.menuHeader, replyKeyboard: MAIN_MENU };
  }

  private async startCreateWizard(
    update: TelegramUpdate,
    command: ParsedCommand | null,
  ): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);

    if (command && command.args.length >= 2) {
      const template = command.args[0]?.toUpperCase() ?? '';
      const title = command.args.slice(1).join(' ').trim();
      if (isKhatmTemplateType(template) && title.length > 0) {
        const draft: WizardDraft = { templateType: template as KhatmTemplateType, title, niyyat: null };
        return await this.finishCreation(update, draft);
      }
      return reply(REPLIES.createUsage);
    }

    await this.store.set(update.chatId, { step: 'create:template' });
    return {
      text: 'نوع ختم را انتخاب کنید:',
      inlineKeyboard: TEMPLATE_KEYBOARD,
      replyKeyboard: CANCEL_KEYBOARD,
    };
  }

  private async myKhatms(update: TelegramUpdate): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);

    const [created, joined] = await Promise.all([
      this.khatms.listKhatmsByCreator(principal.userId),
      this.workflow.listMyKhatms(principal.userId),
    ]);

    if (created.length === 0 && joined.length === 0) {
      return { text: REPLIES.noKhatms, replyKeyboard: MAIN_MENU };
    }

    const lines: string[] = [];
    const inlineRows: { text: string; callbackData: string }[][] = [];

    if (created.length > 0) {
      lines.push('📖 <b>ختم‌هایی که ساخته‌اید:</b>');
      for (const k of created) {
        lines.push(`• ${k.title} — ${STATUS_FA[k.status] ?? k.status}`);
        const row: { text: string; callbackData: string }[] = [];
        if (k.status === 'ACTIVE') {
          row.push({ text: '📨 دعوت‌نامه', callbackData: `KHATM_INVITE:${k.id}` });
          row.push({ text: '✅ پایان ختم', callbackData: `KHATM_CLOSE:${k.id}` });
        }
        if (row.length > 0) inlineRows.push(row);
      }
    }

    if (joined.length > 0) {
      if (lines.length > 0) lines.push('');
      lines.push('🤲 <b>ختم‌هایی که عضو هستید:</b>');
      for (const k of joined) {
        lines.push(`• ${k.title} — ${STATUS_FA[k.status] ?? k.status}`);
        inlineRows.push([
          { text: '📋 بخش‌هایم', callbackData: `KHATM_PORTIONS:${k.id}` },
          { text: '📊 پیشرفت', callbackData: `KHATM_PROGRESS:${k.id}` },
          { text: '🚪 خروج', callbackData: `KHATM_LEAVE:${k.id}` },
        ]);
      }
    }

    return {
      text: lines.join('\n'),
      inlineKeyboard: inlineRows.length > 0 ? inlineRows : undefined,
    };
  }

  private async join(update: TelegramUpdate, command: ParsedCommand | null): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const token = command?.args[0];
    if (!token) return reply(REPLIES.joinUsage);
    const result = await this.invitations.acceptInvitation(token, principal.userId);
    if (result.participationId) await this.autoAllocate(result.khatmId, result.participationId);
    return reply(REPLIES.joined(result.khatmId));
  }

  private async leave(update: TelegramUpdate, command: ParsedCommand | null): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const khatmId = command?.args[0];
    if (!khatmId) {
      const joined = await this.workflow.listMyKhatms(principal.userId);
      if (joined.length === 0) return replyWithMenu(REPLIES.noKhatms);
      const rows = joined.map((k) => [{ text: `${k.title}`, callbackData: `KHATM_LEAVE:${k.id}` }]);
      return { text: 'از کدام ختم خارج شوید؟', inlineKeyboard: rows };
    }
    await this.workflow.leaveKhatm(khatmId, principal.userId);
    return replyWithMenu(REPLIES.left);
  }

  private async progress(update: TelegramUpdate, command: ParsedCommand | null): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const khatmId = command?.args[0];
    if (!khatmId) {
      const khatms = await this.workflow.listMyKhatms(principal.userId);
      if (khatms.length === 0) return replyWithMenu(REPLIES.noKhatms);
      const lines = ['<b>پیشرفت ختم‌های شما:</b>', ''];
      for (const k of khatms) {
        const p = await this.workflow.progress(k.id);
        const pct = p.total > 0 ? Math.round((p.completed / p.total) * 100) : 0;
        lines.push(`📖 ${k.title}`);
        lines.push(`${progressBar(pct)} ${pct}٪`);
        lines.push(`تمام‌شده: ${p.completed} از ${p.total}`);
        lines.push('');
      }
      return reply(lines.join('\n'));
    }
    const p = await this.workflow.progress(khatmId);
    const remaining = p.open + p.assigned;
    const pct = p.total > 0 ? Math.round((p.completed / p.total) * 100) : 0;
    return reply(REPLIES.progressDetail(p.total, p.completed, remaining, pct, progressBar(pct)));
  }

  private async portions(update: TelegramUpdate, command: ParsedCommand | null): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const khatmId = command?.args[0];
    if (!khatmId) {
      const joined = await this.workflow.listMyKhatms(principal.userId);
      if (joined.length === 0) return replyWithMenu(REPLIES.noKhatms);
      const rows = joined.map((k) => [{ text: `📋 ${k.title}`, callbackData: `KHATM_PORTIONS:${k.id}` }]);
      return { text: 'بخش‌های کدام ختم را ببینید؟', inlineKeyboard: rows };
    }
    return await this.portionsForKhatm(update, khatmId);
  }

  private async portionsForKhatm(update: TelegramUpdate, khatmId: string): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const portions = await this.workflow.listMyPortions(khatmId, principal.userId);
    if (portions.length === 0) return reply(REPLIES.noPortions);

    const lines = ['<b>بخش‌های شما:</b>', ''];
    for (const pt of portions) {
      const status = pt.status === 'COMPLETED' ? '✅' : pt.status === 'ASSIGNED' ? '⏳' : '○';
      const label =
        pt.spec.kind === 'POSITIONAL'
          ? `${pt.spec.unitStart} تا ${pt.spec.unitEnd}`
          : `${pt.spec.quantity} عدد`;
      lines.push(`${status} ${label}`);
    }

    const hasAssigned = portions.some((p) => p.status === 'ASSIGNED');
    if (hasAssigned) {
      return {
        text: lines.join('\n'),
        inlineKeyboard: [[{ text: '✅ ثبت انجام همه بخش‌ها', callbackData: `DONE:${khatmId}` }]],
      };
    }
    return reply(lines.join('\n'));
  }

  private async walletCmd(update: TelegramUpdate): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const balance = await this.wallet.getBalance(principal.userId);
    const hasPayment = !!(this.zarinpal && this.intents);
    return {
      text: REPLIES.walletInfo(balance.balance, balance.credit),
      inlineKeyboard: hasPayment
        ? [[{ text: '💳 شارژ کیف‌پول', callbackData: 'WALLET_TOPUP' }]]
        : undefined,
    };
  }

  private walletTopupOptions(): CallbackReply {
    return {
      toast: 'مبلغ شارژ را انتخاب کنید:',
      text: 'مبلغ مورد نظر برای شارژ کیف‌پول را انتخاب کنید:',
      inlineKeyboard: [
        [{ text: '۱۰,۰۰۰ تومان', callbackData: 'WALLET_TOPUP_AMOUNT:10000' }],
        [{ text: '۵۰,۰۰۰ تومان', callbackData: 'WALLET_TOPUP_AMOUNT:50000' }],
        [{ text: '۲۰۰,۰۰۰ تومان', callbackData: 'WALLET_TOPUP_AMOUNT:200000' }],
      ],
    };
  }

  private async walletCreatePaymentCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    if (!this.zarinpal || !this.intents) {
      return { toast: 'درگاه پرداخت در حال حاضر در دسترس نیست.' };
    }
    const amountStr = query.data.slice('WALLET_TOPUP_AMOUNT:'.length);
    const amount = parseInt(amountStr, 10);
    if (!amount || amount < 1000) return { toast: 'مبلغ نامعتبر.' };

    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: REPLIES.pleaseStart };

    try {
      const cfg = zarinpalConfig();
      const callbackUrl = `${cfg.callbackBaseUrl}/payment/verify`;
      const { paymentUrl, authority } = await this.zarinpal.createPayment(
        user.id,
        amount,
        `شارژ کیف‌پول — ${amount.toLocaleString('fa-IR')} تومان`,
        callbackUrl,
      );
      await this.intents.create({
        id: newUuidV7(),
        userId: user.id,
        authority,
        amountToman: amount,
        description: `شارژ کیف‌پول — ${amount} تومان`,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      });
      return {
        toast: 'لینک پرداخت ساخته شد.',
        text: REPLIES.paymentLink(amount, paymentUrl),
      };
    } catch {
      return { toast: 'ایجاد پرداخت ناموفق بود. دوباره تلاش کنید.' };
    }
  }

  private async settingsMain(update: TelegramUpdate): Promise<TelegramReply> {
    const principal = await this.resolvePrincipal(update);
    if (!principal) return reply(REPLIES.pleaseStart);
    const s = await this.settingsSvc.getSettings(principal.userId);
    const lines = [
      '<b>تنظیمات شما:</b>',
      '',
      `⏰ ساعت یادآوری: ${s.reminderHour}:${String(s.reminderMinute).padStart(2, '0')}`,
      `📳 یادآوری پیامکی: ${s.smsEnabled ? 'فعال' : 'غیرفعال'}`,
      '',
      'برای تغییر ساعت یادآوری، عدد ساعت را بنویسید:',
    ];
    await this.store.set(update.chatId, { step: 'settings:reminder_hour' });
    return { text: lines.join('\n'), replyKeyboard: CANCEL_KEYBOARD };
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  private supportStart(_unused: unknown): TelegramReply {
    return reply(
      'برای ارتباط با پشتیبانی، پیام خود را به آدرس زیر ارسال کنید:\n\nاگر سوال یا مشکلی دارید، در گروه پشتیبانی مطرح کنید.',
    );
  }

  // ─── Inline-keyboard callbacks ──────────────────────────────────────────────

  private async inviteCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('KHATM_INVITE:'.length);
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: REPLIES.pleaseStart };
    const { token } = await this.invitations.createInvitation(khatmId, user.id);
    return { toast: 'دعوت‌نامه ساخته شد.', text: REPLIES.inviteCreated(token) };
  }

  private async portionsCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('KHATM_PORTIONS:'.length);
    const fakeUpdate: TelegramUpdate = { chatId: query.chatId ?? query.fromId, fromId: query.fromId, text: '' };
    const result = await this.portionsForKhatm(fakeUpdate, khatmId);
    return { toast: 'بخش‌های شما:', text: result.text, inlineKeyboard: result.inlineKeyboard };
  }

  private async progressCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('KHATM_PROGRESS:'.length);
    const p = await this.workflow.progress(khatmId);
    const remaining = p.open + p.assigned;
    const pct = p.total > 0 ? Math.round((p.completed / p.total) * 100) : 0;
    return { toast: `${pct}٪ تکمیل شده`, text: REPLIES.progressDetail(p.total, p.completed, remaining, pct, progressBar(pct)) };
  }

  private async leaveCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('KHATM_LEAVE:'.length);
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: REPLIES.pleaseStart };
    await this.workflow.leaveKhatm(khatmId, user.id);
    return { toast: 'از ختم خارج شدید.', text: REPLIES.left };
  }

  private async closeCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('KHATM_CLOSE:'.length);
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: REPLIES.pleaseStart };
    await this.workflow.completeKhatm(khatmId, user.id);
    return { toast: 'ختم به پایان رسید.', text: 'ختم با موفقیت پایان یافت. جزاکم الله خیرا.' };
  }

  private async doneCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('DONE:'.length);
    if (!khatmId) return { toast: 'اطلاعات ناقص است.' };
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: 'ابتدا دستور /start را بفرستید.' };
    const completed = await this.workflow.completeAllMyPortions(khatmId, user.id);
    if (completed === 0) return { toast: 'بخش فعالی برای ثبت وجود ندارد.' };
    return { toast: 'ثبت شد.', text: `${completed} بخش با موفقیت ثبت شد. جزاکم الله خیرا.` };
  }

  private async joinCallback(query: TelegramCallbackQuery): Promise<CallbackReply> {
    const khatmId = query.data.slice('JOIN:'.length);
    if (!khatmId) return { toast: 'اطلاعات ناقص است.' };
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, query.fromId);
    if (!user) return { toast: 'ابتدا دستور /start را بفرستید.' };
    const participation = await this.workflow.joinKhatm(khatmId, user.id);
    await this.autoAllocate(khatmId, participation.id);
    return { toast: 'به ختم پیوستید.', text: REPLIES.joined(khatmId) };
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  private async autoAllocate(khatmId: string, participationId: string): Promise<void> {
    try {
      const khatm = await this.khatms.findKhatmById(khatmId);
      if (!khatm || khatm.khatmType !== KhatmType.COMMITMENT) return;
      await this.workflow.allocatePortions(khatmId, khatm.creatorUserId, participationId, 1);
    } catch {
      // best-effort
    }
  }

  private async resolvePrincipal(update: TelegramUpdate): Promise<AuthenticatedPrincipal | null> {
    const user = await this.identity.findUserByPlatformIdentity(Platform.BALE, update.fromId);
    return user ? { userId: user.id, sessionId: null } : null;
  }
}

// ─── Plan spec computation ───────────────────────────────────────────────────

function computePlanSpec(draft: WizardDraft): PlanSpec {
  switch (draft.templateType) {
    case 'QURAN_FULL':
    case 'QURAN_JUZ':
      return { kind: 'POSITIONAL', from: 1, to: 30 };
    case 'QURAN_PAGE':
      return { kind: 'POSITIONAL', from: 1, to: EDITION_PAGES[draft.editionId ?? ''] ?? 604 };
    case 'QURAN_SURAH':
      return { kind: 'QUANTITY', total: draft.repetitionTarget ?? 1, chunk: 1 };
    default: {
      const q = draft.quantity ?? 100;
      return { kind: 'QUANTITY', total: q, chunk: Math.max(1, Math.ceil(q / 10)) };
    }
  }
}

// ─── Static keyboards ────────────────────────────────────────────────────────

const MAIN_MENU = [
  [{ text: BUTTON_LABELS.MY_KHATMS }, { text: BUTTON_LABELS.CREATE }],
  [{ text: BUTTON_LABELS.PROGRESS }, { text: BUTTON_LABELS.WALLET }],
  [{ text: BUTTON_LABELS.SETTINGS }, { text: BUTTON_LABELS.HELP }],
];

const CANCEL_KEYBOARD = [[{ text: BUTTON_LABELS.CANCEL }]];
const NIYYAT_KEYBOARD = [[{ text: BUTTON_LABELS.NO_NIYYAT }], [{ text: BUTTON_LABELS.CANCEL }]];

const TEMPLATE_KEYBOARD = [
  [
    { text: 'قرآن کامل (۳۰ جزء)', callbackData: 'TEMPLATE:QURAN_FULL' },
    { text: 'یک جزء', callbackData: 'TEMPLATE:QURAN_JUZ' },
  ],
  [
    { text: 'صفحه به صفحه', callbackData: 'TEMPLATE:QURAN_PAGE' },
    { text: 'یک سوره', callbackData: 'TEMPLATE:QURAN_SURAH' },
  ],
  [
    { text: 'صلوات', callbackData: 'TEMPLATE:SALAWAT' },
    { text: 'دعا', callbackData: 'TEMPLATE:DUA' },
  ],
  [
    { text: 'زیارت', callbackData: 'TEMPLATE:ZIYARAT' },
    { text: 'آزاد', callbackData: 'TEMPLATE:CUSTOM' },
  ],
  [{ text: '🚫 لغو', callbackData: 'WIZARD_CANCEL' }],
];

const EDITION_KEYBOARD = [
  [{ text: 'مدینه (حفص) — ۶۰۴ صفحه', callbackData: 'EDITION:MADINA_HAFS' }],
  [{ text: 'ایران ساده — ۵۶۰ صفحه', callbackData: 'EDITION:IRAN_SIMPLE' }],
  [{ text: 'ایران جیبی — ۲۸۶ صفحه', callbackData: 'EDITION:IRAN_POCKET' }],
  [{ text: '🚫 لغو', callbackData: 'WIZARD_CANCEL' }],
];

const TEMPLATE_LABELS: Partial<Record<KhatmTemplateType, string>> = {
  QURAN_FULL: 'قرآن کامل', QURAN_JUZ: 'یک جزء', QURAN_PAGE: 'صفحه به صفحه',
  QURAN_SURAH: 'یک سوره', SALAWAT: 'صلوات', DUA: 'دعا', ZIYARAT: 'زیارت', CUSTOM: 'آزاد',
};

const EDITION_LABELS: Record<string, string> = {
  MADINA_HAFS: 'مدینه (حفص) ۶۰۴ صفحه', IRAN_SIMPLE: 'ایران ساده ۵۶۰ صفحه', IRAN_POCKET: 'ایران جیبی ۲۸۶ صفحه',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function reply(text: string): TelegramReply { return { text }; }
function replyWithMenu(text: string): TelegramReply { return { text, replyKeyboard: MAIN_MENU }; }
function progressBar(pct: number): string {
  const filled = Math.round(pct / 10);
  return '█'.repeat(filled) + '░'.repeat(10 - filled);
}
function parsePositiveInt(text: string): number | null {
  const n = parseInt(text.replace(/,/g, '').replace(/،/g, '').trim(), 10);
  return Number.isInteger(n) ? n : null;
}

const STATUS_FA: Record<string, string> = {
  DRAFT: 'پیش‌نویس', ACTIVE: 'فعال', COMPLETED: 'پایان‌یافته', CANCELLED: 'لغو شده',
};

const REPLIES = {
  notACommand: 'از منوی پایین یک گزینه انتخاب کنید یا /help را بفرستید.',
  unknownCommand: 'این دستور شناخته نشد. برای راهنما /help را بفرستید.',
  pleaseStart: 'ابتدا دستور /start را بفرستید.',
  menuHeader: 'از منو زیر انتخاب کنید:',
  welcomeNew: 'به ختم‌ساز خوش آمدید.\nبرای شروع، یک گزینه از منو انتخاب کنید.',
  welcomeBack: 'خوش آمدید. از منو زیر استفاده کنید.',
  cancelled: 'عملیات لغو شد.',
  accountInactive: 'حساب شما در حال حاضر محدود است. برای اطلاع بیشتر با پشتیبانی تماس بگیرید.',
  createUsage: 'برای ساخت ختم از منو گزینه «ساخت ختم» را انتخاب کنید.\nیا: /create_khatm <نوع> <عنوان>',
  khatmLive: (title: string, token: string) =>
    `ختم «${title}» ساخته و فعال شد.\n\nبرای دعوت دیگران:\n\n<code>/join ${token}</code>`,
  inviteCreated: (token: string) => `دعوت‌نامه ساخته شد.\n\n<code>/join ${token}</code>`,
  noKhatms: 'هنوز در ختمی عضو نیستید یا ختمی نساخته‌اید.',
  joinUsage: 'برای پیوستن با لینک دعوت:\n/join <توکن دعوت>',
  joined: (khatmId: string) =>
    `با موفقیت به ختم پیوستید.\n\nشناسه ختم: <code>${khatmId}</code>`,
  left: 'از ختم خارج شدید.',
  progressDetail: (total: number, completed: number, remaining: number, pct: number, bar: string) =>
    `<b>پیشرفت ختم</b>\n\n${bar} ${pct}٪\n\nتمام‌شده: ${completed}\nباقی‌مانده: ${remaining}\nمجموع بخش‌ها: ${total}`,
  noPortions: 'بخشی برای این ختم به شما تخصیص داده نشده است.',
  walletInfo: (balance: number, credit: number) =>
    `<b>کیف‌پول شما</b>\n\nموجودی: ${balance.toLocaleString('fa-IR')} تومان\nاعتبار: ${credit.toLocaleString('fa-IR')} تومان`,
  paymentLink: (amount: number, url: string) =>
    `برای شارژ ${amount.toLocaleString('fa-IR')} تومان روی لینک زیر کلیک کنید:\n\n${url}\n\nپس از پرداخت، موجودی کیف‌پولتان به‌روز می‌شود.`,
  help: `<b>راهنمای ختم‌ساز</b>

/start — شروع و ثبت‌نام
📖 ختم‌های من — مشاهده و مدیریت ختم‌ها
➕ ساخت ختم — ایجاد ختم جدید
/join <توکن> — پیوستن با لینک دعوت
💰 کیف‌پول — موجودی و شارژ
/help — این راهنما`,
};

function describeError(error: unknown): string {
  const name = error instanceof Error ? error.name : '';
  if (name === 'InactiveCreatorError' || name === 'InactiveParticipantError') return 'حساب شما فعال نیست.';
  if (name === 'CapabilityRequiredError') return 'برای ساخت ختم به مجوز نیاز دارید.';
  if (name === 'ResourceOwnershipError') return 'شما اجازه انجام این کار را ندارید.';
  if (name === 'DuplicateParticipationError') return 'شما پیش‌تر در این ختم عضو شده‌اید.';
  if (name === 'InvitationNotFoundError') return 'دعوت‌نامه یافت نشد یا نامعتبر است.';
  if (name === 'InvitationNotAcceptableError') return 'این دعوت‌نامه قابل استفاده نیست.';
  if (name === 'KhatmNotActiveError' || name === 'KhatmNotAllocatableError') return 'این ختم فعال نیست.';
  if (name === 'KhatmNotConfiguredError') return 'این ختم هنوز آماده نیست.';
  if (name === 'KhatmNotCompletableError') return 'هنوز همه بخش‌ها انجام نشده‌اند.';
  if (name === 'ParticipationNotActiveError' || name === 'ParticipationNotFoundError') return 'شما در این ختم عضو نیستید.';
  if (name.includes('NotFound')) return 'ختم موردنظر یافت نشد.';
  if (name === 'InvalidUuidV7Error' || name.startsWith('Invalid') || name.startsWith('Unknown')) return 'ورودی نامعتبر است.';
  return 'خطایی رخ داد. لطفاً دوباره تلاش کنید.';
}
