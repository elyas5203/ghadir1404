import { Injectable } from '@nestjs/common';
import { PhoneVerificationService } from '../../phone/application/phone-verification.service';
import { PhoneOwnershipConflictError } from '../../phone/domain/phone.errors';
import { IdentityService } from '../../identity/application/identity.service';
import { AuthenticationService } from './authentication.service';

/** A completed phone-first login: an opaque session plus who it belongs to. */
export interface PhoneLoginSession {
  readonly userId: string;
  /** Raw opaque session token — returned once; the caller decides how to transport it. */
  readonly token: string;
  readonly sessionId: string;
  readonly expiresAt: Date;
  /** True when this login created the account (first time this number was seen). */
  readonly isNewUser: boolean;
}

/**
 * Phone-first authentication orchestration (Phase 10, DEC-0066).
 *
 * The proper "sign in by phone" flow, needing NO caller-supplied user id:
 *   phone → request OTP → verify OTP → resolve existing user OR create → session.
 *
 * It composes the phone capability's USER-LESS possession proof, the identity
 * capability (to resolve/create the user), and the session capability (to mint an
 * opaque session). Phone verification stays separate from sessions, authentication
 * stays separate from authorization, and the Phone capability is only extended
 * (never rewritten). It reveals nothing about whether an account already existed.
 */
@Injectable()
export class PhoneAuthService {
  constructor(
    private readonly phone: PhoneVerificationService,
    private readonly identity: IdentityService,
    private readonly auth: AuthenticationService,
  ) {}

  /** Step 1: issue a login code for a phone number. Returns only the canonical E.164. */
  async requestLogin(phone: string): Promise<{ e164: string }> {
    const { e164 } = await this.phone.requestLoginCode(phone);
    return { e164 };
  }

  /**
   * Step 2: verify the code (possession proof), resolve or create the user, and mint
   * a session. A wrong/expired/exhausted code propagates the phone capability's
   * domain error unchanged.
   */
  async completeLogin(phone: string, code: string): Promise<PhoneLoginSession> {
    const { e164, region } = await this.phone.verifyLoginCode(phone, code);
    const { userId, isNewUser } = await this.resolveOrCreateUser(e164, region);
    const created = await this.auth.createSession(userId);
    return {
      userId,
      token: created.token,
      sessionId: created.session.id,
      expiresAt: created.session.expiresAt,
      isNewUser,
    };
  }

  private async resolveOrCreateUser(
    e164: string,
    region: string | null,
  ): Promise<{ userId: string; isNewUser: boolean }> {
    const ownerId = await this.phone.findVerifiedOwner(e164);
    if (ownerId) return { userId: ownerId, isNewUser: false };

    const user = await this.identity.createUser();
    try {
      await this.phone.establishVerifiedOwnership(user.id, e164, region);
      return { userId: user.id, isNewUser: true };
    } catch (error) {
      if (error instanceof PhoneOwnershipConflictError) {
        // A concurrent first login for this number won the ownership index; use it.
        const owner = await this.phone.findVerifiedOwner(e164);
        if (owner) return { userId: owner, isNewUser: false };
      }
      throw error;
    }
  }
}
