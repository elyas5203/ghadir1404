import { TelegramCommandService } from './telegram-command.service';
import type { IdentityService } from '../../identity/application/identity.service';
import type { KhatmWorkflowService } from '../../khatm-workflow/application/khatm-workflow.service';
import type { KhatmService } from '../../khatm/application/khatm.service';
import type { InvitationService } from '../../invitation/application/invitation.service';
import type { WalletService } from '../../payment/application/wallet.service';
import type { UserSettingsService } from '../../user-settings/application/user-settings.service';
import type { TelegramUpdate } from '../domain/telegram-message';

const FROM = '556677';
const update = (text: string): TelegramUpdate => ({ chatId: 'c1', fromId: FROM, text });

function make(overrides: {
  identity?: Partial<IdentityService>;
  workflow?: Partial<KhatmWorkflowService>;
  khatms?: Partial<KhatmService>;
  invitations?: Partial<InvitationService>;
  wallet?: Partial<WalletService>;
  settings?: Partial<UserSettingsService>;
}): { service: TelegramCommandService; calls: Record<string, unknown[]> } {
  const calls: Record<string, unknown[]> = {};
  const record = (name: string, value?: unknown) => {
    calls[name] = (calls[name] ?? []).concat([value]);
  };

  const identity = {
    findUserByPlatformIdentity: async () => ({ id: 'u1', isActive: true }),
    createUser: async () => {
      record('createUser');
      return { id: 'u-new', isActive: true };
    },
    attachPlatformIdentity: async (userId: unknown, platform: unknown, subject: unknown) =>
      record('attach', { userId, platform, subject }),
    ...overrides.identity,
  } as unknown as IdentityService;

  const workflow = {
    createKhatm: async (input: unknown) => {
      record('createKhatm', input);
      return { id: 'k1', title: (input as { title: string }).title, khatmType: 'COMMITMENT' } as never;
    },
    generateAllocationPlan: async () => ({} as never),
    activateKhatm: async () => undefined,
    progress: async () => ({ total: 30, open: 20, assigned: 5, completed: 5 }),
    listMyKhatms: async () => [],
    listMyPortions: async () => [],
    leaveKhatm: async () => undefined,
    completeAllMyPortions: async () => 0,
    allocatePortions: async () => [],
    ...overrides.workflow,
  } as unknown as KhatmWorkflowService;

  const khatms = {
    listKhatmsByCreator: async () => [],
    findKhatmById: async () => ({ id: 'k1', khatmType: 'COMMITMENT', creatorUserId: 'u1' } as never),
    ...overrides.khatms,
  } as unknown as KhatmService;

  const invitations = {
    acceptInvitation: async (token: unknown, userId: unknown) => {
      record('acceptInvitation', { token, userId });
      return { khatmId: 'k1', participationId: 'p1' };
    },
    createInvitation: async () => ({ invitation: {} as never, token: 'invite-tok' }),
    ...overrides.invitations,
  } as unknown as InvitationService;

  const wallet = {
    getBalance: async () => ({ userId: 'u1', balance: 0, credit: 0, currency: 'IRR' }),
    ...overrides.wallet,
  } as unknown as WalletService;

  const settings = {
    getSettings: async () => ({
      userId: 'u1',
      reminderHour: 9,
      reminderMinute: 0,
      timezone: 'Asia/Tehran',
      fontSize: 'NORMAL',
      preferredReciter: null,
      smsEnabled: false,
      city: null,
      province: null,
      gender: null,
      language: 'fa',
    }),
    updateSettings: async () => ({} as never),
    ...overrides.settings,
  } as unknown as UserSettingsService;

  return {
    service: new TelegramCommandService(identity, workflow, khatms, invitations, wallet, settings),
    calls,
  };
}

describe('TelegramCommandService', () => {
  it('guides the user when the text is not a command', async () => {
    const { service } = make({});
    const r = await service.handle(update('hi'));
    expect(r.text).toBeTruthy();
    expect(r.replyKeyboard).toBeDefined();
  });

  describe('/start', () => {
    it('provisions a new user + platform identity on first contact', async () => {
      const { service, calls } = make({ identity: { findUserByPlatformIdentity: async () => null } });
      const r = await service.handle(update('/start'));
      expect(calls.createUser).toHaveLength(1);
      expect(calls.attach?.[0]).toMatchObject({ userId: 'u-new', platform: 'TELEGRAM', subject: FROM });
      expect(r.text).toContain('خوش آمدید');
    });

    it('greets a returning user without creating one', async () => {
      const { service, calls } = make({});
      await service.handle(update('/start'));
      expect(calls.createUser).toBeUndefined();
    });
  });

  describe('/create_khatm', () => {
    it('creates, plans, activates and returns an invite token for a known user', async () => {
      const { service, calls } = make({});
      const r = await service.handle(update('/create_khatm QURAN_FULL ختم خانوادگی'));
      expect(calls.createKhatm?.[0]).toMatchObject({
        creatorUserId: 'u1',
        title: 'ختم خانوادگی',
        templateType: 'QURAN_FULL',
        khatmType: 'COMMITMENT',
      });
      expect(r.text).toContain('invite-tok');
    });

    it('shows usage for an invalid template', async () => {
      const { service, calls } = make({});
      expect((await service.handle(update('/create_khatm PRAYER x'))).text).toContain('نوع‌های مجاز');
      expect(calls.createKhatm).toBeUndefined();
    });

    it('starts the wizard when called without arguments', async () => {
      const { service } = make({});
      const r = await service.handle(update('/create_khatm'));
      expect(r.inlineKeyboard).toBeDefined();
      expect(r.text).toContain('نوع ختم');
    });

    it('asks an unknown user to /start first', async () => {
      const { service } = make({ identity: { findUserByPlatformIdentity: async () => null } });
      expect((await service.handle(update('/create_khatm DUA x'))).text).toContain('/start');
    });
  });

  describe('menu buttons', () => {
    it('routes "📖 ختم‌های من" button to my_khatms', async () => {
      const { service } = make({
        khatms: { listKhatmsByCreator: async () => [] },
        workflow: { listMyKhatms: async () => [] } as never,
      });
      const r = await service.handle(update('📖 ختم‌های من'));
      expect(r.text).toContain('هنوز');
    });

    it('routes "➕ ساخت ختم" button to creation wizard', async () => {
      const { service } = make({});
      const r = await service.handle(update('➕ ساخت ختم'));
      expect(r.inlineKeyboard).toBeDefined();
    });

    it('routes "❓ راهنما" button to help', async () => {
      const { service } = make({});
      const r = await service.handle(update('❓ راهنما'));
      expect(r.text).toContain('راهنما');
    });
  });

  describe('/my_khatms', () => {
    it('lists the user\'s khatms', async () => {
      const { service } = make({
        khatms: {
          listKhatmsByCreator: async () =>
            [{ id: 'k1', title: 'ختم', status: 'DRAFT' }] as never,
        },
      });
      expect((await service.handle(update('/my_khatms'))).text).toContain('ختم');
    });

    it('handles an empty list', async () => {
      const { service } = make({});
      expect((await service.handle(update('/my_khatms'))).text).toContain('هنوز');
    });
  });

  describe('/progress', () => {
    it('reports progress counts', async () => {
      const { service } = make({});
      const r = await service.handle(update('/progress k1'));
      expect(r.text).toContain('30');
      expect(r.text).toContain('باقی‌مانده');
    });
  });

  describe('/join', () => {
    it('accepts a valid invitation token and confirms the khatm id', async () => {
      const { service, calls } = make({});
      const r = await service.handle(update('/join abc-token-123'));
      expect(calls.acceptInvitation?.[0]).toMatchObject({ token: 'abc-token-123', userId: 'u1' });
      expect(r.text).toContain('k1');
    });

    it('shows usage when no token is provided', async () => {
      const { service } = make({});
      expect((await service.handle(update('/join'))).text).toContain('/join');
    });

    it('asks an unknown user to /start first', async () => {
      const { service } = make({ identity: { findUserByPlatformIdentity: async () => null } });
      expect((await service.handle(update('/join tok'))).text).toContain('/start');
    });

    it('returns a friendly message for an invalid or cancelled invitation', async () => {
      const { service } = make({
        invitations: {
          acceptInvitation: async () => {
            const e = new Error('InvitationNotAcceptableError') as Error & { name: string };
            e.name = 'InvitationNotAcceptableError';
            throw e;
          },
        },
      });
      expect((await service.handle(update('/join bad-tok'))).text).toContain('قابل استفاده نیست');
    });
  });

  it('handles an unknown command', async () => {
    const { service } = make({});
    expect((await service.handle(update('/frobnicate'))).text).toContain('شناخته نشد');
  });
});
