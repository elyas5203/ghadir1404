'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import type {
  KhatmListResponse,
  KhatmProgressResponse,
  KhatmSummary,
} from '@khatmsaz/contracts';
import { RequireAuth } from '../../components/require-auth';
import { useAuth } from '../../lib/auth-context';
import { ApiError } from '../../lib/api-error';
import { TEMPLATE_LABEL, TEMPLATE_ICON, STATUS_LABEL, KHATM_TYPE_LABEL } from '../../lib/labels';

export default function DashboardPage() {
  return (
    <RequireAuth>
      <Dashboard />
    </RequireAuth>
  );
}

function Dashboard() {
  const { logout, authed } = useAuth();
  const [createdKhatms, setCreatedKhatms] = useState<KhatmSummary[]>([]);
  const [joinedKhatms, setJoinedKhatms] = useState<KhatmSummary[]>([]);
  const [progresses, setProgresses] = useState<Record<string, KhatmProgressResponse>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const [created, joined] = await Promise.all([
        authed<KhatmListResponse>('/api/khatms'),
        authed<KhatmListResponse>('/api/me/khatms'),
      ]);
      setCreatedKhatms([...created.khatms]);
      setJoinedKhatms([...joined.khatms]);

      const allActiveIds = [
        ...created.khatms.filter((k) => k.status === 'ACTIVE').map((k) => k.id),
        ...joined.khatms.filter((k) => k.status === 'ACTIVE').map((k) => k.id),
      ];
      const progMap: Record<string, KhatmProgressResponse> = {};
      if (allActiveIds.length > 0) {
        const batch = await authed<Record<string, KhatmProgressResponse>>(
          `/api/khatms/batch-progress?ids=${allActiveIds.join(',')}`,
        ).catch(() => ({} as Record<string, KhatmProgressResponse>));
        Object.assign(progMap, batch);
      }
      setProgresses(progMap);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'بارگذاری ناموفق بود.');
    } finally {
      setLoading(false);
    }
  }, [authed]);

  useEffect(() => {
    void load();
  }, [load]);

  const isEmpty = !loading && createdKhatms.length === 0 && joinedKhatms.length === 0;

  return (
    <div className="page page-ambient">
      <header className="shell app-bar">
        <span className="wordmark">ختم‌ساز</span>
        <div className="app-bar-end">
          <button className="btn btn-ghost btn-sm" type="button" onClick={() => void logout()}>
            خروج
          </button>
        </div>
      </header>

      <main className="shell stack">
        {error ? (
          <div className="alert" role="alert">
            <span>{error}</span>
            <span style={{ marginInlineStart: 'var(--ks-space-3)' }}>
              <button className="btn btn-sm" type="button" onClick={() => void load()}>
                تلاش مجدد
              </button>
            </span>
          </div>
        ) : null}

        {isEmpty ? (
          <div className="onboarding-banner">
            <h2>خوش آمدید</h2>
            <p>
              ختم تازه‌ای بسازید یا با لینک دعوت به ختم یک گروه بپیوندید.
            </p>
            <div className="actions">
              <Link href="/khatms/create" className="btn btn-primary">
                ساخت ختم
              </Link>
            </div>
          </div>
        ) : null}

        <section className="panel">
          <div className="section-header">
            <h2>ختم‌های من</h2>
            <Link href="/khatms/create" className="btn btn-primary btn-sm">
              ختم تازه
            </Link>
          </div>

          {loading ? (
            <SkeletonCards />
          ) : createdKhatms.length === 0 ? (
            <div className="empty-state">
              <span className="empty-state-icon" aria-hidden="true">📖</span>
              <p className="empty-state-text">هنوز ختمی نساخته‌اید. با دکمهٔ بالا اولین ختم خود را بسازید.</p>
              <Link href="/khatms/create" className="btn btn-primary">ساخت اولین ختم</Link>
            </div>
          ) : (
            <div className="khatm-cards">
              {createdKhatms.map((k) => (
                <KhatmCard key={k.id} khatm={k} progress={progresses[k.id] ?? null} />
              ))}
            </div>
          )}
        </section>

        <section className="panel">
          <h2>ختم‌هایی که در آن شرکت دارم</h2>

          {loading ? (
            <SkeletonCards />
          ) : joinedKhatms.length === 0 ? (
            <div className="empty-state">
              <span className="empty-state-icon" aria-hidden="true">🔗</span>
              <p className="empty-state-text">
                هنوز در ختمی شرکت نکرده‌اید. از سازندهٔ ختم لینک دعوت بخواهید و آن را باز کنید.
              </p>
            </div>
          ) : (
            <div className="khatm-cards">
              {joinedKhatms.map((k) => (
                <KhatmCard key={k.id} khatm={k} progress={progresses[k.id] ?? null} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function SkeletonCards() {
  return (
    <div className="khatm-cards">
      {[1, 2].map((i) => (
        <div key={i} className="skeleton skeleton-card" />
      ))}
    </div>
  );
}

function KhatmCard({
  khatm,
  progress,
}: {
  khatm: KhatmSummary;
  progress: KhatmProgressResponse | null;
}) {
  const pct =
    progress && progress.total > 0
      ? Math.round((progress.completed / progress.total) * 100)
      : null;

  return (
    <Link href={`/khatms/${khatm.id}`} className="khatm-card">
      {/* emoji icon — visible on mobile as the leading visual */}
      <span aria-hidden="true" style={{ fontSize: '1.4rem', flexShrink: 0, lineHeight: 1 }}>
        {TEMPLATE_ICON[khatm.templateType]}
      </span>
      <div className="khatm-card-body">
        <div className="khatm-card-header">
          <span className="khatm-card-title">{khatm.title}</span>
          <span className={`badge${khatm.status === 'ACTIVE' ? ' badge-on' : khatm.status === 'COMPLETED' ? ' badge-primary' : ''}`}>
            {STATUS_LABEL[khatm.status]}
          </span>
        </div>
        <span className="khatm-card-meta">
          {TEMPLATE_LABEL[khatm.templateType]} · {KHATM_TYPE_LABEL[khatm.khatmType]}
          {pct !== null ? ` · ${pct}٪` : ''}
        </span>
        {pct !== null ? (
          <div className="progress-wrap" title={`${pct}٪ انجام‌شده`} style={{ marginBlockStart: 'var(--ks-space-1)' }}>
            <div className="progress-fill" style={{ inlineSize: `${pct}%` }} />
          </div>
        ) : null}
      </div>
    </Link>
  );
}
