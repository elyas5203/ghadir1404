/**
 * Khatm transport contracts — the SHAPE of data crossing the API/bot boundary.
 *
 * Contracts describe shapes only: no business rules, no validation policy, no
 * persistence concerns, and no domain-entity leakage (a Prisma model or a domain
 * class must never appear here). These types are the stable external surface the
 * HTTP API and (conceptually) any client depend on; the string unions mirror the
 * wire representation of the domain enums without importing them.
 */

/** Wire values of a khatm's participation model (mirrors the domain enum, DEC-0071). */
export type KhatmTypeDto = 'COMMITMENT' | 'OPEN';

export const KHATM_TYPES: readonly KhatmTypeDto[] = ['COMMITMENT', 'OPEN'];

/** Wire values of a khatm's content template (mirrors the domain enum). */
export type KhatmTemplateTypeDto =
  | 'QURAN_FULL'
  | 'QURAN_JUZ'
  | 'SURAH'
  | 'QURAN_PAGE'
  | 'QURAN_SURAH'
  | 'SALAWAT'
  | 'DUA'
  | 'ZIYARAT'
  | 'CUSTOM';

export const KHATM_TEMPLATE_TYPES: readonly KhatmTemplateTypeDto[] = [
  'QURAN_FULL',
  'QURAN_JUZ',
  'SURAH',
  'QURAN_PAGE',
  'QURAN_SURAH',
  'SALAWAT',
  'DUA',
  'ZIYARAT',
  'CUSTOM',
];

/** Wire values of a khatm's lifecycle status. */
export type KhatmStatusDto = 'DRAFT' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';

/** Wire values of a participation's status. */
export type ParticipationStatusDto = 'ACTIVE' | 'COMPLETED' | 'LEFT' | 'REMOVED';

/** Wire values of a portion's unit family. */
export type PortionUnitKindDto = 'POSITIONAL' | 'QUANTITY';

/**
 * Quran edition config embedded in a QURAN_PAGE khatm summary (QURAN-001).
 * Total pages drives page-based allocation and cycle computation.
 */
export interface QuranPageConfigDto {
  readonly quranEditionId: string;
  /** Edition display name (Persian). */
  readonly editionNameFa: string;
  readonly totalPages: number;
}

/**
 * Surah repetition config embedded in a QURAN_SURAH khatm summary (QURAN-001).
 * surahNumber is 1–114; repetitionTarget is the collective recitation goal.
 */
export interface QuranSurahConfigDto {
  readonly surahNumber: number;
  /** Surah display name (Persian). */
  readonly surahNameFa: string;
  readonly repetitionTarget: number;
}

/** A khatm as returned to clients (never a domain entity or Prisma row). */
export interface KhatmSummary {
  readonly id: string;
  readonly creatorUserId: string;
  readonly title: string;
  readonly description: string | null;
  readonly templateType: KhatmTemplateTypeDto;
  readonly khatmType: KhatmTypeDto;
  readonly status: KhatmStatusDto;
  /** Present only for QURAN_PAGE khatms. */
  readonly quranPageConfig?: QuranPageConfigDto | null;
  /** Present only for QURAN_SURAH khatms. */
  readonly quranSurahConfig?: QuranSurahConfigDto | null;
  /**
   * Optional collective target count — used by QURAN_SURAH (via quranSurahConfig) and
   * also by SALAWAT / DUA / ZIYARAT / CUSTOM when the creator sets a target.
   */
  readonly repetitionTarget?: number | null;
  /** ISO-8601 UTC timestamps. */
  readonly createdAt: string;
  readonly updatedAt: string;
}

/**
 * POST /api/khatms — create a khatm (DRAFT). The creator is the AUTHENTICATED
 * principal (Phase 6, DEC-0060) — it is no longer supplied in the body.
 *
 * QURAN_PAGE requires `quranEditionId`.
 * QURAN_SURAH requires `surahNumber` (1–114) and `repetitionTarget` (>0).
 */
export interface CreateKhatmRequest {
  readonly title: string;
  readonly description?: string | null;
  readonly templateType: KhatmTemplateTypeDto;
  readonly khatmType: KhatmTypeDto;
  /** Required when templateType === 'QURAN_PAGE'. */
  readonly quranEditionId?: string | null;
  /** Required when templateType === 'QURAN_SURAH'. Surah number 1–114. */
  readonly surahNumber?: number | null;
  /** Required when templateType === 'QURAN_SURAH'. Total collective repetitions ≥ 1. */
  readonly repetitionTarget?: number | null;
}

/** GET /api/quran/editions — list available Quran editions (QURAN-001). */
export interface QuranEditionDto {
  readonly id: string;
  readonly nameFa: string;
  readonly totalPages: number;
}

/** GET /api/quran/surahs — list all 114 surahs (QURAN-001). */
export interface SurahDto {
  readonly number: number;
  readonly nameFa: string;
}

/** GET /api/khatms/:id/open-progress — aggregate progress for OPEN khatms. */
export interface OpenProgressResponse {
  readonly khatmId: string;
  readonly totalContributed: number;
  readonly participantCount: number;
}

/** POST /api/khatms/:id/contributions — record a contribution in an OPEN khatm. */
export interface RecordContributionRequest {
  readonly amount: number;
  readonly note?: string | null;
}

export interface ContributionSummary {
  readonly id: string;
  readonly participationId: string;
  readonly amount: number;
  readonly note: string | null;
  readonly recordedAt: string;
}

/** GET /api/khatms/:id/my-contributions — the participant's own contributions. */
export interface MyContributionsResponse {
  readonly contributions: readonly ContributionSummary[];
}

/** GET /api/khatms — the authenticated principal's own created khatms. */
export interface KhatmListResponse {
  readonly khatms: readonly KhatmSummary[];
}

/** The allocation plan spec a client supplies (discriminated by `kind`). */
export type AllocationPlanSpecDto =
  | { readonly kind: 'POSITIONAL'; readonly from: number; readonly to: number }
  | { readonly kind: 'QUANTITY'; readonly total: number; readonly chunk: number };

/** POST /api/khatms/:id/plan — generate the allocation plan. */
export interface GenerateAllocationRequest {
  readonly spec: AllocationPlanSpecDto;
}

export interface GenerateAllocationResponse {
  readonly khatmId: string;
  readonly unitKind: PortionUnitKindDto;
  readonly totalPortions: number;
}

/**
 * POST /api/khatms/:id/join — the authenticated principal joins (Phase 6). No body
 * is required; the joining user is the principal.
 */
export interface JoinKhatmResponse {
  readonly participationId: string;
  readonly khatmId: string;
  readonly status: ParticipationStatusDto;
}

/** POST /api/khatms/:id/allocate — allocate open portions to a participant. */
export interface AllocatePortionsRequest {
  readonly participationId: string;
  readonly count: number;
}

export interface AllocatePortionsResponse {
  readonly assignedPortionIds: readonly string[];
}

/** POST /api/portions/:portionId/complete — the holder completes a portion. */
export interface CompletePortionRequest {
  readonly participationId: string;
}

/** GET /api/khatms/:id/progress — derived allocation progress (counts). */
export interface KhatmProgressResponse {
  readonly khatmId: string;
  readonly total: number;
  readonly open: number;
  readonly assigned: number;
  readonly completed: number;
}

/** A participation as returned to the khatm's creator (management view). */
export interface ParticipationSummary {
  readonly participationId: string;
  readonly userId: string;
  readonly status: ParticipationStatusDto;
  /** ISO-8601 UTC timestamp. */
  readonly joinedAt: string;
  /** The participant's chosen display name, or null when unset (Phase 14, DEC-0073). */
  readonly displayName: string | null;
}

/** GET /api/khatms/:id/participants — the khatm's participations (owner only). */
export interface KhatmParticipantsResponse {
  readonly participants: readonly ParticipationSummary[];
}

/** Stable error envelope for transport failures. `message` is safe (no secrets). */
export interface TransportErrorResponse {
  readonly error: {
    readonly code: string;
    readonly message: string;
  };
}
