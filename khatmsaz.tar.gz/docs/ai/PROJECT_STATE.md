# PROJECT_STATE

## Current state — 2026-09-13 — Sprint 5: Functional Bot Journeys

### What was done (Sprint 5)
- **Menu buttons now functional**: `BUTTON_LABELS` + `BUTTON_TO_COMMAND` map added to `telegram/domain/telegram-command.ts`. `ReplyKeyboard` button presses (plain text like "📖 ختم‌های من") are now routed to the correct command handlers in both Telegram and Bale services.
- **Khatm creation wizard (full journey)**: Multi-step in-memory wizard state machine in `TelegramCommandService` and `BaleCommandService`. Steps: template selection (inline keyboard) → title → template-specific fields (edition/surah/count) → niyyat → create + generate plan + activate + issue invite. Result is an ACTIVE khatm with a shareable `/join <token>` invite.
- **Auto plan + activation on creation**: `generateAllocationPlan` + `activateKhatm` called automatically during wizard completion and shorthand `/create_khatm TEMPLATE title` invocations.
- **Invitation generation from bot**: New `KHATM_INVITE:<id>` callback handler; shows shareable `/join <token>` message.
- **Context-aware khatm selection**: `/my_khatms`, `/progress`, `/leave`, `/portions` all show inline keyboards with per-khatm buttons — no UUID typing required. Creator khatms show "دعوت‌نامه" + "پایان ختم" buttons. Joined khatms show "بخش‌هایم" + "پیشرفت" + "خروج" buttons.
- **Ban enforcement at service level**: `handle()` checks `user.isActive` before processing any non-`/start` message; inactive users (WARNED/SUSPENDED/BANNED) receive a friendly block message.
- **Settings wizard**: `/settings` or "⚙️ تنظیمات" button shows current settings and prompts for `reminderHour`; saved via `UserSettingsService`.
- **Auto-allocation on join**: When a participant joins a COMMITMENT khatm (via `/join <token>` or `JOIN:` callback), 1 open portion is auto-allocated using the creator's userId — best-effort, failure silently ignored.
- **`KHATM_CLOSE:<id>` callback**: Creator can complete a khatm from "ختم‌های من" inline button.
- **`CallbackReply` extended**: Added `inlineKeyboard` + `replyKeyboard` fields; Telegram and Bale gateways forward them to `sender.send`.
- **`UserSettingsModule` imported** in both `TelegramModule` and `BaleModule`.
- **377 tests pass**. Typecheck / Lint / Build all PASS.

### Commands known to work
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

### Remaining / deferred
- Notification worker (BullMQ processor — seeds are enqueued but never processed).
- ZarinPal payment flow in bot (wallet shows balance only, no top-up).
- SMS reminder purchase flow in bot.
- Surah content delivery (Arabic text, audio).
- Admin template/content management UI.

---

## Previous state — 2026-09-13 — Sprint 4: Bot Completion + Admin Panel

### What was done (Sprint 4)
- **Web app disabled**: `apps/web/src/middleware.ts` (feature-flag gate `WEB_APP_ENABLED`), `apps/web/src/app/disabled/page.tsx` (Persian maintenance page).
- **Telegram + Bale bots — full command set**: `ReplyKeyboard` support in domain + both senders. Commands: `/start`, `/menu`, `/my_khatms` (created + joined), `/progress`, `/leave`, `/portions`, `/wallet`, `/help`, `/settings`, `/support`. Inline callback: `DONE:<id>`, `JOIN:<khatmId>`. `WalletService` injected. Both bots are mirrors.
- **SMS OTP wiring**: `SmsOtpDeliveryAdapter` bridges `SmsProvider` → `OtpDelivery`; `PhoneModule` selects: Kavenegar (if configured) → SMS adapter, else noop. No more stub.
- **User moderation**: WARNED/SUSPENDED/BANNED added to `user_status` enum (migration `20260913220000_admin_moderation`). `UserRepository.search/updateStatus/updateRole` added. `IdentityService.searchUsers/updateUserStatus/updateUserRole` added.
- **Audit logs**: `audit_logs` table (migration). `AuditService` with `log()`/`list()`. `AuditModule` imported by `AppModule` and `HttpApiModule`.
- **Admin controller expanded**: search users, set status (warn/suspend/ban/activate), grant/revoke CREATOR, promote to SUPER_ADMIN, set plan, list/detail khatms, audit log endpoint.
- **Admin panel (`apps/admin`) — fully built**: `middleware.ts` (cookie guard), `lib/` (api-client, api-error, auth-context), pages: `/login` (phone OTP), `/dashboard` (stats), `/customers` (list+search+pagination), `/customers/[id]` (detail+moderation actions), `/khatms` (list+filter), `/khatms/[id]` (detail), `/audit` (log), `AdminShell` component (topbar+sidebar+nav).
- **Tests fixed**: `FakeUserRepository` stubs updated in 2 spec files; `TelegramCommandService` test patched for new constructor signature and `listMyKhatms` mock.
- **373 tests pass**. Typecheck / Lint / Build all PASS.

### Commands known to work
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

### Remaining / deferred
- Admin library page (`/admin/library`) for approving custom khatm requests.
- Feature entitlement engine (connect `UserPlan` to actual limit enforcement).
- Notification template system.
- Khatm template library admin UI.

---

## Previous state — 2026-09-13 — Sprint 3: Security + Deploy (v1 LAUNCH READY)

### What was done (Sprint 3 additions)
- **Security — IDOR + Replay**: `PendingPayment` model added. `PaymentController.createPayment()` persists intent; `verifyPayment()` looks up stored `userId`+`amountToman` by authority, performs atomic CAS `markUsed()`. ZarinPal code 101 rejected. Session userId not used for charging.
- **Plan change**: `UserPlan` model + `PlanTier` enum. `PlanService.assignPlan()`. `AdminController.setCustomerPlan()` now persists.
- **DB migrations**: `20260913200000_add_pending_payment`, `20260913210000_add_user_plan`.
- **Docker**: `docker-compose.prod.yml`, `apps/api/Dockerfile`, `apps/web/Dockerfile` (Node 24 Alpine, npm workspaces, standalone Next.js). `apps/web/next.config.mjs` adds `output: 'standalone'`.
- **Seed script**: `apps/api/prisma/seed-admin.ts` promotes a user to SUPER_ADMIN by verified phone.
- **Health check**: already present at `/health` (liveness) and `/health/ready` (readiness).
- **373 tests pass**. Typecheck / Lint / Build / docker compose config: all PASS.

### What was done (Sprint 2)
- **FIX A**: `KhatmWorkflowService.leaveKhatm()` added; hooks `WaitingListService.promoteNext()` for COMMITMENT khatms.
- **FIX B**: `KhatmWorkflowService.activateKhatm()` now calls `NotificationService.onKhatmActivated()` after status transition.
- **FIX C**: `.env.example` updated with all sprint env vars (REDIS_URL, BALE_*, ZARINPAL_*, SMS_*, BASE_URL, NEXT_PUBLIC_TELEGRAM_BOT_USERNAME, KHATMSAZ_DEV_OTP).
- **FIX D**: `.ai-guide/INDEX.md` updated with sprint 2 start entry and expanded Key Services table.
- **Phase 06 — Admin Dashboard (backend)**: `UserRole` enum (`USER | SUPER_ADMIN`) added to schema + migration (`20260913100000_add_user_role`). `role` field added to `User` domain entity + mapper. `listAll`/`countAll` added to both `UserRepository` and `KhatmRepository` (interfaces + Prisma impls + service methods). `AdminGuard` checks SUPER_ADMIN role. `AdminController` at `/admin/stats`, `/admin/customers`, `/admin/customers/:id`, `/admin/customers/:id/plan`, `/admin/khatms`. `PaymentController` moved to `HttpApiModule` (fixes SessionAuthGuard DI). `SmsModule` added to `AppModule`.
- **Phase 06 — Admin Dashboard (frontend)**: `apps/web/src/app/admin/` pages created: `layout.tsx` (role guard + nav), `page.tsx` (stats), `customers/page.tsx` (user table with pagination), `khatms/page.tsx` (khatm table with search + pagination). `MeResponse` contract extended with `role` field. `MeController` returns `role`.
- **Phase 08 — SMS System**: `SmsProvider` interface + `SMS_PROVIDER` token + `KavenegarSmsService` (no SDK — raw fetch, API key never logged) + `NoopSmsService` + `SmsModule` (config-gated). `packages/config/src/sms.ts` added with `smsConfig`/`smsEnabled`.
- **All 373 tests pass** (363 API + 10 web). Typecheck / Lint / Build all PASS.

### Commands known to work
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

### ENV vars added (not committed — update .env.example)
```
REDIS_URL=redis://localhost:6379
ZARINPAL_MERCHANT_ID=
ZARINPAL_SANDBOX=true
BALE_BOT_TOKEN=
BALE_WEBHOOK_SECRET=
BALE_API_BASE_URL=https://tapi.bale.ai
BASE_URL=https://your-domain.com
NEXT_PUBLIC_TELEGRAM_BOT_USERNAME=khatmsazbot
KHATMSAZ_DEV_OTP=1
SMS_PROVIDER=noop
KAVENEGAR_API_KEY=
KAVENEGAR_SENDER=10004346
```

### Pending / deferred
- Security fixes for `PaymentController`: IDOR (authority→userId mapping) + replay (idempotency on refId). Requires `PaymentIntent` table.
- SMS OTP integration: wire `SMS_PROVIDER` into OTP delivery adapter.
- Admin library page (`/admin/library`) for approving custom khatm requests (not yet in backend).
- Customer plan change (`POST /admin/customers/:id/plan`) is a stub — does not yet persist.

---

## Previous state — 2026-09-12 — Sprint: Foundation for Phases 01–07

### What was done
- **`.ai-guide/` folder** created with INDEX, FOLDER-MAP, RELATIONS, BUGS, ROADMAP, DECISIONS files.
- **DB schema additions** (`20260912140000_sprint_wallet_waiting_list_settings`): `NotificationJob`, `WaitingList`, `Wallet`, `WalletTransaction`, `UserSettings` models + 5 new enums (`NotifChannel`, `JobStatus`, `TxType`, `FontSize`, `Gender`). All additive, no existing tables altered.
- **DB schema addition** (`20260912150000_khatm_public_slug`): `publicSlug` and `niyyat` nullable columns on `khatms`; partial unique index on slug.
- **Khatm domain** (`khatm.ts`, `khatm.repository.ts`): `publicSlug`/`niyyat` added to `KhatmProps` (optional). `findBySlug()` added to repository interface + Prisma implementation. `KhatmService.findKhatmBySlug()` added.
- **BullMQ installed** (`bullmq`, `@nestjs/bullmq`, `ioredis`). `packages/config/src/redis.ts` added; `redisConfig`/`redisEnabled` exported.
- **NotificationModule** (Sprint Phase 01): `NOTIFICATION_SCHEDULER` port + `NoopNotificationScheduler` (no Redis) + `BullmqNotificationScheduler` (with Redis). Config-gated — no-op when `REDIS_URL` empty. `NotificationService` orchestration facade.
- **WaitingListModule** (Sprint Phase 02): `WaitingListService` + `PrismaWaitingListRepository` + 6 unit tests. `waitingListModule` wired into `app.module`.
- **PaymentModule** (Sprint Phase 03): `WalletService` + `PrismaWalletRepository` + `ZarinpalService` + `PaymentController`. `ZarinpalConfig` in `packages/config/src/zarinpal.ts`. Config-gated sandbox mode.
- **BaleModule** (Sprint Phase 04): `BaleCommandService` + `BaleGateway` + `BotApiBaleSender` / `NoopBaleSender` + `BaleWebhookController`. Mirrors TelegramModule; config-gated. `packages/config/src/bale.ts` added.
- **UserSettingsModule** (Sprint Phase 07): `UserSettingsService` + `PrismaUserSettingsRepository`. Lazy creation (missing row = defaults). `UserSettingsModule` wired into `app.module`.
- **Public khatm page** (`apps/web/src/app/khatm/[slug]/page.tsx`): server component, no auth; shows title, progress bar, niyyat, organizer, join-Telegram link. API endpoint `GET /public/khatm/:slug` added.
- **All 372 tests pass** (362 API + 10 web). Typecheck / Lint / Build all PASS.

### Commands known to work
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

### ENV vars added (not committed — update .env.example)
```
REDIS_URL=redis://localhost:6379
ZARINPAL_MERCHANT_ID=
ZARINPAL_SANDBOX=true
BALE_BOT_TOKEN=
BALE_WEBHOOK_SECRET=
BALE_API_BASE_URL=https://tapi.bale.ai
BASE_URL=https://your-domain.com
NEXT_PUBLIC_TELEGRAM_BOT_USERNAME=khatmsazbot
```

---

## Previous state — 2026-09-12 — QURAN-001 follow-up: optional target count for SALAWAT/DUA/ZIYARAT/CUSTOM

### What was done
- **`KhatmSummary` contract** (`packages/contracts/src/khatm.ts`): added top-level `repetitionTarget?: number | null` field so clients can read the target count for any khatm type.
- **`toKhatmSummary()` mapper** (`apps/api/src/http-api/khatm-view.mapper.ts`): always exposes `khatm.repetitionTarget` in the DTO; previously only surfaced via `quranSurahConfig`.
- **Create page** (`apps/web/src/app/khatms/create/page.tsx`): optional "هدف تعداد" input shown for SALAWAT/DUA/ZIYARAT/CUSTOM; submitted as `repetitionTarget` only when non-empty.
- **Detail page** (`apps/web/src/app/khatms/[id]/page.tsx`): shows "هدف: N بار" under the khatm header for non-QURAN_SURAH khatms when `repetitionTarget` is set; `defaultsForKhatm()` uses `repetitionTarget` to pre-fill plan generator defaults for count types.
- All validation: 366 tests pass (356 API + 10 web). Typecheck · Lint · Build all PASS.

---

## Previous state — 2026-09-12 — QURAN-001: Two new Quran khatm modes

### What was done
- **Two new `KhatmTemplateType` values** added (domain + DB enum): `QURAN_PAGE`, `QURAN_SURAH`.
- **Static Quran registries** in `packages/shared/src/quran/`:
  - `editions.ts` — 3 Quran editions with page counts (Madina Hafs 604p, Iran Simple 560p, Iran Pocket 286p).
  - `surahs.ts` — all 114 surahs with Persian names; `findSurah`, `isValidSurahNumber`.
  - Importable by both API and web (framework-free, DEC-0076).
- **Prisma migration** (`20260912100000_quran_modes`): adds `QURAN_PAGE`/`QURAN_SURAH` to enum; adds nullable columns `quran_edition_id`, `surah_number`, `repetition_target` with CHECK constraints on the khatms table.
- **Domain layer** (`khatm.ts`): `quranEditionId`, `surahNumber`, `repetitionTarget` fields on `KhatmProps`/`Khatm` entity; preserved across lifecycle transitions.
- **Infrastructure**: mapper (`khatm.mapper.ts`), repository (`prisma-khatm.repository.ts`), generated Prisma enum updated.
- **Application layer**: `KhatmService.createKhatm()` and `CreateKhatmWorkflowInput` accept the new optional fields.
- **HTTP transport**: `parseCreateKhatm()` validates edition id against static registry and surah number 1–114; `toKhatmSummary()` populates `quranPageConfig` / `quranSurahConfig` DTOs; `GET /api/quran/editions` and `GET /api/quran/surahs` reference endpoints (no auth).
- **Web UI** (`/khatms/create`): edition selector shown when QURAN_PAGE; surah selector + repetition target input shown when QURAN_SURAH.
- **Khatm detail page**: edition name / surah config displayed in header; `GeneratePlan` auto-fills defaults from config.
- **Labels** (`labels.ts`): all three label maps (`TEMPLATE_LABEL`, `TEMPLATE_ICON`, `TEMPLATE_EXPLAIN`) extended; Quran help texts updated; `'نوع قرائت'` help updated with new modes.
- **Tests**: 356 unit tests pass (added Quran registry tests, khatm-template spec updated 7→9, khatm.spec.ts QURAN-001 suite, khatm-requests.spec.ts QURAN_PAGE/QURAN_SURAH cases). Typecheck · Lint · Build all PASS.

### Commands known to work
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

---

## Previous state — 2026-09-12 — Phase 18: Telegram /join + Invitation no-expiry

- **Invitation no-expiry (DEC-0075):** `DEFAULT_INVITATION_TTL_SECONDS` changed to 100 years.
  Links remain valid until explicitly cancelled. Schema unchanged. Revocation still works.
- **`/join` Telegram command** added end-to-end:
  - `TelegramCommandName.JOIN` added to command enum.
  - `InvitationService` injected into `TelegramCommandService`; `join()` delegates to
    `invitations.acceptInvitation(token, userId)`.
  - `InvitationModule` imported into `TelegramModule`.
  - Error messages for `InvitationNotFoundError` and `InvitationNotAcceptableError` added.
  - `unknownCommand` reply updated to include `/join`.
- **Tests:** 3 new `/join` unit tests (happy path, missing token, invalid invitation).
  Telegram webhook integration test gains `/join` e2e case: Telegram user issues
  `/start`, then `/join <token>`, joins a live khatm, sender confirms khatm id.
  340 unit tests pass. Build / Lint / Typecheck all PASS.
- **Bot token configuration:** Token set in `apps/api/.env` (git-ignored). Webhook secret
  generated (`openssl rand -hex 32`). The security guard hook blocked any committed write.
- **Tunnel limitation:** `cloudflared` is installed but the WSL environment blocks direct
  outbound to `api.telegram.org`. `setWebhook` and real message delivery require a host
  with direct egress. Local inbound path is fully testable (supertest, capturing sender).

---

## Previous state — 2026-09-12 — Phase 17: Premium UI/UX Quality Pass

- **Design tokens** (`packages/ui/src/tokens.css`): custom easing curves (`--ks-ease-out/inout/spring`),
  touch-target floors (`--ks-touch-min` 44px, `--ks-touch-sm` 36px), `--ks-color-surface-raised`.
- **globals.css** comprehensive upgrade:
  - Form fields: `min-block-size: 48px`, `font-size: var(--ks-text-md)`, custom easing.
  - Buttons: `min-block-size: 44px` (`btn-sm`: 36px), spring active scale, custom easing throughout.
  - Field labels: full body color + weight 700 (not muted — readability for elderly users).
  - List rows: larger padding, `surface-raised` background, 44px min height.
  - Badges: weight 700, 1.5px border.
  - Alerts: larger padding, directional RTL accent stripe (`border-inline-start: 4px`).
  - Progress bar: 10px tall, RTL gradient (`to left`), `ease-out` transition.
  - HelpTip popover: `position: fixed` with JS-driven centering — no longer clips at viewport edge.
  - `.workflow-step` component: numbered step with circle indicator, done state (✓).
  - `.empty-state`: improved spacing and icon treatment.
- **HelpTip component** (`apps/web/src/components/help-tip.tsx`): JS `getBoundingClientRect`-based
  positioning, clamped to viewport on both edges, scrolls correctly in all parents.
- **Khatm detail DRAFT section** (`khatms/[id]/page.tsx`): replaced inline layout with
  `.workflow-steps` / `.workflow-step` pattern; step 1 shows ✓ when plan exists; activate button
  is disabled for COMMITMENT khatms until a plan is built.
- **Invitation accept page** (`invitations/accept/page.tsx`): skeleton loading state instead of text;
  clearer success/error copy in plain Persian.
- **347 tests pass.** Typecheck · lint · build all PASS.

---

## Previous state — 2026-09-12 — Phase 16: Core Journey Completion + UI Fixes

- **`POST :id/portions/:portionId/complete`** added to khatm controller.
  `completeMyPortion(khatmId, portionId, userId)` in workflow service resolves the
  participation by userId, then delegates to the holder-checked allocation completion.
  Two spec tests cover the happy path and the not-a-participant rejection.
- **Auto-CREATOR on `GET /api/me` (DEC-0074).** Every authenticated user is granted
  CREATOR on first touch — no extra call to `/become-creator` needed.
- **Dashboard cards** redesigned for mobile: single compact row (icon + title + badge + progress).
- **Khatm detail DRAFT workflow** reordered: plan form first, activate button second.
  `GeneratePlan` form is hidden once a plan exists (`progress.total > 0`), preventing
  the 409 Conflict error. 409 is also caught and translated to Persian as a safety net.
- **"انجام شد" button** shown for ASSIGNED portions in the participant view.
- **Allocate dropdown** shows `displayName` (not sequential index).
- **GeneratePlan smart defaults**: QURAN_FULL=30/1, SALAWAT=1000/100, others=10/1.
- **Type selector cards** fixed: RTL text overflow eliminated (CSS grid + overflow:hidden).
- **Login placeholder** changed to Persian digits (`۰۹×××××××××`), maxLength=11.
- **`PUT` added** to `authed` / `RequestOptions` method union.
- **347 tests pass.** Typecheck · lint · build all PASS.

---

## Previous state — 2026-09-12 — Phase 15: UI/UX Visual Overhaul

- **Vazirmatn now loaded from Google Fonts** via `<link>` in `layout.tsx`. Font was in CSS
  stack but not fetched — now loads weights 400–800 from `fonts.googleapis.com`.
- **Design tokens expanded:** gold/amber scale + glassmorphism tokens added to `tokens.css`
  (both light and dark variants). New: `--ks-gold-*`, `--ks-color-gold*`, `--ks-glass-*`,
  `--ks-blur-*`, `--ks-shadow-lg`.
- **globals.css full upgrade:** glassmorphism auth card + ambient gradient auth shell,
  gradient hero h1, sticky blurred app-bar, gradient primary button with shadow, improved
  hover/active states, wider glass help popover, better khatm cards (lift on hover),
  `page-ambient` utility, empty-state icons, `badge-primary`, `ks-note-gold`, `type-card-icon`.
- **labels.ts:** `TEMPLATE_ICON` (emoji) + `TEMPLATE_EXPLAIN` (one-liner per template)
  exported; `HELP_TEXT` expanded to 19 entries — simple, grandparent-friendly Persian.
- **Pages:** landing (emoji icons, ambient bg), dashboard (colored status badges, template icons,
  better empty states), create khatm (type-card icons, template explain, richer descriptions).
- **345 tests pass.** Typecheck · lint · build all PASS.
- **Dev OTP login:** with `KHATMSAZ_DEV_OTP=1` in API `.env`, run
  `curl --unix-socket /tmp/khatmsaz-otp-$(id -u)/delivery.sock "http://local/latest?e164=+98..."`.

---

## Previous state — 2026-09-12 — Phase 14: Core User Journey Completion

- **OPEN khatm completion fixed (DEC-0072).** `KhatmWorkflowService.completeKhatm`
  now skips the portion-completeness check for OPEN khatms. COMMITMENT behavior unchanged.
- **`POST /api/me/become-creator`** added: idempotent, authenticated, grants CREATOR
  capability without an approval flow (DEC-0070 MVP path now implemented).
- **User display names (DEC-0073):** migration `20260911200000_user_display_name` adds
  `display_name VARCHAR(64) NULLABLE` to `users`. Domain, infrastructure, service, and
  contracts all updated. `PUT /api/me/profile` lets users set their name. `GET /api/me`
  and `GET /api/khatms/:id/participants` both return `displayName`.
- **Frontend:** khatm detail participant list shows display name when set, falls back to
  "شرکت‌کننده N". `layout.tsx` theme-color updated to lapis `#1E3E90`. Type card overflow
  fixed with `min-width: 0`.
- **345 tests pass.** Typecheck · lint · unit (345) · build all PASS.
- **Next:** integration/e2e tests for full flows; participant journey UX improvements.

---

## Current state — 2026-09-11 — Product Review + UX/UI Foundation

- **Design system overhauled.** Lapis (لاجوردی) palette replaces the temporary
  green. Tokens migrated in `packages/ui/src/tokens.css`: warm stone neutrals,
  lapis-blue primary, `--ks-color-error` added, `--ks-space-5` added (was missing).
- **Five new docs/ai documents** produced:
  - `UI_UX_AUDIT.md` — full audit of all pages with Critical / Important / Nice priorities.
  - `DESIGN_SYSTEM.md` — colour palette, typography, spacing, component inventory.
  - `KHATM_LOGIC_REVIEW.md` — domain correctness, edge-case analysis, khatm type variations.
  - `PRODUCT_GAPS.md` — prioritised pre-launch gaps (Must have / Should have / Future).
- **Frontend improvements applied:**
  - `globals.css` rewritten: fixed `--ks-space-5` bug, added `.btn-danger`, `.empty-state`,
    `.skeleton` loading state, `.confirm-bar`, `.onboarding-banner`, `.alert-info`,
    `.badge-danger`, improved `.auth-card` with larger radius + shadow; all colours use tokens.
  - Landing page (`/`): removed developer `ApiStatus`/`StatusCard`; clean hero + feature list.
  - Login page (`/login`): brand wordmark section, OTP expiry copy, error positioned above CTA.
  - Dashboard (`/dashboard`): skeleton loading state, retry button on error,
    onboarding banner when empty, better empty-state copy; `canCreateKhatm` guard removed (DEC-0070).
  - Khatm detail (`/khatms/[id]`): skeleton loading state; participants shown as
    "شرکت‌کننده ۱…" with join date (no UUIDs); invitations shown as "دعوت‌نامه ۱…";
    confirmation bar before "اعلام پایان ختم"; `GeneratePlan` defaults changed to
    total=30/chunk=1; plan-before-activation note added.
  - `HelpTip` component: popover now shows term as bold title above explanation.
- **Known issues identified (see KHATM_LOGIC_REVIEW.md + PRODUCT_GAPS.md):**
  - OPEN khatm completion gate broken: `KhatmNotCompletableError` always thrown.
  - No user display names — participants identified by join order only.
  - Creator self-service elevation (`POST /api/me/become-creator`) still not implemented.
- **Validation gate (2026-09-11 UX foundation):** typecheck PASS · lint PASS ·
  unit 343 PASS · build PASS (7 routes: /, /dashboard, /login, /khatms/[id],
  /khatms/create, /invitations/accept, /_not-found).

---

## Current state — 2026-09-11 — Phase 13: Khatm Type Domain Implementation

- **Khatm Type is now a real domain concept.** Two types: `COMMITMENT` (portions
  assigned, allocation plan required) and `OPEN` (free contributions, no mandatory
  allocation). Recorded as DEC-0071.
- **Database migration applied:** `khatm_type` enum column added to `khatms` table
  (default `COMMITMENT`); `open_contributions` table added for OPEN khatm
  contributions.
- **Open Contribution domain:** `OpenContribution` entity, `OpenContributionService`,
  `PrismaOpenContributionRepository` — participants record contribution amounts; progress
  is aggregate (`totalContributed`, `participantCount`).
- **Activation gate updated:** COMMITMENT khatms still require an allocation plan
  (DEC-0055). OPEN khatms can be activated without a plan (DEC-0071).
- **Contracts updated:** `KhatmTypeDto`, `KHATM_TYPES`, `khatmType` on `KhatmSummary`
  and `CreateKhatmRequest`, plus `OpenProgressResponse`, `RecordContributionRequest`,
  `ContributionSummary`, `MyContributionsResponse`.
- **New API endpoints:**
  - `GET /api/khatms/:id/open-progress` — aggregate contribution progress.
  - `POST /api/khatms/:id/contributions` — record a contribution (OPEN khatms only).
  - `GET /api/khatms/:id/my-contributions` — participant's own contributions.
  - `GET /api/khatms/:id/findMyParticipation` (internal workflow helper, not HTTP).
- **Frontend updated:**
  - Create page: sends `khatmType` (COMMITMENT/OPEN) in the POST body.
  - Dashboard: shows `KHATM_TYPE_LABEL` alongside template label on khatm cards.
  - Khatm detail page: shows khatm type; OPEN khatms show contribution form +
    my contributions list + aggregate progress.
  - `labels.ts`: `KHATM_TYPE_LABEL`, `HELP_TEXT` (centralized HelpTip texts for all
    domain concepts including سهم, مشارکت, پیشرفت, ختم تعهددار, ختم غیرتعهددار, دعوت).
- **Tests added/updated:** khatm domain (+4 tests), workflow (+1 OPEN activation test),
  khatm-requests DTO (+2 tests), telegram (+1 updated). 333 API + 10 web = 343 total.
- **Validation gate (2026-09-11 Phase 13):** typecheck PASS · lint PASS · unit 343 PASS ·
  build PASS.
- **Next:** Self-service Creator elevation (`POST /api/me/become-creator`) so any
  authenticated user can become a Creator without manual `grantCapability`.

---

## Current state — 2026-09-11 — Phase 12: Product UI Foundation

- **Phase 12 UI Foundation complete.** First production-ready web experience built on
  top of the existing NestJS/Next.js stack. No new database migrations; no new
  domain rules. All new work is frontend + one backend endpoint addition.
- **New backend endpoint:** `GET /api/khatms/:id` — fetch a single khatm by id without
  ownership requirement. Used by the participant view. `KhatmNotFoundError` is mapped
  via the existing `DomainExceptionFilter` to HTTP 404.
- **New frontend pages/components:**
  - `/khatms/create` — dedicated create page with commitment vs. open type selector
    (radio cards) and HelpTip popovers.
  - `/invitations/accept?token=…` — invitation acceptance landing page; accepts token
    from URL, calls `POST /api/invitations/accept`, redirects to khatm.
  - `HelpTip` reusable component — `?` circle button with popover for contextual help
    (supports: نوع ختم, نوع قرائت, سهم, دعوت).
- **Dashboard overhauled:** Creator section shows khatm cards with progress bars
  (`GET /api/khatms`); Participant section shows joined khatms (`GET /api/me/khatms`,
  endpoint existed from Phase 8). Both use the same `KhatmCard` component.
- **Khatm manage page overhauled:** Uses new `GET /api/khatms/:id` (works for all
  users, not just creator). Shows: progress bar, my portions, creator management
  (plan generation, activate, complete, allocate), invitation management (create link +
  cancel), participant list. Sections shown conditionally based on `me.userId ===
  khatm.creatorUserId`.
- **CSS additions:** progress bar, khatm type radio cards, help-tip popover, section
  header, `btn-sm`, `khatm-card`, `ks-note`, invitation status badge variants.
- **Labels updated:** `INVITATION_STATUS_LABEL` added to `labels.ts`.
- **Validation gate (2026-09-11 Phase 12):** typecheck PASS · lint PASS · unit
  326+10 PASS · build PASS. All 4 web routes present in build output.
- **Missing endpoint (documented, not implemented):** There is no per-user
  "list my portions across all khatms" endpoint. The dashboard participant section
  uses `GET /api/me/khatms` to list joined khatms. Per-khatm portions are fetched
  from `GET /api/khatms/:id/my-portions` on the khatm detail page.
- **Note on ختم غیرتعهددار:** The UI presents it as a distinct type but the domain
  does not yet distinguish it from a تعهددار khatm — both are created identically.
  A note is shown on the create form. Domain-level open participation is future work.
- **Next:** Self-service Creator elevation endpoint (`POST /api/me/become-creator`) so
  any logged-in user can become a Creator without manual `grantCapability`.

---

## Current state — 2026-09-11 — Repository hygiene & MVP Creator decision

- **Repository hygiene checkpoint.** `cloudflared.deb` (19 MB Cloudflare Tunnel
  installer binary, accidentally committed in Phase 9.1) removed from git tracking
  with `git rm --cached` and added to `.gitignore` alongside `all_code.txt` and
  other binary/dump patterns. No real secrets found in git history — all values in
  tracked files are clearly-labeled development placeholders.
- **MVP Creator model recorded (DEC-0070).** Any authenticated user may become a
  Creator for MVP; a manual approval workflow is not needed. The `grantCapability`
  internal call remains the only path until a self-service endpoint is built. Billing
  and usage limits are future phases; DEC-0008 (paid creation) is superseded for MVP.
- **Validation gate (2026-09-11):** typecheck PASS · lint PASS · unit 326+10 PASS ·
  build PASS.
- **Authentication state confirmed:** phone-first OTP auth (DEC-0066), httpOnly
  cookie sessions (DEC-0067), dev OTP (DEC-0069) is opt-in development-only behind
  `KHATMSAZ_DEV_OTP=1`, no production bypass exists.
- **Next:** Phase 12 planning — self-service Creator elevation and MVP launch
  readiness. Not started.

---

## Current state — 2026-09-08 — Local OTP and development fixtures

- Continued the uncommitted local OTP work after Phase 11; no migration, new role,
  authentication redesign, or commit. Existing unfinished changes were preserved.
- Opt-in `NODE_ENV=development KHATMSAZ_DEV_OTP=1` delivery uses bounded memory and
  an owner-only Linux/WSL Unix socket. No public OTP endpoint. CLI supports seed,
  numeric Telegram binding and interactive OTP retrieval. See LOCAL_DEVELOPMENT.md.
- Two local CREATOR accounts were seeded idempotently, as approved by the user;
  the supplied real numeric Telegram identity was bound to the primary fixture.
  User profile names and a global ADMIN role are absent from the existing schema.
- Fixed pre-existing PhoneError HTTP mapping: invalid/expired/used OTP is handled
  as an expected client error, cooldown/attempt exhaustion as 429, not 500.
- Verification before user takeover: typecheck/lint passed before the final small
  PhoneError mapping change; unit API 321 + web 10 passed before that change;
  integration 113/113 passed after it; existing E2E 1/1 passed. Build passed before
  that mapping change. Live API health/readiness and web login returned 200.
- Browser OTP login, httpOnly session, refresh, CREATOR display, khatm creation,
  plan generation and activation verified. The browser script then incorrectly
  expected completion with 10 unfinished portions; the application correctly
  rejected that transition. The demonstration khatm remains ACTIVE; no full
  browser-suite PASS or browser logout result is claimed.
  User explicitly took over further manual testing; no additional validation is
  claimed after that instruction. Five added PhoneError unit cases remain unrun.
- `.env` was not edited and remains ignored; no application dependency added.
- Next: user manual verification using LOCAL_DEVELOPMENT.md. Stop here; do not
  begin a new phase. Real Telegram-client delivery is left to the user.

---

> Newest state is always at the top. History follows below.
> Read this file first in every session.

---

> **Product boundary (DEC-0047):** KhatmSaz is an **independent product**. Identity
> is KhatmSaz-internal; Telegram/Bale/Web are channels of the one product and share
> it; account merge is intra-product. Future products (study/donation bots) are
> separate with their own identity — **no cross-product / shared identity**.

## Current state — 2026-09-07 (Phase 9.1 — Telegram local activation & verification; done, no code change)

### Current phase

Phase 9.1 — **operational activation** of the Phase-9 Telegram adapter against the
real bot (`@Khatm_Saz_bot`) and local end-to-end verification. **No code change, no
migration, no new decision** (DEC-0065 stands) — configuration + verification only.

### What was done

- **Config (local `.env` only, git-ignored, never logged):** `TELEGRAM_BOT_TOKEN` +
  `TELEGRAM_WEBHOOK_SECRET` set. Token validity confirmed via read-only `getMe`
  (bot `@Khatm_Saz_bot`; token not printed). Reachable in this sandbox **only via the
  WSL proxy**; the sender uses direct `fetch`, so replies do not deliver from here (an
  environment quirk — a normal-internet host works).
- **Verified locally** by POSTing to `/telegram/webhook` exactly as Telegram would
  (real secret): wrong/missing secret → **403**; `/start` → **200** + one
  `PlatformIdentity`; duplicate `/start` → still one (idempotent); `/my_khatms` → 200;
  malformed update → 200 (ignored); `/create_khatm` **without CREATOR** → 200 denial,
  **no khatm created** (authorization intact). No token/secret in logs. Test rows
  cleaned up.
- **Not done here (needs a normal-internet host + a human):** a public HTTPS tunnel,
  the real `setWebhook`, and sending from a Telegram client. Exact steps recorded in
  `INTEGRATIONS.md`.

### Verification (this phase)

- Full gate re-run green (code unchanged): **typecheck / lint / unit (api 312 + web
  10) / build / integration 95 / e2e 1** PASS. Live `/health` 200; webhook **403** on
  bad/missing secret and **200** on the correct secret with the real bot configured.

### Next planned phase

Not decided — stop after Phase 9.1.

---

## Current state — 2026-09-07 (Phase 9 — Real Telegram Bot adapter; complete)

### Current phase

Phase 9 — connect the Phase-5 Telegram boundary to the **real Bot API**, keeping the
domain/application untouched and all Phase 6/7 rules intact. **No** payments,
notifications, admin, marketplace, or web redesign. **No migration.**

### What changed

- **Inbound webhook** — `TelegramWebhookController` (`POST /telegram/webhook`, in
  `telegram/infrastructure`): verifies Telegram's `X-Telegram-Bot-Api-Secret-Token`
  (constant-time) against `TELEGRAM_WEBHOOK_SECRET`, maps the **raw** Bot API update to
  the vendor-neutral `TelegramUpdate` (`toTelegramUpdate` — pure, defensive, `null` for
  unsupported updates), and dispatches through the **existing** `TelegramGateway` /
  `TelegramCommandService`. Returns 200 for verified requests (even ignored updates),
  403 on a bad/missing secret. **No polling loop** (DEC-0065).
- **Outbound sender** — `BotApiTelegramSender` (implements the existing
  `TelegramSender` port) calls the Bot API `sendMessage` with plain **`fetch`** — **no
  SDK dependency**. Bound only when `TELEGRAM_BOT_TOKEN` is set; otherwise the existing
  no-op sender (channel dark).
- **Config** — `@khatmsaz/config.telegramConfig()` (`botToken`, `webhookSecret`,
  `apiBaseUrl`), all optional; `TELEGRAM_CONFIG` DI token. `.env.example` documents the
  three (blank secrets). Empty env ⇒ outbound no-op **and** webhook rejects everything.
- The `/start /create_khatm /my_khatms /join /progress` commands are now reachable over
  a real channel; they run through the existing services unchanged — **no business
  logic in the Telegram code**. Identity resolves via the identity capability; creating
  a khatm still requires the CREATOR capability (enforced in the workflow).

### Key behaviours / invariants

- **Telegram SDK/vendor surface stays in infrastructure**: the command layer speaks
  only `TelegramUpdate`/`TelegramReply`; the raw Bot API payload is understood only by
  `toTelegramUpdate`, and the only outbound vendor call is one `fetch` in the sender.
- **Safe by default**: with an empty environment the webhook is disabled (403) and
  nothing is sent — no open command surface, and the repo still builds/tests.
- **Secrets never logged** — the sender logs neither the token-bearing URL nor the
  message body; the webhook secret is compared constant-time and never echoed.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (api 312 (+9) + web 10) / build** PASS; **e2e**
  1/1; **integration** 95/95 (+7 webhook: bad/missing secret → 403; malformed update
  ignored → 200; unknown command reply; `/start` provisions exactly one user+identity
  idempotently; unauthorized `/create_khatm` denied; granted CREATOR creates via the
  webhook). Live `/health` 200; webhook **disabled → 403** with no secret configured;
  `TelegramWebhookController` mapped; no secret in the boot log. **No migration.**

### Not done (later)

- `getUpdates` polling; a real `setWebhook` registration step (ops); Bale adapter
  (same shape); a vendor SDK (optional, behind the same port); rich conversation state;
  payments, notifications, admin, marketplace, web redesign.

### Notes / gotchas

- Going live is an ops step: set `TELEGRAM_BOT_TOKEN` + `TELEGRAM_WEBHOOK_SECRET` and
  register the webhook URL + secret with Telegram (`setWebhook`). Until then the channel
  is inert by design.

### Next planned phase

Not decided — stop after Phase 9.

---

## Current state — 2026-09-08 (Phase 11 — Product completion core; complete)

### Current phase

Phase 11 — participant **invitations**, **participant experience** reads, **lifecycle
hardening** review, and **API completeness**. No payments/subscriptions/marketplace/
admin/analytics/notifications/multi-product.

### What changed

- **Invitations (DEC-0068)** — new `invitation` capability (`apps/api/src/invitation/`).
  An `Invitation` is issued by the khatm **owner**, carries an **opaque token stored
  only as a SHA-256 hash** (raw token returned once), and has a **derived** lifecycle
  **CREATED → ACCEPTED / EXPIRED / CANCELLED** (from `expiresAt`/`acceptedAt`/
  `cancelledAt`; history preserved). `InvitationService`: `createInvitation` /
  `listInvitations` / `cancelInvitation` (owner-gated via ownership), `acceptInvitation`
  (authenticated → joins the khatm through the existing workflow — authorization &
  the one-active-participation invariant never bypassed). Migration
  `20260907xxxxxx_khatm_invitations` (FKs RESTRICT, unique `token_hash`).
  HTTP: `POST/GET /api/khatms/:id/invitations`, `POST /api/invitations/:id/cancel`,
  `POST /api/invitations/accept`.
- **Participant experience** — `GET /api/me/khatms` (khatms I joined) and
  `GET /api/khatms/:id/my-portions` (my assigned portions; a participant sees only
  their own). Completing an own portion already existed (holder-checked). New reads:
  `ParticipationRepository.findByUser`, `PlanPortionRepository.findByParticipation`,
  `KhatmService.listKhatmsForParticipant`/`findParticipation`,
  `AllocationService.listPortionsForParticipation`, workflow `listMyKhatms`/`listMyPortions`.
- **Lifecycle hardening** — reviewed: allocation (generate/allocate/release) already
  runs in `UnitOfWork`; khatm/participation/session/invitation transitions are guarded
  `updateMany`s or DB unique constraints. No new race fix required; added a concurrent-
  activation test proving the guarded DRAFT→ACTIVE transition lets exactly one win.
- **Telegram** — no new command (invite acceptance is fully served by the web; a
  Telegram invite-accept command is a documented, non-required follow-up).

### Verification (all run this phase)

- Gate green: **typecheck / lint / build** PASS; **unit** api 311 + web 10; **e2e** 1;
  **integration 105** (+ invitations: create/accept/expired/unauthenticated + participant
  reads; concurrent activation). Migration `khatm_invitations` verified in PostgreSQL.

### Security review (this phase)

- **No new IDOR**: khatm manage is ownership-gated (403); invitation issue/list/cancel
  are owner-gated; `accept` joins the **caller** (principal), not an arbitrary user;
  `my-portions` returns only the caller's participation's portions (`[]` for a
  non-participant); the participants list is owner-only. `progress` stays authenticated-
  only and returns **aggregate counts only** (no PII/identities) — accepted.
- **Secrets/tokens**: invite & session tokens are opaque, high-entropy, stored SHA-256
  hashed; never logged or returned twice. Session cookie httpOnly (DEC-0067).
- **Deferred (documented)**: double-submit CSRF token; Telegram invite-accept; removing
  the legacy user-scoped login.

### Next planned phase

None scheduled — stop after Phase 11 (no payments/subscriptions/notifications/scaling).

---

## Current state — 2026-09-08 (Phase 10 — Product readiness foundation; complete)

### Current phase

Phase 10 — closing core usability gaps: **phone-first authentication**, **httpOnly
cookie browser sessions**, the **creator journey** over real auth, and a **Telegram
command review**. No payments/subscription/marketplace/admin/analytics/notifications.

### What changed

- **Phone-first auth (DEC-0066)** — sign in by phone with **no `userId`**. A new
  **user-less OTP challenge** (`otp_purpose` value `PHONE_LOGIN`, `user_id` null)
  proves possession, decoupled from any user. Phone capability **extended** (not
  rewritten): `requestLoginCode` / `verifyLoginCode` (user-less), `findVerifiedOwner`,
  `establishVerifiedOwnership`, `normalize` — reusing the existing generator/hasher/
  delivery/repo and invariants. Session orchestration `PhoneAuthService.requestLogin`/
  `completeLogin` verifies possession → **resolves the verified owner OR creates a
  user** and binds the number as their verified claim → mints an opaque session. The
  Phone capability still never imports Identity; the flow reveals nothing about
  whether an account existed. Migration `20260907201909_phone_login_purpose` (additive
  enum value).
- **Cookie sessions (DEC-0067)** — `POST /api/auth/phone/request` + `/verify` set an
  **httpOnly, `SameSite=Lax`, `Secure`-in-prod** cookie carrying the opaque token; the
  raw token is **never** in a response body or reachable by JS. `SessionAuthGuard`
  reads the **cookie first, then the `Authorization: Bearer` header** (bearer clients
  unaffected). `POST /api/auth/logout` revokes the session and clears the cookie. No
  JWT; sessions stay opaque + revocable. CORS already allow-lists origins with
  `credentials: true`. CSRF: `SameSite=Lax` + JSON-only + origin allow-list now; a
  double-submit token is the recorded next step.
- **Web** now cookie-based: `api-client` sends `credentials:'include'` and holds **no
  token**; `auth-context` restores the session on load via `/api/me`, logs in via
  `requestLoginCode`/`verifyLoginCode`, logs out server-side; the login page is a
  phone→code flow (no `userId` field).
- **Telegram review (Phase 10.4)** — the product command set is **`/start`,
  `/create_khatm`, `/my_khatms`, `/progress`** (identity resolved via the platform
  identity, CREATE authorized via the workflow's CREATOR check, Persian replies, no
  business logic in the adapter). Raw **`/join` retired** (UUID-based joining isn't a
  product command; invitations replace it in Phase 11) — it now returns the
  unknown-command help.
- **Legacy** `POST /api/auth/login` (+ `request-otp`, explicit `userId`) retained but
  superseded by the phone-first flow (DEC-0066); to be removed once no client uses it.

### Verification (all run this phase)

- Gate green: **typecheck / lint / build** PASS; **unit** api 311 + web 10; **e2e** 1;
  **integration 102** (+ phone-first auth: new-user/existing-user/invalid/absent OTP +
  session mints; cookie: httpOnly set, cookie authenticates, logout invalidates,
  no-cookie 401; creator journey over cookie auth incl. non-creator 403 + ownership
  403; Telegram retired-`/join`). One additive migration verified in PostgreSQL.

### Not done (later / deferred)

- Double-submit CSRF token; removing the legacy user-scoped login; real SMS provider;
  and everything explicitly out of scope (payments/subscriptions/marketplace/admin/
  analytics/notifications/multi-product).

### Next planned phase

Phase 11 — product completion core (invitations, participant experience, lifecycle
hardening, API completeness).

---

## Current state — 2026-09-07 (Phase 8 — Creator experience (web) foundation; complete)

### Current phase

Phase 8 — the first real **user-facing layer**: a Web app that consumes the existing
authenticated APIs (login, dashboard, khatm management). UI holds **no business
logic**; authorization stays server-side. **No** payments, notifications, admin,
marketplace, subscriptions, mobile, or production Telegram. **No migration.**

### What changed

- **Web app** (`apps/web`, Next.js App Router, Persian/RTL) — thin client (DEC-0064):
  - `src/lib`: `api-client` (bearer injection, `{error:{code,message}}` → typed
    `ApiError`), `auth-context` (session token **in memory only**; `establishSession`/
    `logout`/`authed`), `permissions` (pure UI gating), `labels` (Persian enum labels).
  - `components/require-auth` — client route guard (redirect to `/login`; UX only).
  - Pages: `/login` (request-OTP → verify → session), `/dashboard` (current user,
    creator badge, own khatms, create form **gated on `isCreator`**), `/khatms/[id]`
    (status, progress, participants; owner actions: activate / generate plan /
    allocate / complete). Landing page links to login/dashboard.
  - `globals.css` extended with token-based, RTL (logical-property) styles.
- **API additions** (thin controllers, DTO validation only, existing contracts —
  DEC-0064): `GET /api/me` (`{userId, isCreator}`), `POST /api/auth/request-otp`
  (`{e164}`), `GET /api/khatms/:id/participants` (owner-only). Supporting reads:
  `KhatmService.listParticipations` + `ParticipationRepository.findByKhatm`,
  `PhoneOtpLoginService.requestOtp`. New contracts: `MeResponse`, `RequestOtp*`,
  `ParticipationSummary`, `KhatmParticipantsResponse`.
- **No schema change / no migration** — all reads use existing tables.

### Key behaviours / invariants

- The UI is **never a security boundary**: `canCreateKhatm`/`RequireAuth` only gate
  what is offered; the backend re-authenticates (401) and re-authorizes (403) every
  action. UI never trusts its own permission state.
- Session token lives **in memory only** — no `localStorage`/cookies; never logged.
- Web talks to the backend **only** through the typed `api-client`; no domain/Prisma
  in the UI.

### Verification (all run this phase)

- Gate green: **typecheck / lint / build** PASS (api + web + admin); **unit** api 303
  + **web 10** (api-client/api-error/permissions); **integration** 88/88 (+3: `GET
  /api/me` creator/plain/401, owner-only participants + non-owner 403, request-otp
  e164); **e2e** 1/1. Live `/health` 200; `GET /api/me` → 401 unauthenticated;
  request-otp bad body → 400 envelope; no secret in boot log. Web builds all routes
  (`/`, `/login`, `/dashboard`, `/khatms/[id]`).
- Local URLs: web `http://localhost:3000`, API `http://localhost:3001`. (No
  screenshots — no browser in this environment.)

### Not done (later)

- Persistent sessions (httpOnly cookies), a proper "sign in by phone" (no userId
  field — needs a phone→owner lookup, a Phone change deferred), real SMS delivery,
  production Telegram, payments, notifications, admin, marketplace, subscriptions,
  mobile.

### Notes / gotchas

- Web login carries a `userId` field — a limitation of the user-scoped phone-OTP
  model (DEC-0060), not a new auth system. End-to-end login needs a real SMS provider.
- Web tests live in `apps/web/test/` (node env, ts-jest, CommonJS override) so
  `eslint src` and `next build` ignore them; jest/ts-jest are hoisted from the root.

### Next planned phase

Not decided — stop after Phase 8.

---

## Current state — 2026-09-07 (Phase 7 — Creator capability & authorization foundation; complete)

### Current phase

Phase 7 — **authorization**: the capability model, the Creator capability, and
resource-ownership enforcement that closes the Phase-6 IDOR. Authorization foundation
**only**: no Web UI, production Telegram, payments, notifications, admin, Creator
marketplace, or subscriptions.

### What changed

- **New `authorization` capability** `apps/api/src/authorization/{domain,application,
  infrastructure}` + `AuthorizationModule` (wired into `AppModule`). Answers only
  "is this user allowed?" (DEC-0061): `Capability` entity (grant/revoke **history**,
  `isActive` when not revoked), `CapabilityType` enum (**CREATOR** only; no Admin),
  `CapabilityRepository` port (+ Prisma impl), authorization errors.
- **`AuthorizationService`** (Prisma-free; no session/HTTP knowledge): `hasCapability`,
  `requireCapability` (→ 403), `grantCapability` (idempotent; the **explicit internal
  grant** — no public onboarding endpoint), `revokeCapability` (history retained).
- **Workflow authorization (DEC-0063)** — enforced in `KhatmWorkflowService` (the
  orchestration layer where "who" meets "what"):
  - **createKhatm** requires the **CREATOR** capability (after the active-user check).
  - **manage** actions — `activateKhatm`, `generateAllocationPlan`, `allocatePortions`,
    `completeKhatm` — now take the **acting user id** and require **ownership**
    (`actingUserId === khatm.creatorUserId`) via `requireKhatmOwner` → 403 otherwise.
    **This closes the Phase-6 IDOR.**
  - **participant** actions (join, complete own portion) stay participant logic —
    authentication only, no capability/ownership.
- **Transport** — controllers pass `principal.userId` to the manage workflows
  (`@Principal()`), staying thin (no role/ownership/Prisma logic). The
  `DomainExceptionFilter` maps `CapabilityRequiredError`/`ResourceOwnershipError` →
  **403** (distinct from the guard's **401**). Telegram maps the denial to a calm
  Persian message.
- **Seventh reviewed migration** `20260907081109_authorization_capability_foundation`:
  `user_capabilities` table + `capability_type` enum + FK RESTRICT + a **hand-written
  partial unique index** `UNIQUE (user_id, type) WHERE revoked_at IS NULL` (one active
  grant per user+type). All-CREATE; no ALTER to existing tables; `psql`-verified.

### Key behaviours / invariants

- **Authorization ≠ authentication ≠ validity**: session says who; authorization says
  allowed; the domain says valid. Authentication failure = **401**, authorization
  failure = **403** — kept distinct (proven).
- **Create** is capability-gated; **manage** is ownership-gated; user A can never
  manage user B's khatm.
- One **active** grant per (user, type) — DB partial unique; revoke keeps history; a
  re-grant is a new row.
- Granting CREATOR is an **explicit internal mechanism** — no onboarding rule
  invented, no public grant endpoint (tests/dev grant via the service).

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (303 unit, +17) / build** PASS; **e2e** 1/1;
  **integration** 85/85 (+10: authorization — no-CREATOR→create denied, CREATOR→create
  allowed, owner can manage, non-owner 403, revoke removes access, active-grant
  persistence + history, DB partial-unique; HTTP 401-vs-403 + ownership 403). Live
  `/health` + `/health/ready` 200 with `AuthorizationModule` initialized; no-token
  create → 401; no secret in the boot log. `psql` confirmed the partial index
  predicate + FK RESTRICT.

### Not done (later)

- No Web UI, production Telegram Bot API, payments, notifications, admin, Creator
  marketplace, or subscriptions. **How** a user earns CREATOR (onboarding/payment
  DEC-0008/0013) is not decided. Whether revoking CREATOR should also freeze
  management of already-owned khatms is a deferred product nuance (manage is
  ownership-gated, not capability-gated).

### Next planned phase

Not decided — stop after Phase 7.

---

## Current state — 2026-09-07 (Phase 6 — Authentication & session foundation; complete)

### Current phase

Phase 6 — **authenticated principals and sessions**, so transports stop trusting
explicit user ids. Authentication foundation **only**: no Web UI, payments,
notifications, admin, Creator permissions, real SMS, or OAuth.

### What changed

- **New `session` capability** `apps/api/src/session/{domain,application,
  infrastructure}` + `SessionModule` (wired into `AppModule`). Server-side opaque
  sessions (DEC-0059): `Session` entity with **derived** status (ACTIVE/REVOKED/
  EXPIRED from `revoked_at`/`expires_at`); token generator (256-bit CSPRNG) + hasher
  (**SHA-256**, constant-time compare) ports/impls; `Clock` port; `SessionRepository`
  (+ Prisma impl); session errors; `AuthenticatedPrincipal` type.
- **`AuthenticationService`**: `createSession` (returns the raw token **once**;
  stores only its hash), `authenticate` (hash → lookup → constant-time verify →
  status + active-user checks → principal; touches `last_used_at`), `revokeSession`,
  `revokeAllForUser`. A session authenticates only when ACTIVE **and** its user is
  still active (merged users' sessions die).
- **Phone-OTP login bridge** `PhoneOtpLoginService` (DEC-0060 Part 5): consumes the
  existing `verifyPhone` unchanged; on VERIFIED/ALREADY_VERIFIED mints a session;
  MERGE_REQUIRED yields no session.
- **Transport integration (DEC-0060):**
  - **HTTP**: `SessionAuthGuard` (Bearer → principal, 401 on failure) + `@Principal()`;
    `AuthController` (`POST /api/auth/login`, `POST /api/auth/logout`). Create / join /
    list / logout are guarded and derive the user from the principal — their bodies
    **no longer carry `creatorUserId`/`userId`** (contract updated).
  - **Telegram**: command service resolves an `AuthenticatedPrincipal` from the
    platform identity (`sessionId: null`, channel-authenticated); boundary unchanged.
- **Sixth reviewed migration** `20260907071058_session_foundation`: `sessions` table
  (unique `token_hash`, indexed `user_id`, FK CASCADE — mirrors `otp_challenges`);
  SQL was all-CREATE, no ALTER to existing tables, applied and `psql`-verified.
- **Config**: `sessionPolicyConfig()` (`SESSION_TTL_SECONDS`, `SESSION_TOKEN_BYTES`),
  non-secret, documented in `.env.example`. **No session server secret** (token
  entropy makes a pepper unnecessary — the deliberate contrast with OTP).

### Key behaviours / invariants

- Raw token returned **once**, never stored/logged; DB holds only the SHA-256 hash
  (verified in tests + psql). Auth failures are coarse (invalid/revoked/expired) and
  leak nothing about token existence.
- Status is derived; revocation beats expiry; revoked/expired/inactive-user sessions
  cannot authenticate.
- Transports pass an `AuthenticatedPrincipal`, not a caller-supplied id (HTTP bearer;
  Telegram platform identity).

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (286 unit, +17) / build** PASS; **e2e** 1/1;
  **integration** 75/75 (+8: session create/authenticate/revoke/expired/unknown, hash-
  not-plaintext, phone-OTP→session; HTTP journey updated to authenticate; 401/400
  envelopes). Live `/health` 200 with `SessionModule` initialized; guarded route →
  401 (no leak), login bad body → 400; no secret/token in the boot log. Migration
  applied; `psql` confirmed the `sessions` table, unique `token_hash`, FK CASCADE.

### Not done (later)

- Every `/api/khatms` + `/api/portions` route requires **authentication** (a valid
  session), but per-resource **authorization** is deferred — an authenticated user
  can still act on a khatm they don't own (IDOR). Enforcing creator ownership is
  Creator permissions (out of scope; the rule isn't written). No refresh-token
  rotation; no Web UI, real SMS, OAuth, payments, notifications, or admin.

### Security review (this phase)

An automated review flagged the resource-scoped khatm/portion routes as
unauthenticated (anonymous state mutation). **Fixed:** all such routes now require a
valid session. **Deferred (flagged):** per-resource authorization/IDOR (needs the
Creator-permissions ownership rule). The login `userId` parameter is **not
spoofable** (the OTP code bound to that user is the credential); deriving the user
from phone+code would redesign the Phone capability (out of scope).

### Notes / gotchas

- `@khatmsaz/config` and `@khatmsaz/contracts` must be rebuilt (`build:packages`)
  after editing their sources before the API typechecks.
- Session tokens use **plain SHA-256 (no pepper)** by deliberate decision (DEC-0059):
  a 256-bit token can't be brute-forced from its hash; do **not** "harden" it with
  the OTP pepper pattern.

### Next planned phase

Creator capability + per-resource authorization (building on the principal), or a
real SMS provider / Telegram Bot API adapter. Not started.

---

## Current state — 2026-09-07 (Phase 5 — Transport foundation; complete)

### Current phase

Phase 5 — **the transport layer that drives the existing workflows**: an HTTP/REST
API and a Telegram channel adapter foundation. Transport **only translates** external
input into application use-cases — no business logic moved into transport. **No** Web
UI/React, no real Telegram network/deployment, no payments, notifications,
authentication, or admin. **No migration / no schema change.**

### What changed

- **Shared contracts** — `packages/contracts/src/khatm.ts` (exported from `index.ts`):
  pure DTO shapes for the khatm transport (create/list/generate-plan/join/allocate/
  progress/complete-portion requests + responses, `KhatmSummary`, status/template
  string unions, `TransportErrorResponse`). Shapes only — no validation, no domain
  leakage (DEC-0057).
- **HTTP transport** — new `apps/api/src/http-api/` (`HttpApiModule`, wired into
  `AppModule`). Thin `KhatmController` (`/api/khatms`) + `PortionController`
  (`/api/portions`) calling `KhatmWorkflowService`/`KhatmService`; dependency-free DTO
  validation (`dto/validate.ts` + parsers); `toKhatmSummary` maps domain→DTO (no
  entity/Prisma on the wire); a `DomainExceptionFilter` maps capability errors to a
  stable `{error:{code,message}}` envelope by kind (404/400/403/409, 500 generic).
  `/health` unchanged. No auth — ids are explicit in the request (DEC-0057).
- **Telegram transport** — new `apps/api/src/telegram/` (`TelegramModule`, wired).
  Vendor-neutral `TelegramUpdate`/`TelegramReply` (the adapter boundary), a pure
  command parser, `TelegramCommandService` resolving the caller's platform identity
  via `IdentityService` and routing `/start /create_khatm /my_khatms /join /progress`
  to the workflows with calm **Persian** replies; `/start` provisions a user
  (createUser + attachPlatformIdentity). Outbound `TelegramSender` port bound to a
  **no-op** adapter (no bot token, no network); `TelegramGateway` is the inbound
  entry point. No Telegram SDK, no webhook (DEC-0058).
- **Additive khatm read** — `KhatmService.listKhatmsByCreator` +
  `KhatmRepository.findByCreator` (Prisma impl), backing `GET /api/khatms` and
  `/my_khatms`. Application read, not transport logic.

### Key behaviours / invariants

- **Transport holds no business logic** — controllers/command handlers validate,
  translate, resolve identity, and map errors; every rule stays in the
  application/domain layers, which re-validate regardless.
- **No domain entity or Prisma type crosses a boundary** — HTTP returns contract
  DTOs; Telegram speaks vendor-neutral shapes.
- **Identity via the identity capability** — Telegram uses the immutable Telegram
  user id as the platform `subject` (never a username); `/start` provisions, it does
  not authenticate (no session/token).
- **Stable error surface** — HTTP errors are a `{error:{code,message}}` envelope;
  domain messages are safe (no secrets/PII); unexpected errors are a generic 500.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (269 unit, +37) / build** PASS; **e2e** 1/1;
  **integration** 67/67 (+6: HTTP full journey via supertest, and Telegram
  identity→User→workflow — no real network). Live: `/health` 200 with `HttpApiModule`
  + `TelegramModule` initialized; real HTTP calls proved routing, DTO validation
  (400 envelope), and domain-error mapping (`InactiveCreatorError`→409,
  `InvalidUuidV7Error`→400). No secret in the boot log. **No migration.**

### Not done (later)

- No Web UI/React; no real Bot API adapter / webhook / long-poll / deployment; no
  auth/session (ids are explicit); no payments, notifications, wallet, Creator roles,
  or admin. Plan-generation/activation are not yet bot commands (available over HTTP).

### Notes / gotchas

- `@khatmsaz/contracts` must be rebuilt (`npm run build:packages`) after editing its
  source before the API typechecks against the new DTOs.
- The Telegram no-op sender uses a narrower `send()` signature (no params) so it
  logs neither the chat id nor the reply body (PII/user content).

### Next planned phase

Phase 3C (Creator identity & sessions / auth) so transport can authenticate a
principal instead of trusting explicit ids, or a real Telegram Bot API adapter +
webhook behind the existing port. Not started.

---

## Current state — 2026-09-07 (Phase 4.2 — Khatm workflow orchestration; complete)

### Current phase

Phase 4.2 — **application-level orchestration** connecting the existing Khatm
capabilities into end-to-end workflows: create → activate → join → allocate →
complete. **Application only** — no Telegram/Bale/Web transport, no HTTP
controllers, no notifications, payments, or authentication. No new persistence
(**no migration this phase**).

### What changed

- **New `khatm-workflow` capability** `apps/api/src/khatm-workflow/` (application
  only) + `khatm-workflow.module.ts` (wired into `AppModule`). It is a **dedicated
  orchestration module** (the `account-merge` pattern, ARCHITECTURE.md): imports
  IdentityModule + KhatmModule + AllocationModule and composes their **exported
  services** — no capability imports another's domain (DEC-0039). Owns no domain,
  no persistence, and no transaction of its own.
- **`KhatmWorkflowService` — six flows (DEC-0054):**
  - `createKhatm` — validates the creator is an **ACTIVE** user (merged/unknown →
    `InactiveCreatorError`), then delegates to `KhatmService.createKhatm` (DRAFT).
  - `activateKhatm` — requires the khatm to exist and have a **valid allocation
    plan** (≥1 portion) before DRAFT→ACTIVE (DEC-0055; `KhatmNotConfiguredError`).
  - `joinKhatm` — validates the user is **ACTIVE** (merged/unknown →
    `InactiveParticipantError`), then delegates to `KhatmService.join` (ACTIVE khatm
    + duplicate-active rejection stay in the khatm capability).
  - `generateAllocationPlan` / `allocatePortions` — **delegate** to
    `AllocationService` (no allocation logic duplicated).
  - `completePortion` — delegates to the new **holder-checked**
    `AllocationService.completeHeldPortion`.
  - `completeKhatm` — completes **only when every portion is completed**
    (`completed === total > 0`, DEC-0056; `KhatmNotCompletableError`).
- **Allocation capability extended (additive):** `AllocationService.completeHeldPortion
  (portionId, participationId)` — only the assigned **holder** may complete a portion
  (`PortionNotHeldByParticipationError`); a completed portion can't be completed
  again (guarded transition). Runs in `UnitOfWork`.

### Key behaviours / invariants

- **Cross-capability preconditions live only in the orchestrator**; each capability
  keeps enforcing its own rules (creator ownership, lifecycle legality, one-active-
  participation, non-overlap) and its own transactions.
- **Setup order** is create → generate plan → activate → join → allocate → complete
  (activation gated on a plan; completion gated on all portions done).
- **Merged/tombstoned users** (DEC-0040/0041) cannot create or join a khatm.
- **No new transaction** was introduced — plan generation, batch allocation, and
  holder-checked completion already run inside the allocation `UnitOfWork` (DEC-0044).

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (232 unit, +15) / build** PASS; **e2e** 1/1;
  **integration** 61/61 (+3 workflow: full journey create→generate→activate→join→
  allocate→complete with DB assertions; duplicate-participation rejected via the DB
  constraint; merged user rejected as creator and joiner). Live `/health` +
  `/health/ready` 200 with `KhatmWorkflowModule` initialized; no secret in boot log.
  **No migration / no schema change** this phase.

### Not done (later)

- No transport (bot/web/HTTP) calling these workflows; no auto-completion, no
  auto-release of a leaving participant's portions (offered as explicit allocation
  calls); no reminders, payments, wallet, Creator roles, or authentication.

### Notes / gotchas

- The orchestrator composes exported **services** (not repos) because no flow needs
  a *new* cross-capability atomic transaction — the multi-write ops are already
  transactional inside the allocation capability. (Account-merge composes repo ports
  precisely because it needs one atomic cross-capability transaction.)
- A tiny check-then-act race (user merged between the ACTIVE check and the write) is
  accepted at this layer and documented (DEC-0054); not security-critical, no auth yet.

### Next planned phase

Phase 3C (Creator identity & sessions) or Phase 5 (Telegram adapter) — a transport
that *drives* these workflows — or wiring auto-release into Participation
leave/remove. Not started.

---

## Current state — 2026-09-07 (Phase 4.1 — Khatm allocation engine; complete)

### Current phase

Phase 4.1 — **the generic, template-driven Khatm allocation engine**: plan
generation, non-overlapping portions, allocation, reallocation, progress, and
transaction safety. Built **additively** on Phase 4 — Phase 4's tables, entities
and semantics are **unmodified** (DEC-0052). **No transport** (no Telegram/Bale/Web
UI, no controllers), no notifications, payments, or auth.

### What changed

- **New `allocation` capability** `apps/api/src/allocation/{domain,application,
  infrastructure}` + `allocation.module.ts` (wired into `AppModule`), same layering
  as the rest: domain owns the ports/entities (Prisma-free), Prisma only in
  infrastructure. Self-contained — imports **no** Phase-4 domain.
- **Plan/portion model (DEC-0052).** Two new tables: **`khatm_allocation_plans`**
  (one per khatm — `UNIQUE(khatm_id)`, race-safe generation) and **`khatm_portions`**
  (allocatable "slots"). Portion lifecycle **OPEN → ASSIGNED (holder=participation)
  → COMPLETED**, with **ASSIGNED → OPEN** release for reallocation. Repos apply every
  transition as a guarded `updateMany` on the prior status.
- **Template → portion generation (DEC-0052).** A pure domain generator over a
  `PlanSpec`: POSITIONAL `{from,to}` → atomic units (e.g. Qur'an Juz `{1,30}` → 30
  units); QUANTITY `{total,chunk}` → chunks summing to the total (e.g. 1000 Salawat
  by 100 → ten chunks + remainder). Numbers are **caller-supplied** — no per-template
  count hard-coded (nothing invented). Cap `MAX_PORTIONS_PER_PLAN = 10_000`.
- **Non-overlap (DEC-0053).** Positional units are atomic (`unit_start = unit_end`);
  non-overlap is DB-enforced by a **hand-written partial unique index** `UNIQUE
  (plan_id, unit_start) WHERE unit_kind='POSITIONAL'` — chosen over a gist range
  exclusion to keep the stack boring.
- **Allocation / reallocation / progress.** `AllocationService`: `generatePlan`,
  `allocateOpenPortions` (batch, sequence order), `allocatePortion`,
  `reassignPortion`, `releaseParticipation` (reallocation — returns a participant's
  ASSIGNED portions to the pool), `completePortion`, `progress`
  (`{total,open,assigned,completed}`). Reads Phase-4 khatm/participation state via
  the engine-owned **`KhatmStateReader`** port (Prisma reads of the khatm tables in
  the engine's infra — no Phase-4 domain import).
- **Transaction safety (DEC-0044).** Plan generation, batch allocation, and release
  run inside `uow.run`; the guarding state checks read through the same transaction.
- **Fifth reviewed migration** `20260907004303_khatm_allocation_engine`: created via
  `db:plan`, the non-overlap partial unique index **appended by hand**, SQL reviewed
  (all CREATE — **no ALTER to any Phase-4 table**, no data loss), applied via
  `db:migrate`, verified in real PostgreSQL. New enums `portion_unit_kind`,
  `khatm_portion_status`; four new FKs, all **RESTRICT**.

### Key behaviours / invariants

- **One plan per khatm** (unique `khatm_id`); a plan may be generated while the khatm
  is DRAFT or ACTIVE. **Allocation requires the khatm ACTIVE and the participation an
  ACTIVE participant** of that khatm (checked via `KhatmStateReader`).
- **Non-overlap**: no two POSITIONAL portions in a plan cover the same unit (DB
  partial unique + generation tiling); each portion is held by ≤1 participation.
- **Reallocation** returns a leaving participant's ASSIGNED portions to OPEN (never
  touches COMPLETED); released units can be re-allocated to others.
- **Progress** is derived by counting portions (no stored progress field).
- Phase 4 is **untouched**: `khatms`/`khatm_participations`/`assignments` keep their
  exact columns; the engine's FKs live on the new tables.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (217 unit, +44) / build** PASS; **e2e** 1/1;
  **integration** 58/58 (+9 allocation: migration recorded; positional 30-unit &
  quantity 1000/100 generation; one-plan-per-khatm; **DB non-overlap** duplicate-unit
  reject; allocate + complete + derived progress; **reallocation** release→reallocate
  transaction-safe; allocation rejected once not ACTIVE; FK RESTRICT on khatm delete).
  Live `/health/ready` 200 with `AllocationModule` initialized; no secret in boot
  log. `psql` confirmed the partial index predicate, 4 FKs RESTRICT, and `khatms`
  still has exactly its 8 Phase-4 columns. DB cleaned up.

### Not done (later)

- No transport (bot/web/HTTP) driving the engine; no auto-release wired into Phase-4
  `leave`/`remove` (offered as an explicit `releaseParticipation` call); no
  reminders, payments, wallet, Creator roles, or authentication.

### Notes / gotchas

- The `khatm_portions` non-overlap partial unique index is **not** in
  `schema.prisma`; strip any auto-generated `DROP` on a future `migrate dev` diff
  (KI-0012).
- The engine and Phase-4's manual `assignPortion`/`Assignment` are **separate**
  allocation concepts that don't interact (a consequence of not modifying Phase 4);
  a future unification would be its own reviewed change.

### Next planned phase

Phase 3C (Creator identity & sessions) or Phase 5 (Telegram adapter) to *drive* the
engine, or a transport/orchestration step that auto-releases portions when a
participant leaves. Not started.

---

## Current state — 2026-09-07 (Phase 4 — Khatm engine foundation; complete)

### Current phase

Phase 4 — **the core business domain of KhatmSaz**: the Khatm aggregate and its
lifecycle, a generic template classification, participation, and the
assignment/portion system. Domain foundation only — **no HTTP controllers, no
Telegram/Bale bot, no WebApp UI, no reminders, payments, wallet, Creator roles, or
authentication** (all explicitly out of scope this phase). Builds on the identity/
phone/merge foundations; intra-product (DEC-0047).

### What changed

- **New `khatm` capability** `apps/api/src/khatm/{domain,application,infrastructure}`
  + `khatm.module.ts` (wired into `AppModule`), mirroring the identity/phone
  layering: domain owns the ports and entities (Prisma-free), Prisma lives only in
  infrastructure (DEC-0031). No transport surface.
- **Khatm aggregate (DEC-0048).** `id` (UUIDv7), `creatorUserId`, `title`, optional
  `description`, `templateType`, `status`, timestamps. Lifecycle **DRAFT → ACTIVE →
  COMPLETED**, or **CANCELLED** from DRAFT/ACTIVE; COMPLETED/CANCELLED terminal.
  Immutable entity with pure transition methods (`activate`/`complete`/`cancel`) +
  guards (`canAcceptParticipants`/`canReceiveAssignments`, both = ACTIVE). Repo
  applies transitions **guarded on the prior status** (concurrency-safe, the
  tombstone pattern).
- **Generic template (DEC-0048).** A single `KhatmTemplateType` enum
  (QURAN_FULL/QURAN_JUZ/SURAH/SALAWAT/DUA/ZIYARAT/CUSTOM) on the khatm — **not** a
  table/class per prayer type (realises DEC-0019). Per-template division is the
  deferred allocation engine's job, not encoded now.
- **Participation (DEC-0050).** `khatmId`, `userId`, `status`
  (ACTIVE/COMPLETED/LEFT/REMOVED), `joinedAt`, timestamps. One ACTIVE per (khatm,
  user) via a **hand-written partial unique index** (KI-0012 pattern); terminal
  states retained as history — a user who LEFT may rejoin as a new ACTIVE row.
- **Assignment + Portion (DEC-0049).** Assignment belongs to a participation,
  scoped to its khatm, PENDING → COMPLETED (with `completedAt`). Portion is a
  discriminated value object: **POSITIONAL** (`unitStart..unitEnd`, e.g. Juz 1-30)
  or **QUANTITY** (`quantity`, e.g. 500 Salawat), flattened to nullable columns.
  Progress is **derived** by counting (`{total, completed}`), not stored.
- **Fourth reviewed migration** `20260906195317_khatm_engine_foundation`: created via
  `db:plan` (create-only), the participation partial unique index **appended by
  hand**, SQL reviewed (all CREATE/ALTER ADD — no DROP, no data loss), applied via
  `db:migrate`, verified in real PostgreSQL. Tables `khatms`, `khatm_participations`,
  `assignments`; enums `khatm_status`, `khatm_template_type`, `participation_status`,
  `assignment_unit_kind`, `assignment_status`.
- **FK strategy (DEC-0051):** all five new FKs **RESTRICT** (verified `confdeltype=r`).
  The Phase 3B merge use-case is **not** changed to reassign khatms — a merged
  creator is a tombstone that still resolves, and the tombstone pointer gives the
  path to the winner. Actively re-attributing khatms on merge is **flagged for a
  product decision**, not invented.

### Key behaviours / invariants

- Only an **ACTIVE** khatm accepts participants and assignments (service-checked);
  COMPLETED/CANCELLED reject both.
- Lifecycle legality is decided in the **domain**; the DB applies it guarded on the
  prior status, so concurrent transitions can't both win.
- **One ACTIVE participation per (khatm, user)**, DB-enforced; history retained.
- Portions cover both **positional ranges** and **counts** generically; no
  per-template rule, no overlap/allocation logic (deferred to the engine phase).
- **No UnitOfWork used** — every operation is a single-aggregate write (batch
  allocation, which would need a transaction, is the later engine's concern).

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (173 unit, +50) / build** PASS; **e2e** 1/1;
  **integration** 49/49 (+8 khatm: migration recorded; DRAFT round-trip incl.
  template & trimmed title/description; creator-FK reject; lifecycle persistence;
  one-active-participation + rejoin-after-leave history; positional & quantity
  portion round-trip + derived progress; assignment rejected once COMPLETED; FK
  RESTRICT on creator delete). Live `/health` + `/health/ready` 200 with
  `KhatmModule` wired; no secret in boot log. `psql` confirmed the partial index
  predicate, all 5 FKs RESTRICT, and the 7-value template enum. DB cleaned up.

### Not done (later)

- No HTTP/bot/UI transport for khatms; no allocation engine (auto-split content),
  non-overlap enforcement, reallocation, reminders, payments, wallet, Creator
  roles, or authentication. All out of scope this phase.

### Notes / gotchas

- The participation partial unique index is **not** in `schema.prisma`; keep it in
  the migration and strip any auto-generated `DROP` on a future `migrate dev` diff
  (KI-0012).
- Running `node dist/main.js` directly needs the DB env loaded (`set -a; . .env`);
  the tests inject env via `test/load-env.ts` / prisma config.

### Next planned phase

Phase 3C (Creator identity & sessions) or Phase 5 (Telegram adapter), or the Khatm
**allocation engine** (auto-splitting a template into portions across
participants). Not started.

---

## Current state — 2026-09-06 (Phase 3B step 2 — merge engine + change-phone; complete)

### Current phase

Phase 3B **step 2: the account-merge use-case and change-phone-via-OTP flow.**
Intra-product only (DEC-0047). **No authentication, sessions, or Creator work.**
Builds on the step-1 schema/domain foundation.

### What changed

- **Transaction-aware repositories (DEC-0044).** The `UnitOfWork`/`TransactionContext`/
  `UNIT_OF_WORK` boundary **moved to `@khatmsaz/kernel`** so domain repository ports
  can declare a `tx?: TransactionContext` parameter without importing infrastructure
  (`database.tokens.ts` re-exports them). An infra `dbClient(prisma, tx?)` helper
  routes each write to the transaction client or the base client; the one `txClient`
  cast stays in infrastructure. Repository methods that participate in a
  multi-write flow gained an optional `tx`, plus new methods: phone-claim `revoke`,
  `revokeAllActiveByUser`, `reassignOwner`, `findVerifiedByUser`, `findVerifiedOwnerId`;
  user `tombstone`; platform-identity `reassignOwner`; account-merge `append(tx)`.
- **Change phone via OTP (DEC-0046).** `verifyPhone` now: detects a cross-account
  conflict (number verified by another user → `MERGE_REQUIRED`, no consume); and,
  when the user already has a different verified number, **revokes the old and
  promotes the new atomically in one transaction** — maintaining one verified phone
  per user. `VERIFIED` carries `replacedE164` when it replaced a number.
- **Account-merge use-case** — new capability `apps/api/src/account-merge/` (an
  application-only ORCHESTRATION module importing IdentityModule + PhoneModule,
  which now export their repository ports). `AccountMergeService.mergeAccounts`
  runs entirely inside `UnitOfWork`: reassigns the loser's platform identities to
  the winner; revokes the loser's active phone claims then reassigns all of them to
  the winner as retained history; **tombstones** the loser (status MERGED,
  `mergedIntoId` = winner, guarded on ACTIVE for concurrency); appends the immutable
  audit record. Everything is an UPDATE — **never a delete** — so history is kept and
  FK RESTRICT (DEC-0045) is respected. The winner (existing verified owner) stays
  canonical (DEC-0042/0046).

### Key behaviours / invariants

- Merge **moves data, never deletes**; loser retained as a tombstone; one audit row
  per merge (append-only).
- One verified phone per user holds through change-phone and merge (a losing second
  verified number is revoked to history).
- All merge/change-phone writes are **atomic** (proven: a merge with a non-existent
  winner rolls back and changes nothing).
- Two concurrent merges of the same loser: the ACTIVE-guarded tombstone lets exactly
  one win.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (123 unit) / build** PASS; **e2e** 1/1;
  **integration** 41/41 (+5: change-phone; merge resolves MERGE_REQUIRED; loser's own
  verified number revoked; already-merged rejected; rollback-on-bad-winner). Live
  `/health` + `/health/ready` 200 with `AccountMergeModule` wired; DB cleaned to 0.

### Not done (later)

- No HTTP/bot transport that *calls* merge or change-phone (detection returns
  `MERGE_REQUIRED`; resolving it is invoked by tests/future flows). No auth/session/
  Creator. No cross-product anything (DEC-0047).

### Notes / gotchas

- `UnitOfWork`/`TransactionContext`/`UNIT_OF_WORK` now import from `@khatmsaz/kernel`
  (was `database.tokens`); `database.tokens.ts` re-exports for infra consumers.
- Fakes for repository ports must implement the (now larger) interfaces; a fake with
  fewer params than a `tx?`-bearing method still satisfies the interface.

### Next planned phase

Phase 4 — Khatm engine (template-driven), or a transport phase (Telegram adapter)
that would *drive* verify/merge. Not started.

---

## Current state — 2026-09-06 (Phase 3B step 1 — schema + domain foundation)

### Current phase

Phase 3B, **step 1 of N: the database/domain foundation only.** The **merge
use-case is deliberately NOT implemented** — no code moves data, tombstones an
account, or writes an audit row as part of a flow. This step lays the reviewed
schema and the domain/persistence models the merge engine will later use.

### What changed

- **Third reviewed migration** `20260906120252_account_merge_foundation` (created
  via `db:plan` create-only, one **hand-written partial unique index** appended,
  SQL reviewed — all CREATE/ALTER ADD, the only DROPs are two FK constraints
  immediately re-added with RESTRICT; no data loss — applied via `db:migrate`,
  verified in real PostgreSQL):
  - `users`: **`status`** (`user_status` enum `ACTIVE`/`MERGED`, default `ACTIVE`,
    DEC-0040) + **`merged_into_id`** self-FK tombstone pointer (DEC-0041).
  - **`account_merges`** append-only audit table (DEC-0043): winner/loser (FK
    RESTRICT), `verified_e164`, `initiating_challenge_id` (plain id, no FK — survives
    OTP pruning), moved counts, context, `created_at`; **no `updated_at`**.
  - **`phone_claims_verified_user_key`** — partial unique `(user_id) WHERE
    status='VERIFIED'`: **one verified phone per user** (DEC-0046).
  - **FK on-delete (DEC-0045):** `platform_identities`, `phone_claims`,
    `users.merged_into`, `account_merges` → **RESTRICT**; `otp_challenges` stays
    **CASCADE**. Verified in `pg_constraint`.
- **Domain foundation (identity capability):** `UserStatus` enum; `User` now carries
  `status` + `mergedIntoId` with lifecycle invariants (MERGED ⇒ has a UUIDv7
  pointer; ACTIVE ⇒ none); new `AccountMerge` audit entity (winner≠loser, non-empty
  e164, non-negative counts) + `AccountMergeRepository` port (append/findById only —
  append-only). Two new domain errors (`UnknownUserStatusError`, `InvalidUserError`,
  `InvalidAccountMergeError`). `AccountMerge` stores the phone as a plain string —
  identity stays **decoupled from the phone capability**.
- **Infrastructure:** mapper maps the new User fields + `AccountMerge`;
  `PrismaAccountMergeRepository` (append/findById); identity module binds
  `ACCOUNT_MERGE_REPOSITORY`. `PrismaUserRepository` unchanged (mapper carries the
  new fields; `create` still yields an ACTIVE user via the DB default).

### Not done (still deferred — later Phase 3B steps)

- The **merge use-case** itself (winner=existing owner, move platform identities +
  phone claims, resolve a losing second verified number, tombstone the loser, write
  the audit record, all inside the DEC-0044 transaction) — **not built.**
- Making repositories **transaction-aware** (routing writes through `txClient`).
- The **"change phone via OTP"** flow (verify-when-already-verified → revoke old,
  promote new) that DEC-0046's per-user index now requires.
- No authentication, sessions, or Creator capability.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (116 unit) / build** PASS; **e2e** 1/1;
  **integration** 36/36 (+10 foundation: lifecycle round-trip, tombstone + self-FK
  reject, one-verified-per-user reject, FK RESTRICT on platform/phone, OTP CASCADE,
  audit append/read, audit FK reject). Migration applied, `db:status` up to date,
  `psql` confirmed columns/enum/FKs/partial index; DB cleaned to 0 rows.
- Existing identity/phone integration cleanups updated for the RESTRICT FKs (delete
  children before users).

### Notes / gotchas

- **RESTRICT changes delete order:** a user with a platform identity or phone claim
  can no longer be deleted directly — remove children first (tests updated).
  `otp_challenges` still cascade.
- `User.status`/`mergedIntoId` are **optional in `UserProps`** (default ACTIVE/null)
  so existing `User.restore` callers/fakes are unchanged; the mapper always passes
  explicit values from the row.

### Next planned phase

Phase 3B **step 2:** transaction-aware repositories + the merge use-case + the
change-phone flow, on the foundation above. Not started.

---

## Current state — 2026-09-06 (Phase 3B product decisions confirmed — still not started)

### What changed

The product owner answered DEC-0042's open questions; recorded as **DEC-0046**
(decisions only — **no code, no schema change**):

1. **Canonical account:** the pre-existing verified owner stays canonical; the
   newly-verifying conflicting account merges into it.
2. **One verified phone per user:** a user may hold **at most one `VERIFIED` phone
   claim** across all numbers (stricter than DEC-0034's per-number rule).
3. **Irreversible merges:** no unmerge; an append-only audit record is required.

**Consequence to carry into 3B (flagged, not invented):** rule (2) is a phone-model
invariant **not yet enforced** — today's schema/code would let one user verify two
numbers. It needs a DB partial unique index `UNIQUE(user_id) WHERE status='VERIFIED'`
plus a "change phone via OTP" flow (verify-when-already-verified → revoke old,
promote new), and the merge must resolve the case where the loser holds a *different*
verified number. These land in the Phase 3B migration/flow.

**Phase 3B is unblocked on product input but has NOT started** — awaiting explicit
go-ahead. No merge/auth/session code exists.

---

## Current state — 2026-09-06 (Phase 3B preparation — architectural prerequisites)

### Current phase

Phase 3B **preparation only** — the architectural prerequisites identified by the
pre-3B architecture review. **No merge functionality, no authentication, no
sessions were built.** Phase 3B (the account-merge engine) has **not** started;
it is gated on the product decisions flagged below.

### What changed

- **Decisions DEC-0039…DEC-0045.** Two are implemented now (shared kernel,
  transaction seam); five record 3B **design intent** whose schema/flows are
  deferred to 3B (user lifecycle, tombstone/alias, merge policy, merge audit, FK
  strategy). Genuine product rules (merge winner selection, extra user states,
  reversibility) are **flagged as needing product-owner sign-off**, not invented.
- **Shared kernel `@khatmsaz/kernel` (new package)** — extracted the canonical
  UUIDv7 primitives (`newUuidV7`, `isUuidV7`, `assertUuidV7`, `InvalidUuidV7Error`)
  out of `identity/domain`. This **removes the capability-to-capability coupling**
  the review flagged (M1): `phone/domain` + `phone/application` now import the
  kernel and no longer import `identity`. `identity` re-exports the kernel under
  stable names (`newIdentityId`, `InvalidIdentityIdError`), so its tests are
  unchanged. `uuid@14.0.2` moved from `apps/api` into the kernel.
- **Transaction boundary (DEC-0044)** — a Prisma-free **`UnitOfWork` port**
  (`UNIT_OF_WORK`, opaque `TransactionContext`) exported by the global
  `DatabaseModule`, with a `PrismaUnitOfWork` implementation over Prisma
  interactive transactions and an infra-only `txClient()` unwrap helper. Wired and
  tested (commit / rollback / multi-write atomic) against real PostgreSQL. **No
  merge or other use-case logic** — just the seam 3B will run inside.
- **FK cascade review (DEC-0045)** — proposed `ON DELETE RESTRICT` for
  `platform_identities` and `phone_claims`, keep `CASCADE` for `otp_challenges`;
  the migration is deferred to 3B (so RESTRICT has the audited termination path to
  route through). **No schema change in this task.**

### Key invariants / boundaries reinforced

- **Capabilities never import each other's domain.** Shared domain primitives live
  in `@khatmsaz/kernel`; `apps/* → packages/*` direction preserved.
- **Transactions stay Prisma-free at the boundary.** Application code will
  orchestrate atomic multi-repo work through `UnitOfWork`, never importing Prisma
  (DEC-0031 upheld).
- **No merge yet.** `MERGE_REQUIRED` (DEC-0037) is still only *detected*; the engine
  is 3B and blocked on the flagged product decisions.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (106 unit) / build** PASS; **e2e** 1/1;
  **integration** 26/26 (5 database + 8 identity + 10 phone + **3 transaction**).
- No `.env` touched; no secrets; no schema/migration change (pure prerequisite
  refactor + new package + transaction seam).

### Notes / gotchas

- New workspace package requires `npm install` (link) + `build:packages` before
  app typecheck/test; the kernel is built first in `build:packages`.
- ts-jest emits benign "Unable to process …/dist/index.js, falling back to original
  content" warnings for CJS workspace packages (kernel/config/shared) — pre-existing
  pattern, tests pass.

### Next planned phase

Phase 3B — account-merge engine, **gated on the DEC-0042 product decisions** (winner
selection, multiple-verified-phones, reversibility) being signed off. It will add
the `users.status`/`merged_into` columns, the merge audit table, the FK change
(DEC-0045), transaction-aware repositories, and the merge use-case. Not started.

---

## Current state — 2026-09-06 (Phase 3A — phone claims & OTP verification foundation)

### Current phase

Phase 3A — Phone-claim and OTP-verification foundation. **Complete and validated.**
Establishes how a phone number is claimed, verified by OTP, and made a unique
proven claim — deliberately narrow. It does **not** add Creator capability, any
login/session flow, participant/registration UI, bot handlers, a real SMS
provider, or account merging (a verified-ownership conflict is only *detected* and
handed off).

### What changed

- **Decisions DEC-0033…DEC-0038:** phone stored as canonical **E.164** in a
  separate **`PhoneClaim`** model (not `User.phone`), normalised by
  **`libphonenumber-js`** behind a domain port; claimed-vs-verified modelled as a
  `PhoneClaimStatus` lifecycle enum with the two hard invariants enforced by
  **partial unique indexes** in the DB; OTP codes protected by a **server-secret
  keyed HMAC** (never plaintext/logged/returned); OTP **delivery behind an adapter**
  with no real SMS; verified-ownership conflict → explicit **`MERGE_REQUIRED`**
  outcome (merge engine deferred to 3B); **Redis/distributed rate limiting
  deferred**, per-target cooldown enforced in the DB.
- **Second reviewed migration:** `20260906070332_phone_verification_foundation` —
  created via `db:plan` (create-only), the two **partial unique indexes appended by
  hand** (Prisma cannot express them), SQL reviewed (all CREATE, no data loss),
  applied via `db:migrate`, verified in real PostgreSQL (both partial indexes with
  their WHERE predicates confirmed). Tables `phone_claims` + `otp_challenges`, enums
  `phone_claim_status` + `otp_purpose`.
- **Phone capability** (`apps/api/src/phone/`, second domain module, same
  domain/application/infrastructure shape as identity):
  - `domain/` (Prisma- and vendor-free): `PhoneNumber` (E.164), `PhoneClaim` +
    `PhoneClaimStatus`, `OtpChallenge` + `OtpPurpose`, errors, the
    verification-outcome union, and **ports** — `PhoneNormalizer`, `OtpCodeGenerator`,
    `OtpCodeHasher`, `OtpDelivery`, `Clock`, and the two repositories (+ DI tokens).
  - `application/phone-verification.service.ts`: `claimPhone`,
    `requestPhoneVerification`, `verifyPhone` (Prisma-free).
  - `infrastructure/`: Prisma repositories + mapper, `libphonenumber-js` normalizer,
    CSPRNG code generator, HMAC hasher, **no-op** delivery adapter, system clock,
    Prisma-error translation. The only place Prisma / the phone library live.
  - `phone.module.ts` binds ports → implementations (normalizer & hasher via
    `useFactory` because they take a config string, not a provider); imported in
    AppModule. No HTTP controller and no bot surface yet.
- **Config** (`@khatmsaz/config`): `otpHmacSecret()` (fail-fast in prod, dev
  placeholder), `otpPolicyConfig()` (code length / TTL / max attempts / cooldown),
  `phoneDefaultRegion()`. `.env.example` documents them (blank secret).

### Key invariants enforced

- **Unverified ≠ identity.** An UNVERIFIED claim is contact data only, is **not**
  globally unique (different users may claim the same number), and never proves
  ownership.
- **One active verified owner per number, globally** — a partial unique index, not
  a pre-check. Concurrent verification of the same number by two users resolves to
  exactly one VERIFIED; the loser gets `MERGE_REQUIRED` (proven against real
  PostgreSQL).
- **One active (non-revoked) claim per (user, number)** — a second partial unique
  index; revoked history is retained.
- **OTP:** CSPRNG-generated, single-use, short TTL, bounded attempts, superseded on
  resend; stored only as a keyed HMAC bound to (e164, purpose); never logged,
  returned, or included in an error.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (106 unit) / build** PASS; **e2e** 1/1;
  **integration** 23/23 (5 database + 8 identity + **10 phone**, incl. duplicate
  unverified claims allowed, one verified owner, **concurrent verify → one wins**,
  history preserved, HMAC-only storage, migration recorded).
- Migration applied; `db:status` → up to date; `psql` confirmed both partial unique
  indexes with predicates, tables, enums.
- Live regression: `/health` 200 and `/health/ready` 200 with PhoneModule wired;
  boot log shows DB connected and app started, **no secret** (pepper/URL) in logs.
- `npm audit`: unchanged (4 high, all via the `prisma` CLI devDep — KI-0010);
  `libphonenumber-js@1.13.12` added **0** advisories.

### Notes / gotchas

- Classes with a **plain-string constructor arg** (`LibphonenumberPhoneNormalizer`,
  `HmacOtpCodeHasher`) must be provided via `useFactory`, not `useClass` — Nest
  otherwise tries to inject a `String` and fails at boot.
- The two partial unique indexes are **not** in `schema.prisma`; keep them in the
  migration and strip any auto-generated DROP on future `migrate dev` diffs (KI-0012).

### Next planned phase

Phase 3B — account-merge workflow: resolve a `MERGE_REQUIRED` verified-ownership
conflict (canonical account selection, platform-identity/data movement, audit
trail). Not started. Creator capability and login/session remain later phases.

---

## Current state — 2026-09-06 (Phase 2B — identity foundation)

### Current phase

Phase 2B — Identity foundation. **Complete and validated.** First real domain
model and first reviewed migration. Deliberately narrow: **no** OTP, phone
verification, registration UX, bot handlers, creator capability, profile, Khatm,
payments, wallet, or admin roles.

### What changed

- **Decision DEC-0032:** canonical identity is an internal, immutable **UUIDv7**
  (generated in app code, stored as native PG `uuid`); **PlatformIdentity** is an
  external claim/link only; **usernames are not identity**; **phone verification
  deferred**. UUIDv7 via `uuid@14.0.2` (pinned, current stable, not prerelease).
- **First migration:** `20260906062900_identity_foundation` — created via
  `db:plan` (create-only), SQL reviewed (all CREATE, no data loss), applied via
  `db:migrate`, verified. Tables `users` + `platform_identities`, enum `platform`.
- **Identity capability** (`apps/api/src/identity/`, first domain module):
  - `domain/` (Prisma-free): `User`, `PlatformIdentity`, `Platform`, UUIDv7
    id helpers, domain errors, and repository **ports** (`UserRepository`,
    `PlatformIdentityRepository`) + DI tokens.
  - `application/`: `IdentityService` — `createUser`, `findUserById`,
    `findUserByPlatformIdentity`, `attachPlatformIdentity` (Prisma-free).
  - `infrastructure/`: Prisma-backed repositories + mapper (the only Prisma here);
    translate Prisma `P2002`/`P2003` into domain errors.
  - `identity.module.ts` binds ports → Prisma impls; imported in AppModule. No
    HTTP controller (no registration/bot surface yet).
- **Schema:** `users` (id/created_at/updated_at only) and `platform_identities`
  (unique `(platform, subject)`, `user_id` index, FK cascade).

### Key invariants enforced

- Canonical `User.id` is a UUIDv7 (validated on every domain reconstitution).
- One external `(platform, subject)` belongs to at most one User — a **database
  unique constraint**, not a pre-check; concurrent attaches fail with a domain
  error. Same subject may exist on different platforms.
- Attaching to a missing user fails (FK → `UserNotFoundError`). Blank/whitespace
  subject rejected; subject trimmed. A username is never used as the subject.

### Verification (all run this phase)

- Gate green: **typecheck / lint / test (43 unit) / build** PASS; **e2e** 1/1;
  **integration** 13/13 (5 database + 8 identity: migration recorded, native
  uuid, round-trip, attach+lookup, same-subject-different-platform, uniqueness,
  **concurrent attach → one wins**, FK rejection).
- Migration applied; `db:status` → "Database schema is up to date"; `db:verify`
  OK; `psql` confirmed tables/constraints/indexes and `id` is native `uuid`.
- Live regression: `/health` 200 and `/health/ready` 200 with IdentityModule
  wired; boot log shows both modules and DB connected, **no secret** in logs.
- `npm audit`: unchanged (4 high, all via the `prisma` CLI devDep — KI-0010);
  `uuid@14.0.2` added **0** vulnerabilities.

### Notes / gotchas

- `uuid@14` is **ESM-only**; Node 24 runs it via `require(esm)` at runtime, and
  Jest transforms it (ts-jest `allowJs` + `transformIgnorePatterns:
  ["/node_modules/(?!uuid/)"]`). Do not "downgrade" for CJS.

### Next planned phase

Phase 3 — Creator identity & phone verification (OTP), building on the User model:
verified-phone state (DEC-0012), creator capability, OTP delivery behind an
adapter. Not started.

---

## Current state — 2026-09-05 (Phase 2A — persistence foundation)

### Current phase

Phase 2A — Persistence foundation. **Complete and validated.** First
production-code persistence phase: local infrastructure verified running,
PostgreSQL + Prisma wired into the API's infrastructure layer, connectivity
proven, migration workflow established, readiness endpoint added. **No product
feature and no domain table** was implemented. Phase 2B has not started.

### What changed

- **Decision DEC-0031:** PostgreSQL + **Prisma** as the persistence stack, Prisma
  confined to `apps/api/src/infrastructure/database`. Prisma pinned **exactly** to
  `7.10.0` (`@prisma/client`, `prisma`, `@prisma/adapter-pg`; `pg@8.23.0`).
  "Prisma 8" was the stated intent, but there is **no stable Prisma 8** yet (npm
  `latest` = `8.0.0-rc.13`, an RC; RCs are forbidden), so the current stable
  Prisma line is used and Prisma 8 will be adopted at GA — chosen by the user.
- **Infrastructure database layer** (`src/infrastructure/database/`): a single
  app-lifetime `PrismaService` (driver adapter `@prisma/adapter-pg`, connect on
  init / disconnect on shutdown, tolerant of a down DB at startup); a
  `DatabaseReadinessService` and a Prisma-free `DATABASE_PING` probe so nothing
  outside infrastructure sees Prisma types; a `@Global` `DatabaseModule`.
- **Config layer** (`@khatmsaz/config`): `databaseUrl()` / `resolveDatabaseUrl()`
  / `assertValidDatabaseUrl()` — validated, fail-fast, secret-free. `DATABASE_URL`
  is canonical; when unset it is derived from the `POSTGRES_*` values.
- **Readiness endpoint** `GET /health/ready` (contract `ReadinessResponse`): real
  `SELECT 1`, 2s timeout, HTTP 200 up / 503 down, no config leak. `GET /health`
  liveness is unchanged and never depends on the DB.
- **Prisma layout:** `apps/api/prisma.config.ts`, `prisma/schema.prisma`
  (datasource + generator only, **no models**), `prisma/migrations/` (empty),
  `prisma/scripts/verify-connection.ts`. Generated client is git-ignored and
  regenerated via `db:generate` (wired into `pretypecheck`/`prebuild`).
- **Migration scripts** (root, delegating to API): `db:generate`, `db:plan`,
  `db:migrate`, `db:migrate:dev`, `db:status`, `db:verify`, `db:push`.
- **Integration tests** (`test:integration:db`, Docker-gated, separate from unit).

### Verification (all run this phase)

- Infra up via Docker, all three healthy; **real** checks: PostgreSQL
  `pg_isready` + `SELECT 1` (PostgreSQL 17.11), Redis `PING` → PONG, MinIO
  live+console HTTP 200. Ports all `127.0.0.1`, named volumes only.
- `db:verify` → `SELECT 1` OK. `db:status` connects and reports the empty graph.
- Gate green: **typecheck / lint / test (21 unit) / build** all PASS; **e2e**
  1/1 PASS; **integration** 5/5 PASS (real SELECT 1; ready; real unreachable →
  not_ready at the 2s timeout; no-credential-leak).
- Live runtime: `GET /health` → 200 (unchanged); `GET /health/ready` → 200
  `{database:"up"}`; startup log shows "Database connection established" and
  contains **no** password/URL.
- `npm audit`: 4 high, all via the **`prisma` CLI devDependency** transitive tree
  (`mysql2` — a MySQL driver we never load — and `deepmerge-ts` in
  `@prisma/config`). Not reachable in the PostgreSQL runtime. Documented as
  KI-0010; not "fixed" because the only offered fix downgrades Prisma to 6.

### Blockers

None for Phase 2A. Environment notes: the Docker **daemon** carries a dead proxy
(`127.0.0.1:12334`, unreachable from its VM) so `docker pull` fails; images were
sideloaded with `crane` over the working WSL proxy, then `docker load` (KI-0011).
`DOCKER_INSECURE_NO_IPTABLES_RAW` is set on the local daemon — a **development-only**
concern, never acceptable for production (KI-0011).

### Commands known to work (added this phase)

```
npm run infra:up          # bring up postgres/redis/minio (reads repo-root .env)
npm run db:verify         # real SELECT 1 against local PostgreSQL
npm run db:status         # migration graph status
npm run test:integration:db   # DB integration suite (requires local PostgreSQL)
```

Registry/network access in this shell goes through the WSL proxy
`http://127.0.0.1:12334` (e.g. `HTTPS_PROXY=… npm view …`); local HTTP still needs
`curl --noproxy '*'`.

### Next planned phase

Phase 2B / Phase 3 — first real domain model (internal user identity and platform
identity), arriving with the first reviewed Prisma migration and repository
interfaces owned by the domain.

---

## Current state — 2026-09-05 (Phase 1.2 — Claude toolkit installed)

### Current phase

Phase 1.2 — Claude project kit and capability setup. **Complete.** No product
feature was implemented; this phase added the developer/AI capability system only.
Phase 2 has not started.

### What changed

- Added a portable, curated Claude Code toolkit at `tooling/claude-project-kit/`
  (one copyable folder): marketplace/plugin manifests, install/verify/update/
  uninstall scripts, profiles, an audited plugin set, and this repo's own plugin
  (`project-kit`) with 9 workflow skills, 3 review subagents, and 2 safety hooks.
- Enabled a lean first-party plugin set at **project scope** (in
  `.claude/settings.json`): `typescript-lsp`, `security-guidance`,
  `frontend-design`, `commit-commands`, `skill-creator`, `feature-dev`, plus the
  local `project-kit`. Always-on context ≈ 1,300 tok.
- Installed the TypeScript language server user-level (no sudo): npm prefix set
  to `~/.local`; `typescript-language-server` 6.0.0 on PATH; global `typescript`
  pinned to 5.9.3.
- Registered the official marketplace `anthropics/claude-plugins-official` and a
  local marketplace `claude-project-kit`.
- Wired a KhatmSaz-specific PreToolUse hook that blocks mutating the
  `/mnt/z/KhatmSaz` backup.
- Full details in `docs/ai/CLAUDE_TOOLKIT.md`.

### Verification (all done this phase)

- `claude plugin validate` passes for the kit plugin and marketplace.
- `claude plugin details` confirms component inventory + token cost for every
  active plugin (discoverable, load without error).
- Kit `verify.sh` — ALL CHECKS PASSED (marketplaces, enabled plugins, plugin
  validate, hook self-tests, LSP on PATH, script syntax).
- Safety hooks unit-tested (block `.env`/keys and catastrophic commands; allow
  normal source/commands; allow reading but not mutating the backup).
- Regression gate re-run green: typecheck, lint, test, build — all PASS. **No
  application source was changed** (only `tooling/`, `.claude/settings.json`,
  `docs/ai/`).

### Blockers

None for Phase 1.2. Operational notes: Git identity is repo-local only; Docker
WSL integration is still off (Phase 2 concern); the kit's local marketplace uses
a machine-specific path (re-registered by `install.sh` per checkout — KI-0008).

### Next planned phase

Phase 2 — persistence foundation (enable Docker WSL integration, bring up local
infra, choose ORM/migration tooling as a recorded decision, add a real
PostgreSQL connection and the first domain module with tests).

### Note

Installing the newly evaluated Claude skills/plugins beyond this curated set is
deferred; new plugins activate only on the next Claude Code session.

---

## Current state — 2026-09-04 (Phase 1.1 — validated and closed)

### Current phase

Phase 1 — Bootstrap and project foundation. **VALIDATED AND COMPLETE.** The full
gate (install, typecheck, lint, test, build) passed on the developer machine and
all three applications were run and smoke-tested. Phase 2 has not started.

### Authoritative location

- **Working copy (authoritative):** `/home/elyas/KhatmSaz` (WSL-native, ext4).
- **Old copy (non-authoritative backup):** `/mnt/z/KhatmSaz` (Windows-mounted).
  Do not edit it; it is a stale backup only.

### Verified development environment

- OS: Ubuntu 24.04 on WSL2 (Linux 6.6.87.2-microsoft-standard-WSL2)
- Node: v24.20.0 (`/usr/bin/node`) · npm: 11.19.0 · Git: 2.43.0
- Docker: Docker Desktop CLI resolves on PATH, but **WSL integration is not
  activated for this distro**, so no daemon is reachable and `docker compose`
  cannot run here. Compose file was validated structurally instead (below).
- Ports 3000, 3001, 3002, 5432, 6379, 9000, 9001 were all free before testing.

### Validation gate — all PASS (2026-09-04)

- `npm install` — PASS. 670 packages, **0 vulnerabilities**. `package-lock.json`
  written (first authoritative lockfile). All caret ranges resolved without any
  version change: `next@16.3.4`, `react@19.2.8`, `@nestjs/core@11.2.3`,
  `typescript@5.9.3`, `typescript-eslint@8.69.0`, `eslint@9.39.5`, `jest@29.x`.
- `npm run typecheck` — PASS (all 7 workspaces).
- `npm run lint` — PASS (after adding the four missing package ESLint configs and
  resolving the NestJS DI vs `consistent-type-imports` conflict — see CHANGELOG).
- `npm test` — PASS (API unit 2/2). `test:e2e` — PASS (1/1).
- `npm run build` — PASS (api via `nest build`; web + admin via `next build`).
- Docker Compose — structurally validated (YAML parses; three services; all
  data in named volumes `postgres-data`/`redis-data`/`minio-data`, **zero** bind
  mounts into the project; **all** ports bound to `127.0.0.1`). Daemon run NOT
  performed (WSL integration off).

### Runtime smoke test — all PASS

- API: starts clean; `GET http://127.0.0.1:3001/health` → HTTP 200,
  `{status:"ok",service:"khatmsaz-api",version:"0.1.0",timestamp,uptimeSeconds}`,
  no config/env leak. (curl must bypass the WSL HTTP proxy: `curl --noproxy '*'`.)
- Web: HTTP 200, `<html lang="fa" dir="rtl">`, Persian content.
- Admin: HTTP 200, `<html lang="fa" dir="rtl">`, Persian content,
  `<meta name="robots" content="noindex, nofollow">`.
- All dev/prod processes were stopped afterwards; ports released.

### Commands known to work (verified on this machine)

```
npm install
npm run typecheck
npm run lint
npm test
npm run test:e2e -w @khatmsaz/api
npm run build
node apps/api/dist/main.js        # API on 127.0.0.1:3001
npm run start -w @khatmsaz/web    # Web on 3000
npm run start -w @khatmsaz/admin  # Admin on 3002
curl --noproxy '*' http://127.0.0.1:3001/health
```

Note: this shell has `http_proxy`/`https_proxy` set to `127.0.0.1:12334`; local
HTTP requests must pass `--noproxy '*'` or they return 502.

### Git

Repository initialised (`git init -b main`), full tree staged (`git add -A`) and
committed. `.env` is **not** tracked; `node_modules`, build output and runtime
data are all ignored. Repo-local identity `Amirali Raeesi
<raeesiamirali86@gmail.com>` (local scope only, not global). Initial commit:
`38bbee8 chore: bootstrap khatmsaz workspace`. Working tree clean.

### Blockers

Phase 1 is complete, validated and committed. One operational item remains for
Phase 2 (not a code defect): **Docker daemon is unavailable** in this distro
(WSL integration off) — enable Docker Desktop WSL integration before Phase 2
persistence work that needs live Postgres/Redis/MinIO.

### Next planned phase

Phase 2 — persistence foundation: enable Docker WSL integration, bring up local
infra, choose ORM/migration tooling (record as a decision), add a real
PostgreSQL connection and the first domain module with tests.

### Important recent changes

Phase 1.1: moved to WSL-native authoritative path; first real dependency install
and full validation gate; added four missing package ESLint flat configs; fixed
the NestJS DI / type-import lint conflict; removed a benign ts-jest `.js`
transform warning; Git initialised and the bootstrap tree committed (`38bbee8`).
See CHANGELOG.

---

## History

_(No earlier state — this is the first entry.)_
