# Candidates — evaluated, not installed

Tooling considered during Phase 1.2 research and deliberately **not** activated,
with the reason. Discovery used the official Claude Code docs and the
`anthropics/claude-plugins-official` marketplace (inspected directly), plus web
search for discovery only.

## Recorded as optional (trusted, available on demand)

These are safe and useful but not enabled by default to control context cost or
because they suit a specific task, not every session. Enable via the matching
profile in `profiles/`.

- **pr-review-toolkit** (Anthropic) — 6 PR-review agents. ~1,600 always-on
  tokens; overlaps the built-in `/code-review`. Enable for review-heavy work.
- **plugin-dev** (Anthropic) — full plugin-authoring toolkit (8 skills, 3
  agents). ~1,700 always-on tokens; overlaps `skill-creator`. Enable when
  actively developing plugins.
- **context7** (Upstash, listed in official marketplace) — up-to-date library
  docs via a **hosted remote MCP**. Genuinely useful, but sends queries to
  `mcp.context7.com` — **network egress**. Opt-in per project/privacy posture.
- **playwright** (Microsoft, official marketplace) — browser automation / E2E
  MCP. Heavy (launches a browser). Enable in Phase 2+ when E2E work begins.
- **claude-security** (Anthropic) — deep, effort-tiered vulnerability scanning
  with challenged findings. Strong on-demand complement to `security-guidance`.
- **claude-md-management** (Anthropic) — CLAUDE.md audit/maintenance. Overlaps
  this kit's memory skills; enable if you prefer its automation.
- **hookify** (Anthropic) — author hooks from Markdown rules. Useful for ad-hoc
  guards; this kit ships its safety hooks directly instead.
- **serena / greptile** (third-party, official marketplace) — semantic code
  search MCPs. Capable, but external MCP servers; evaluate trust/network per
  project before enabling.

## Not installed — reason

- **Community 3D / animation plugins (Three.js, R3F, WebGL, GSAP)** — no
  first-party plugin exists, and no community plugin met the trust bar
  (inspectable source, maintained, no `curl | bash`, no unexplained network or
  secret access). `profiles/design-3d/` uses audited **libraries** + guidance
  instead. Also intentionally off for KhatmSaz (simplicity/accessibility goal).
- **Language-server plugins for other languages** (pyright, gopls, rust-analyzer,
  etc.) — not relevant to a TypeScript/Node project.
- **Messaging/integration MCPs** (telegram, github, gitlab, linear, asana, …) —
  out of scope for Phase 1.2 (developer capability, not product integrations).
  Telegram is a Phase 5 product concern and belongs behind the domain's adapter,
  not a Claude plugin.
- **Any plugin recommended only by a blog/social post** with no inspectable,
  maintained source — recorded here, not installed.
