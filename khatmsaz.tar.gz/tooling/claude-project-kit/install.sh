#!/usr/bin/env bash
#
# claude-project-kit installer.
#
# Installs a curated, low-overhead Claude Code setup into the CURRENT project:
#   - registers the official first-party marketplace and this kit's local one
#   - enables a lean set of first-party plugins at PROJECT scope
#   - enables this kit's own plugin (skills + review agents + safety hooks)
#
# Safe to re-run. Nothing here downloads or executes untrusted code; it only
# calls the `claude` CLI and (optionally) installs the TypeScript language
# server via npm. Run from your project root:  ./tooling/claude-project-kit/install.sh
#
set -euo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OFFICIAL_MARKETPLACE="anthropics/claude-plugins-official"

# Curated ACTIVE plugins (see manifest.json for the reasoning and token cost).
OFFICIAL_PLUGINS=(
  typescript-lsp
  security-guidance
  frontend-design
  commit-commands
  skill-creator
  feature-dev
)

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33m!! %s\033[0m\n' "$*" >&2; }

command -v claude >/dev/null 2>&1 || { warn "The 'claude' CLI was not found on PATH. Install Claude Code first."; exit 1; }

say "Registering the official first-party marketplace"
claude plugin marketplace add "$OFFICIAL_MARKETPLACE" 2>&1 | tail -1 || warn "marketplace add reported an issue (already added is fine)"

say "Registering this kit's local marketplace at project scope"
claude plugin marketplace add "$KIT_DIR" --scope project 2>&1 | tail -1 || warn "local marketplace add reported an issue (already added is fine)"

say "Enabling curated first-party plugins (project scope)"
for p in "${OFFICIAL_PLUGINS[@]}"; do
  echo "  - $p"
  claude plugin install "${p}@claude-plugins-official" --scope project 2>&1 | tail -1 || warn "could not enable $p"
done

say "Enabling this kit's plugin (project scope)"
claude plugin install "project-kit@claude-project-kit" --scope project 2>&1 | tail -1 || warn "could not enable project-kit"

say "Checking the TypeScript language server (needed by typescript-lsp)"
if command -v typescript-language-server >/dev/null 2>&1; then
  echo "  found: $(typescript-language-server --version 2>&1 | head -1)"
else
  warn "typescript-language-server is not on PATH. To enable TypeScript code intelligence, install it without sudo:"
  warn "    npm config set prefix ~/.local && npm install -g typescript-language-server typescript@5"
  warn "  (ensure ~/.local/bin is on PATH)"
fi

say "Done. RESTART your Claude Code session to load the newly enabled plugins."
echo "Optional profiles (pr-review-toolkit, playwright, context7, design-3d, ...) are documented in $KIT_DIR/profiles/."
