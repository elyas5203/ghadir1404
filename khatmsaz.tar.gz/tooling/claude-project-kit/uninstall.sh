#!/usr/bin/env bash
#
# claude-project-kit uninstaller. Removes the kit's plugins from the CURRENT
# project (project scope). Does not touch other projects. The official
# marketplace registration (shared, user-level) is left in place unless you pass
# --remove-official. Run from the project root.
#
set -uo pipefail

REMOVE_OFFICIAL=0
[ "${1:-}" = "--remove-official" ] && REMOVE_OFFICIAL=1

ALL_PLUGINS=( typescript-lsp security-guidance frontend-design commit-commands skill-creator feature-dev pr-review-toolkit plugin-dev )

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }

command -v claude >/dev/null 2>&1 || { echo "claude CLI not found" >&2; exit 1; }

say "Removing this kit's plugin"
claude plugin uninstall "project-kit@claude-project-kit" 2>&1 | tail -1 || true

say "Removing curated first-party plugins from this project"
for p in "${ALL_PLUGINS[@]}"; do
  echo "  - $p"
  claude plugin uninstall "${p}@claude-plugins-official" 2>&1 | tail -1 || true
done

say "Removing the kit's local marketplace"
claude plugin marketplace remove claude-project-kit 2>&1 | tail -1 || true

if [ "$REMOVE_OFFICIAL" = 1 ]; then
  say "Removing the official marketplace (shared, user-level)"
  claude plugin marketplace remove claude-plugins-official 2>&1 | tail -1 || true
else
  say "Left the official marketplace registered (use --remove-official to drop it)."
fi

say "Done. You may also delete .claude/settings.json entries and this tooling/ folder. RESTART Claude Code to apply."
